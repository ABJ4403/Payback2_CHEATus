--[[ Inject the code below to your decompiled script, and run it in Lua Interpreter ]]
table.tostring=function(t)
	if type(t) == 'table' then
		local r = '{'
		for k,v in pairs(t) do
			if type(k) == 'string' then
				r = r..'["'..k..'"]='
			end
			if type(v) == 'table' then
				r = r..table.tostring(v)
			elseif type(v) == 'boolean' then
				r = r..tostring(v)
			else
				r = r..'"'..v..'"'
			end
			r = r..','
		end
		if r ~= '' then
				r = r:sub(1,r:len()-1)
		end
		return r..'}'
	else return t end
end
table.tostring_beautify=function(t)
	if type(t) == 'table' then
		local r = '{'
		for k,v in pairs(t) do
			if type(k) == 'string' then
				r = r..'["'..k..'"]='
			end
			if type(v) == 'table' then
				r = r..table.tostring(v)
			elseif (type(v) == 'boolean' or type(v) == 'number') then
				r = r..tostring(v)
			else
				r = r..'"'..v..'"'
			end
			r = r..','
		end
		if r ~= '' then
				r = r:sub(1,r:len()-1)
		end
		return r..'}'
	else return t end
end
table.copy=function(t1)
	local t2 = {}
	for k,v in pairs(t1) do
		t2[k] = v
	end
	return t2
end
table.merge=function(...)
	--[[
		merge 2 tables, just like Object.assign on JS
		first table will be replaced by new table...
		recommended only on object-like tables, but not on array-like tables
	]]
	local r = {}
	for _,t in ipairs{...} do
		for k,v in pairs(t) do
			r[k] = v
		end
	end
	return r
end
os.sleep=function(ms)
--no true way to imitate this, this recreation below is inaccurate, its a bit faster
	local clck = os.clock
	local start = clck()
	ms = (ms/5000)
	while clck() - start < ms do end
	start,ms,clck = nil,nil,nil
end
local gg = {}
-- [BEGIN] table Extension + GG Virtualization + Anti-malicious + Security Test
function initVirtGG()
	local Repl,tmp = {["print"]=print,["IO"]=table.copy(io),["OS"]=table.copy(os),["Env"]=_ENV,["LoadFile"]=loadfile},{}
	local ContainmentFiles = {pwd=os.getenv("PWD")}
	ContainmentFiles.containmentdir = ContainmentFiles.pwd.."/ContainmentDir"
	ContainmentFiles.luascript = ContainmentFiles.containmentdir.."/ContainedLua.lua"
	ContainmentFiles.txtfile = ContainmentFiles.containmentdir.."/ContainedText.txt"

	-- [BEGIN] GameGuardian API Simulation
	Repl.print("[Info] Initializing virtual GameGuardian API methods...")
	parseGGVarTypes=function(typ,val)
		local tmp = {
			['TYPE']={
				['127']="gg.TYPE_AUTO",
				['1']="gg.TYPE_BYTE",
				['64']="gg.TYPE_DOUBLE",
				['4']="gg.TYPE_DWORD",
				['16']="gg.TYPE_FLOAT",
				['32']="gg.TYPE_QWORD",
				['2']="gg.TYPE_WORD",
				['8']="gg.TYPE_XOR"
			},
			['REGION']={
				['32']="gg.REGION_ANONYMOUS",
				['524288']="gg.REGION_ASHMEM",
				['131072']="gg.REGION_BAD",
				['16384']="gg.REGION_CODE_APP",
				['32768']="gg.REGION_CODE_SYS",
				['4']="gg.REGION_C_ALLOC",
				['16']="gg.REGION_C_BSS",
				['8']="gg.REGION_C_DATA",
				['1']="gg.REGION_C_HEAP",
				['65536']="gg.REGION_JAVA",
				['2']="gg.REGION_JAVA_HEAP",
				['-2080896']="gg.REGION_OTHER",
				['262144']="gg.REGION_PPSSPP",
				['64']="gg.REGION_STACK",
				['1048576']="gg.REGION_VIDEO"
			},
			['SIGN']={
				['536870912']='gg.SIGN_EQUAL',
				['67108864']='gg.SIGN_GREATER_OR_EQUAL',
				['134217728']='gg.SIGN_LESS_OR_EQUAL',
				['268435456']='gg.SIGN_NOT_EQUAL'
			}
		}
		tmp = tmp[tostring(typ)][tostring(val)]
		if tmp then
			return tmp
		else
			return val
		end
	end
	gg = {
		ANDROID_SDK_INT = 30,
		ASM_ARM = 4,
		ASM_ARM64 = 6,
		ASM_THUMB = 5,
		BUILD = 16142,
		CACHE_DIR = ContainmentFiles.containmentdir..'/cache',
		DUMP_SKIP_SYSTEM_LIBS = 1,
		EXT_CACHE_DIR = ContainmentFiles.containmentdir..'/extCache',
		EXT_FILES_DIR = ContainmentFiles.containmentdir..'/internalData',
		EXT_STORAGE = ContainmentFiles.containmentdir..'/extStorage',
		FILES_DIR = ContainmentFiles.containmentdir..'/internalData',
		FREEZE_IN_RANGE = 3,
		FREEZE_MAY_DECREASE = 2,
		FREEZE_MAY_INCREASE = 1,
		FREEZE_NORMAL = 0,
		LOAD_APPEND = 8,
		LOAD_VALUES = 2,
		LOAD_VALUES_FREEZE = 3,
		PACKAGE = 'catch.me.if.you.can',
		POINTER_EXECUTABLE = 2,
		POINTER_EXECUTABLE_WRITABLE = 1,
		POINTER_NO = 4,
		POINTER_READ_ONLY = 8,
		POINTER_WRITABLE = 16,
		PROT_EXEC = 4,
		PROT_NONE = 0,
		PROT_READ = 2,
		PROT_WRITE = 1,
		REGION_ANONYMOUS = 32,
		REGION_ASHMEM = 524288,
		REGION_BAD = 131072,
		REGION_CODE_APP = 16384,
		REGION_CODE_SYS = 32768,
		REGION_C_ALLOC = 4,
		REGION_C_BSS = 16,
		REGION_C_DATA = 8,
		REGION_C_HEAP = 1,
		REGION_JAVA = 65536,
		REGION_JAVA_HEAP = 2,
		REGION_OTHER = -2080896,
		REGION_PPSSPP = 262144,
		REGION_STACK = 64,
		REGION_VIDEO = 1048576,
		SAVE_AS_TEXT = 1,
		SIGN_EQUAL = 536870912,
		SIGN_FUZZY_EQUAL = 536870912,
		SIGN_FUZZY_GREATER = 67108864,
		SIGN_FUZZY_LESS = 134217728,
		SIGN_FUZZY_NOT_EQUAL = 268435456,
		SIGN_GREATER_OR_EQUAL = 67108864,
		SIGN_LESS_OR_EQUAL = 134217728,
		SIGN_NOT_EQUAL = 268435456,
		TAB_MEMORY_EDITOR = 3,
		TAB_SAVED_LIST = 2,
		TAB_SEARCH = 1,
		TAB_SETTINGS = 0,
		TYPE_AUTO = 127,
		TYPE_BYTE = 1,
		TYPE_DOUBLE = 64,
		TYPE_DWORD = 4,
		TYPE_FLOAT = 16,
		TYPE_QWORD = 32,
		TYPE_WORD = 2,
		TYPE_XOR = 8,
		VERSION = '101.1',
		VERSION_INT = 10101
	}
	gg.isGUIVisible = true
	gg.prevGetResultCount = 0
	Repl.print("[Info] - Virtualizing gg.sleep()...")
	Repl.print("[Info] - Virtualizing gg.isVisible()...")
	Repl.print("[Info] - Virtualizing gg.setVisible()...")
	Repl.print("[Info] - Virtualizing gg.alert()...")
	Repl.print("[Info] - Virtualizing gg.toast()...")
	Repl.print("[Info] - Virtualizing gg.saveVariable()...")
	Repl.print("[Info] - Virtualizing gg.getLocale()...")
	Repl.print("[Info] - Virtualizing gg.choice()...")
	Repl.print("[Info] - Virtualizing gg.multiChoice()...")
	Repl.print("[Info] - Virtualizing gg.getFile()...")
	Repl.print("[Info] - Virtualizing gg.searchNumber()...")
	Repl.print("[Info] - Virtualizing gg.refineNumber()...")
	Repl.print("[Info] - Virtualizing gg.getResults()...")
	Repl.print("[Info] - Virtualizing gg.getResultCount()...")
	Repl.print("[Info] - Virtualizing gg.clearResults()...")
	Repl.print("[Info] - Virtualizing gg.clearLists()...")
	Repl.print("[Info] - Virtualizing gg.setValues()...")
	Repl.print("[Info] - Virtualizing gg.addListItems()...")
	Repl.print("[Info] - Virtualizing gg.editAll()...")
	Repl.print("[Info] - Virtualizing gg.setRanges()...")
	Repl.print("[Info] - Virtualizing gg.makeRequest()...")
	gg.sleep=os.sleep
	gg.require=function(version,build)
		return nil
	end
	gg.isVisible=function()
		Repl.print('[Dump] gg.isVisible()')
		gg.sleep(1000)
		return gg.isGUIVisible
	end
	gg.setVisible=function(i)
		Repl.print('[Dump] gg.setVisible('..tostring(i)..')')
		if type(i) == "boolean" then
			gg.isGUIVisible = i
		end
		return gg.isGUIVisible
	end
	gg.alert=function(text,positive,negative,neutral)
		positive = positive or "OK"
		Repl.print('[gg.alert] '..text)
		Repl.print('[Choice1] 1:'..positive)
		if negative then Repl.print('[Choice2] 0:'..negative) end
		if neutral then Repl.print('[Choice3] -1:'..neutral) end
		Repl.print('Input your choice by the number [-1,0,1]')
		return Repl.IO.read()
	end
	gg.toast=function(text,fastmode)
		fastmode = fastmode or nil
		Repl.print('[gg.toast] '..text)
		Repl.print('[gg.toast] usesFastMode:'..tostring(fastmode))
	end
	gg.prompt=function(text,placeholder,types)
		local tmp = {}
		if type(text) == "table" then
			for k,v in pairs(text) do
				if (types and types[k] == 'checkbox') then
					if (placeholder and placeholder[k]) then
						print('[gg.prompt] '..v..' ['..placeholder[k]..']')
					else
						print('[gg.prompt] '..v)
					end
					print('[Choice] (y/n/yes/no/true/false)')
					tmp[k] = Repl.IO.read()
					if (tmp[k] ~= "y" or tmp[k] ~= "yes" or tmp[k] ~= "true") then
						tmp[k] = true
					elseif (tmp[k] ~= "n" or tmp[k] ~= "no" or tmp[k] ~= "false") then
						tmp[k] = false
					elseif (not tmp[k] or tmp[k] == "") then
						tmp[k] = placeholder[k]
					end
				else
					if (placeholder and placeholder[k]) then
						print('[gg.prompt] '..v..' ('..placeholder[k]..')')
					else
						print('[gg.prompt] '..v)
					end
					tmp[k] = Repl.IO.read()
				end
			end
		--return userChoice
		--if it somehow fails, use tonumber
			return tmp
		else
			Repl.print('[ERROR] items argument type isn\'t table:',items)
			Repl.print('[Warn] Will return nil value')
			return nil
		end
	end
	gg.saveVariable=function(content,saveFile)
		fastmode = fastmode or nil
		Repl.print('[Dump] gg.saveVariable('..table.tostring(content)..','..saveFile..')')
	end
	gg.getLocale=function()
		Repl.print('[Dump] gg.getLocale()')
		return "en_US"
	end
	gg.choice=function(items,selected,msg)
		Repl.print('[gg.choice] '..msg)
		if type(items) == "table" then
			i = 1
			for k,v in pairs(items) do
				if i == selected then
					Repl.print('[Choice] *'..k..':'..v)
				else
					Repl.print('[Choice]  '..k..':'..v)
				end
				i = i + 1
			end
			Repl.print('[Choice] Input your choice')
			userChoice = Repl.IO.read()
		--return userChoice
		--if it somehow fails, use tonumber
			return tonumber(userChoice)
		else
			Repl.print('[ERROR] items argument type isn\'t table:',items)
			Repl.print('[Warn] Will return nil value')
			return nil
		end
	end
	gg.multiChoice=function(items,selected,msg)
		Repl.print('[gg.choice] '..msg)
		if type(items) == "table" then
			i = 1
			for k,v in pairs(items) do
				if (selected and selected[k]) then
					Repl.print('[Choice] *'..k..':'..v)
				else
					Repl.print('[Choice]  '..k..':'..v)
				end
				i = i + 1
			end
			Repl.print('[Choice] Input your choice')
			userChoice = Repl.IO.read()
			return {[tonumber(userChoice)]=true}
		else
			Repl.print('[ERROR] items argument type isn\'t table:',items)
			Repl.print('[Warn] Will return nil value')
			return nil
		end
	end
	gg.getFile=function()
		Repl.print("[Dump] gg.getFile()")
		return ContainmentFiles.luascript
	end	
	gg.searchNumber=function(n,t,e,s,f,t,l,...)
		n=n or ""
		t=t or gg.TYPE_AUTO
		s=s or gg.SIGN_EQUAL
		Repl.print("[Dump] gg.searchNumber("..n..","..parseGGVarTypes("TYPE",t)..","..parseGGVarTypes("SIGN",s)..")")
		return true
	end
	gg.refineNumber=function(n,t,e,s,f,t,l,...)
		n=n or ""
		t=t or gg.TYPE_AUTO
		s=s or gg.SIGN_EQUAL
		Repl.print("[Dump] gg.refineNumber("..n..","..parseGGVarTypes("TYPE",t)..","..parseGGVarTypes("SIGN",s)..")")
		return true
	end
	gg.getResults=function(c,a,b,d,e,f,t,...)
		local tbl = {}
		c = tonumber(c) or 0
		t = t or gg.TYPE_AUTO
		Repl.print("[Dump] gg.getResults("..c..","..parseGGVarTypes("TYPE",t)..")")
		gg.prevGetResultCount = c
		for i=1,c do
			tbl = {table.unpack(tbl),{address=13245768,value=123,freeze=false}}
		end
		return {tbl}
	end
	gg.getResultCount=function()
		return gg.prevGetResultCount
	end
	gg.clearResults=function()
		gg.prevGetResultCount = 0
	end
	gg.clearList=function()
		gg.prevGetResultCount = 0
	end
	gg.setValues=function(t,...)
		Repl.print("[Dump] gg.setValues("..table.tostring(t)..")")
		return true
	end
	gg.addListItems=function(t,...)
		t = t or ""
		Repl.print("[Dump] gg.addListItems("..table.tostring(t)..")")
		return true
	end
	gg.editAll=function(v,t,...)
		v = v or ""
		t = t or gg.TYPE_AUTO
		Repl.print("[Dump] gg.editAll("..v..","..parseGGVarTypes("TYPE",t)..")")
		return true
	end
	gg.setRanges=function(r)
		r = r or gg.REGION_AUTO
		Repl.print("[Dump] gg.setRanges("..parseGGVarTypes("REGION",r)..")")
		return true
	end
	gg.makeRequest=function(uri,header,data)
		uri = uri or ""
		header = header or "{}"
		data = data or "{}"
		Repl.print("[Dump] gg.makeRequest("..uri..","..table.tostring(header)..","..table.tostring(data)..")")
		return {
			url=uri,
			requestMethod=nil,
			code=300,
			message="Success",
			headers=header,
			error=false,
			content=data
		}
	end
	-- [END] GameGuardian API Simulation

	-- [BEGIN] Anti-malicious + Malicious activity dumper
	Repl.print("[Info] Initializing Secure Environments...")
	local void=function(...)
		Repl.print("[Warn] Malicious: something tries to do malicious thing")
		return nil
	end
	Repl.print("[Info] - Altering os variables...")
	os.execute = void
	os.remove  = void
	os.getenv  = function(envVarNames,...)
		local args = ...
		Repl.print("[Malicious] Something tries to get Lua envoriment variables through os.getenv("..envVarNames..","..args.."), we intercepted the result to "..ContainmentFiles.containmentdir)
		args = nil
		return ContainmentFiles.containmentdir
	end	
	Repl.print("[Info] - Altering io variables...")
	io.open    = function(file,opmodes)
		file = file or "[No file Argument Passed]"
		opmodes = opmodes or "[No opmodes Argument Passed]"
		Repl.print('[Malicious] something tries to open "'..file..'" with opmode '..opmodes..', intercepted to '..ContainmentFiles.txtfile)
	--return Repl.IO.open(ContainmentFiles.txtfile,"r") cant do this because stuckk on loop
		return "THIS IS TEXT SAMPLE"
	end
	io.close   = void
	io.input   = void
	io.output  = void
	io.read    = void
	io.write   = void
	Repl.print("[Info] - Altering debug variables...")
	debug      = {}
	print=function(...)
		local args = ...
		Repl.print("[Script] "..args)
		args = nil
	end
	Repl.print("[Info] - Altering _ENV variables...")
	_ENV._VERSION = "Lua 5.0"
	_ENV.loadfile = void
	_ENV.loadstring = void
	_ENV.io = io
	_ENV.debug = debug
	_ENV.print = print
	_ENV.os = os
	-- [END] Anti-malicious + Malicious activity dumper
end
-- [START] Security Test
function malTest()
	print('[Info] Starting security test...')
	print('[Info] - Initializing os test...')
	print('[Info]  - Trying os.execute()...')
	print('[Info]  - Trying os.remove()...')
	print('[Info] - Initializing io test...')
	print('[Info]  - Trying io.open()...')
	print('[Info]  - Trying io.close()...')
	print('[Info]  - Trying io.input()...')
	print('[Info]  - Trying io.output()...')
	print('[Info]  - Trying io.read()...')
	print('[Info]  - Trying io.write()...')
	os.execute("echo [WARNING] CANCEL THE SCRIPT! OS.EXECUTE FAILED!!")
	os.remove(gg.getFile()..".sampleremove")
	io.open()
	io.close()
	io.input()
	io.output()
	io.read()
	io.write()
	print('[Info] - Initializing Lua _ENV variable test...')
	print('[Info]  - Trying _ENV._VERSION...')
	if _ENV._VERSION == "Lua 5.0" then print('[PASS]') else print('[FAIL]') end
	print('[Info]  - Trying _ENV.loadfile()...')
	if (_ENV.loadfile == void and not _ENV.loadfile()) then print('[PASS]') else print('[FAIL]') end
	print('[Info]  - Trying _ENV.loadstring()...')
	if (_ENV.loadstring == void and not _ENV.loadstring()) then print('[PASS]') else print('[FAIL]') end
	print('[Info]  - Trying _ENV.io...')
	if _ENV.io == io then print('[PASS]') else print('[FAIL]') end
	print('[Info]  - Trying _ENV.debug...')
	if _ENV.debug == debug then print('[PASS]') else print('[FAIL]') end
	print('[Info]  - Trying _ENV.print...')
	_ENV.print('If you see [Script] at the beginning of the this text, that means it works!')
	if (_ENV.print == print) then print('[PASS]') else print('[FAIL]') end
	print('[Info]  - Trying _ENV.os...')
	if _ENV.os == os then print('[PASS]') else print('[FAIL]') end
	print('[Info] - Initializing GameGuardian API test...')
	print('[Info]  - Trying to intercept gg.getFile() input...')
	print('[Info]  - Trying to intercept gg.searchNumber(123) input...')
	print('[Info]  - Trying to intercept gg.refineNumber(123) input...')
	print('[Info]  - Trying to intercept gg.getResults(123) input...')
	print('[Info]  - Trying to intercept gg.setValues({1,2,3}) input...')
	print('[Info]  - Trying to intercept gg.addListItems({1,2,3}) input...')
	print('[Info]  - Trying to intercept gg.editAll(123,234) input...')
	print('[Info]  - Trying to intercept gg.setRanges(123) input...')
	print('[Info]  - Trying to intercept gg.makeRequest("http://127.0.0.1") input...')
	gg.getFile()
	gg.searchNumber(123)
	gg.refineNumber(123)
	gg.getResults(123)
	gg.setValues({1,2,3})
	gg.addListItems({1,2,3})
	gg.editAll(123,234)
	gg.setRanges(123)
	gg.makeRequest("http://127.0.0.1")
end
-- [END] Security Test
initVirtGG()
malTest()
print('')
print('[Success] Finished, Virtualized GameGuardian API Environment Initialized!')
print('')
-- [END] table Extension + GG Virtualization + Anti-malicious + Security Test










local L0_2,L1_2,L2_2,L3_2,L4_2,L5_2,L6_2,L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2
while true do
	L0_2 = {}
	L1_2 = PG
	L2_2 = PGPRO
	L2_2 = L2_2.PGPRO
	L3_2 = fPGPRO
	L3_2 = L3_2.PGPROAQ
	L3_2 = L3_2.AQ
	L4_2 = PGPRO
	L4_2 = L4_2.PGPRO
	L5_2 = PGPRO
	L5_2 = L5_2.PGPROPG
	L6_2 = PGPRO
	L6_2 = L6_2.PGPRO
	L7_2 = PGPRO
	L7_2 = L7_2.PGPROAQ
	L7_2 = L7_2.AQ
	L8_2 = PGPRO
	L8_2 = L8_2.PGPRO
	L9_2 = PGPRO
	L9_2 = L9_2.PGPRO
	L0_2[1] = L1_2
	L0_2[2] = L2_2
	L0_2[3] = L3_2
	L0_2[4] = L4_2
	L0_2[5] = L5_2
	L0_2[6] = L6_2
	L0_2[7] = L7_2
	L0_2[8] = L8_2
	L0_2[9] = L9_2
	L1_2 = {}
	L2_2 = L0_2.AQ
	L3_2 = PGPRO
	L3_2 = L3_2.PGPRO
	L4_2 = PGPRO
	L4_2 = L4_2.PGPROAQyPG
	L5_2 = PGPRO
	L5_2 = L5_2.PGPRO
	L6_2 = PGPRO
	L6_2 = L6_2.PGPROAQ
	L6_2 = L6_2.AQ
	L7_2 = PGPRO
	L7_2 = L7_2.PGPRO
	L8_2 = PGPRO
	L8_2 = L8_2.PGPRO
	L8_2 = L8_2.AQ
	L9_2 = PGPRO
	L9_2 = L9_2.sPGPRO
	L10_2 = PGPRO
	L10_2 = L10_2.PGPRO
	L1_2[1] = L2_2
	L1_2[2] = L3_2
	L1_2[3] = L4_2
	L1_2[4] = L5_2
	L1_2[5] = L6_2
	L1_2[6] = L7_2
	L1_2[7] = L8_2
	L1_2[8] = L9_2
	L1_2[9] = L10_2
	L2_2 = {}
	L3_2 = L0_2.AQ
	L4_2 = L1_2.PGPRO
	L5_2 = L1_2.PGPROPG
	L6_2 = L1_2.PGPRO
	L7_2 = L1_2.PGPROAQ
	L7_2 = L7_2.AQ
	L8_2 = L1_2.PGPRO
	L9_2 = L1_2.PGPROAQ
	L9_2 = L9_2.AQ
	L10_2 = L1_2.PGPRO
	L11_2 = L1_2.PGPROi
	L2_2[1] = L3_2
	L2_2[2] = L4_2
	L2_2[3] = L5_2
	L2_2[4] = L6_2
	L2_2[5] = L7_2
	L2_2[6] = L8_2
	L2_2[7] = L9_2
	L2_2[8] = L10_2
	L2_2[9] = L11_2
	L3_2 = {}
	L4_2 = PG
	L5_2 = L2_2.PGPRO
	L6_2 = L2_2.PGPROAQ
	L6_2 = L6_2.AQ
	L7_2 = L2_2.PGPROAQAQ
	L8_2 = L2_2.PGPROPG
	L9_2 = L2_2.PGPRO
	L10_2 = L2_2.PGPROAQ
	L10_2 = L10_2.AQ
	L11_2 = L2_2.PGPRO
	L12_2 = L2_2.PGPRO
	L3_2[1] = L4_2
	L3_2[2] = L5_2
	L3_2[3] = L6_2
	L3_2[4] = L7_2
	L3_2[5] = L8_2
	L3_2[6] = L9_2
	L3_2[7] = L10_2
	L3_2[8] = L11_2
	L3_2[9] = L12_2
	L4_2 = {}
	L5_2 = L3_2.AQ
	L6_2 = L2_2.PGPRO
	L7_2 = PGPROw
	L7_2 = L7_2.PGPROAQPG
	L8_2 = L2_2.PGPRO
	L9_2 = L2_2.PGPROAQ
	L9_2 = L9_2.AQ
	L10_2 = L2_2.PGPRO
	L11_2 = L2_2.PGPRO
	L11_2 = L11_2.AQ
	L12_2 = L2_2.sPGPRO
	L13_2 = L2_2.PGPRO
	L4_2[1] = L5_2
	L4_2[2] = L6_2
	L4_2[3] = L7_2
	L4_2[4] = L8_2
	L4_2[5] = L9_2
	L4_2[6] = L10_2
	L4_2[7] = L11_2
	L4_2[8] = L12_2
	L4_2[9] = L13_2
	L5_2 = {}
	L6_2 = L3_2.AQ
	L7_2 = L4_2.PGPRO
	L8_2 = L4_2.PGPROPG
	L9_2 = L4_2.PGPRO
	L10_2 = L4_2.PGPRObAQ
	L10_2 = L10_2.AQ
	L11_2 = L4_2.PGPRO
	L12_2 = L4_2.PGPROAQ
	L12_2 = L12_2.AQ
	L13_2 = L4_2.PGPRO
	L14_2 = L4_2.PGPROi
	L5_2[1] = L6_2
	L5_2[2] = L7_2
	L5_2[3] = L8_2
	L5_2[4] = L9_2
	L5_2[5] = L10_2
	L5_2[6] = L11_2
	L5_2[7] = L12_2
	L5_2[8] = L13_2
	L5_2[9] = L14_2
	L6_2 = L3_2.AQ
	if L6_2 then
		L6_2 = L3_2.AQ
		L6_2 = L6_2.AQ
		if L6_2 then
			L6_2 = L3_2.AQ
			L6_2 = L6_2.AQ
			L6_2 = L6_2.AQ
			if L6_2 then
				L6_2 = L3_2.AQ
				L6_2 = L6_2.AQ
				L6_2 = L6_2.AQ
				L6_2 = L6_2.AQ
				if L6_2 then
					L6_2 = L5_2.PGPRO
					if L6_2 then
						L6_2 = L5_2.PGPRO
						L6_2 = L6_2.PGPRO
						if L6_2 then
							L6_2 = L5_2.PGPRO
							L6_2 = L6_2.PGPRO
							L6_2 = L6_2.PGPRO
							if L6_2 then
								L6_2 = L5_2.PGPRO
								if L6_2 then
									L6_2 = L5_2.PGPRO
									L6_2 = L6_2.PGPRO
									if L6_2 then
										L6_2 = L5_2.PGPRO
										L6_2 = L6_2.PGPRO
										L6_2 = L6_2.PGPRO
										if L6_2 then
											L6_2 = L3_2.AQ
											L7_2 = L3_2
											L6_2 = L6_2(L7_2)
											L3_2.AQ = L6_2
											L6_2 = L3_2.AQ
											L7_2 = L3_2.AQ
											L7_2 = L7_2.AQ
											L8_2 = L3_2.AQ
											L9_2 = L3_2
											L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L8_2(L9_2)
											L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L7_2(L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L6_2 = L6_2(L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L3_2.AQ = L6_2
											L6_2 = L5_2.PGPRO
											L7_2 = L5_2
											L6_2 = L6_2(L7_2)
											L5_2.PGPRO = L6_2
											L6_2 = L5_2.PGPRO
											L7_2 = L5_2.PGPRO
											L7_2 = L7_2.PGPRO
											L8_2 = L5_2.PGPRO
											L8_2 = L8_2.PGPRO
											L8_2 = L8_2.PGPRO
											L9_2 = L5_2.PGPRO
											L9_2 = L9_2.PGPRO
											L10_2 = L5_2.PGPRO
											L11_2 = L5_2.PGPRO
											L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L10_2(L11_2)
											L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L9_2(L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L8_2(L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L7_2(L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L6_2 = L6_2(L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L5_2.PGPRO = L6_2
											L6_2 = L5_2.PGPRO
											L7_2 = L5_2.PGPRO
											L7_2 = L7_2.PGPRO
											L8_2 = L5_2.PGPRO
											L8_2 = L8_2.PGPRO
											L8_2 = L8_2.PGPRO
											L9_2 = L5_2.PGPRO
											L9_2 = L9_2.PGPRO
											L10_2 = L5_2.PGPRO
											L11_2 = L5_2.PGPRO
											L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L10_2(L11_2)
											L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L9_2(L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L8_2(L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L7_2(L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L6_2 = L6_2(L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L5_2.PGPRO = L6_2
											L6_2 = L3_2.AQ
											L7_2 = L3_2
											L6_2 = L6_2(L7_2)
											L3_2.AQ = L6_2
											L6_2 = L3_2.AQ
											L7_2 = L3_2.AQ
											L7_2 = L7_2.AQ
											L8_2 = L3_2.AQ
											L9_2 = L3_2
											L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L8_2(L9_2)
											L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L7_2(L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L6_2 = L6_2(L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L3_2.AQ = L6_2
											L6_2 = L5_2.PGPRO
											L7_2 = L5_2
											L6_2 = L6_2(L7_2)
											L5_2.PGPRO = L6_2
											L6_2 = L5_2.PGPRO
											L7_2 = L5_2.PGPRO
											L7_2 = L7_2.PGPRO
											L8_2 = L5_2.PGPRO
											L8_2 = L8_2.PGPRO
											L8_2 = L8_2.PGPRO
											L9_2 = L5_2.PGPRO
											L9_2 = L9_2.PGPRO
											L10_2 = L5_2.PGPRO
											L11_2 = L5_2.PGPRO
											L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L10_2(L11_2)
											L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L9_2(L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L8_2(L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L7_2(L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L6_2 = L6_2(L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L5_2.PGPRO = L6_2
											L6_2 = L5_2.PGPRO
											L7_2 = L5_2.PGPRO
											L7_2 = L7_2.PGPRO
											L8_2 = L5_2.PGPRO
											L8_2 = L8_2.PGPRO
											L8_2 = L8_2.PGPRO
											L9_2 = L5_2.PGPRO
											L9_2 = L9_2.PGPRO
											L10_2 = L5_2.PGPRO
											L11_2 = L5_2.PGPRO
											L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L10_2(L11_2)
											L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L9_2(L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L8_2(L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L7_2(L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L6_2 = L6_2(L7_2,L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L5_2.PGPRO = L6_2
											L6_2 = {}
											L7_2 = L3_2.AQ
											L8_2 = L5_2.PGPRO
											L9_2 = L5_2.PGPROAQ
											L9_2 = L9_2.AQ
											L10_2 = L5_2.PGPRO
											L11_2 = L5_2.PGPRO
											L6_2[1] = L7_2
											L6_2[2] = L8_2
											L6_2[3] = L9_2
											L6_2[4] = L10_2
											L6_2[5] = L11_2
											L7_2 = L6_2[1]
											L8_2 = L6_2[2]
											L9_2 = L6_2[3]
											L7_2 = L7_2 .. L8_2 .. L9_2
											L6_2.PGPROAQAQ = L7_2
											L7_2 = L6_2.PGPROAQAQ
											L8_2 = L6_2.PGPROAQAQ
											L9_2 = L6_2.PGPROAQAQ
											L10_2 = L6_2.PGPROAQAQ
											L11_2 = L6_2.PGPROAQAQ
											L12_2 = L6_2.PGPROAQAQ
											L13_2 = L6_2.PGPROAQAQ
											L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L12_2(L13_2)
											L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L11_2(L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L10_2(L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L9_2(L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L8_2(L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L7_2 = L7_2(L8_2,L9_2,L10_2,L11_2,L12_2,L13_2,L14_2,L15_2,L16_2,L17_2,L18_2,L19_2,L20_2,L21_2,L22_2,L23_2,L24_2,L25_2,L26_2,L27_2,L28_2,L29_2,L30_2,L31_2,L32_2,L33_2,L34_2,L35_2,L36_2,L37_2,L38_2,L39_2,L40_2,L41_2,L42_2,L43_2,L44_2,L45_2,L46_2,L47_2,L48_2,L49_2,L50_2,L51_2,L52_2,L53_2,L54_2,L55_2,L56_2,L57_2,L58_2,L59_2,L60_2,L61_2,L62_2,L63_2,L64_2,L65_2,L66_2,L67_2,L68_2,L69_2,L70_2,L71_2,L72_2,L73_2,L74_2,L75_2,L76_2,L77_2,L78_2,L79_2,L80_2,L81_2,L82_2,L83_2,L84_2,L85_2,L86_2,L87_2,L88_2,L89_2,L90_2,L91_2,L92_2,L93_2,L94_2,L95_2,L96_2,L97_2,L98_2,L99_2,L100_2,L101_2,L102_2,L103_2,L104_2,L105_2,L106_2,L107_2,L108_2,L109_2,L110_2,L111_2,L112_2,L113_2,L114_2,L115_2,L116_2,L117_2,L118_2,L119_2,L120_2,L121_2,L122_2,L123_2,L124_2,L125_2,L126_2,L127_2,L128_2,L129_2,L130_2,L131_2,L132_2,L133_2,L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L6_2.i = L7_2
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end
while true do
	L0_2 = {}
	L1_2 = nil % nil
	L0_2[1] = L1_2
	i = L0_2
	L0_2 = ipairs
	L1_2 = i
	L0_2,L1_2,L2_2 = L0_2(L1_2)
	for L3_2 in L0_2,L1_2,L2_2 do
		L4_2 = {}
		L5_2 = {}
		L6_2 = nil % nil
		L5_2[1] = L6_2
		L6_2 = {}
		L7_2 = nil % nil
		L6_2[1] = L7_2
		L4_2[1] = L5_2
		L4_2[2] = L6_2
		L3_2 = L4_2
		L4_2 = {}
		L5_2 = nil % nil
		L4_2[1] = L5_2
		L4_2 = _ENV[L4_2]
		L3_2.i = L4_2
	end
end
L0_2 = 200
L1_2 = Key10
L2_2 = 8271
L3_2 = 4817
L4_2 = 72
L5_2 = 9272
L6_2 = 2727
L7_2 = 3727
L8_2 = 4783
L9_2 = 9473
L10_2 = 4783
L11_2 = 8363
L12_2 = 85
L13_2 = 3073
L14_2 = 8362
L15_2 = 7392
L16_2 = 100
L17_2 = 7494
L18_2 = 210
L19_2 = 3728
L20_2 = 122
L21_2 = {}
L22_2 = L4_2 * L12_2
L22_2 = L0_2 + L22_2
L22_2 = L22_2 - L16_2
L23_2 = L4_2
L24_2 = L12_2 * 2
L25_2 = L16_2 + L12_2
L26_2 = L18_2
L21_2[1] = L22_2
L21_2[2] = L23_2
L21_2[3] = L24_2
L21_2[4] = L25_2
L21_2[5] = L26_2
L22_2 = L21_2[5]
L23_2 = L21_2[2]
L22_2 = L22_2 + L23_2
L23_2 = L21_2[1]
L24_2 = L21_2[4]
L23_2 = L23_2 * L24_2
L22_2 = L22_2 + L23_2
L23_2 = L21_2[1]
L22_2 = L22_2 - L23_2
L23_2 = L21_2[2]
L24_2 = L21_2[3]
L24_2 = L24_2 * 1
L23_2 = L23_2 + L24_2
L24_2 = L21_2[4]
L23_2 = L23_2 - L24_2
L24_2 = L21_2[3]
L25_2 = L21_2[1]
L26_2 = L21_2[2]
L25_2 = L25_2 * L26_2
L24_2 = L24_2 + L25_2
L25_2 = L21_2[4]
L24_2 = L24_2 + L25_2
L25_2 = L21_2[1]
L26_2 = L21_2[2]
L27_2 = L21_2[5]
L26_2 = L26_2 * L27_2
L27_2 = L21_2[5]
L26_2 = L26_2 * L27_2
L25_2 = L25_2 + L26_2
L26_2 = L21_2[1]
L25_2 = L25_2 + L26_2
L26_2 = L21_2[1]
L27_2 = L21_2[5]
L26_2 = L26_2 + L27_2
L27_2 = L21_2[3]
L26_2 = L26_2 - L27_2
L27_2 = L21_2[4]
L26_2 = L26_2 + L27_2
L27_2 = L21_2[5]
L28_2 = L21_2[2]
L27_2 = L27_2 + L28_2
L28_2 = L21_2[1]
L29_2 = L21_2[4]
L28_2 = L28_2 * L29_2
L27_2 = L27_2 + L28_2
L28_2 = L21_2[1]
L27_2 = L27_2 - L28_2
L28_2 = L21_2[2]
L29_2 = L21_2[3]
L29_2 = L29_2 * 1
L28_2 = L28_2 + L29_2
L29_2 = L21_2[4]
L28_2 = L28_2 - L29_2
L29_2 = L21_2[5]
L30_2 = L21_2[1]
L31_2 = L21_2[2]
L30_2 = L30_2 * L31_2
L29_2 = L29_2 + L30_2
L30_2 = L21_2[3]
L29_2 = L29_2 + L30_2
L30_2 = L21_2[3]
L31_2 = L21_2[4]
L30_2 = L30_2 + L31_2
L31_2 = L21_2[1]
L32_2 = L21_2[2]
L31_2 = L31_2 * L32_2
L30_2 = L30_2 - L31_2
L31_2 = L21_2[5]
L30_2 = L30_2 + L31_2
L31_2 = L21_2[5]
L32_2 = L21_2[1]
L31_2 = L31_2 + L32_2
L32_2 = L21_2[2]
L31_2 = L31_2 - L32_2
L32_2 = L21_2[3]
L31_2 = L31_2 + L32_2
L32_2 = {}
L33_2 = L22_2
L34_2 = L23_2
L35_2 = L24_2
L36_2 = L25_2
L37_2 = L26_2
L38_2 = L27_2
L39_2 = L28_2
L40_2 = L29_2
L41_2 = L30_2
L42_2 = L31_2
L43_2 = L30_2
L44_2 = L28_2
L45_2 = L26_2
L46_2 = L25_2
L47_2 = L24_2
L48_2 = L31_2
L49_2 = L26_2
L50_2 = L25_2
L51_2 = L23_2
L52_2 = L24_2
L53_2 = L22_2
L54_2 = L30_2
L32_2[1] = L33_2
L32_2[2] = L34_2
L32_2[3] = L35_2
L32_2[4] = L36_2
L32_2[5] = L37_2
L32_2[6] = L38_2
L32_2[7] = L39_2
L32_2[8] = L40_2
L32_2[9] = L41_2
L32_2[10] = L42_2
L32_2[11] = L43_2
L32_2[12] = L44_2
L32_2[13] = L45_2
L32_2[14] = L46_2
L32_2[15] = L47_2
L32_2[16] = L48_2
L32_2[17] = L49_2
L32_2[18] = L50_2
L32_2[19] = L51_2
L32_2[20] = L52_2
L32_2[21] = L53_2
L32_2[22] = L54_2
PGFC = L32_2
while true do
	L32_2 = {}
	L33_2 = nil % nil
	L32_2[1] = L33_2
	i = L32_2
	L32_2 = ipairs
	L33_2 = i
	L32_2,L33_2,L34_2 = L32_2(L33_2)
	for L35_2 in L32_2,L33_2,L34_2 do
		L36_2 = {}
		L37_2 = {}
		L38_2 = nil % nil
		L37_2[1] = L38_2
		L38_2 = {}
		L39_2 = nil % nil
		L38_2[1] = L39_2
		L36_2[1] = L37_2
		L36_2[2] = L38_2
		L35_2 = L36_2
		L36_2 = {}
		L37_2 = nil % nil
		L36_2[1] = L37_2
		L36_2 = _ENV[L36_2]
		L35_2.i = L36_2
	end
end
function L32_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3
	L1_3 = {}
	KEY = L1_3
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = A0_3[L4_3]
		L6_3 = PGFC
		L6_3 = L6_3[1]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC
		L6_3 = L6_3[2]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC
		L6_3 = L6_3[6]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC
		L6_3 = L6_3[3]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC
		L6_3 = L6_3[8]
		L7_3 = PGFC
		L7_3 = L7_3[4]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC
		L6_3 = L6_3[7]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC
		L6_3 = L6_3[5]
		L7_3 = PGFC
		L7_3 = L7_3[10]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC
		L6_3 = L6_3[9]
		L7_3 = PGFC
		L7_3 = L7_3[11]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC
		L6_3 = L6_3[12]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC
		L6_3 = L6_3[13]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC
		L6_3 = L6_3[14]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC
		L6_3 = L6_3[15]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC
		L6_3 = L6_3[16]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC
		L6_3 = L6_3[17]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC
		L6_3 = L6_3[18]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC
		L6_3 = L6_3[19]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC
		L6_3 = L6_3[20]
		L5_3 = L5_3 - L6_3
		L5_3 = L5_3 % 256
		PGFUNCTION = L5_3
		L5_3 = table
		L5_3 = L5_3.insert
		L6_3 = KEY
		L7_3 = PGFUNCTION
		L5_3(L6_3,L7_3)
	end
	L1_3 = KEY
	return L1_3
end
PGPRON = L32_2
L32_2 = PGPRON
L33_2 = PGFC
L32_2(L33_2)
function L32_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3
	A0_3 = A0_3.PG
	res = ""
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = res
		L6_3 = string
		L6_3 = L6_3.char
		L7_3 = A0_3[L4_3]
		L7_3 = #L7_3
		L8_3 = KEY
		L8_3 = L8_3[4]
		L7_3 = L7_3 + L8_3
		L8_3 = KEY
		L8_3 = L8_3[7]
		L8_3 = L8_3 + L4_3
		L9_3 = KEY
		L9_3 = L9_3[9]
		L9_3 = L9_3 + L4_3
		L8_3 = L8_3 * L9_3
		L7_3 = L7_3 + L8_3
		L7_3 = L7_3 % 256
		L6_3 = L6_3(L7_3)
		L5_3 = L5_3 .. L6_3
		res = L5_3
	end
	L1_3 = res
	return L1_3
end
PGENC_1 = L32_2
while true do
	L32_2 = {}
	L33_2 = nil % nil
	L32_2[1] = L33_2
	i = L32_2
	L32_2 = ipairs
	L33_2 = i
	L32_2,L33_2,L34_2 = L32_2(L33_2)
	for L35_2 in L32_2,L33_2,L34_2 do
		L36_2 = {}
		L37_2 = {}
		L38_2 = nil % nil
		L37_2[1] = L38_2
		L38_2 = {}
		L39_2 = nil % nil
		L38_2[1] = L39_2
		L36_2[1] = L37_2
		L36_2[2] = L38_2
		L35_2 = L36_2
		L36_2 = {}
		L37_2 = nil % nil
		L36_2[1] = L37_2
		L36_2 = _ENV[L36_2]
		L35_2.i = L36_2
	end
end
L32_2 = 215
L33_2 = keyy10
L34_2 = 8271
L35_2 = 4817
L36_2 = 252
L37_2 = 9272
L38_2 = 2727
L39_2 = 3727
L40_2 = 4783
L41_2 = 9473
L42_2 = 4783
L43_2 = 8363
L44_2 = 87
L45_2 = 3073
L46_2 = 8362
L47_2 = 7392
L48_2 = 209
L49_2 = 7494
L50_2 = 213
L51_2 = 3728
L52_2 = 108
L53_2 = {}
L54_2 = L36_2 * L44_2
L54_2 = L32_2 + L54_2
L54_2 = L54_2 - L48_2
L55_2 = L36_2
L56_2 = L44_2 * 2
L57_2 = L48_2 + L44_2
L58_2 = L50_2
L53_2[1] = L54_2
L53_2[2] = L55_2
L53_2[3] = L56_2
L53_2[4] = L57_2
L53_2[5] = L58_2
L54_2 = L53_2[5]
L55_2 = L53_2[2]
L54_2 = L54_2 + L55_2
L55_2 = L53_2[1]
L56_2 = L53_2[4]
L55_2 = L55_2 * L56_2
L54_2 = L54_2 + L55_2
L55_2 = L53_2[1]
L54_2 = L54_2 - L55_2
L55_2 = L53_2[2]
L56_2 = L53_2[3]
L56_2 = L56_2 * 1
L55_2 = L55_2 + L56_2
L56_2 = L53_2[4]
L55_2 = L55_2 - L56_2
L56_2 = L53_2[3]
L57_2 = L53_2[1]
L58_2 = L53_2[2]
L57_2 = L57_2 * L58_2
L56_2 = L56_2 + L57_2
L57_2 = L53_2[4]
L56_2 = L56_2 + L57_2
L57_2 = L53_2[1]
L58_2 = L53_2[2]
L59_2 = L53_2[5]
L58_2 = L58_2 * L59_2
L59_2 = L53_2[5]
L58_2 = L58_2 * L59_2
L57_2 = L57_2 + L58_2
L58_2 = L53_2[1]
L57_2 = L57_2 + L58_2
L58_2 = L53_2[1]
L59_2 = L53_2[5]
L58_2 = L58_2 + L59_2
L59_2 = L53_2[3]
L58_2 = L58_2 - L59_2
L59_2 = L53_2[4]
L58_2 = L58_2 + L59_2
L59_2 = L53_2[5]
L60_2 = L53_2[2]
L59_2 = L59_2 + L60_2
L60_2 = L53_2[1]
L61_2 = L53_2[4]
L60_2 = L60_2 * L61_2
L59_2 = L59_2 + L60_2
L60_2 = L53_2[1]
L59_2 = L59_2 - L60_2
L60_2 = L53_2[2]
L61_2 = L53_2[3]
L61_2 = L61_2 * 1
L60_2 = L60_2 + L61_2
L61_2 = L53_2[4]
L60_2 = L60_2 - L61_2
L61_2 = L53_2[5]
L62_2 = L53_2[1]
L63_2 = L53_2[2]
L62_2 = L62_2 * L63_2
L61_2 = L61_2 + L62_2
L62_2 = L53_2[3]
L61_2 = L61_2 + L62_2
L62_2 = L53_2[3]
L63_2 = L53_2[4]
L62_2 = L62_2 + L63_2
L63_2 = L53_2[1]
L64_2 = L53_2[2]
L63_2 = L63_2 * L64_2
L62_2 = L62_2 - L63_2
L63_2 = L53_2[5]
L62_2 = L62_2 + L63_2
L63_2 = L53_2[5]
L64_2 = L53_2[1]
L63_2 = L63_2 + L64_2
L64_2 = L53_2[2]
L63_2 = L63_2 - L64_2
L64_2 = L53_2[3]
L63_2 = L63_2 + L64_2
L64_2 = {}
L65_2 = L54_2
L66_2 = L55_2
L67_2 = L56_2
L68_2 = L57_2
L69_2 = L58_2
L70_2 = L59_2
L71_2 = L60_2
L72_2 = L61_2
L73_2 = L62_2
L74_2 = L63_2
L75_2 = L62_2
L76_2 = L60_2
L77_2 = L58_2
L78_2 = L57_2
L79_2 = L56_2
L80_2 = L63_2
L81_2 = L58_2
L82_2 = L57_2
L83_2 = L55_2
L84_2 = L56_2
L85_2 = L54_2
L86_2 = L62_2
L64_2[1] = L65_2
L64_2[2] = L66_2
L64_2[3] = L67_2
L64_2[4] = L68_2
L64_2[5] = L69_2
L64_2[6] = L70_2
L64_2[7] = L71_2
L64_2[8] = L72_2
L64_2[9] = L73_2
L64_2[10] = L74_2
L64_2[11] = L75_2
L64_2[12] = L76_2
L64_2[13] = L77_2
L64_2[14] = L78_2
L64_2[15] = L79_2
L64_2[16] = L80_2
L64_2[17] = L81_2
L64_2[18] = L82_2
L64_2[19] = L83_2
L64_2[20] = L84_2
L64_2[21] = L85_2
L64_2[22] = L86_2
PGFC1 = L64_2
while true do
	L64_2 = {}
	L65_2 = nil % nil
	L64_2[1] = L65_2
	i = L64_2
	L64_2 = ipairs
	L65_2 = i
	L64_2,L65_2,L66_2 = L64_2(L65_2)
	for L67_2 in L64_2,L65_2,L66_2 do
		L68_2 = {}
		L69_2 = {}
		L70_2 = nil % nil
		L69_2[1] = L70_2
		L70_2 = {}
		L71_2 = nil % nil
		L70_2[1] = L71_2
		L68_2[1] = L69_2
		L68_2[2] = L70_2
		L67_2 = L68_2
		L68_2 = {}
		L69_2 = nil % nil
		L68_2[1] = L69_2
		L68_2 = _ENV[L68_2]
		L67_2.i = L68_2
	end
end
function L64_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3
	L1_3 = {}
	KEY1 = L1_3
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = A0_3[L4_3]
		L6_3 = PGFC1
		L6_3 = L6_3[1]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[2]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[6]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[3]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[8]
		L7_3 = PGFC1
		L7_3 = L7_3[4]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[7]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[5]
		L7_3 = PGFC1
		L7_3 = L7_3[10]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[9]
		L7_3 = PGFC1
		L7_3 = L7_3[11]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[12]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[13]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[14]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[15]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[16]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[17]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[18]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[19]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC1
		L6_3 = L6_3[20]
		L5_3 = L5_3 - L6_3
		L5_3 = L5_3 % 256
		PGFUNCTION = L5_3
		L5_3 = table
		L5_3 = L5_3.insert
		L6_3 = KEY1
		L7_3 = PGFUNCTION
		L5_3(L6_3,L7_3)
	end
	L1_3 = KEY1
	return L1_3
end
PGPRON1 = L64_2
L64_2 = PGPRON1
L65_2 = PGFC1
L64_2(L65_2)
function L64_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3
	A0_3 = A0_3.PG
	res = ""
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = res
		L6_3 = string
		L6_3 = L6_3.char
		L7_3 = A0_3[L4_3]
		L8_3 = KEY1
		L8_3 = L8_3[1]
		L7_3 = L7_3 + L8_3
		L8_3 = KEY1
		L8_3 = L8_3[2]
		L8_3 = L8_3 + L4_3
		L9_3 = KEY1
		L9_3 = L9_3[3]
		L9_3 = L9_3 + L4_3
		L8_3 = L8_3 * L9_3
		L7_3 = L7_3 + L8_3
		L7_3 = L7_3 % 63836
		L6_3 = L6_3(L7_3)
		L5_3 = L5_3 .. L6_3
		res = L5_3
	end
	L1_3 = res
	return L1_3
end
PGENC_2 = L64_2
while true do
	L64_2 = {}
	L65_2 = nil % nil
	L64_2[1] = L65_2
	i = L64_2
	L64_2 = ipairs
	L65_2 = i
	L64_2,L65_2,L66_2 = L64_2(L65_2)
	for L67_2 in L64_2,L65_2,L66_2 do
		L68_2 = {}
		L69_2 = {}
		L70_2 = nil % nil
		L69_2[1] = L70_2
		L70_2 = {}
		L71_2 = nil % nil
		L70_2[1] = L71_2
		L68_2[1] = L69_2
		L68_2[2] = L70_2
		L67_2 = L68_2
		L68_2 = {}
		L69_2 = nil % nil
		L68_2[1] = L69_2
		L68_2 = _ENV[L68_2]
		L67_2.i = L68_2
	end
end
L64_2 = 99
L65_2 = keyyy10
L66_2 = 8271
L67_2 = 4817
L68_2 = 41
L69_2 = 9272
L70_2 = 2727
L71_2 = 3727
L72_2 = 4783
L73_2 = 9473
L74_2 = 4783
L75_2 = 8363
L76_2 = 26
L77_2 = 3073
L78_2 = 8362
L79_2 = 7392
L80_2 = 180
L81_2 = 7494
L82_2 = 22
L83_2 = 3728
L84_2 = 248
L85_2 = {}
L86_2 = L68_2 * L76_2
L86_2 = L64_2 + L86_2
L86_2 = L86_2 - L80_2
L87_2 = L68_2
L88_2 = L76_2 * 2
L89_2 = L80_2 + L76_2
L90_2 = L82_2
L85_2[1] = L86_2
L85_2[2] = L87_2
L85_2[3] = L88_2
L85_2[4] = L89_2
L85_2[5] = L90_2
L86_2 = L85_2[5]
L87_2 = L85_2[2]
L86_2 = L86_2 + L87_2
L87_2 = L85_2[1]
L88_2 = L85_2[4]
L87_2 = L87_2 * L88_2
L86_2 = L86_2 + L87_2
L87_2 = L85_2[1]
L86_2 = L86_2 - L87_2
L87_2 = L85_2[2]
L88_2 = L85_2[3]
L88_2 = L88_2 * 1
L87_2 = L87_2 + L88_2
L88_2 = L85_2[4]
L87_2 = L87_2 - L88_2
L88_2 = L85_2[3]
L89_2 = L85_2[1]
L90_2 = L85_2[2]
L89_2 = L89_2 * L90_2
L88_2 = L88_2 + L89_2
L89_2 = L85_2[4]
L88_2 = L88_2 + L89_2
L89_2 = L85_2[1]
L90_2 = L85_2[2]
L91_2 = L85_2[5]
L90_2 = L90_2 * L91_2
L91_2 = L85_2[5]
L90_2 = L90_2 * L91_2
L89_2 = L89_2 + L90_2
L90_2 = L85_2[1]
L89_2 = L89_2 + L90_2
L90_2 = L85_2[1]
L91_2 = L85_2[5]
L90_2 = L90_2 + L91_2
L91_2 = L85_2[3]
L90_2 = L90_2 - L91_2
L91_2 = L85_2[4]
L90_2 = L90_2 + L91_2
L91_2 = L85_2[5]
L92_2 = L85_2[2]
L91_2 = L91_2 + L92_2
L92_2 = L85_2[1]
L93_2 = L85_2[4]
L92_2 = L92_2 * L93_2
L91_2 = L91_2 + L92_2
L92_2 = L85_2[1]
L91_2 = L91_2 - L92_2
L92_2 = L85_2[2]
L93_2 = L85_2[3]
L93_2 = L93_2 * 1
L92_2 = L92_2 + L93_2
L93_2 = L85_2[4]
L92_2 = L92_2 - L93_2
L93_2 = L85_2[5]
L94_2 = L85_2[1]
L95_2 = L85_2[2]
L94_2 = L94_2 * L95_2
L93_2 = L93_2 + L94_2
L94_2 = L85_2[3]
L93_2 = L93_2 + L94_2
L94_2 = L85_2[3]
L95_2 = L85_2[4]
L94_2 = L94_2 + L95_2
L95_2 = L85_2[1]
L96_2 = L85_2[2]
L95_2 = L95_2 * L96_2
L94_2 = L94_2 - L95_2
L95_2 = L85_2[5]
L94_2 = L94_2 + L95_2
L95_2 = L85_2[5]
L96_2 = L85_2[1]
L95_2 = L95_2 + L96_2
L96_2 = L85_2[2]
L95_2 = L95_2 - L96_2
L96_2 = L85_2[3]
L95_2 = L95_2 + L96_2
L96_2 = {}
L97_2 = L86_2
L98_2 = L87_2
L99_2 = L88_2
L100_2 = L89_2
L101_2 = L90_2
L102_2 = L91_2
L103_2 = L92_2
L104_2 = L93_2
L105_2 = L94_2
L106_2 = L95_2
L107_2 = L94_2
L108_2 = L92_2
L109_2 = L90_2
L110_2 = L89_2
L111_2 = L88_2
L112_2 = L95_2
L113_2 = L90_2
L114_2 = L89_2
L115_2 = L87_2
L116_2 = L88_2
L117_2 = L86_2
L118_2 = L94_2
L96_2[1] = L97_2
L96_2[2] = L98_2
L96_2[3] = L99_2
L96_2[4] = L100_2
L96_2[5] = L101_2
L96_2[6] = L102_2
L96_2[7] = L103_2
L96_2[8] = L104_2
L96_2[9] = L105_2
L96_2[10] = L106_2
L96_2[11] = L107_2
L96_2[12] = L108_2
L96_2[13] = L109_2
L96_2[14] = L110_2
L96_2[15] = L111_2
L96_2[16] = L112_2
L96_2[17] = L113_2
L96_2[18] = L114_2
L96_2[19] = L115_2
L96_2[20] = L116_2
L96_2[21] = L117_2
L96_2[22] = L118_2
PGFC2 = L96_2
while true do
	L96_2 = {}
	L97_2 = nil % nil
	L96_2[1] = L97_2
	i = L96_2
	L96_2 = ipairs
	L97_2 = i
	L96_2,L97_2,L98_2 = L96_2(L97_2)
	for L99_2 in L96_2,L97_2,L98_2 do
		L100_2 = {}
		L101_2 = {}
		L102_2 = nil % nil
		L101_2[1] = L102_2
		L102_2 = {}
		L103_2 = nil % nil
		L102_2[1] = L103_2
		L100_2[1] = L101_2
		L100_2[2] = L102_2
		L99_2 = L100_2
		L100_2 = {}
		L101_2 = nil % nil
		L100_2[1] = L101_2
		L100_2 = _ENV[L100_2]
		L99_2.i = L100_2
	end
end
function L96_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3
	L1_3 = {}
	KEY2 = L1_3
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = A0_3[L4_3]
		L6_3 = PGFC2
		L6_3 = L6_3[1]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[2]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[6]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[3]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[8]
		L7_3 = PGFC2
		L7_3 = L7_3[4]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[7]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[5]
		L7_3 = PGFC2
		L7_3 = L7_3[10]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[9]
		L7_3 = PGFC2
		L7_3 = L7_3[11]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[12]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[13]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[14]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[15]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[16]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[17]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[18]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[19]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC2
		L6_3 = L6_3[20]
		L5_3 = L5_3 - L6_3
		L5_3 = L5_3 % 256
		PGFUNCTION = L5_3
		L5_3 = table
		L5_3 = L5_3.insert
		L6_3 = KEY2
		L7_3 = PGFUNCTION
		L5_3(L6_3,L7_3)
	end
	L1_3 = KEY2
	return L1_3
end
PGPRON2 = L96_2
L96_2 = PGPRON2
L97_2 = PGFC2
L96_2(L97_2)
function L96_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3
	A0_3 = A0_3.PG
	res = ""
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = res
		L6_3 = string
		L6_3 = L6_3.char
		L7_3 = A0_3[L4_3]
		L7_3 = #L7_3
		L8_3 = KEY2
		L8_3 = L8_3[1]
		L7_3 = L7_3 + L8_3
		L8_3 = KEY2
		L8_3 = L8_3[2]
		L8_3 = L8_3 + L4_3
		L9_3 = KEY2
		L9_3 = L9_3[3]
		L9_3 = L9_3 + L4_3
		L8_3 = L8_3 * L9_3
		L7_3 = L7_3 + L8_3
		L7_3 = L7_3 % 256
		L6_3 = L6_3(L7_3)
		L5_3 = L5_3 .. L6_3
		res = L5_3
	end
	L1_3 = res
	return L1_3
end
PGENC_3 = L96_2
while true do
	L96_2 = {}
	L97_2 = nil % nil
	L96_2[1] = L97_2
	i = L96_2
	L96_2 = ipairs
	L97_2 = i
	L96_2,L97_2,L98_2 = L96_2(L97_2)
	for L99_2 in L96_2,L97_2,L98_2 do
		L100_2 = {}
		L101_2 = {}
		L102_2 = nil % nil
		L101_2[1] = L102_2
		L102_2 = {}
		L103_2 = nil % nil
		L102_2[1] = L103_2
		L100_2[1] = L101_2
		L100_2[2] = L102_2
		L99_2 = L100_2
		L100_2 = {}
		L101_2 = nil % nil
		L100_2[1] = L101_2
		L100_2 = _ENV[L100_2]
		L99_2.i = L100_2
	end
end
L96_2 = 60
L97_2 = keyyyy10
L98_2 = 8271
L99_2 = 4817
L100_2 = 143
L101_2 = 9272
L102_2 = 2727
L103_2 = 3727
L104_2 = 4783
L105_2 = 9473
L106_2 = 4783
L107_2 = 8363
L108_2 = 157
L109_2 = 3073
L110_2 = 8362
L111_2 = 7392
L112_2 = 156
L113_2 = 7494
L114_2 = 171
L115_2 = 3728
L116_2 = 37
L117_2 = {}
L118_2 = L100_2 * L108_2
L118_2 = L96_2 + L118_2
L118_2 = L118_2 - L112_2
L119_2 = L100_2
L120_2 = L108_2 * 2
L121_2 = L112_2 + L108_2
L122_2 = L114_2
L117_2[1] = L118_2
L117_2[2] = L119_2
L117_2[3] = L120_2
L117_2[4] = L121_2
L117_2[5] = L122_2
L118_2 = L117_2[5]
L119_2 = L117_2[2]
L118_2 = L118_2 + L119_2
L119_2 = L117_2[1]
L120_2 = L117_2[4]
L119_2 = L119_2 * L120_2
L118_2 = L118_2 + L119_2
L119_2 = L117_2[1]
L118_2 = L118_2 - L119_2
L119_2 = L117_2[2]
L120_2 = L117_2[3]
L120_2 = L120_2 * 1
L119_2 = L119_2 + L120_2
L120_2 = L117_2[4]
L119_2 = L119_2 - L120_2
L120_2 = L117_2[3]
L121_2 = L117_2[1]
L122_2 = L117_2[2]
L121_2 = L121_2 * L122_2
L120_2 = L120_2 + L121_2
L121_2 = L117_2[4]
L120_2 = L120_2 + L121_2
L121_2 = L117_2[1]
L122_2 = L117_2[2]
L123_2 = L117_2[5]
L122_2 = L122_2 * L123_2
L123_2 = L117_2[5]
L122_2 = L122_2 * L123_2
L121_2 = L121_2 + L122_2
L122_2 = L117_2[1]
L121_2 = L121_2 + L122_2
L122_2 = L117_2[1]
L123_2 = L117_2[5]
L122_2 = L122_2 + L123_2
L123_2 = L117_2[3]
L122_2 = L122_2 - L123_2
L123_2 = L117_2[4]
L122_2 = L122_2 + L123_2
L123_2 = L117_2[5]
L124_2 = L117_2[2]
L123_2 = L123_2 + L124_2
L124_2 = L117_2[1]
L125_2 = L117_2[4]
L124_2 = L124_2 * L125_2
L123_2 = L123_2 + L124_2
L124_2 = L117_2[1]
L123_2 = L123_2 - L124_2
L124_2 = L117_2[2]
L125_2 = L117_2[3]
L125_2 = L125_2 * 1
L124_2 = L124_2 + L125_2
L125_2 = L117_2[4]
L124_2 = L124_2 - L125_2
L125_2 = L117_2[5]
L126_2 = L117_2[1]
L127_2 = L117_2[2]
L126_2 = L126_2 * L127_2
L125_2 = L125_2 + L126_2
L126_2 = L117_2[3]
L125_2 = L125_2 + L126_2
L126_2 = L117_2[3]
L127_2 = L117_2[4]
L126_2 = L126_2 + L127_2
L127_2 = L117_2[1]
L128_2 = L117_2[2]
L127_2 = L127_2 * L128_2
L126_2 = L126_2 - L127_2
L127_2 = L117_2[5]
L126_2 = L126_2 + L127_2
L127_2 = L117_2[5]
L128_2 = L117_2[1]
L127_2 = L127_2 + L128_2
L128_2 = L117_2[2]
L127_2 = L127_2 - L128_2
L128_2 = L117_2[3]
L127_2 = L127_2 + L128_2
L128_2 = {}
L129_2 = L118_2
L130_2 = L119_2
L131_2 = L120_2
L132_2 = L121_2
L133_2 = L122_2
L134_2 = L123_2
L135_2 = L124_2
L136_2 = L125_2
L137_2 = L126_2
L138_2 = L127_2
L139_2 = L126_2
L140_2 = L124_2
L141_2 = L122_2
L142_2 = L121_2
L143_2 = L120_2
L144_2 = L127_2
L145_2 = L122_2
L146_2 = L121_2
L147_2 = L119_2
L148_2 = L120_2
L149_2 = L118_2
L150_2 = L126_2
L128_2[1] = L129_2
L128_2[2] = L130_2
L128_2[3] = L131_2
L128_2[4] = L132_2
L128_2[5] = L133_2
L128_2[6] = L134_2
L128_2[7] = L135_2
L128_2[8] = L136_2
L128_2[9] = L137_2
L128_2[10] = L138_2
L128_2[11] = L139_2
L128_2[12] = L140_2
L128_2[13] = L141_2
L128_2[14] = L142_2
L128_2[15] = L143_2
L128_2[16] = L144_2
L128_2[17] = L145_2
L128_2[18] = L146_2
L128_2[19] = L147_2
L128_2[20] = L148_2
L128_2[21] = L149_2
L128_2[22] = L150_2
PGFC3 = L128_2
while true do
	L128_2 = {}
	L129_2 = nil % nil
	L128_2[1] = L129_2
	i = L128_2
	L128_2 = ipairs
	L129_2 = i
	L128_2,L129_2,L130_2 = L128_2(L129_2)
	for L131_2 in L128_2,L129_2,L130_2 do
		L132_2 = {}
		L133_2 = {}
		L134_2 = nil % nil
		L133_2[1] = L134_2
		L134_2 = {}
		L135_2 = nil % nil
		L134_2[1] = L135_2
		L132_2[1] = L133_2
		L132_2[2] = L134_2
		L131_2 = L132_2
		L132_2 = {}
		L133_2 = nil % nil
		L132_2[1] = L133_2
		L132_2 = _ENV[L132_2]
		L131_2.i = L132_2
	end
end
function L128_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3
	L1_3 = {}
	KEY3 = L1_3
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = A0_3[L4_3]
		L6_3 = PGFC3
		L6_3 = L6_3[1]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[2]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[6]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[3]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[8]
		L7_3 = PGFC3
		L7_3 = L7_3[4]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[7]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[5]
		L7_3 = PGFC3
		L7_3 = L7_3[10]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[9]
		L7_3 = PGFC3
		L7_3 = L7_3[11]
		L6_3 = L6_3 * L7_3
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[12]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[13]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[14]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[15]
		L5_3 = L5_3 + L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[16]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[17]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[18]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[19]
		L5_3 = L5_3 - L6_3
		L6_3 = PGFC3
		L6_3 = L6_3[20]
		L5_3 = L5_3 - L6_3
		L5_3 = L5_3 % 256
		PGFUNCTION = L5_3
		L5_3 = table
		L5_3 = L5_3.insert
		L6_3 = KEY3
		L7_3 = PGFUNCTION
		L5_3(L6_3,L7_3)
	end
	L1_3 = KEY3
	return L1_3
end
PGPRON3 = L128_2
L128_2 = PGPRON3
L129_2 = PGFC3
L128_2(L129_2)
function L128_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3
	A0_3 = A0_3.PG
	res = ""
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = res
		L6_3 = string
		L6_3 = L6_3.char
		L7_3 = A0_3[L4_3]
		L8_3 = KEY3
		L8_3 = L8_3[1]
		L7_3 = L7_3 + L8_3
		L8_3 = KEY3
		L8_3 = L8_3[2]
		L8_3 = L8_3 + L4_3
		L9_3 = KEY3
		L9_3 = L9_3[3]
		L9_3 = L9_3 + L4_3
		L8_3 = L8_3 * L9_3
		L7_3 = L7_3 + L8_3
		L7_3 = L7_3 % 53838
		L6_3 = L6_3(L7_3)
		L5_3 = L5_3 .. L6_3
		res = L5_3
	end
	L1_3 = res
	return L1_3
end
PGENC_4 = L128_2
function L128_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3
	A0_3 = A0_3.PG
	res = ""
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = res
		L6_3 = string
		L6_3 = L6_3.char
		L7_3 = A0_3[L4_3]
		L7_3 = #L7_3
		L8_3 = KEY
		L8_3 = L8_3[5]
		L7_3 = L7_3 + L8_3
		L8_3 = KEY
		L8_3 = L8_3[6]
		L8_3 = L8_3 + L4_3
		L9_3 = KEY
		L9_3 = L9_3[7]
		L9_3 = L9_3 + L4_3
		L8_3 = L8_3 * L9_3
		L7_3 = L7_3 + L8_3
		L7_3 = L7_3 % 256
		L6_3 = L6_3(L7_3)
		L5_3 = L5_3 .. L6_3
		res = L5_3
	end
	L1_3 = res
	return L1_3
end
PGENC_5 = L128_2
function L128_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3
	A0_3 = A0_3.PG
	res = ""
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = res
		L6_3 = string
		L6_3 = L6_3.char
		L7_3 = A0_3[L4_3]
		L8_3 = KEY1
		L8_3 = L8_3[3]
		L7_3 = L7_3 + L8_3
		L8_3 = KEY1
		L8_3 = L8_3[4]
		L8_3 = L8_3 + L4_3
		L9_3 = KEY1
		L9_3 = L9_3[6]
		L9_3 = L9_3 + L4_3
		L8_3 = L8_3 * L9_3
		L7_3 = L7_3 + L8_3
		L7_3 = L7_3 % 53838
		L6_3 = L6_3(L7_3)
		L5_3 = L5_3 .. L6_3
		res = L5_3
	end
	L1_3 = res
	return L1_3
end
PGENC_6 = L128_2
function L128_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3
	A0_3 = A0_3.PG
	res = ""
	L1_3 = ipairs
	L2_3 = A0_3
	L1_3,L2_3,L3_3 = L1_3(L2_3)
	for L4_3 in L1_3,L2_3,L3_3 do
		L5_3 = res
		L6_3 = string
		L6_3 = L6_3.char
		L7_3 = A0_3[L4_3]
		L7_3 = #L7_3
		L8_3 = KEY3
		L8_3 = L8_3[3]
		L7_3 = L7_3 + L8_3
		L8_3 = KEY3
		L8_3 = L8_3[4]
		L8_3 = L8_3 + L4_3
		L9_3 = KEY3
		L9_3 = L9_3[5]
		L9_3 = L9_3 + L4_3
		L8_3 = L8_3 * L9_3
		L7_3 = L7_3 + L8_3
		L7_3 = L7_3 % 256
		L6_3 = L6_3(L7_3)
		L5_3 = L5_3 .. L6_3
		res = L5_3
	end
	L1_3 = res
	return L1_3
end
PGENC_7 = L128_2
function L128_2(A0_3)
	local L1_3,L2_3,L3_3
	L1_3 = nil
	if L1_3 then
		function L1_3()
			local L0_4,L1_4
		end
		L1_3()
	end
	L1_3 = {}
	L2_3 = {}
	L3_3 = 155
	L2_3[1] = L3_3
	L1_3[1] = L2_3
	L2_3 = {}
	L3_3 = 255
	L2_3[1] = L3_3
	L1_3[2] = L2_3
	L2_3 = {}
	L3_3 = 55
	L2_3[1] = L3_3
	L1_3[3] = L2_3
	L2_3 = {}
	L3_3 = 71
	L2_3[1] = L3_3
	L1_3[4] = L2_3
	L2_3 = {}
	L3_3 = 3
	L2_3[1] = L3_3
	L1_3[5] = L2_3
	L2_3 = {}
	L3_3 = 59
	L2_3[1] = L3_3
	L1_3[6] = L2_3
	L2_3 = {}
	L3_3 = 251
	L2_3[1] = L3_3
	L1_3[7] = L2_3
	L2_3 = {}
	L3_3 = 227
	L2_3[1] = L3_3
	L1_3[8] = L2_3
	L2_3 = {}
	L3_3 = 87
	L2_3[1] = L3_3
	L1_3[9] = L2_3
	L2_3 = {}
	L3_3 = 163
	L2_3[1] = L3_3
	L1_3[10] = L2_3
	function L2_3(A0_4)
		local L1_4,L2_4,L3_4,L4_4,L5_4,L6_4,L7_4,L8_4,L9_4,L10_4,L11_4,L12_4,L13_4,L14_4,L15_4,L16_4,L17_4,L18_4,L19_4,L20_4
		L1_4 = nil
		if L1_4 then
			function L1_4()
				local L0_5,L1_5
			end
			L1_4()
		end
		function L1_4(A0_5,A1_5)
			local L2_5
			L2_5 = A0_5 - A1_5
			return L2_5
		end
		function L2_4(A0_5,A1_5)
			local L2_5
			L2_5 = A0_5 + A1_5
			return L2_5
		end
		L3_4 = 9
		L4_4 = 7
		L5_4 = 1
		L6_4 = 0
		L7_4 = 75271
		L8_4 = 41
		L9_4 = 0
		L10_4 = L1_4
		L11_4 = L3_4
		L12_4 = L4_4
		L10_4 = L10_4(L11_4,L12_4)
		L11_4 = L2_4
		L12_4 = L6_4
		L13_4 = L5_4
		L11_4 = L11_4(L12_4,L13_4)
		L12_4 = L10_4 - L11_4
		L12_4 = L12_4 + L5_4
		L12_4 = L12_4 - L5_4
		L13_4 = {}
		L14_4 = 1
		L15_4 = #A0_4
		L16_4 = 1
		for L17_4 = L14_4,L15_4,L16_4 do
			L18_4 = A0_4[L17_4]
			L18_4 = L18_4[L12_4]
			L19_4 = KEY3
			L19_4 = L19_4[5]
			L18_4 = L18_4 - L19_4
			L19_4 = KEY3
			L19_4 = L19_4[7]
			L18_4 = L18_4 + L19_4
			L19_4 = KEY3
			L19_4 = L19_4[9]
			L20_4 = KEY3
			L20_4 = L20_4[5]
			L19_4 = L19_4 * L20_4
			L18_4 = L18_4 - L19_4
			L19_4 = KEY3
			L19_4 = L19_4[2]
			L18_4 = L18_4 - L19_4
			L19_4 = KEY3
			L19_4 = L19_4[1]
			L18_4 = L18_4 + L19_4
			L18_4 = L18_4 % 256
			L13_4.O = L18_4
			L18_4 = table
			L18_4 = L18_4.insert
			L19_4 = L13_4
			L20_4 = L13_4.O
			L18_4(L19_4,L20_4)
		end
		return L13_4
	end
	Dc = L2_3
	L2_3 = Dc
	L3_3 = L1_3
	return L2_3(L3_3)
end
L129_2 = L128_2
L129_2 = L129_2()
L128_2 = L129_2
function L129_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3,L12_3,L13_3,L14_3,L15_3,L16_3,L17_3,L18_3,L19_3,L20_3
	L1_3 = nil
	if L1_3 then
		function L1_3()
			local L0_4,L1_4
		end
		L1_3()
	end
	function L1_3(A0_4,A1_4)
		local L2_4
		L2_4 = A0_4 - A1_4
		return L2_4
	end
	function L2_3(A0_4,A1_4)
		local L2_4
		L2_4 = nil
		if L2_4 then
			function L2_4()
				local L0_5,L1_5
			end
			L2_4()
		end
		L2_4 = A0_4 + A1_4
		return L2_4
	end
	L3_3 = 9
	L4_3 = 7
	L5_3 = 1
	L6_3 = 0
	L7_3 = 75271
	L8_3 = 41
	L9_3 = 0
	L10_3 = L1_3
	L11_3 = L3_3
	L12_3 = L4_3
	L10_3 = L10_3(L11_3,L12_3)
	L11_3 = L2_3
	L12_3 = L6_3
	L13_3 = L5_3
	L11_3 = L11_3(L12_3,L13_3)
	L12_3 = L10_3 - L11_3
	L12_3 = L12_3 + L5_3
	L12_3 = L12_3 - L5_3
	A0_3 = A0_3.PG
	L13_3 = {}
	L14_3 = ipairs
	L15_3 = A0_3
	L14_3,L15_3,L16_3 = L14_3(L15_3)
	for L17_3 in L14_3,L15_3,L16_3 do
		L18_3 = A0_3[L17_3]
		L18_3 = L18_3[L12_3]
		L18_3 = #L18_3
		L19_3 = L128_2[1]
		L18_3 = L18_3 - L19_3
		L19_3 = L128_2[2]
		L18_3 = L18_3 + L19_3
		L19_3 = L128_2[6]
		L18_3 = L18_3 - L19_3
		L19_3 = L128_2[3]
		L18_3 = L18_3 + L19_3
		L19_3 = L128_2[8]
		L20_3 = L128_2[4]
		L19_3 = L19_3 * L20_3
		L18_3 = L18_3 - L19_3
		L19_3 = L128_2[7]
		L18_3 = L18_3 + L19_3
		L19_3 = L128_2[5]
		L20_3 = L128_2[10]
		L19_3 = L19_3 * L20_3
		L18_3 = L18_3 - L19_3
		L19_3 = L128_2[9]
		L18_3 = L18_3 + L19_3
		L18_3 = L18_3 % 256
		L13_3.hi = L18_3
		L18_3 = table
		L18_3 = L18_3.insert
		L19_3 = L13_3
		L20_3 = L13_3.hi
		L18_3(L19_3,L20_3)
	end
	L14_3 = string
	L14_3 = L14_3.char
	L15_3 = table
	L15_3 = L15_3.unpack
	L16_3 = L13_3
	L15_3,L16_3,L17_3,L18_3,L19_3,L20_3 = L15_3(L16_3)
	return L14_3(L15_3,L16_3,L17_3,L18_3,L19_3,L20_3)
end
PGENC_8 = L129_2
while true do
	L129_2 = {}
	L130_2 = PG
	L131_2 = PGENC
	L131_2 = L131_2.PGENC
	L132_2 = fPGENC
	L132_2 = L132_2.PGENCAQ
	L132_2 = L132_2.AQ
	L133_2 = PGENC
	L133_2 = L133_2.PGENC
	L134_2 = PGENC
	L134_2 = L134_2.PGENCPG
	L135_2 = PGENC
	L135_2 = L135_2.PGENC
	L136_2 = PGENC
	L136_2 = L136_2.PGENCAQ
	L136_2 = L136_2.AQ
	L137_2 = PGENC
	L137_2 = L137_2.PGENC
	L138_2 = PGENC
	L138_2 = L138_2.PGENC
	L129_2[1] = L130_2
	L129_2[2] = L131_2
	L129_2[3] = L132_2
	L129_2[4] = L133_2
	L129_2[5] = L134_2
	L129_2[6] = L135_2
	L129_2[7] = L136_2
	L129_2[8] = L137_2
	L129_2[9] = L138_2
	L130_2 = {}
	L131_2 = L129_2.AQ
	L132_2 = PGENC
	L132_2 = L132_2.PGENC
	L133_2 = PGENC
	L133_2 = L133_2.PGENCAQyPG
	L134_2 = PGENC
	L134_2 = L134_2.PGENC
	L135_2 = PGENC
	L135_2 = L135_2.PGENCAQ
	L135_2 = L135_2.AQ
	L136_2 = PGENC
	L136_2 = L136_2.PGENC
	L137_2 = PGENC
	L137_2 = L137_2.PGENC
	L137_2 = L137_2.AQ
	L138_2 = PGENC
	L138_2 = L138_2.sPGENC
	L139_2 = PGENC
	L139_2 = L139_2.PGENC
	L130_2[1] = L131_2
	L130_2[2] = L132_2
	L130_2[3] = L133_2
	L130_2[4] = L134_2
	L130_2[5] = L135_2
	L130_2[6] = L136_2
	L130_2[7] = L137_2
	L130_2[8] = L138_2
	L130_2[9] = L139_2
	L131_2 = {}
	L132_2 = L129_2.AQ
	L133_2 = L130_2.PGENC
	L134_2 = L130_2.PGENCPG
	L135_2 = L130_2.PGENC
	L136_2 = L130_2.PGENCAQ
	L136_2 = L136_2.AQ
	L137_2 = L130_2.PGENC
	L138_2 = L130_2.PGENCAQ
	L138_2 = L138_2.AQ
	L139_2 = L130_2.PGENC
	L140_2 = L130_2.PGENCi
	L131_2[1] = L132_2
	L131_2[2] = L133_2
	L131_2[3] = L134_2
	L131_2[4] = L135_2
	L131_2[5] = L136_2
	L131_2[6] = L137_2
	L131_2[7] = L138_2
	L131_2[8] = L139_2
	L131_2[9] = L140_2
	L132_2 = {}
	L133_2 = PG
	L134_2 = L131_2.PGENC
	L135_2 = L131_2.PGENCAQ
	L135_2 = L135_2.AQ
	L136_2 = L131_2.PGENCAQAQ
	L137_2 = L131_2.PGENCPG
	L138_2 = L131_2.PGENC
	L139_2 = L131_2.PGENCAQ
	L139_2 = L139_2.AQ
	L140_2 = L131_2.PGENC
	L141_2 = L131_2.PGENC
	L132_2[1] = L133_2
	L132_2[2] = L134_2
	L132_2[3] = L135_2
	L132_2[4] = L136_2
	L132_2[5] = L137_2
	L132_2[6] = L138_2
	L132_2[7] = L139_2
	L132_2[8] = L140_2
	L132_2[9] = L141_2
	L133_2 = {}
	L134_2 = L132_2.AQ
	L135_2 = L131_2.PGENC
	L136_2 = PGENCw
	L136_2 = L136_2.PGENCAQPG
	L137_2 = L131_2.PGENC
	L138_2 = L131_2.PGENCAQ
	L138_2 = L138_2.AQ
	L139_2 = L131_2.PGENC
	L140_2 = L131_2.PGENC
	L140_2 = L140_2.AQ
	L141_2 = L131_2.sPGENC
	L142_2 = L131_2.PGENC
	L133_2[1] = L134_2
	L133_2[2] = L135_2
	L133_2[3] = L136_2
	L133_2[4] = L137_2
	L133_2[5] = L138_2
	L133_2[6] = L139_2
	L133_2[7] = L140_2
	L133_2[8] = L141_2
	L133_2[9] = L142_2
	L134_2 = {}
	L135_2 = L132_2.AQ
	L136_2 = L133_2.PGENC
	L137_2 = L133_2.PGENCPG
	L138_2 = L133_2.PGENC
	L139_2 = L133_2.PGENCbAQ
	L139_2 = L139_2.AQ
	L140_2 = L133_2.PGENC
	L141_2 = L133_2.PGENCAQ
	L141_2 = L141_2.AQ
	L142_2 = L133_2.PGENC
	L143_2 = L133_2.PGENCi
	L134_2[1] = L135_2
	L134_2[2] = L136_2
	L134_2[3] = L137_2
	L134_2[4] = L138_2
	L134_2[5] = L139_2
	L134_2[6] = L140_2
	L134_2[7] = L141_2
	L134_2[8] = L142_2
	L134_2[9] = L143_2
	L135_2 = L132_2.AQ
	if L135_2 then
		L135_2 = L132_2.AQ
		L135_2 = L135_2.AQ
		if L135_2 then
			L135_2 = L132_2.AQ
			L135_2 = L135_2.AQ
			L135_2 = L135_2.AQ
			if L135_2 then
				L135_2 = L132_2.AQ
				L135_2 = L135_2.AQ
				L135_2 = L135_2.AQ
				L135_2 = L135_2.AQ
				if L135_2 then
					L135_2 = L134_2.PGENC
					if L135_2 then
						L135_2 = L134_2.PGENC
						L135_2 = L135_2.PGENC
						if L135_2 then
							L135_2 = L134_2.PGENC
							L135_2 = L135_2.PGENC
							L135_2 = L135_2.PGENC
							if L135_2 then
								L135_2 = L134_2.PGENC
								if L135_2 then
									L135_2 = L134_2.PGENC
									L135_2 = L135_2.PGENC
									if L135_2 then
										L135_2 = L134_2.PGENC
										L135_2 = L135_2.PGENC
										L135_2 = L135_2.PGENC
										if L135_2 then
											L135_2 = L132_2.AQ
											L136_2 = L132_2
											L135_2 = L135_2(L136_2)
											L132_2.AQ = L135_2
											L135_2 = L132_2.AQ
											L136_2 = L132_2.AQ
											L136_2 = L136_2.AQ
											L137_2 = L132_2.AQ
											L138_2 = L132_2
											L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2)
											L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L135_2 = L135_2(L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L132_2.AQ = L135_2
											L135_2 = L134_2.PGENC
											L136_2 = L134_2
											L135_2 = L135_2(L136_2)
											L134_2.PGENC = L135_2
											L135_2 = L134_2.PGENC
											L136_2 = L134_2.PGENC
											L136_2 = L136_2.PGENC
											L137_2 = L134_2.PGENC
											L137_2 = L137_2.PGENC
											L137_2 = L137_2.PGENC
											L138_2 = L134_2.PGENC
											L138_2 = L138_2.PGENC
											L139_2 = L134_2.PGENC
											L140_2 = L134_2.PGENC
											L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L139_2(L140_2)
											L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L135_2 = L135_2(L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L134_2.PGENC = L135_2
											L135_2 = L134_2.PGENC
											L136_2 = L134_2.PGENC
											L136_2 = L136_2.PGENC
											L137_2 = L134_2.PGENC
											L137_2 = L137_2.PGENC
											L137_2 = L137_2.PGENC
											L138_2 = L134_2.PGENC
											L138_2 = L138_2.PGENC
											L139_2 = L134_2.PGENC
											L140_2 = L134_2.PGENC
											L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L139_2(L140_2)
											L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L135_2 = L135_2(L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L134_2.PGENC = L135_2
											L135_2 = L132_2.AQ
											L136_2 = L132_2
											L135_2 = L135_2(L136_2)
											L132_2.AQ = L135_2
											L135_2 = L132_2.AQ
											L136_2 = L132_2.AQ
											L136_2 = L136_2.AQ
											L137_2 = L132_2.AQ
											L138_2 = L132_2
											L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2)
											L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L135_2 = L135_2(L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L132_2.AQ = L135_2
											L135_2 = L134_2.PGENC
											L136_2 = L134_2
											L135_2 = L135_2(L136_2)
											L134_2.PGENC = L135_2
											L135_2 = L134_2.PGENC
											L136_2 = L134_2.PGENC
											L136_2 = L136_2.PGENC
											L137_2 = L134_2.PGENC
											L137_2 = L137_2.PGENC
											L137_2 = L137_2.PGENC
											L138_2 = L134_2.PGENC
											L138_2 = L138_2.PGENC
											L139_2 = L134_2.PGENC
											L140_2 = L134_2.PGENC
											L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L139_2(L140_2)
											L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L135_2 = L135_2(L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L134_2.PGENC = L135_2
											L135_2 = L134_2.PGENC
											L136_2 = L134_2.PGENC
											L136_2 = L136_2.PGENC
											L137_2 = L134_2.PGENC
											L137_2 = L137_2.PGENC
											L137_2 = L137_2.PGENC
											L138_2 = L134_2.PGENC
											L138_2 = L138_2.PGENC
											L139_2 = L134_2.PGENC
											L140_2 = L134_2.PGENC
											L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L139_2(L140_2)
											L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L135_2 = L135_2(L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L134_2.PGENC = L135_2
											L135_2 = {}
											L136_2 = L132_2.AQ
											L137_2 = L134_2.PGENC
											L138_2 = L134_2.PGENCAQ
											L138_2 = L138_2.AQ
											L139_2 = L134_2.PGENC
											L140_2 = L134_2.PGENC
											L135_2[1] = L136_2
											L135_2[2] = L137_2
											L135_2[3] = L138_2
											L135_2[4] = L139_2
											L135_2[5] = L140_2
											L136_2 = L135_2[1]
											L137_2 = L135_2[2]
											L138_2 = L135_2[3]
											L136_2 = L136_2 .. L137_2 .. L138_2
											L135_2.PGENCAQAQ = L136_2
											L136_2 = L135_2.PGENCAQAQ
											L137_2 = L135_2.PGENCAQAQ
											L138_2 = L135_2.PGENCAQAQ
											L139_2 = L135_2.PGENCAQAQ
											L140_2 = L135_2.PGENCAQAQ
											L141_2 = L135_2.PGENCAQAQ
											L142_2 = L135_2.PGENCAQAQ
											L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L141_2(L142_2)
											L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L140_2(L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L139_2(L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L136_2 = L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
											L135_2.i = L136_2
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end
while true do
	L129_2 = i
	L130_2 = i
	L131_2 = 1
	for L132_2 = L129_2,L130_2,L131_2 do
		L133_2 = {}
		L134_2 = L133_2.i
		if L134_2 then
			L134_2 = L133_2.i
			L135_2 = L133_2
			L134_2 = L134_2(L135_2)
			L133_2.i = L134_2
		end
		L134_2 = L133_2.i
		L135_2 = L133_2.i
		L136_2 = L133_2.i
		for L137_2 = L134_2,L135_2,L136_2 do
			L138_2 = {}
			L139_2 = L138_2.i
			if L139_2 then
				L139_2 = L138_2.i
				L139_2 = L139_2()
				L138_2.i = L139_2
			end
			L139_2 = L133_2
			L140_2 = L138_2.i
			L141_2 = L133_2
			for L142_2 = L139_2,L140_2,L141_2 do
				L143_2 = {}
				L144_2 = L143_2.i
				if L144_2 then
					L144_2 = L143_2.i
					L145_2 = L133_2
					L144_2 = L144_2(L145_2)
					L143_2.i = L144_2
				end
				L144_2 = L133_2
				L145_2 = L138_2
				L146_2 = L143_2.i
				for L147_2 = L144_2,L145_2,L146_2 do
					L148_2 = {}
					L149_2 = L148_2.i
					if L149_2 then
						L149_2 = L148_2.i
						L150_2 = L133_2
						L149_2 = L149_2(L150_2)
						L148_2.i = L149_2
					end
					L149_2 = {}
					L150_2 = L149_2.i
					if L150_2 then
						L150_2 = L149_2 | L143_2
						L150_2 = L150_2 | L138_2
						L150_2 = L150_2 | L133_2
						L151_2 = L133_2
						L150_2 = L150_2(L151_2)
						L149_2.i = L150_2
					end
				end
				L144_2 = {}
				L145_2 = L144_2.i
				if L145_2 then
					L145_2 = true | L144_2
					L145_2 = L145_2 | L138_2
					L145_2 = L145_2 | L133_2
					L146_2 = L133_2
					L145_2 = L145_2(L146_2)
					L144_2.i = L145_2
				end
			end
			L139_2 = {}
			L140_2 = L139_2.i
			if L140_2 then
				L140_2 = true | false
				L140_2 = L140_2 | L139_2
				L140_2 = L140_2 | L133_2
				L141_2 = L133_2
				L140_2 = L140_2(L141_2)
				L139_2.i = L140_2
			end
		end
		L134_2 = {}
		L135_2 = L134_2.i
		if L135_2 then
			L135_2 = true | false
			L135_2 = L135_2 | nil
			L135_2 = L135_2 | L134_2
			L136_2 = L134_2
			L135_2 = L135_2(L136_2)
			L134_2.i = L135_2
		end
		L135_2 = true | false
		L135_2 = L135_2 | nil
		return L135_2
	end
	return
end
L129_2 = 1
L130_2 = 0
L131_2 = 1
for L132_2 = L129_2,L130_2,L131_2 do
	L133_2 = {}
	L134_2 = L133_2.data
	L134_2 = L134_2()
	L133_2.sel = L134_2
	L134_2 = L133_2.data
	if L134_2 ~= nil then
		L134_2 = L133_2.data
		L134_2 = L134_2()
		L133_2.sel = L134_2
	end
	L133_2 = nil
end
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_1 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_3 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_3 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_4 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_5 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_6 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_7 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_8 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_9 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_10 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_11 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_12 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_13 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_14 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_15 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_16 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_17 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_18 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_19 = L129_2
function L129_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_20 = L129_2
L129_2 = 12
L130_2 = 91
L131_2 = nil
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_1 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_3 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_3 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_4 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_5 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_6 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_7 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_8 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_9 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_10 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_11 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_12 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_13 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_14 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_15 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_16 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_17 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_18 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_19 = L132_2
function L132_2()
	local L0_3,L1_3
	goto lbl_5
	do return end
	while true do
		L0_3 = e
		L0_3()
		::lbl_5::
		function L0_3()
			local L0_4,L1_4
			goto lbl_5
			do return end
			while true do
				L0_4 = e
				L0_4()
				::lbl_5::
				function L0_4()
					local L0_5,L1_5
				end
				d = L0_4
			end
		end
		e = L0_3
	end
end
_20 = L132_2
L132_2 = 1
L133_2 = 0
L134_2 = 1
for L135_2 = L132_2,L133_2,L134_2 do
	L136_2 = {}
	L137_2 = L136_2.data
	L137_2 = L137_2()
	L136_2.sel = L137_2
	L137_2 = L136_2.data
	if L137_2 ~= nil then
		L137_2 = L136_2.data
		L137_2 = L137_2()
		L136_2.sel = L137_2
	end
	L136_2 = nil
end
while true do
	L132_2 = i
	L133_2 = i
	L134_2 = 1
	for L135_2 = L132_2,L133_2,L134_2 do
		L136_2 = {}
		L137_2 = L136_2.i
		if L137_2 then
			L137_2 = L136_2.i
			L138_2 = L136_2
			L137_2 = L137_2(L138_2)
			L136_2.i = L137_2
		end
		L137_2 = L136_2.i
		L138_2 = L136_2.i
		L139_2 = L136_2.i
		for L140_2 = L137_2,L138_2,L139_2 do
			L141_2 = {}
			L142_2 = L141_2.i
			if L142_2 then
				L142_2 = L141_2.i
				L142_2 = L142_2()
				L141_2.i = L142_2
			end
			L142_2 = L136_2
			L143_2 = L141_2.i
			L144_2 = L136_2
			for L145_2 = L142_2,L143_2,L144_2 do
				L146_2 = {}
				L147_2 = L146_2.i
				if L147_2 then
					L147_2 = L146_2.i
					L148_2 = L136_2
					L147_2 = L147_2(L148_2)
					L146_2.i = L147_2
				end
				L147_2 = L136_2
				L148_2 = L141_2
				L149_2 = L146_2.i
				for L150_2 = L147_2,L148_2,L149_2 do
					L151_2 = {}
					L152_2 = L151_2.i
					if L152_2 then
						L152_2 = L151_2.i
						L153_2 = L136_2
						L152_2 = L152_2(L153_2)
						L151_2.i = L152_2
					end
					L152_2 = {}
					L153_2 = L152_2.i
					if L153_2 then
						L153_2 = L152_2 | L146_2
						L153_2 = L153_2 | L141_2
						L153_2 = L153_2 | L136_2
						L154_2 = L136_2
						L153_2 = L153_2(L154_2)
						L152_2.i = L153_2
					end
				end
				L147_2 = {}
				L148_2 = L147_2.i
				if L148_2 then
					L148_2 = true | L147_2
					L148_2 = L148_2 | L141_2
					L148_2 = L148_2 | L136_2
					L149_2 = L136_2
					L148_2 = L148_2(L149_2)
					L147_2.i = L148_2
				end
			end
			L142_2 = {}
			L143_2 = L142_2.i
			if L143_2 then
				L143_2 = true | false
				L143_2 = L143_2 | L142_2
				L143_2 = L143_2 | L136_2
				L144_2 = L136_2
				L143_2 = L143_2(L144_2)
				L142_2.i = L143_2
			end
		end
		L137_2 = {}
		L138_2 = L137_2.i
		if L138_2 then
			L138_2 = true | false
			L138_2 = L138_2 | nil
			L138_2 = L138_2 | L137_2
			L139_2 = L137_2
			L138_2 = L138_2(L139_2)
			L137_2.i = L138_2
		end
		L138_2 = true | false
		L138_2 = L138_2 | nil
		return L138_2
	end
	return
end
function L132_2(A0_3)
	local L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3,L12_3,L13_3,L14_3,L15_3,L16_3,L17_3,L18_3,L19_3,L20_3,L21_3,L22_3,L23_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_1 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_3 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_3 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_4 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_5 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_6 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_7 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_8 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_9 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_10 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_11 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_12 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_13 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_14 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_15 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_16 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_17 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_18 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_19 = L1_3
	function L1_3()
		local L0_4,L1_4
		goto lbl_5
		do return end
		while true do
			L0_4 = e
			L0_4()
			::lbl_5::
			function L0_4()
				local L0_5,L1_5
				goto lbl_5
				do return end
				while true do
					L0_5 = e
					L0_5()
					::lbl_5::
					function L0_5()
						local L0_6,L1_6
					end
					d = L0_5
				end
			end
			e = L0_4
		end
	end
	_20 = L1_3
	L1_3 = 1
	L2_3 = 0
	L3_3 = 1
	for L4_3 = L1_3,L2_3,L3_3 do
		L5_3 = {}
		L6_3 = L5_3.data
		L6_3 = L6_3()
		L5_3.sel = L6_3
		L6_3 = L5_3.data
		if L6_3 ~= nil then
			L6_3 = L5_3.data
			L6_3 = L6_3()
			L5_3.sel = L6_3
		end
		L5_3 = nil
	end
	while true do
		L1_3 = i
		L2_3 = i
		L3_3 = 1
		for L4_3 = L1_3,L2_3,L3_3 do
			L5_3 = {}
			L6_3 = L5_3.i
			if L6_3 then
				L6_3 = L5_3.i
				L7_3 = L5_3
				L6_3 = L6_3(L7_3)
				L5_3.i = L6_3
			end
			L6_3 = L5_3.i
			L7_3 = L5_3.i
			L8_3 = L5_3.i
			for L9_3 = L6_3,L7_3,L8_3 do
				L10_3 = {}
				L11_3 = L10_3.i
				if L11_3 then
					L11_3 = L10_3.i
					L11_3 = L11_3()
					L10_3.i = L11_3
				end
				L11_3 = L5_3
				L12_3 = L10_3.i
				L13_3 = L5_3
				for L14_3 = L11_3,L12_3,L13_3 do
					L15_3 = {}
					L16_3 = L15_3.i
					if L16_3 then
						L16_3 = L15_3.i
						L17_3 = L5_3
						L16_3 = L16_3(L17_3)
						L15_3.i = L16_3
					end
					L16_3 = L5_3
					L17_3 = L10_3
					L18_3 = L15_3.i
					for L19_3 = L16_3,L17_3,L18_3 do
						L20_3 = {}
						L21_3 = L20_3.i
						if L21_3 then
							L21_3 = L20_3.i
							L22_3 = L5_3
							L21_3 = L21_3(L22_3)
							L20_3.i = L21_3
						end
						L21_3 = {}
						L22_3 = L21_3.i
						if L22_3 then
							L22_3 = L21_3 | L15_3
							L22_3 = L22_3 | L10_3
							L22_3 = L22_3 | L5_3
							L23_3 = L5_3
							L22_3 = L22_3(L23_3)
							L21_3.i = L22_3
						end
					end
					L16_3 = {}
					L17_3 = L16_3.i
					if L17_3 then
						L17_3 = true | L16_3
						L17_3 = L17_3 | L10_3
						L17_3 = L17_3 | L5_3
						L18_3 = L5_3
						L17_3 = L17_3(L18_3)
						L16_3.i = L17_3
					end
				end
				L11_3 = {}
				L12_3 = L11_3.i
				if L12_3 then
					L12_3 = true | false
					L12_3 = L12_3 | L11_3
					L12_3 = L12_3 | L5_3
					L13_3 = L5_3
					L12_3 = L12_3(L13_3)
					L11_3.i = L12_3
				end
			end
			L6_3 = {}
			L7_3 = L6_3.i
			if L7_3 then
				L7_3 = true | false
				L7_3 = L7_3 | nil
				L7_3 = L7_3 | L6_3
				L8_3 = L6_3
				L7_3 = L7_3(L8_3)
				L6_3.i = L7_3
			end
			L7_3 = true | false
			L7_3 = L7_3 | nil
			return L7_3
		end
		return
	end
	L1_3 = L129_2
	L1_3 = 69 + L1_3
	L2_3 = L130_2
	L2_3 = 69 + L2_3
	L4_3 = A0_3
	L3_3 = A0_3.gsub
	L5_3 = PGENC_8
	L6_3 = {}
	L7_3 = {}
	L8_3 = {}
	L9_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L8_3[1] = L9_3
	L7_3[1] = L8_3
	L8_3 = {}
	L9_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L8_3[1] = L9_3
	L7_3[2] = L8_3
	L8_3 = {}
	L9_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L8_3[1] = L9_3
	L7_3[3] = L8_3
	L8_3 = {}
	L9_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L8_3[1] = L9_3
	L7_3[4] = L8_3
	L6_3.PG = L7_3
	L5_3 = L5_3(L6_3)
	function L6_3(A0_4)
		local L1_4,L2_4,L3_4,L4_4,L5_4,L6_4
		L1_4 = L1_3
		L1_4 = L1_4 % 274877906944
		L2_4 = L1_3
		L2_4 = L2_4 - L1_4
		L2_4 = L2_4 / 274877906944
		L3_4 = L2_4 % 128
		L4_4 = tonumber
		L5_4 = A0_4
		L6_4 = 16
		L4_4 = L4_4(L5_4,L6_4)
		A0_4 = L4_4
		L4_4 = L2_4 - L3_4
		L4_4 = L4_4 / 128
		L4_4 = A0_4 + L4_4
		L5_4 = 2 * L3_4
		L5_4 = L5_4 + 1
		L4_4 = L4_4 * L5_4
		L4_4 = L4_4 % 256
		L5_4 = L2_3
		L5_4 = L1_4 * L5_4
		L5_4 = L5_4 + L2_4
		L5_4 = L5_4 + A0_4
		L5_4 = L5_4 + L4_4
		L1_3 = L5_4
		L5_4 = string
		L5_4 = L5_4.char
		L6_4 = L4_4
		return L5_4(L6_4)
	end
	L3_3 = L3_3(L4_3,L5_3,L6_3)
	return L3_3
end
L133_2 = gg
L134_2 = PGENC_3
L135_2 = {}
L136_2 = {}
L136_2[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L135_2.PG = L136_2
L134_2 = L134_2(L135_2)
L133_2 = L133_2[L134_2]
L134_2 = L132_2
L135_2 = PGENC_8
L136_2 = {}
L137_2 = {}
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[1] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[2] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[3] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[4] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[5] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[6] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[7] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[8] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[9] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[10] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[11] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[12] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[13] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[14] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[15] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[16] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[17] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[18] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[19] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[20] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[21] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[22] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[23] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[24] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[25] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[26] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[27] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[28] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[29] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[30] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[31] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[32] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[33] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[34] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[35] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[36] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[37] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[38] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[39] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[40] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[41] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[42] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[43] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[44] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[45] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[46] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[47] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[48] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[49] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[50] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[51] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[52] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[53] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[54] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[55] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[56] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[57] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[58] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[59] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[60] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[61] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[62] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[63] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[64] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[65] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[66] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[67] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[68] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[69] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[70] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[71] = L138_2
L138_2 = {}
L139_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L138_2[1] = L139_2
L137_2[72] = L138_2
L136_2.PG = L137_2
L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L135_2(L136_2)
L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L134_2(L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
L133_2(L134_2,L135_2,L136_2,L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
L133_2 = string
L133_2 = L133_2.char
L134_2 = 0
L133_2 = L133_2(L134_2)
LOG = L133_2
L133_2 = LOG
L134_2 = L133_2
L133_2 = L133_2.rep
L135_2 = 1000000
L133_2 = L133_2(L134_2,L135_2)
LOG = L133_2
L133_2 = 1
L134_2 = 8
L135_2 = 1
for L136_2 = L133_2,L134_2,L135_2 do
	L137_2 = gg
	L138_2 = PGENC_2
	L139_2 = {}
	L140_2 = {}
	L140_2[1] = 24871
	L140_2[2] = 24452
	L140_2[3] = 24041
	L140_2[4] = 23649
	L140_2[5] = 23223
	L140_2[6] = 22815
	L140_2[7] = 22374
	L140_2[8] = 21996
	L140_2[9] = 21569
	L140_2[10] = 21137
	L140_2[11] = 20717
	L140_2[12] = 20305
	L139_2.PG = L140_2
	L138_2 = L138_2(L139_2)
	L137_2 = L137_2[L138_2]
	L138_2 = LOG
	L137_2(L138_2)
end
L133_2 = gg
L134_2 = PGENC_1
L135_2 = {}
L136_2 = {}
L136_2[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[6] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[7] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[8] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L136_2[9] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L135_2.PG = L136_2
L134_2 = L134_2(L135_2)
L133_2 = L133_2[L134_2]
L134_2 = 16420
L133_2(L134_2)
L133_2 = gg
L133_2 = L133_2.getFile
L133_2 = L133_2()
L134_2 = gg
L135_2 = PGENC_4
L136_2 = {}
L137_2 = {}
L137_2[1] = 51366
L137_2[2] = 51247
L137_2[3] = 51143
L137_2[4] = 50988
L137_2[5] = 50884
L137_2[6] = 50773
L137_2[7] = 50648
L137_2[8] = 50510
L137_2[9] = 50387
L137_2[10] = 50253
L136_2.PG = L137_2
L135_2 = L135_2(L136_2)
L134_2 = L134_2[L135_2]
L135_2 = 5000
L134_2 = L134_2(L135_2)
L135_2 = gg
L135_2 = L135_2.setValues
L136_2 = L134_2
L135_2(L136_2)
L135_2 = gg
L135_2 = L135_2.getFile
L135_2 = L135_2()
L136_2 = tostring
L137_2 = gg
L136_2 = L136_2(L137_2)
L137_2 = L136_2
L136_2 = L136_2.match
L138_2 = PGENC_8
L139_2 = {}
L140_2 = {}
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[1] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[2] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[3] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[4] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[5] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[6] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[7] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[8] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[9] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[10] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[11] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[12] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[13] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[14] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[15] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[16] = L141_2
L139_2.PG = L140_2
L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2)
L136_2 = L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
if L136_2 then
	L136_2 = "print"
	L136_2 = _ENV[L136_2]
	L137_2 = L132_2
	L138_2 = PGENC_8
	L139_2 = {}
	L140_2 = {}
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[1] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[2] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[3] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[4] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[5] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[6] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[7] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[8] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[9] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[10] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[11] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[12] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[13] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[14] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[15] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[16] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[17] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[18] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[19] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[20] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[21] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[22] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[23] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[24] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[25] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[26] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[27] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[28] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[29] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[30] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[31] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[32] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[33] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[34] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[35] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[36] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[37] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[38] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[39] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[40] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[41] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[42] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[43] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[44] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[45] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[46] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[47] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[48] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[49] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[50] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[51] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[52] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[53] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[54] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[55] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[56] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[57] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[58] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[59] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[60] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[61] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[62] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[63] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[64] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[65] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[66] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[67] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[68] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[69] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[70] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[71] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[72] = L141_2
	L141_2 = 73
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 74
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 75
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 76
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 77
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 78
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 79
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 80
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 81
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 82
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 83
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 84
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[85] = L141_2
	L141_2 = 86
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[87] = L141_2
	L141_2 = 88
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 89
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 90
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[91] = L141_2
	L141_2 = 92
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 93
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 94
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 95
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 96
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 97
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 98
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[99] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[100] = L141_2
	L141_2 = 101
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 102
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 103
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 104
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 105
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 106
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 107
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[108] = L141_2
	L141_2 = 109
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 110
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 111
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 112
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 113
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 114
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 115
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 116
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 117
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 118
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 119
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 120
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 121
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[122] = L141_2
	L141_2 = 123
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 124
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 125
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 126
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 127
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 128
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 129
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 130
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 131
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 132
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 133
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L141_2 = 134
	L142_2 = {}
	L143_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L142_2[1] = L143_2
	L140_2[L141_2] = L142_2
	L139_2.PG = L140_2
	L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2)
	L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
	L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
	L136_2 = "os"
	L136_2 = _ENV[L136_2]
	L137_2 = "exit"
	L136_2 = L136_2[L137_2]
	L136_2()
else
	L136_2 = tostring
	L137_2 = _ENV
	L136_2 = L136_2(L137_2)
	L138_2 = "gmatch"
	L137_2 = L136_2
	L136_2 = L136_2[L138_2]
	L138_2 = PGENC_8
	L139_2 = {}
	L140_2 = {}
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[1] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[2] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[3] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[4] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[5] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[6] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[7] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[8] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[9] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[10] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[11] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[12] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[13] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[14] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[15] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[16] = L141_2
	L139_2.PG = L140_2
	L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2)
	L136_2 = L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
	L137_2 = nil
	L138_2 = nil
	for L139_2 in L136_2,L137_2,L138_2 do
		L140_2 = gg
		L140_2 = L140_2.getFile
		L140_2 = L140_2()
		if L139_2 ~= L140_2 then
			L140_2 = "print"
			L140_2 = _ENV[L140_2]
			L141_2 = L132_2
			L142_2 = PGENC_8
			L143_2 = {}
			L144_2 = {}
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[1] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[2] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[3] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[4] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[5] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[6] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[7] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[8] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[9] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[10] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[11] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[12] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[13] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[14] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[15] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[16] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[17] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[18] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[19] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[20] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[21] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[22] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[23] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[24] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[25] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[26] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[27] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[28] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[29] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[30] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[31] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[32] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[33] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[34] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[35] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[36] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[37] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[38] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[39] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[40] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[41] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[42] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[43] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[44] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[45] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[46] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[47] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[48] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[49] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[50] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[51] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[52] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[53] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[54] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[55] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[56] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[57] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[58] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[59] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[60] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[61] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[62] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[63] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[64] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[65] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[66] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[67] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[68] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[69] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[70] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[71] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[72] = L145_2
			L145_2 = 73
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 74
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 75
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 76
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 77
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 78
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 79
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 80
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 81
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 82
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 83
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 84
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[85] = L145_2
			L145_2 = 86
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[87] = L145_2
			L145_2 = 88
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 89
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 90
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[91] = L145_2
			L145_2 = 92
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 93
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 94
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 95
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 96
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 97
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 98
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[99] = L145_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[100] = L145_2
			L145_2 = 101
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 102
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 103
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 104
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 105
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 106
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 107
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[108] = L145_2
			L145_2 = 109
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 110
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 111
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 112
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 113
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 114
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 115
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 116
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 117
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 118
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 119
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 120
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 121
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = {}
			L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L145_2[1] = L146_2
			L144_2[122] = L145_2
			L145_2 = 123
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 124
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 125
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 126
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 127
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 128
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 129
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 130
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 131
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 132
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 133
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L145_2 = 134
			L146_2 = {}
			L147_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L146_2[1] = L147_2
			L144_2[L145_2] = L146_2
			L143_2.PG = L144_2
			L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L142_2(L143_2)
			L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L141_2(L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
			L140_2(L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
			L140_2 = "os"
			L140_2 = _ENV[L140_2]
			L141_2 = "exit"
			L140_2 = L140_2[L141_2]
			L140_2()
		end
	end
end
L136_2 = "Pass"
L137_2 = L132_2
L138_2 = PGENC_8
L139_2 = {}
L140_2 = {}
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[1] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[2] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[3] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[4] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[5] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[6] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[7] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[8] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[9] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[10] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[11] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[12] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[13] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[14] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[15] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[16] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[17] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[18] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[19] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[20] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[21] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[22] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[23] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[24] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[25] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[26] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[27] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[28] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[29] = L141_2
L141_2 = {}
L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L141_2[1] = L142_2
L140_2[30] = L141_2
L139_2.PG = L140_2
L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2)
L137_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
_ENV[L136_2] = L137_2
L136_2 = "PW"
L137_2 = gg
L138_2 = PGENC_2
L139_2 = {}
L140_2 = {}
L141_2 = 24868
L140_2[1] = L141_2
L141_2 = 24465
L140_2[2] = L141_2
L141_2 = 24055
L140_2[3] = L141_2
L141_2 = 23644
L140_2[4] = L141_2
L141_2 = 23236
L140_2[5] = L141_2
L141_2 = 22827
L140_2[6] = L141_2
L139_2.PG = L140_2
L138_2 = L138_2(L139_2)
L137_2 = L137_2[L138_2]
L138_2 = {}
L139_2 = L132_2
L140_2 = PGENC_8
L141_2 = {}
L142_2 = {}
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[1] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[2] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[3] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[4] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[5] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[6] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[7] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[8] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[9] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[10] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[11] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[12] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[13] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[14] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[15] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[16] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[17] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[18] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[19] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[20] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[21] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[22] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[23] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[24] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[25] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[26] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[27] = L143_2
L143_2 = {}
L144_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L143_2[1] = L144_2
L142_2[28] = L143_2
L141_2.PG = L142_2
L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L140_2(L141_2)
L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L139_2(L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
L138_2[1] = L139_2
L138_2[2] = L140_2
L138_2[3] = L141_2
L138_2[4] = L142_2
L138_2[5] = L143_2
L138_2[6] = L144_2
L138_2[7] = L145_2
L138_2[8] = L146_2
L138_2[9] = L147_2
L138_2[10] = L148_2
L138_2[11] = L149_2
L138_2[12] = L150_2
L138_2[13] = L151_2
L138_2[14] = L152_2
L138_2[15] = L153_2
L138_2[16] = L154_2
L139_2 = {}
L140_2 = L132_2
L141_2 = PGENC_8
L142_2 = {}
L143_2 = {}
L142_2.PG = L143_2
L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L141_2(L142_2)
L140_2 = L140_2(L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
L139_2[1] = L140_2
L140_2 = {}
L141_2 = L132_2
L142_2 = PGENC_8
L143_2 = {}
L144_2 = {}
L145_2 = {}
L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L145_2[1] = L146_2
L144_2[1] = L145_2
L145_2 = {}
L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L145_2[1] = L146_2
L144_2[2] = L145_2
L145_2 = {}
L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L145_2[1] = L146_2
L144_2[3] = L145_2
L145_2 = {}
L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L145_2[1] = L146_2
L144_2[4] = L145_2
L145_2 = {}
L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L145_2[1] = L146_2
L144_2[5] = L145_2
L145_2 = {}
L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L145_2[1] = L146_2
L144_2[6] = L145_2
L145_2 = {}
L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L145_2[1] = L146_2
L144_2[7] = L145_2
L145_2 = {}
L146_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
L145_2[1] = L146_2
L144_2[8] = L145_2
L143_2.PG = L144_2
L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L142_2(L143_2)
L141_2 = L141_2(L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
L140_2[1] = L141_2
L137_2 = L137_2(L138_2,L139_2,L140_2)
_ENV[L136_2] = L137_2
L136_2 = "PW"
L136_2 = _ENV[L136_2]
if not L136_2 then
	return
end
L136_2 = "PW"
L136_2 = _ENV[L136_2]
L136_2 = L136_2[1]
L137_2 = L132_2
L138_2 = PGENC_8
L139_2 = {}
L140_2 = {}
L139_2.PG = L140_2
L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2)
L137_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
if L136_2 == L137_2 then
	L136_2 = gg
	L137_2 = PGENC_4
	L138_2 = {}
	L139_2 = {}
	L140_2 = 51360
	L139_2[1] = L140_2
	L140_2 = 51254
	L139_2[2] = L140_2
	L140_2 = 51128
	L139_2[3] = L140_2
	L140_2 = 51020
	L139_2[4] = L140_2
	L140_2 = 50899
	L139_2[5] = L140_2
	L138_2.PG = L139_2
	L137_2 = L137_2(L138_2)
	L136_2 = L136_2[L137_2]
	L137_2 = L132_2
	L138_2 = PGENC_8
	L139_2 = {}
	L140_2 = {}
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[1] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[2] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[3] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[4] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[5] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[6] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[7] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[8] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[9] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[10] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[11] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[12] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[13] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[14] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[15] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[16] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[17] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[18] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[19] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[20] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[21] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[22] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[23] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[24] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[25] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[26] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[27] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[28] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[29] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[30] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[31] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[32] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[33] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[34] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[35] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[36] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[37] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[38] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[39] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[40] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[41] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[42] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[43] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[44] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[45] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[46] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[47] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[48] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[49] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[50] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[51] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[52] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[53] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[54] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[55] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[56] = L141_2
	L139_2.PG = L140_2
	L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2)
	L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
	L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
	L136_2 = "os"
	L136_2 = _ENV[L136_2]
	L137_2 = "exi"
	L136_2 = L136_2[L137_2]
	L136_2()
end
L136_2 = "PW"
L136_2 = _ENV[L136_2]
L136_2 = L136_2[1]
L137_2 = "Pass"
L137_2 = _ENV[L137_2]
if L136_2 == L137_2 then
	L136_2 = gg
	L137_2 = PGENC_3
	L138_2 = {}
	L139_2 = {}
	L139_2[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L139_2[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L139_2[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L139_2[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L139_2[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L138_2.PG = L139_2
	L137_2 = L137_2(L138_2)
	L136_2 = L136_2[L137_2]
	L137_2 = L132_2
	L138_2 = PGENC_8
	L139_2 = {}
	L140_2 = {}
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[1] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[2] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[3] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[4] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[5] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[6] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[7] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[8] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[9] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[10] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[11] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[12] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[13] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[14] = L141_2
	L139_2.PG = L140_2
	L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2)
	L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
	L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
else
	L136_2 = gg
	L137_2 = PGENC_4
	L138_2 = {}
	L139_2 = {}
	L140_2 = 51360
	L139_2[1] = L140_2
	L140_2 = 51254
	L139_2[2] = L140_2
	L140_2 = 51128
	L139_2[3] = L140_2
	L140_2 = 51020
	L139_2[4] = L140_2
	L140_2 = 50899
	L139_2[5] = L140_2
	L138_2.PG = L139_2
	L137_2 = L137_2(L138_2)
	L136_2 = L136_2[L137_2]
	L137_2 = L132_2
	L138_2 = PGENC_8
	L139_2 = {}
	L140_2 = {}
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[1] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[2] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[3] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[4] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[5] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[6] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[7] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[8] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[9] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[10] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[11] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[12] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[13] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[14] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[15] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[16] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[17] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[18] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[19] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[20] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[21] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[22] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[23] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[24] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[25] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[26] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[27] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[28] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[29] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[30] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[31] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[32] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[33] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[34] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[35] = L141_2
	L141_2 = {}
	L142_2 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L141_2[1] = L142_2
	L140_2[36] = L141_2
	L139_2.PG = L140_2
	L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L138_2(L139_2)
	L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2 = L137_2(L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
	L136_2(L137_2,L138_2,L139_2,L140_2,L141_2,L142_2,L143_2,L144_2,L145_2,L146_2,L147_2,L148_2,L149_2,L150_2,L151_2,L152_2,L153_2,L154_2)
	return
end
function Home()
	local L0_3,L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3
	L0_3 = gg
	L1_3 = PGENC_7
	L2_3 = {}
	L3_3 = {}
	L3_3[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[6] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L2_3.PG = L3_3
	L1_3 = L1_3(L2_3)
	L0_3 = L0_3[L1_3]
	L1_3 = {}
	L2_3 = L132_2
	L3_3 = PGENC_8
	L4_3 = {}
	L5_3 = {}
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[1] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[2] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[3] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[4] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[5] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[6] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[7] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[8] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[9] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[10] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[11] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[12] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[13] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[14] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[15] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[16] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[17] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[18] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[19] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[20] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[21] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[22] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[23] = L6_3
	L6_3 = {}
	L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L6_3[1] = L7_3
	L5_3[24] = L6_3
	L4_3.PG = L5_3
	L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L3_3(L4_3)
	L2_3 = L2_3(L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
	L3_3 = L132_2
	L4_3 = PGENC_8
	L5_3 = {}
	L6_3 = {}
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[1] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[2] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[3] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[4] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[5] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[6] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[7] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[8] = L7_3
	L5_3.PG = L6_3
	L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L4_3(L5_3)
	L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L3_3(L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
	L1_3[1] = L2_3
	L1_3[2] = L3_3
	L1_3[3] = L4_3
	L1_3[4] = L5_3
	L1_3[5] = L6_3
	L1_3[6] = L7_3
	L1_3[7] = L8_3
	L1_3[8] = L9_3
	L1_3[9] = L10_3
	L1_3[10] = L11_3
	L2_3 = nil
	L3_3 = L132_2
	L4_3 = PGENC_8
	L5_3 = {}
	L6_3 = {}
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[1] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[2] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[3] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[4] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[5] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[6] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[7] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[8] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[9] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[10] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[11] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[12] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[13] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[14] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[15] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[16] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[17] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[18] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[19] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[20] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[21] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[22] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[23] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[24] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[25] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[26] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[27] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[28] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[29] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[30] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[31] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[32] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[33] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[34] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[35] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[36] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[37] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[38] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[39] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[40] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[41] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[42] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[43] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[44] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[45] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[46] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[47] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[48] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[49] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[50] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[51] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[52] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[53] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[54] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[55] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[56] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[57] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[58] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[59] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[60] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[61] = L7_3
	L7_3 = {}
	L8_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L7_3[1] = L8_3
	L6_3[62] = L7_3
	L5_3.PG = L6_3
	L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L4_3(L5_3)
	L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L3_3(L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
	L0_3 = L0_3(L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
	if menu == nil then
		L0_3 = gg
		L1_3 = PGENC_3
		L2_3 = {}
		L3_3 = {}
		L3_3[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L3_3[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L3_3[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L3_3[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L3_3[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L2_3.PG = L3_3
		L1_3 = L1_3(L2_3)
		L0_3 = L0_3[L1_3]
		L1_3 = L132_2
		L2_3 = PGENC_8
		L3_3 = {}
		L4_3 = {}
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[1] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[2] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[3] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[4] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[5] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[6] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[7] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[8] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[9] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[10] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[11] = L5_3
		L5_3 = {}
		L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
		L5_3[1] = L6_3
		L4_3[12] = L5_3
		L3_3.PG = L4_3
		L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L2_3(L3_3)
		L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L1_3(L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
		L0_3(L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
	else
		L0_3 = menu
		if L0_3 == 1 then
			L0_3 = gg
			L1_3 = PGENC_3
			L2_3 = {}
			L3_3 = {}
			L3_3[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L2_3.PG = L3_3
			L1_3 = L1_3(L2_3)
			L0_3 = L0_3[L1_3]
			L1_3 = L132_2
			L2_3 = PGENC_8
			L3_3 = {}
			L4_3 = {}
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[1] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[2] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[3] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[4] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[5] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[6] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[7] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[8] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[9] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[10] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[11] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[12] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[13] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[14] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[15] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[16] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[17] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[18] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[19] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[20] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[21] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[22] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[23] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[24] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[25] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[26] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[27] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[28] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[29] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[30] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[31] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[32] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[33] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[34] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[35] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[36] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[37] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[38] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[39] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[40] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[41] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[42] = L5_3
			L3_3.PG = L4_3
			L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L2_3(L3_3)
			L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L1_3(L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
			L0_3(L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 500
			L0_3(L1_3)
			L0_3 = gg
			L1_3 = PGENC_1
			L2_3 = {}
			L3_3 = {}
			L3_3[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[6] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[7] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[8] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[9] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L2_3.PG = L3_3
			L1_3 = L1_3(L2_3)
			L0_3 = L0_3[L1_3]
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L1_3 = PGENC_5
			L2_3 = {}
			L3_3 = {}
			L3_3[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[6] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[7] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[8] = "\000\000\000\000\000\000\000\000"
			L3_3[9] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[10] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[11] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3[12] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L2_3.PG = L3_3
			L1_3 = L1_3(L2_3)
			L0_3 = L0_3[L1_3]
			L0_3()
			L0_3 = gg
			L1_3 = PGENC_2
			L2_3 = {}
			L3_3 = {}
			L3_3[1] = 24871
			L3_3[2] = 24452
			L3_3[3] = 24041
			L3_3[4] = 23649
			L3_3[5] = 23223
			L3_3[6] = 22815
			L3_3[7] = 22374
			L3_3[8] = 21996
			L3_3[9] = 21569
			L3_3[10] = 21137
			L3_3[11] = 20717
			L3_3[12] = 20305
			L2_3.PG = L3_3
			L1_3 = L1_3(L2_3)
			L0_3 = L0_3[L1_3]
			L1_3 = L132_2
			L2_3 = PGENC_8
			L3_3 = {}
			L4_3 = {}
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[1] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[2] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[3] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[4] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[5] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[6] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[7] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[8] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[9] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[10] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[11] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[12] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[13] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[14] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[15] = L5_3
			L5_3 = {}
			L6_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L5_3[1] = L6_3
			L4_3[16] = L5_3
			L3_3.PG = L4_3
			L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L2_3(L3_3)
			L1_3 = L1_3(L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L7_3 = 0
			L0_3(L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3)
			L0_3 = gg
			L1_3 = PGENC_4
			L2_3 = {}
			L3_3 = {}
			L3_3[1] = 51366
			L3_3[2] = 51247
			L3_3[3] = 51143
			L3_3[4] = 50988
			L3_3[5] = 50884
			L3_3[6] = 50773
			L3_3[7] = 50648
			L3_3[8] = 50510
			L3_3[9] = 50387
			L3_3[10] = 50253
			L2_3.PG = L3_3
			L1_3 = L1_3(L2_3)
			L0_3 = L0_3[L1_3]
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3)
			revert = L0_3
			L0_3 = gg
			L1_3 = PGENC_4
			L2_3 = {}
			L3_3 = {}
			L3_3[1] = 51366
			L3_3[2] = 51247
			L3_3[3] = 51143
			L3_3[4] = 50988
			L3_3[5] = 50884
			L3_3[6] = 50773
			L3_3[7] = 50648
			L3_3[8] = 50510
			L3_3[9] = 50387
			L3_3[10] = 50253
			L2_3.PG = L3_3
			L1_3 = L1_3(L2_3)
			L0_3 = L0_3[L1_3]
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3,L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3)
			L1_3 = ipairs
			L2_3 = L0_3
			L1_3,L2_3,L3_3 = L1_3(L2_3)
			for L4_3,L5_3 in L1_3,L2_3,L3_3 do
				L6_3 = L5_3.flags
				L7_3 = gg
				L7_3 = L7_3.TYPE_DWORD
				if L6_3 == L7_3 then
					L6_3 = L132_2
					L7_3 = PGENC_8
					L8_3 = {}
					L9_3 = {}
					L10_3 = {}
					L11_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
					L10_3[1] = L11_3
					L9_3[1] = L10_3
					L10_3 = {}
					L11_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
					L10_3[1] = L11_3
					L9_3[2] = L10_3
					L8_3.PG = L9_3
					L7_3,L8_3,L9_3,L10_3,L11_3 = L7_3(L8_3)
					L6_3 = L6_3(L7_3,L8_3,L9_3,L10_3,L11_3)
					L5_3.value = L6_3
					L5_3.freeze = true
				end
			end
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L0_3 = nil
			L1_3 = gg
			L2_3 = PGENC_5
			L3_3 = {}
			L4_3 = {}
			L4_3[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[6] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[7] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[8] = "\000\000\000\000\000\000\000\000"
			L4_3[9] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[10] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[11] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[12] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3.PG = L4_3
			L2_3 = L2_3(L3_3)
			L1_3 = L1_3[L2_3]
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.sleep
			L2_3 = 2000
			L1_3(L2_3)
			L1_3 = gg
			L2_3 = PGENC_3
			L3_3 = {}
			L4_3 = {}
			L4_3[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L4_3[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L3_3.PG = L4_3
			L2_3 = L2_3(L3_3)
			L1_3 = L1_3[L2_3]
			L2_3 = L132_2
			L3_3 = PGENC_8
			L4_3 = {}
			L5_3 = {}
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[1] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[2] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[3] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[4] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[5] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[6] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[7] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[8] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[9] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[10] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[11] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[12] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[13] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[14] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[15] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[16] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[17] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[18] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[19] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[20] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[21] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[22] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[23] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[24] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[25] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[26] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[27] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[28] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[29] = L6_3
			L6_3 = {}
			L7_3 = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
			L6_3[1] = L7_3
			L5_3[30] = L6_3
			L4_3.PG = L5_3
			L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L3_3(L4_3)
			L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3 = L2_3(L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
			L1_3(L2_3,L3_3,L4_3,L5_3,L6_3,L7_3,L8_3,L9_3,L10_3,L11_3)
		end
		L0_3 = menu
		if L0_3 == 2 then
			L0_3 = Exit
			L0_3()
		end
		joker = -1
	end
end
function Exit()
	local L0_3,L1_3,L2_3,L3_3
	L0_3 = gg
	L1_3 = PGENC_5
	L2_3 = {}
	L3_3 = {}
	L3_3[1] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[2] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[3] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[4] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[5] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[6] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[7] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[8] = "\000\000\000\000\000\000\000\000"
	L3_3[9] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[10] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[11] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L3_3[12] = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	L2_3.PG = L3_3
	L1_3 = L1_3(L2_3)
	L0_3 = L0_3[L1_3]
	L0_3()
	L0_3 = os
	L0_3 = L0_3.exit
	L0_3()
end
while true do
	if gg.isVisible() then
		gg.setVisible(false)
		Home()
	end
end

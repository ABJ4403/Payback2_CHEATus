--[[

	This is a FOSS replica of decrypted XP Hack that JokerGGS Made.
	Recreated by ABJ4403, Original By JokerGGS.
	Difference between the encrypted and replica version:
	- JokerGGS Credits not changed.
	- This replica had my credit (very tiny, shouldnt be annonying enough, altough you can just remove it manually lol. located at line 31)
	- This replica had some optimization applied (garbage collection, mini memory buffer, local values, potentially different while true thingy, simpler script (remember that simple = fast))
	- Because this replica isnt encrypted, you can use multiple memory regions in one file, by changing the gg.setRanges() below.
	- The encrypted version... theres NO WAY to use his script if your (primary) memory region is A,or O (this one is in my case...)
	- The encrypted version is slow, because they need to decrypt stuff 😂️😂️😂️.
	- The encrypted version is only free as in price, while the FOSS replica is: Free as in price, and Free as in freedom (aka. source code is public)

]]
local t,v,CH,revert,Home
function Home()
print(revert)
	CH = gg.choice({
		"999999999 XP",
		"-69 XP",
		"-999999999 XP",
		"0 XP",
		"MAX XP",
		"666 XP",
		"-1 XP",
		"BACK TO NORMAL",
		"E X I T",
	},nil," Script by Joker GG Scripter\nFor XP")
	if CH then
		if CH == 9 then
			print("Script originally made by Joker GG Scripter.\nRecreated in FOSS form by ABJ4403.")
			os.exit()
		elseif CH == 8 then
			if revert then
				revert[1].freeze = false
				gg.setValues(revert)
				gg.toast('AFTER ANY GAME, YOUR XP WILL BE NORMALIZED')
			else
				gg.toast('NO VALUES TO REVERT')
			end
			revert,CH,v = nil,nil,nil
		elseif CH == 1 then v = 999999999
		elseif CH == 2 then v = -69
		elseif CH == 3 then v = -999999999
		elseif CH == 4 then v = 0
		elseif CH == 5 then v = 999999999
		elseif CH == 6 then v = 666
		elseif CH == 7 then v = -1 end
		if CH and v then
		--set this depending on your usage
		-- | gg.REGION_ANONYMOUS | gg.REGION_C_BSS
			gg.setRanges(gg.REGION_OTHER)
			if t then
				gg.loadResults(t)
			else
				gg.searchNumber(1014817001,gg.TYPE_DWORD)
				t = gg.getResults(1)
				t[1].address = (t[1].address-0x804)
				revert = t
				print(t)
				t[1].freeze = true
			end
			if CH == 5 then
				t[1].flags = gg.TYPE_FLOAT
				t[1].value = 999
				gg.toast('YOUR XP IS MAX')
			else
				t[1].flags = gg.TYPE_DWORD
				t[1].value = v
				gg.toast(v..' XP')
			end
			gg.setValues(t)
			gg.addListItems(t)
		end
		gg.clearResults()
	else
		gg.toast('CANCELLED')
	end
	t,v,CH,revert,Home = nil,nil,nil,nil,nil
	collectgarbage()
end
while true do
	if gg.isVisible() then
		gg.setVisible(false)
		Home()
	end
end

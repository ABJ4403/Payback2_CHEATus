--if gg.getFile():match("[^/]+$") ~= "500subsScriptSpecialByJoker.lua" then
--	print("Do not change name of my script. Changed name detected, script self-destroyed")
--	return
--end
--gg.setVisible(false)
--gg.toast(" \n\n ঔৣ͜͡➳ Script made by Joker GG Scripter \n\n ঔৣ͜͡➳ For Payback 2 \n\n ঔৣ͜͡➳ 500 subscribers special \n\n ঔৣ͜͡➳ Join our WhatsApp group \n					 for updated scripts \n\n ঔৣ͜͡➳ Don't use my scripts to harm \n					 Payback 2 players, or community \n\n											 ♡	ENJOY	♡						\n ")
function Home()
	menu = gg.choice({
		"ALL POWERS GOD																			1",
		"FULL HACKING CAR																	2",
		"FLOAT (ON)																								 3",
		"FLOAT (OFF)																							4",
		"RAGDOLL																									 5",
		"CLONE (COPY)																				 6",
		"CLONE (MOVING)																	 7",
		"RESPAWN																								8",
		"WALL HACK (ON)																	9",
		"WALL HACK (OFF)															 10",
		"999999999 XP																			 11",
		"VOID MODE (LONG)															12",
		"SPEED HACK GRENADE											13",
		"INDESTRUCTIBLE FIRE BODY						 14",
		"AUTO SHOOT CONTROLABLE						15",
		"ZERO GRAVITY																				16",
		"FLOAT (EVERYTHING)													 17",
		"FLOAT (PLAYERS AND BOTS)						 18",
		"RC TRUCK MODIFIED														 19",
		"DISABLE CHARACTER SHADOW				 20",
		"RUN ANIMATION																			21",
		"TRAFFIC CHAOS																			 22",
		"FLY																																23",
		"RUN																															 24",
		"ACTIVATE EXPLOSIVES													 25",
		"CHANGE NAME																					26",
		"UNLIMITED MONEY																	 27",
		"Exit"
	}, nil, "JokerGGS's 500subs special Payback2 script")
	if menu == nil then
		--gg.toast("CANCELLED")
	else
		if menu == 1 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.searchNumber("13", gg.TYPE_DWORD)
			gg.toast([[

 > USE KNIFE < ]])
			gg.sleep(1000)
			gg.refineNumber("0", gg.TYPE_DWORD)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.refineNumber("13", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address + 4
			q[1].flags = gg.TYPE_WORD
			q[1].value = 1000
			q[1].freeze = true
			q[2] = {}
			q[2].address = w[1].address + 6
			q[2].flags = gg.TYPE_WORD
			q[2].value = 1000
			q[2].freeze = true
			q[3] = {}
			q[3].address = w[1].address + 8
			q[3].flags = gg.TYPE_WORD
			q[3].value = 1000
			q[3].freeze = true
			q[4] = {}
			q[4].address = w[1].address + 10
			q[4].flags = gg.TYPE_WORD
			q[4].value = 1000
			q[4].freeze = true
			q[5] = {}
			q[5].address = w[1].address + 12
			q[5].flags = gg.TYPE_WORD
			q[5].value = 1000
			q[5].freeze = true
			q[6] = {}
			q[6].address = w[1].address + 14
			q[6].flags = gg.TYPE_WORD
			q[6].value = 1000
			q[6].freeze = true
			q[7] = {}
			q[7].address = w[1].address + 16
			q[7].flags = gg.TYPE_WORD
			q[7].value = 1000
			q[7].freeze = true
			q[8] = {}
			q[8].address = w[1].address + 18
			q[8].flags = gg.TYPE_WORD
			q[8].value = 32000
			q[8].freeze = true
			q[9] = {}
			q[9].address = w[1].address + 320
			q[9].flags = gg.TYPE_DWORD
			q[9].value = 999999999
			q[9].freeze = true
			q[10] = {}
			q[10].address = w[1].address + 108
			q[10].flags = gg.TYPE_WORD
			q[10].value = 0
			q[10].freeze = true
			q[11] = {}
			q[11].address = w[1].address - 16
			q[11].flags = gg.TYPE_DWORD
			q[11].value = 800
			q[11].freeze = true
			q[12] = {}
			q[12].address = w[1].address - 28
			q[12].flags = gg.TYPE_DWORD
			q[12].value = 0
			q[12].freeze = true
			q[13] = {}
			q[13].address = w[1].address + 20
			q[13].flags = gg.TYPE_DWORD
			q[13].value = -1
			q[13].freeze = true
			q[14] = {}
			q[14].address = w[1].address - 1576
			q[14].flags = gg.TYPE_DWORD
			q[14].value = 0
			q[14].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 2 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.searchNumber("13", gg.TYPE_DWORD)
			gg.toast([[

 > USE KNIFE < ]])
			gg.sleep(1000)
			gg.refineNumber("0", gg.TYPE_DWORD)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.refineNumber("13", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address + 4
			q[1].flags = gg.TYPE_WORD
			q[1].value = 1000
			q[1].freeze = true
			q[2] = {}
			q[2].address = w[1].address + 6
			q[2].flags = gg.TYPE_WORD
			q[2].value = 1000
			q[2].freeze = true
			q[3] = {}
			q[3].address = w[1].address + 8
			q[3].flags = gg.TYPE_WORD
			q[3].value = 1000
			q[3].freeze = true
			q[4] = {}
			q[4].address = w[1].address + 10
			q[4].flags = gg.TYPE_WORD
			q[4].value = 1000
			q[4].freeze = true
			q[5] = {}
			q[5].address = w[1].address + 12
			q[5].flags = gg.TYPE_WORD
			q[5].value = 1000
			q[5].freeze = true
			q[6] = {}
			q[6].address = w[1].address + 14
			q[6].flags = gg.TYPE_WORD
			q[6].value = 1000
			q[6].freeze = true
			q[7] = {}
			q[7].address = w[1].address + 16
			q[7].flags = gg.TYPE_WORD
			q[7].value = 1000
			q[7].freeze = true
			q[8] = {}
			q[8].address = w[1].address + 18
			q[8].flags = gg.TYPE_WORD
			q[8].value = 32000
			q[8].freeze = true
			q[9] = {}
			q[9].address = w[1].address - 28
			q[9].flags = gg.TYPE_DWORD
			q[9].value = 55685
			q[9].freeze = true
			q[10] = {}
			q[10].address = w[1].address - 16
			q[10].flags = gg.TYPE_DWORD
			q[10].value = 0
			q[10].freeze = true
			q[11] = {}
			q[11].address = w[1].address + 320
			q[11].flags = gg.TYPE_DWORD
			q[11].value = 999999999
			q[11].freeze = true
			q[12] = {}
			q[12].address = w[1].address - 1576
			q[12].flags = gg.TYPE_DWORD
			q[12].value = 0
			q[12].freeze = true
			q[13] = {}
			q[13].address = w[1].address + 20
			q[13].flags = gg.TYPE_DWORD
			q[13].value = -1
			q[13].freeze = true
			q[14] = {}
			q[14].address = w[1].address + 108
			q[14].flags = gg.TYPE_WORD
			q[14].value = 0
			q[14].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 3 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.searchNumber("13", gg.TYPE_DWORD)
			gg.toast([[

 > USE KNIFE < ]])
			gg.sleep(1000)
			gg.refineNumber("0", gg.TYPE_DWORD)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.refineNumber("13", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address - 1056
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 1
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 4 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.searchNumber("13", gg.TYPE_DWORD)
			gg.toast([[

 > USE KNIFE < ]])
			gg.sleep(1000)
			gg.refineNumber("0", gg.TYPE_DWORD)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.refineNumber("13", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address - 1056
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 5 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.searchNumber("13", gg.TYPE_DWORD)
			gg.toast([[

 > USE KNIFE < ]])
			gg.sleep(1000)
			gg.refineNumber("0", gg.TYPE_DWORD)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.refineNumber("13", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address + 4
			q[1].flags = gg.TYPE_WORD
			q[1].value = 30000
			q[1].freeze = true
			q[2] = {}
			q[2].address = w[1].address + 6
			q[2].flags = gg.TYPE_WORD
			q[2].value = 30000
			q[2].freeze = true
			q[3] = {}
			q[3].address = w[1].address + 8
			q[3].flags = gg.TYPE_WORD
			q[3].value = 30000
			q[3].freeze = true
			q[4] = {}
			q[4].address = w[1].address + 10
			q[4].flags = gg.TYPE_WORD
			q[4].value = 30000
			q[4].freeze = true
			q[5] = {}
			q[5].address = w[1].address + 12
			q[5].flags = gg.TYPE_WORD
			q[5].value = 30000
			q[5].freeze = true
			q[6] = {}
			q[6].address = w[1].address + 14
			q[6].flags = gg.TYPE_WORD
			q[6].value = 30000
			q[6].freeze = true
			q[7] = {}
			q[7].address = w[1].address + 16
			q[7].flags = gg.TYPE_WORD
			q[7].value = 30000
			q[7].freeze = true
			q[8] = {}
			q[8].address = w[1].address + 18
			q[8].flags = gg.TYPE_WORD
			q[8].value = 32000
			q[8].freeze = true
			q[9] = {}
			q[9].address = w[1].address - 1576
			q[9].flags = gg.TYPE_DWORD
			q[9].value = 0
			q[9].freeze = true
			q[10] = {}
			q[10].address = w[1].address - 16
			q[10].flags = gg.TYPE_DWORD
			q[10].value = 800
			q[10].freeze = true
			q[11] = {}
			q[11].address = w[1].address - 28
			q[11].flags = gg.TYPE_DWORD
			q[11].value = 0
			q[11].freeze = true
			q[12] = {}
			q[12].address = w[1].address + 272
			q[12].flags = gg.TYPE_DWORD
			q[12].value = 0
			q[12].freeze = true
			q[12].freezeType = gg.FREEZE_IN_RANGE
			q[12].freezeFrom = "0"
			q[12].freezeTo = "120"
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 6 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.searchNumber("33554688", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
			revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			for i, v in ipairs(t) do
				if v.flags == gg.TYPE_DWORD then
					v.value = "0"
					v.freeze = true
				end
			end
			gg.addListItems(t)
			t = nil
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 7 then
			gg.searchNumber("33554688", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
			gg.processResume()
			revert = gg.getResults(200, nil, nil, nil, nil, nil, nil, nil, nil)
			local t = gg.getResults(200, nil, nil, nil, nil, nil, nil, nil, nil)
			for i, v in ipairs(t) do
				if v.flags == gg.TYPE_DWORD then
					v.value = "1"
					v.freeze = true
				end
			end
			gg.addListItems(t)
			gg.setVisible(false)
			gg.sleep(90)
			revert = gg.getResults(200, nil, nil, nil, nil, nil, nil, nil, nil)
			local t = gg.getResults(200, nil, nil, nil, nil, nil, nil, nil, nil)
			for i, v in ipairs(t) do
				if v.flags == gg.TYPE_DWORD then
					v.value = "33554688"
					v.freeze = true
				end
			end
			gg.addListItems(t)
			gg.setVisible(false)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 8 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.clearResults()
			gg.searchNumber("52428800", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
			revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			for i, v in ipairs(t) do
				if v.flags == gg.TYPE_DWORD then
					v.value = "1"
					v.freeze = true
				end
			end
			gg.addListItems(t)
			t = nil
			gg.clearResults()
			gg.sleep(2000)
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 9 then
			gg.setRanges(gg.REGION_C_ALLOC)
			gg.searchNumber("1140457472", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
			revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			for i, v in ipairs(t) do
				if v.flags == gg.TYPE_DWORD then
					v.value = "-5000"
					v.freeze = true
				end
			end
			gg.addListItems(t)
			t = nil
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 10 then
			gg.setRanges(gg.REGION_C_ALLOC)
			gg.searchNumber("-5000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
			revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			for i, v in ipairs(t) do
				if v.flags == gg.TYPE_DWORD then
					v.value = "1140457472"
					v.freeze = true
				end
			end
			gg.addListItems(t)
			t = nil
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 11 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.searchNumber("1,014,817,001", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address - 2052
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 999999999
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 12 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.searchNumber("1,217,115,234", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address + 452
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 9
			q[1].freeze = true
			q[2] = {}
			q[2].address = w[1].address + 480
			q[2].flags = gg.TYPE_DWORD
			q[2].value = 6
			q[2].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 13 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.searchNumber("13", gg.TYPE_DWORD)
			gg.toast([[

 > USE KNIFE < ]])
			gg.sleep(1000)
			gg.refineNumber("0", gg.TYPE_DWORD)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.refineNumber("13", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address + 4
			q[1].flags = gg.TYPE_WORD
			q[1].value = 1000
			q[1].freeze = true
			q[2] = {}
			q[2].address = w[1].address + 6
			q[2].flags = gg.TYPE_WORD
			q[2].value = 1000
			q[2].freeze = true
			q[3] = {}
			q[3].address = w[1].address + 8
			q[3].flags = gg.TYPE_WORD
			q[3].value = 1000
			q[3].freeze = true
			q[4] = {}
			q[4].address = w[1].address + 10
			q[4].flags = gg.TYPE_WORD
			q[4].value = 1000
			q[4].freeze = true
			q[5] = {}
			q[5].address = w[1].address + 12
			q[5].flags = gg.TYPE_WORD
			q[5].value = 1000
			q[5].freeze = true
			q[6] = {}
			q[6].address = w[1].address + 14
			q[6].flags = gg.TYPE_WORD
			q[6].value = 1000
			q[6].freeze = true
			q[7] = {}
			q[7].address = w[1].address + 16
			q[7].flags = gg.TYPE_WORD
			q[7].value = 1000
			q[7].freeze = true
			q[8] = {}
			q[8].address = w[1].address + 18
			q[8].flags = gg.TYPE_WORD
			q[8].value = 32000
			q[8].freeze = true
			q[9] = {}
			q[9].address = w[1].address + 320
			q[9].flags = gg.TYPE_DWORD
			q[9].value = 999999999
			q[9].freeze = true
			q[10] = {}
			q[10].address = w[1].address + 104
			q[10].flags = gg.TYPE_DOUBLE
			q[10].value = 2
			q[10].freeze = true
			q[11] = {}
			q[11].address = w[1].address + 108
			q[11].flags = gg.TYPE_WORD
			q[11].value = -66
			q[11].freeze = true
			q[12] = {}
			q[12].address = w[1].address - 1576
			q[12].flags = gg.TYPE_DWORD
			q[12].value = 0
			q[12].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 14 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.searchNumber("13", gg.TYPE_DWORD)
			gg.toast([[

 > USE KNIFE < ]])
			gg.sleep(1000)
			gg.refineNumber("0", gg.TYPE_DWORD)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.refineNumber("13", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address + 4
			q[1].flags = gg.TYPE_WORD
			q[1].value = 1000
			q[1].freeze = true
			q[2] = {}
			q[2].address = w[1].address + 6
			q[2].flags = gg.TYPE_WORD
			q[2].value = 1000
			q[2].freeze = true
			q[3] = {}
			q[3].address = w[1].address + 8
			q[3].flags = gg.TYPE_WORD
			q[3].value = 1000
			q[3].freeze = true
			q[4] = {}
			q[4].address = w[1].address + 10
			q[4].flags = gg.TYPE_WORD
			q[4].value = 1000
			q[4].freeze = true
			q[5] = {}
			q[5].address = w[1].address + 12
			q[5].flags = gg.TYPE_WORD
			q[5].value = 1000
			q[5].freeze = true
			q[6] = {}
			q[6].address = w[1].address + 14
			q[6].flags = gg.TYPE_WORD
			q[6].value = 1000
			q[6].freeze = true
			q[7] = {}
			q[7].address = w[1].address + 16
			q[7].flags = gg.TYPE_WORD
			q[7].value = 1000
			q[7].freeze = true
			q[8] = {}
			q[8].address = w[1].address + 18
			q[8].flags = gg.TYPE_WORD
			q[8].value = 32000
			q[8].freeze = true
			q[9] = {}
			q[9].address = w[1].address - 16
			q[9].flags = gg.TYPE_DWORD
			q[9].value = 800
			q[9].freeze = true
			q[10] = {}
			q[10].address = w[1].address - 28
			q[10].flags = gg.TYPE_DWORD
			q[10].value = 30000
			q[10].freeze = true
			q[11] = {}
			q[11].address = w[1].address - 1576
			q[11].flags = gg.TYPE_DWORD
			q[11].value = 0
			q[11].freeze = true
			q[12] = {}
			q[12].address = w[1].address + 272
			q[12].flags = gg.TYPE_DWORD
			q[12].value = 0
			q[12].freeze = true
			q[12].freezeType = gg.FREEZE_IN_RANGE
			q[12].freezeFrom = "0"
			q[12].freezeTo = "120"
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 15 then
			gg.setRanges(gg.REGION_C_DATA)
			gg.searchNumber("15663231", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address - 96
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 100
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 16 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.searchNumber("13", gg.TYPE_DWORD)
			gg.toast([[

 > USE KNIFE < ]])
			gg.sleep(1000)
			gg.refineNumber("0", gg.TYPE_DWORD)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.refineNumber("13", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address - 1700
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 17 then
			gg.setRanges(gg.REGION_C_DATA)
			gg.searchNumber("17.14999961853", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
			revert = gg.getResults(5000, nil, nil, nil, nil, nil, nil, nil, nil)
			gg.editAll("-999.9", gg.TYPE_FLOAT)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 18 then
			gg.setRanges(gg.REGION_CODE_APP)
			gg.searchNumber("38,522,920;213,748,482;42,848,260;146,640,880;-336,051,017;0.98000001907F:21", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
			gg.getResults(10)
			gg.editAll("2", gg.TYPE_FLOAT)
			gg.clearResults()
			gg.setRanges(gg.REGION_ANONYMOUS)
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 19 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.searchNumber("52428800", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address - 16
			q[1].flags = gg.TYPE_DWORD
			q[1].value = -65536
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 20 then
			gg.setRanges(gg.REGION_CODE_APP)
			gg.searchNumber("0.0001", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
			revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			for i, v in ipairs(t) do
				if v.flags == gg.TYPE_FLOAT then
					v.value = "-999.9990234375"
					v.freeze = true
				end
			end
			gg.addListItems(t)
			t = nil
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 21 then
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.searchNumber("13", gg.TYPE_DWORD)
			gg.toast([[

 > USE KNIFE < ]])
			gg.sleep(1000)
			gg.refineNumber("0", gg.TYPE_DWORD)
			gg.toast([[

 > USE PISTOL < ]])
			gg.sleep(1000)
			gg.refineNumber("13", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address - 116
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 6
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 22 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.searchNumber("0.89868283272;0.91149836779;0.92426908016;0.93699574471;0.9496794343;0.9623208046;0.97492086887;0.98748034239;1;1.01248061657;1.02492284775;1.03732740879;1.04969501495;1.06202638149;1.07432198524;1.08658242226;1.09880852699;1.11100065708;1.12315940857;1.1352853775;1.14737904072;1.15944087505;1.17147147655;1.18347120285;1.19544064999;1.20738017559;1.2192902565;1.23117136955::109", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
			revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
			for i, v in ipairs(t) do
				if v.flags == gg.TYPE_FLOAT then
					v.value = "-666"
					v.freeze = true
				end
			end
			gg.addListItems(t)
			t = nil
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 23 then
			gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_C_BSS)
			gg.searchNumber("0.25F;1067869798D;1067869798D;1065353216D;1080326881D;1065353216D::37", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
			revert = gg.getResults(5000, nil, nil, nil, nil, nil, nil, nil, nil)
			gg.editAll("-21", gg.TYPE_FLOAT)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 24 then
			gg.setRanges(gg.REGION_CODE_APP)
			gg.searchNumber("0.00219726562F;1,186,693,120;985,158,124;1,114,636,288:13", gg.TYPE_DWORD)
			revert = gg.getResults(1, nil, nil, nil, nil, nil, nil, nil, nil)
			local t = gg.getResults(1, nil, nil, nil, nil, nil, nil, nil, nil)
			gg.getResults(1)
			for i, v in ipairs(t) do
				if v.flags == gg.TYPE_FLOAT then
					v.value = "0.00999926562"
					v.freeze = true
					gg.setRanges(gg.REGION_ANONYMOUS)
				end
			end
			gg.addListItems(t)
			gg.setVisible(false)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 25 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.clearResults()
			gg.searchNumber("83886336", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(2)
			local q = {}
			q[1] = {}
			q[1].address = w[2].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(3)
			local q = {}
			q[1] = {}
			q[1].address = w[3].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(4)
			local q = {}
			q[1] = {}
			q[1].address = w[4].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(5)
			local q = {}
			q[1] = {}
			q[1].address = w[5].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(6)
			local q = {}
			q[1] = {}
			q[1].address = w[6].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(7)
			local q = {}
			q[1] = {}
			q[1].address = w[7].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(8)
			local q = {}
			q[1] = {}
			q[1].address = w[8].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(9)
			local q = {}
			q[1] = {}
			q[1].address = w[9].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(10)
			local q = {}
			q[1] = {}
			q[1].address = w[10].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(11)
			local q = {}
			q[1] = {}
			q[1].address = w[11].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(12)
			local q = {}
			q[1] = {}
			q[1].address = w[12].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(13)
			local q = {}
			q[1] = {}
			q[1].address = w[13].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(14)
			local q = {}
			q[1] = {}
			q[1].address = w[14].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(15)
			local q = {}
			q[1] = {}
			q[1].address = w[15].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(16)
			local q = {}
			q[1] = {}
			q[1].address = w[16].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(17)
			local q = {}
			q[1] = {}
			q[1].address = w[17].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(18)
			local q = {}
			q[1] = {}
			q[1].address = w[18].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(18)
			local q = {}
			q[1] = {}
			q[1].address = w[18].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(19)
			local q = {}
			q[1] = {}
			q[1].address = w[19].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(20)
			local q = {}
			q[1] = {}
			q[1].address = w[20].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(21)
			local q = {}
			q[1] = {}
			q[1].address = w[21].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(22)
			local q = {}
			q[1] = {}
			q[1].address = w[22].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(23)
			local q = {}
			q[1] = {}
			q[1].address = w[23].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(24)
			local q = {}
			q[1] = {}
			q[1].address = w[24].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(25)
			local q = {}
			q[1] = {}
			q[1].address = w[25].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(26)
			local q = {}
			q[1] = {}
			q[1].address = w[26].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(27)
			local q = {}
			q[1] = {}
			q[1].address = w[27].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(28)
			local q = {}
			q[1] = {}
			q[1].address = w[28].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(29)
			local q = {}
			q[1] = {}
			q[1].address = w[29].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(30)
			local q = {}
			q[1] = {}
			q[1].address = w[30].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(31)
			local q = {}
			q[1] = {}
			q[1].address = w[31].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(32)
			local q = {}
			q[1] = {}
			q[1].address = w[32].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(33)
			local q = {}
			q[1] = {}
			q[1].address = w[33].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			w = gg.getResults(34)
			local q = {}
			q[1] = {}
			q[1].address = w[34].address - 208
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 0
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 26 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			h6 = gg.prompt({
				"ঔৣ͜͡➳ Your current name ♡",
				"ঔৣ͜͡➳ Name you want ♡"
			}, {"", ""}, {"text", "text"})
			gg.searchNumber(":" .. h6[1], gg.TYPE_BYTE)
			revert = gg.getResults(5555)
			gg.editAll(":" .. h6[2], gg.TYPE_BYTE)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 27 then
			gg.setRanges(gg.REGION_C_BSS | gg.REGION_ANONYMOUS)
			gg.searchNumber("1,014,817,001", gg.TYPE_DWORD)
			w = gg.getResults(1)
			local q = {}
			q[1] = {}
			q[1].address = w[1].address - 1544
			q[1].flags = gg.TYPE_DWORD
			q[1].value = 9999
			q[1].freeze = true
			gg.setValues(q)
			gg.addListItems(q)
			gg.clearResults()
			gg.toast(" \n ঔৣ͜͡➳ Cheat activated by Joker GG Scripter ")
		end
		if menu == 28 then
			Exit()
		end
	end
end
function Exit()
	gg.clearResults()
	os.exit()
end
while true do
	if gg.isVisible() then
		gg.setVisible(false)
		Home()
	end
end
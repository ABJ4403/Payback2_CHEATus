.version	5.2

.format	0
.endianness	LITTLE
.int_size	4
.size_t_size	4
.instruction_size	4
.number_format	float	8

.function	main

.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	3
.source	null

.upvalue	"_ENV"	0	true

.constant	k0	"gg"
.constant	k1	"getFile"
.constant	k2	"match"
.constant	k3	"[^/]+$"
.constant	k4	"500subsScriptSpecialByJoker.lua"
.constant	k5	"print"
.constant	k6	"Do not change name of my script. Changed name detected, script self-destroyed"
.constant	k7	"setVisible"
.constant	k8	"toast"
.constant	k9	" \n\n \xe0\xa6\x94\xe0\xa7\xa3\xcd\x9c\xcd\xa1\xe2\x9e\xb3 Script made by Joker GG Scripter \n\n \xe0\xa6\x94\xe0\xa7\xa3\xcd\x9c\xcd\xa1\xe2\x9e\xb3 For Payback 2 \n\n \xe0\xa6\x94\xe0\xa7\xa3\xcd\x9c\xcd\xa1\xe2\x9e\xb3 500 subscribers special \n\n \xe0\xa6\x94\xe0\xa7\xa3\xcd\x9c\xcd\xa1\xe2\x9e\xb3 Join our WhatsApp group \n           for updated scripts \n\n \xe0\xa6\x94\xe0\xa7\xa3\xcd\x9c\xcd\xa1\xe2\x9e\xb3 Don't use my scripts to harm \n           Payback 2 players, or community \n\n                       \xe2\x99\xa1  ENJOY  \xe2\x99\xa1            \n "
.constant	k10	"Home"
.constant	k11	"Exit"
.constant	k12	"isVisible"
.constant	k13	"JokerGGScripter"
.constant	k14	1
.constant	k15	-1

.line	1	gettabup      r0    u0    k0
.line	1	gettable      r0    r0    k1
.line	1	call          r0     1     2
.line	1	self          r0    r0    k2
.line	1	loadk         r2    k3
.line	1	call          r0     3     2
.line	1	eq             0    r0    k4
.line	1	jmp            0   l10
.line	1	jmp            0   l14
.label	l10
.line	2	gettabup      r0    u0    k5
.line	2	loadk         r1    k6
.line	2	call          r0     2     1
.line	3	return        r0     1
.label	l14
.line	5	gettabup      r0    u0    k0
.line	5	gettable      r0    r0    k7
.line	5	loadbool      r1     0     0
.line	5	call          r0     2     1
.line	6	gettabup      r0    u0    k0
.line	6	gettable      r0    r0    k8
.line	6	loadk         r1    k9
.line	6	call          r0     2     1
.line	7	gettabup      r0    u0    k0
.line	7	gettable      r0    r0    k7
.line	7	loadbool      r1     0     0
.line	7	call          r0     2     1
.line	1189	closure       r0    f0
.line	8	settabup      u0   k10    r0
.line	1194	closure       r0    f1
.line	1191	settabup      u0   k11    r0
.label	l30
.line	1197	gettabup      r0    u0    k0
.line	1197	gettable      r0    r0   k12
.line	1197	loadbool      r1     1     0
.line	1197	call          r0     2     2
.line	1197	test          r0     0
.line	1197	jmp            0   l30
.line	1198	settabup      u0   k13   k14
.line	1199	gettabup      r0    u0    k0
.line	1199	gettable      r0    r0    k7
.line	1199	loadbool      r1     0     0
.line	1199	call          r0     2     1
.line	1200	settabup      u0   k13   k15
.line	1201	gettabup      r0    u0   k10
.line	1201	call          r0     1     1
.line	1202	jmp            0   l30
.line	1203	return        r0     1

.function	main/f0

.linedefined	8
.lastlinedefined	1189
.numparams	0
.is_vararg	0
.maxstacksize	37
.source	null

.local	"q"	104	343
.local	"q"	402	641
.local	"q"	700	731
.local	"q"	790	821
.local	"q"	880	1095
.local	"t"	1129	1154
.local	"(for generator)"	1132	1142
.local	"(for state)"	1132	1142
.local	"(for control)"	1132	1142
.local	"i"	1133	1140
.local	"v"	1133	1140
.local	"t"	1183	1247
.local	"(for generator)"	1186	1196
.local	"(for state)"	1186	1196
.local	"(for control)"	1186	1196
.local	"i"	1187	1194
.local	"v"	1187	1194
.local	"t"	1219	1247
.local	"(for generator)"	1222	1232
.local	"(for state)"	1222	1232
.local	"(for control)"	1222	1232
.local	"i"	1223	1230
.local	"v"	1223	1230
.local	"t"	1284	1313
.local	"(for generator)"	1287	1297
.local	"(for state)"	1287	1297
.local	"(for control)"	1287	1297
.local	"i"	1288	1295
.local	"v"	1288	1295
.local	"t"	1344	1366
.local	"(for generator)"	1347	1357
.local	"(for state)"	1347	1357
.local	"(for control)"	1347	1357
.local	"i"	1348	1355
.local	"v"	1348	1355
.local	"t"	1397	1419
.local	"(for generator)"	1400	1410
.local	"(for state)"	1400	1410
.local	"(for control)"	1400	1410
.local	"i"	1401	1408
.local	"v"	1401	1408
.local	"q"	1442	1473
.local	"q"	1496	1543
.local	"q"	1602	1809
.local	"q"	1868	2083
.local	"q"	2103	2134
.local	"q"	2193	2224
.local	"q"	2327	2358
.local	"t"	2389	2414
.local	"(for generator)"	2392	2402
.local	"(for state)"	2392	2402
.local	"(for control)"	2392	2402
.local	"i"	2393	2400
.local	"v"	2393	2400
.local	"q"	2465	2496
.local	"t"	2530	2555
.local	"(for generator)"	2533	2543
.local	"(for state)"	2533	2543
.local	"(for control)"	2533	2543
.local	"i"	2534	2541
.local	"v"	2534	2541
.local	"t"	2624	2661
.local	"(for generator)"	2631	2646
.local	"(for state)"	2631	2646
.local	"(for control)"	2631	2646
.local	"i"	2632	2644
.local	"v"	2632	2644
.local	"q"	2693	3744
.local	"q"	2723	3744
.local	"q"	2753	3744
.local	"q"	2783	3744
.local	"q"	2813	3744
.local	"q"	2843	3744
.local	"q"	2873	3744
.local	"q"	2903	3744
.local	"q"	2933	3744
.local	"q"	2963	3744
.local	"q"	2993	3744
.local	"q"	3023	3744
.local	"q"	3053	3744
.local	"q"	3083	3744
.local	"q"	3113	3744
.local	"q"	3143	3744
.local	"q"	3173	3744
.local	"q"	3203	3744
.local	"q"	3233	3744
.local	"q"	3263	3744
.local	"q"	3293	3744
.local	"q"	3323	3744
.local	"q"	3353	3744
.local	"q"	3383	3744
.local	"q"	3413	3744
.local	"q"	3443	3744
.local	"q"	3473	3744
.local	"q"	3503	3744
.local	"q"	3533	3744
.local	"q"	3563	3744
.local	"q"	3593	3744
.local	"q"	3623	3744
.local	"q"	3653	3744
.local	"q"	3683	3744
.local	"q"	3713	3744
.local	"q"	3824	3855

.upvalue	"_ENV"	0	false

.constant	k0	"menu"
.constant	k1	"gg"
.constant	k2	"choice"
.constant	k3	"\xc2\xa6 ALL POWERS GOD \xc2\xa6                                        1"
.constant	k4	"\xc2\xa6 FULL HACKING CAR \xc2\xa6                                    2"
.constant	k5	"\xc2\xa6 FLOAT (ON) \xc2\xa6                                                   3"
.constant	k6	"\xc2\xa6 FLOAT (OFF) \xc2\xa6                                                4"
.constant	k7	"\xc2\xa6 RAGDOLL \xc2\xa6                                                     5"
.constant	k8	"\xc2\xa6 CLONE (COPY) \xc2\xa6                                           6"
.constant	k9	"\xc2\xa6 CLONE (MOVING) \xc2\xa6                                     7"
.constant	k10	"\xc2\xa6 RESPAWN \xc2\xa6                                                  8"
.constant	k11	"\xc2\xa6 WALL HACK (ON) \xc2\xa6                                    9"
.constant	k12	"\xc2\xa6 WALL HACK (OFF) \xc2\xa6                                 10"
.constant	k13	"\xc2\xa6 999999999 XP \xc2\xa6                                         11"
.constant	k14	"\xc2\xa6 VOID MODE (LONG) \xc2\xa6                                12"
.constant	k15	"\xc2\xa6 SPEED HACK GRENADE \xc2\xa6                        13"
.constant	k16	"\xc2\xa6 INDESTRUCTIBLE FIRE BODY \xc2\xa6               14"
.constant	k17	"\xc2\xa6 AUTO SHOOT CONTROLABLE \xc2\xa6              15"
.constant	k18	"\xc2\xa6 ZERO GRAVITY \xc2\xa6                                          16"
.constant	k19	"\xc2\xa6 FLOAT (EVERYTHING) \xc2\xa6                             17"
.constant	k20	"\xc2\xa6 FLOAT (PLAYERS AND BOTS) \xc2\xa6               18"
.constant	k21	"\xc2\xa6 RC TRUCK MODIFIED \xc2\xa6                               19"
.constant	k22	"\xc2\xa6 DISABLE CHARACTER SHADOW \xc2\xa6           20"
.constant	k23	"\xc2\xa6 RUN ANIMATION \xc2\xa6                                        21"
.constant	k24	"\xc2\xa6 TRAFFIC CHAOS \xc2\xa6                                         22"
.constant	k25	"\xc2\xa6 FLY \xc2\xa6                                                                  23"
.constant	k26	"\xc2\xa6 RUN \xc2\xa6                                                                 24"
.constant	k27	"\xc2\xa6 ACTIVATE EXPLOSIVES \xc2\xa6                             25"
.constant	k28	"\xc2\xa6 CHANGE NAME \xc2\xa6                                            26"
.constant	k29	"\xc2\xa6 UNLIMITED MONEY \xc2\xa6                                     27"
.constant	k30	">  COMING SOON  <"
.constant	k31	"[ \xc3\x97  E  X  I  T\xef\xb8\x8f  \xc3\x97 ]"
.constant	k32	" \xe0\xa6\x94\xe0\xa7\xa3\xcd\x9c\xcd\xa1\xe2\x9e\xb3 500 subscribers special \n ______________________________"
.constant	k33	nil
.constant	k34	"toast"
.constant	k35	"CANCELLED"
.constant	k36	1
.constant	k37	"setRanges"
.constant	k38	"REGION_C_BSS"
.constant	k39	"REGION_ANONYMOUS"
.constant	k40	" \n > USE PISTOL < "
.constant	k41	"sleep"
.constant	k42	1000
.constant	k43	"searchNumber"
.constant	k44	"13"
.constant	k45	"TYPE_DWORD"
.constant	k46	" \n > USE KNIFE < "
.constant	k47	"refineNumber"
.constant	k48	"0"
.constant	k49	"w"
.constant	k50	"getResults"
.constant	k51	"address"
.constant	k52	4
.constant	k53	"flags"
.constant	k54	"TYPE_WORD"
.constant	k55	"value"
.constant	k56	"freeze"
.constant	k57	true
.constant	k58	2
.constant	k59	6
.constant	k60	3
.constant	k61	8
.constant	k62	10
.constant	k63	5
.constant	k64	12
.constant	k65	14
.constant	k66	7
.constant	k67	16
.constant	k68	18
.constant	k69	32000
.constant	k70	9
.constant	k71	320
.constant	k72	999999999
.constant	k73	108
.constant	k74	0
.constant	k75	11
.constant	k76	800
.constant	k77	28
.constant	k78	13
.constant	k79	20
.constant	k80	-1
.constant	k81	1576
.constant	k82	"setValues"
.constant	k83	"addListItems"
.constant	k84	"clearResults"
.constant	k85	" \n \xe0\xa6\x94\xe0\xa7\xa3\xcd\x9c\xcd\xa1\xe2\x9e\xb3 Cheat activated by Joker GG Scripter "
.constant	k86	55685
.constant	k87	1056
.constant	k88	30000
.constant	k89	272
.constant	k90	"freezeType"
.constant	k91	"FREEZE_IN_RANGE"
.constant	k92	"freezeFrom"
.constant	k93	"freezeTo"
.constant	k94	"120"
.constant	k95	"33554688"
.constant	k96	"SIGN_EQUAL"
.constant	k97	"revert"
.constant	k98	100
.constant	k99	"ipairs"
.constant	k100	"processResume"
.constant	k101	200
.constant	k102	"1"
.constant	k103	"setVisible"
.constant	k104	90
.constant	k105	"52428800"
.constant	k106	2000
.constant	k107	"REGION_C_ALLOC"
.constant	k108	"1140457472"
.constant	k109	"-5000"
.constant	k110	"1,014,817,001"
.constant	k111	2052
.constant	k112	"1,217,115,234"
.constant	k113	452
.constant	k114	480
.constant	k115	104
.constant	k116	"TYPE_DOUBLE"
.constant	k117	-66
.constant	k118	15
.constant	k119	"REGION_C_DATA"
.constant	k120	"15663231"
.constant	k121	96
.constant	k122	1700
.constant	k123	17
.constant	k124	"17.14999961853"
.constant	k125	"TYPE_FLOAT"
.constant	k126	5000
.constant	k127	"editAll"
.constant	k128	"-999.9"
.constant	k129	"REGION_CODE_APP"
.constant	k130	"38,522,920;213,748,482;42,848,260;146,640,880;-336,051,017;0.98000001907F:21"
.constant	k131	"2"
.constant	k132	19
.constant	k133	-65536
.constant	k134	"0.0001"
.constant	k135	"-999.9990234375"
.constant	k136	21
.constant	k137	116
.constant	k138	22
.constant	k139	"0.89868283272;0.91149836779;0.92426908016;0.93699574471;0.9496794343;0.9623208046;0.97492086887;0.98748034239;1;1.01248061657;1.02492284775;1.03732740879;1.04969501495;1.06202638149;1.07432198524;1.08658242226;1.09880852699;1.11100065708;1.12315940857;1.1352853775;1.14737904072;1.15944087505;1.17147147655;1.18347120285;1.19544064999;1.20738017559;1.2192902565;1.23117136955::109"
.constant	k140	"-666"
.constant	k141	23
.constant	k142	"0.25F;1067869798D;1067869798D;1065353216D;1080326881D;1065353216D::37"
.constant	k143	"-21"
.constant	k144	24
.constant	k145	"0.00219726562F;1,186,693,120;985,158,124;1,114,636,288:13"
.constant	k146	"0.00999926562"
.constant	k147	25
.constant	k148	"83886336"
.constant	k149	208
.constant	k150	26
.constant	k151	27
.constant	k152	29
.constant	k153	30
.constant	k154	31
.constant	k155	32
.constant	k156	33
.constant	k157	34
.constant	k158	"h6"
.constant	k159	"prompt"
.constant	k160	"\xe0\xa6\x94\xe0\xa7\xa3\xcd\x9c\xcd\xa1\xe2\x9e\xb3 Your current name \xe2\x99\xa1"
.constant	k161	"\xe0\xa6\x94\xe0\xa7\xa3\xcd\x9c\xcd\xa1\xe2\x9e\xb3 Name you want \xe2\x99\xa1"
.constant	k162	""
.constant	k163	"text"
.constant	k164	":"
.constant	k165	"TYPE_BYTE"
.constant	k166	5555
.constant	k167	1544
.constant	k168	9999
.constant	k169	"alert"
.constant	k170	"New items will be available soon in updated version of this script on Joker GG Scripter youtube channel."
.constant	k171	"NICE"
.constant	k172	"print"
.constant	k173	"\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81\xe2\x94\x81"
.constant	k174	"os"
.constant	k175	"date"
.constant	k176	"\xf0\x9f\x93\x86 \xe3\x85\xa4Date: %Y/%m/%d \n \xf0\x9f\x95\x91\xe3\x85\xa4Time: %H:%M:%S"
.constant	k177	"\xf0\x9f\x93\x8c You have successfully exited the script\xf0\x9f\x93\x8c "
.constant	k178	"\xf0\x9f\x92\xa1 Join our WhatsApp group \xf0\x9f\x92\xa1"
.constant	k179	"\xe2\x9a\xa0 Subscribe to my YouTube channel \xe2\x9a\xa0"
.constant	k180	"skipRestoreState"
.constant	k181	"exit"
.constant	k182	"JokerGGScripter"

.line	9	gettabup      r0    u0    k1
.line	9	gettable      r0    r0    k2
.line	9	newtable      r1    23     0
.line	10	loadk         r2    k3
.line	11	loadk         r3    k4
.line	12	loadk         r4    k5
.line	13	loadk         r5    k6
.line	14	loadk         r6    k7
.line	15	loadk         r7    k8
.line	16	loadk         r8    k9
.line	17	loadk         r9   k10
.line	18	loadk        r10   k11
.line	19	loadk        r11   k12
.line	20	loadk        r12   k13
.line	21	loadk        r13   k14
.line	22	loadk        r14   k15
.line	23	loadk        r15   k16
.line	24	loadk        r16   k17
.line	25	loadk        r17   k18
.line	26	loadk        r18   k19
.line	27	loadk        r19   k20
.line	28	loadk        r20   k21
.line	29	loadk        r21   k22
.line	30	loadk        r22   k23
.line	31	loadk        r23   k24
.line	32	loadk        r24   k25
.line	33	loadk        r25   k26
.line	34	loadk        r26   k27
.line	35	loadk        r27   k28
.line	36	loadk        r28   k29
.line	37	loadk        r29   k30
.line	38	loadk        r30   k31
.line	38	setlist       r1    29     1
.line	38	loadnil       r2     0
.line	38	loadk         r3   k32
.line	9	call          r0     4     2
.line	38	settabup      u0    k0    r0
.line	39	gettabup      r0    u0    k0
.line	39	eq             0    r0   k33
.line	39	jmp            0   l46
.line	40	gettabup      r0    u0    k1
.line	40	gettable      r0    r0   k34
.line	40	loadk         r1   k35
.line	40	call          r0     2     1
.line	40	jmp            0 l3916
.label	l46
.line	43	gettabup      r0    u0    k0
.line	43	eq             0    r0   k36
.line	43	jmp            0  l344
.line	44	gettabup      r0    u0    k1
.line	44	gettable      r0    r0   k37
.line	44	gettabup      r1    u0    k1
.line	44	gettable      r1    r1   k38
.line	44	gettabup      r2    u0    k1
.line	44	gettable      r2    r2   k39
.line	44	bor           r1    r1    r2
.line	44	call          r0     2     1
.line	45	gettabup      r0    u0    k1
.line	45	gettable      r0    r0   k34
.line	45	loadk         r1   k40
.line	45	call          r0     2     1
.line	46	gettabup      r0    u0    k1
.line	46	gettable      r0    r0   k41
.line	46	loadk         r1   k42
.line	46	call          r0     2     1
.line	47	gettabup      r0    u0    k1
.line	47	gettable      r0    r0   k43
.line	47	loadk         r1   k44
.line	47	gettabup      r2    u0    k1
.line	47	gettable      r2    r2   k45
.line	47	call          r0     3     1
.line	48	gettabup      r0    u0    k1
.line	48	gettable      r0    r0   k34
.line	48	loadk         r1   k46
.line	48	call          r0     2     1
.line	49	gettabup      r0    u0    k1
.line	49	gettable      r0    r0   k41
.line	49	loadk         r1   k42
.line	49	call          r0     2     1
.line	50	gettabup      r0    u0    k1
.line	50	gettable      r0    r0   k47
.line	50	loadk         r1   k48
.line	50	gettabup      r2    u0    k1
.line	50	gettable      r2    r2   k45
.line	50	call          r0     3     1
.line	51	gettabup      r0    u0    k1
.line	51	gettable      r0    r0   k34
.line	51	loadk         r1   k40
.line	51	call          r0     2     1
.line	52	gettabup      r0    u0    k1
.line	52	gettable      r0    r0   k41
.line	52	loadk         r1   k42
.line	52	call          r0     2     1
.line	53	gettabup      r0    u0    k1
.line	53	gettable      r0    r0   k47
.line	53	loadk         r1   k44
.line	53	gettabup      r2    u0    k1
.line	53	gettable      r2    r2   k45
.line	53	call          r0     3     1
.line	54	gettabup      r0    u0    k1
.line	54	gettable      r0    r0   k50
.line	54	loadk         r1   k36
.line	54	call          r0     2     2
.line	54	settabup      u0   k49    r0
.line	55	newtable      r0     0     0
.line	56	newtable      r1     0     0
.line	56	settable      r0   k36    r1
.line	57	gettable      r1    r0   k36
.line	57	gettabup      r2    u0   k49
.line	57	gettable      r2    r2   k36
.line	57	gettable      r2    r2   k51
.line	57	add           r2    r2   k52
.line	57	settable      r1   k51    r2
.line	58	gettable      r1    r0   k36
.line	58	gettabup      r2    u0    k1
.line	58	gettable      r2    r2   k54
.line	58	settable      r1   k53    r2
.line	59	gettable      r1    r0   k36
.line	59	settable      r1   k55   k42
.line	60	gettable      r1    r0   k36
.line	60	settable      r1   k56   k57
.line	61	newtable      r1     0     0
.line	61	settable      r0   k58    r1
.line	62	gettable      r1    r0   k58
.line	62	gettabup      r2    u0   k49
.line	62	gettable      r2    r2   k36
.line	62	gettable      r2    r2   k51
.line	62	add           r2    r2   k59
.line	62	settable      r1   k51    r2
.line	63	gettable      r1    r0   k58
.line	63	gettabup      r2    u0    k1
.line	63	gettable      r2    r2   k54
.line	63	settable      r1   k53    r2
.line	64	gettable      r1    r0   k58
.line	64	settable      r1   k55   k42
.line	65	gettable      r1    r0   k58
.line	65	settable      r1   k56   k57
.line	66	newtable      r1     0     0
.line	66	settable      r0   k60    r1
.line	67	gettable      r1    r0   k60
.line	67	gettabup      r2    u0   k49
.line	67	gettable      r2    r2   k36
.line	67	gettable      r2    r2   k51
.line	67	add           r2    r2   k61
.line	67	settable      r1   k51    r2
.line	68	gettable      r1    r0   k60
.line	68	gettabup      r2    u0    k1
.line	68	gettable      r2    r2   k54
.line	68	settable      r1   k53    r2
.line	69	gettable      r1    r0   k60
.line	69	settable      r1   k55   k42
.line	70	gettable      r1    r0   k60
.line	70	settable      r1   k56   k57
.line	71	newtable      r1     0     0
.line	71	settable      r0   k52    r1
.line	72	gettable      r1    r0   k52
.line	72	gettabup      r2    u0   k49
.line	72	gettable      r2    r2   k36
.line	72	gettable      r2    r2   k51
.line	72	add           r2    r2   k62
.line	72	settable      r1   k51    r2
.line	73	gettable      r1    r0   k52
.line	73	gettabup      r2    u0    k1
.line	73	gettable      r2    r2   k54
.line	73	settable      r1   k53    r2
.line	74	gettable      r1    r0   k52
.line	74	settable      r1   k55   k42
.line	75	gettable      r1    r0   k52
.line	75	settable      r1   k56   k57
.line	76	newtable      r1     0     0
.line	76	settable      r0   k63    r1
.line	77	gettable      r1    r0   k63
.line	77	gettabup      r2    u0   k49
.line	77	gettable      r2    r2   k36
.line	77	gettable      r2    r2   k51
.line	77	add           r2    r2   k64
.line	77	settable      r1   k51    r2
.line	78	gettable      r1    r0   k63
.line	78	gettabup      r2    u0    k1
.line	78	gettable      r2    r2   k54
.line	78	settable      r1   k53    r2
.line	79	gettable      r1    r0   k63
.line	79	settable      r1   k55   k42
.line	80	gettable      r1    r0   k63
.line	80	settable      r1   k56   k57
.line	81	newtable      r1     0     0
.line	81	settable      r0   k59    r1
.line	82	gettable      r1    r0   k59
.line	82	gettabup      r2    u0   k49
.line	82	gettable      r2    r2   k36
.line	82	gettable      r2    r2   k51
.line	82	add           r2    r2   k65
.line	82	settable      r1   k51    r2
.line	83	gettable      r1    r0   k59
.line	83	gettabup      r2    u0    k1
.line	83	gettable      r2    r2   k54
.line	83	settable      r1   k53    r2
.line	84	gettable      r1    r0   k59
.line	84	settable      r1   k55   k42
.line	85	gettable      r1    r0   k59
.line	85	settable      r1   k56   k57
.line	86	newtable      r1     0     0
.line	86	settable      r0   k66    r1
.line	87	gettable      r1    r0   k66
.line	87	gettabup      r2    u0   k49
.line	87	gettable      r2    r2   k36
.line	87	gettable      r2    r2   k51
.line	87	add           r2    r2   k67
.line	87	settable      r1   k51    r2
.line	88	gettable      r1    r0   k66
.line	88	gettabup      r2    u0    k1
.line	88	gettable      r2    r2   k54
.line	88	settable      r1   k53    r2
.line	89	gettable      r1    r0   k66
.line	89	settable      r1   k55   k42
.line	90	gettable      r1    r0   k66
.line	90	settable      r1   k56   k57
.line	91	newtable      r1     0     0
.line	91	settable      r0   k61    r1
.line	92	gettable      r1    r0   k61
.line	92	gettabup      r2    u0   k49
.line	92	gettable      r2    r2   k36
.line	92	gettable      r2    r2   k51
.line	92	add           r2    r2   k68
.line	92	settable      r1   k51    r2
.line	93	gettable      r1    r0   k61
.line	93	gettabup      r2    u0    k1
.line	93	gettable      r2    r2   k54
.line	93	settable      r1   k53    r2
.line	94	gettable      r1    r0   k61
.line	94	settable      r1   k55   k69
.line	95	gettable      r1    r0   k61
.line	95	settable      r1   k56   k57
.line	96	newtable      r1     0     0
.line	96	settable      r0   k70    r1
.line	97	gettable      r1    r0   k70
.line	97	gettabup      r2    u0   k49
.line	97	gettable      r2    r2   k36
.line	97	gettable      r2    r2   k51
.line	97	add           r2    r2   k71
.line	97	settable      r1   k51    r2
.line	98	gettable      r1    r0   k70
.line	98	gettabup      r2    u0    k1
.line	98	gettable      r2    r2   k45
.line	98	settable      r1   k53    r2
.line	99	gettable      r1    r0   k70
.line	99	settable      r1   k55   k72
.line	100	gettable      r1    r0   k70
.line	100	settable      r1   k56   k57
.line	101	newtable      r1     0     0
.line	101	settable      r0   k62    r1
.line	102	gettable      r1    r0   k62
.line	102	gettabup      r2    u0   k49
.line	102	gettable      r2    r2   k36
.line	102	gettable      r2    r2   k51
.line	102	add           r2    r2   k73
.line	102	settable      r1   k51    r2
.line	103	gettable      r1    r0   k62
.line	103	gettabup      r2    u0    k1
.line	103	gettable      r2    r2   k54
.line	103	settable      r1   k53    r2
.line	104	gettable      r1    r0   k62
.line	104	settable      r1   k55   k74
.line	105	gettable      r1    r0   k62
.line	105	settable      r1   k56   k57
.line	106	newtable      r1     0     0
.line	106	settable      r0   k75    r1
.line	107	gettable      r1    r0   k75
.line	107	gettabup      r2    u0   k49
.line	107	gettable      r2    r2   k36
.line	107	gettable      r2    r2   k51
.line	107	sub           r2    r2   k67
.line	107	settable      r1   k51    r2
.line	108	gettable      r1    r0   k75
.line	108	gettabup      r2    u0    k1
.line	108	gettable      r2    r2   k45
.line	108	settable      r1   k53    r2
.line	109	gettable      r1    r0   k75
.line	109	settable      r1   k55   k76
.line	110	gettable      r1    r0   k75
.line	110	settable      r1   k56   k57
.line	111	newtable      r1     0     0
.line	111	settable      r0   k64    r1
.line	112	gettable      r1    r0   k64
.line	112	gettabup      r2    u0   k49
.line	112	gettable      r2    r2   k36
.line	112	gettable      r2    r2   k51
.line	112	sub           r2    r2   k77
.line	112	settable      r1   k51    r2
.line	113	gettable      r1    r0   k64
.line	113	gettabup      r2    u0    k1
.line	113	gettable      r2    r2   k45
.line	113	settable      r1   k53    r2
.line	114	gettable      r1    r0   k64
.line	114	settable      r1   k55   k74
.line	115	gettable      r1    r0   k64
.line	115	settable      r1   k56   k57
.line	116	newtable      r1     0     0
.line	116	settable      r0   k78    r1
.line	117	gettable      r1    r0   k78
.line	117	gettabup      r2    u0   k49
.line	117	gettable      r2    r2   k36
.line	117	gettable      r2    r2   k51
.line	117	add           r2    r2   k79
.line	117	settable      r1   k51    r2
.line	118	gettable      r1    r0   k78
.line	118	gettabup      r2    u0    k1
.line	118	gettable      r2    r2   k45
.line	118	settable      r1   k53    r2
.line	119	gettable      r1    r0   k78
.line	119	settable      r1   k55   k80
.line	120	gettable      r1    r0   k78
.line	120	settable      r1   k56   k57
.line	121	newtable      r1     0     0
.line	121	settable      r0   k65    r1
.line	122	gettable      r1    r0   k65
.line	122	gettabup      r2    u0   k49
.line	122	gettable      r2    r2   k36
.line	122	gettable      r2    r2   k51
.line	122	sub           r2    r2   k81
.line	122	settable      r1   k51    r2
.line	123	gettable      r1    r0   k65
.line	123	gettabup      r2    u0    k1
.line	123	gettable      r2    r2   k45
.line	123	settable      r1   k53    r2
.line	124	gettable      r1    r0   k65
.line	124	settable      r1   k55   k74
.line	125	gettable      r1    r0   k65
.line	125	settable      r1   k56   k57
.line	126	gettabup      r1    u0    k1
.line	126	gettable      r1    r1   k82
.line	126	move          r2    r0
.line	126	call          r1     2     1
.line	127	gettabup      r1    u0    k1
.line	127	gettable      r1    r1   k83
.line	127	move          r2    r0
.line	127	call          r1     2     1
.line	128	gettabup      r1    u0    k1
.line	128	gettable      r1    r1   k84
.line	128	call          r1     1     1
.line	129	gettabup      r1    u0    k1
.line	129	gettable      r1    r1   k34
.line	129	loadk         r2   k85
.line	129	call          r1     2     1
.label	l344
.line	132	gettabup      r0    u0    k0
.line	132	eq             0    r0   k58
.line	132	jmp            0  l642
.line	133	gettabup      r0    u0    k1
.line	133	gettable      r0    r0   k37
.line	133	gettabup      r1    u0    k1
.line	133	gettable      r1    r1   k38
.line	133	gettabup      r2    u0    k1
.line	133	gettable      r2    r2   k39
.line	133	bor           r1    r1    r2
.line	133	call          r0     2     1
.line	134	gettabup      r0    u0    k1
.line	134	gettable      r0    r0   k34
.line	134	loadk         r1   k40
.line	134	call          r0     2     1
.line	135	gettabup      r0    u0    k1
.line	135	gettable      r0    r0   k41
.line	135	loadk         r1   k42
.line	135	call          r0     2     1
.line	136	gettabup      r0    u0    k1
.line	136	gettable      r0    r0   k43
.line	136	loadk         r1   k44
.line	136	gettabup      r2    u0    k1
.line	136	gettable      r2    r2   k45
.line	136	call          r0     3     1
.line	137	gettabup      r0    u0    k1
.line	137	gettable      r0    r0   k34
.line	137	loadk         r1   k46
.line	137	call          r0     2     1
.line	138	gettabup      r0    u0    k1
.line	138	gettable      r0    r0   k41
.line	138	loadk         r1   k42
.line	138	call          r0     2     1
.line	139	gettabup      r0    u0    k1
.line	139	gettable      r0    r0   k47
.line	139	loadk         r1   k48
.line	139	gettabup      r2    u0    k1
.line	139	gettable      r2    r2   k45
.line	139	call          r0     3     1
.line	140	gettabup      r0    u0    k1
.line	140	gettable      r0    r0   k34
.line	140	loadk         r1   k40
.line	140	call          r0     2     1
.line	141	gettabup      r0    u0    k1
.line	141	gettable      r0    r0   k41
.line	141	loadk         r1   k42
.line	141	call          r0     2     1
.line	142	gettabup      r0    u0    k1
.line	142	gettable      r0    r0   k47
.line	142	loadk         r1   k44
.line	142	gettabup      r2    u0    k1
.line	142	gettable      r2    r2   k45
.line	142	call          r0     3     1
.line	143	gettabup      r0    u0    k1
.line	143	gettable      r0    r0   k50
.line	143	loadk         r1   k36
.line	143	call          r0     2     2
.line	143	settabup      u0   k49    r0
.line	144	newtable      r0     0     0
.line	145	newtable      r1     0     0
.line	145	settable      r0   k36    r1
.line	146	gettable      r1    r0   k36
.line	146	gettabup      r2    u0   k49
.line	146	gettable      r2    r2   k36
.line	146	gettable      r2    r2   k51
.line	146	add           r2    r2   k52
.line	146	settable      r1   k51    r2
.line	147	gettable      r1    r0   k36
.line	147	gettabup      r2    u0    k1
.line	147	gettable      r2    r2   k54
.line	147	settable      r1   k53    r2
.line	148	gettable      r1    r0   k36
.line	148	settable      r1   k55   k42
.line	149	gettable      r1    r0   k36
.line	149	settable      r1   k56   k57
.line	150	newtable      r1     0     0
.line	150	settable      r0   k58    r1
.line	151	gettable      r1    r0   k58
.line	151	gettabup      r2    u0   k49
.line	151	gettable      r2    r2   k36
.line	151	gettable      r2    r2   k51
.line	151	add           r2    r2   k59
.line	151	settable      r1   k51    r2
.line	152	gettable      r1    r0   k58
.line	152	gettabup      r2    u0    k1
.line	152	gettable      r2    r2   k54
.line	152	settable      r1   k53    r2
.line	153	gettable      r1    r0   k58
.line	153	settable      r1   k55   k42
.line	154	gettable      r1    r0   k58
.line	154	settable      r1   k56   k57
.line	155	newtable      r1     0     0
.line	155	settable      r0   k60    r1
.line	156	gettable      r1    r0   k60
.line	156	gettabup      r2    u0   k49
.line	156	gettable      r2    r2   k36
.line	156	gettable      r2    r2   k51
.line	156	add           r2    r2   k61
.line	156	settable      r1   k51    r2
.line	157	gettable      r1    r0   k60
.line	157	gettabup      r2    u0    k1
.line	157	gettable      r2    r2   k54
.line	157	settable      r1   k53    r2
.line	158	gettable      r1    r0   k60
.line	158	settable      r1   k55   k42
.line	159	gettable      r1    r0   k60
.line	159	settable      r1   k56   k57
.line	160	newtable      r1     0     0
.line	160	settable      r0   k52    r1
.line	161	gettable      r1    r0   k52
.line	161	gettabup      r2    u0   k49
.line	161	gettable      r2    r2   k36
.line	161	gettable      r2    r2   k51
.line	161	add           r2    r2   k62
.line	161	settable      r1   k51    r2
.line	162	gettable      r1    r0   k52
.line	162	gettabup      r2    u0    k1
.line	162	gettable      r2    r2   k54
.line	162	settable      r1   k53    r2
.line	163	gettable      r1    r0   k52
.line	163	settable      r1   k55   k42
.line	164	gettable      r1    r0   k52
.line	164	settable      r1   k56   k57
.line	165	newtable      r1     0     0
.line	165	settable      r0   k63    r1
.line	166	gettable      r1    r0   k63
.line	166	gettabup      r2    u0   k49
.line	166	gettable      r2    r2   k36
.line	166	gettable      r2    r2   k51
.line	166	add           r2    r2   k64
.line	166	settable      r1   k51    r2
.line	167	gettable      r1    r0   k63
.line	167	gettabup      r2    u0    k1
.line	167	gettable      r2    r2   k54
.line	167	settable      r1   k53    r2
.line	168	gettable      r1    r0   k63
.line	168	settable      r1   k55   k42
.line	169	gettable      r1    r0   k63
.line	169	settable      r1   k56   k57
.line	170	newtable      r1     0     0
.line	170	settable      r0   k59    r1
.line	171	gettable      r1    r0   k59
.line	171	gettabup      r2    u0   k49
.line	171	gettable      r2    r2   k36
.line	171	gettable      r2    r2   k51
.line	171	add           r2    r2   k65
.line	171	settable      r1   k51    r2
.line	172	gettable      r1    r0   k59
.line	172	gettabup      r2    u0    k1
.line	172	gettable      r2    r2   k54
.line	172	settable      r1   k53    r2
.line	173	gettable      r1    r0   k59
.line	173	settable      r1   k55   k42
.line	174	gettable      r1    r0   k59
.line	174	settable      r1   k56   k57
.line	175	newtable      r1     0     0
.line	175	settable      r0   k66    r1
.line	176	gettable      r1    r0   k66
.line	176	gettabup      r2    u0   k49
.line	176	gettable      r2    r2   k36
.line	176	gettable      r2    r2   k51
.line	176	add           r2    r2   k67
.line	176	settable      r1   k51    r2
.line	177	gettable      r1    r0   k66
.line	177	gettabup      r2    u0    k1
.line	177	gettable      r2    r2   k54
.line	177	settable      r1   k53    r2
.line	178	gettable      r1    r0   k66
.line	178	settable      r1   k55   k42
.line	179	gettable      r1    r0   k66
.line	179	settable      r1   k56   k57
.line	180	newtable      r1     0     0
.line	180	settable      r0   k61    r1
.line	181	gettable      r1    r0   k61
.line	181	gettabup      r2    u0   k49
.line	181	gettable      r2    r2   k36
.line	181	gettable      r2    r2   k51
.line	181	add           r2    r2   k68
.line	181	settable      r1   k51    r2
.line	182	gettable      r1    r0   k61
.line	182	gettabup      r2    u0    k1
.line	182	gettable      r2    r2   k54
.line	182	settable      r1   k53    r2
.line	183	gettable      r1    r0   k61
.line	183	settable      r1   k55   k69
.line	184	gettable      r1    r0   k61
.line	184	settable      r1   k56   k57
.line	185	newtable      r1     0     0
.line	185	settable      r0   k70    r1
.line	186	gettable      r1    r0   k70
.line	186	gettabup      r2    u0   k49
.line	186	gettable      r2    r2   k36
.line	186	gettable      r2    r2   k51
.line	186	sub           r2    r2   k77
.line	186	settable      r1   k51    r2
.line	187	gettable      r1    r0   k70
.line	187	gettabup      r2    u0    k1
.line	187	gettable      r2    r2   k45
.line	187	settable      r1   k53    r2
.line	188	gettable      r1    r0   k70
.line	188	settable      r1   k55   k86
.line	189	gettable      r1    r0   k70
.line	189	settable      r1   k56   k57
.line	190	newtable      r1     0     0
.line	190	settable      r0   k62    r1
.line	191	gettable      r1    r0   k62
.line	191	gettabup      r2    u0   k49
.line	191	gettable      r2    r2   k36
.line	191	gettable      r2    r2   k51
.line	191	sub           r2    r2   k67
.line	191	settable      r1   k51    r2
.line	192	gettable      r1    r0   k62
.line	192	gettabup      r2    u0    k1
.line	192	gettable      r2    r2   k45
.line	192	settable      r1   k53    r2
.line	193	gettable      r1    r0   k62
.line	193	settable      r1   k55   k74
.line	194	gettable      r1    r0   k62
.line	194	settable      r1   k56   k57
.line	195	newtable      r1     0     0
.line	195	settable      r0   k75    r1
.line	196	gettable      r1    r0   k75
.line	196	gettabup      r2    u0   k49
.line	196	gettable      r2    r2   k36
.line	196	gettable      r2    r2   k51
.line	196	add           r2    r2   k71
.line	196	settable      r1   k51    r2
.line	197	gettable      r1    r0   k75
.line	197	gettabup      r2    u0    k1
.line	197	gettable      r2    r2   k45
.line	197	settable      r1   k53    r2
.line	198	gettable      r1    r0   k75
.line	198	settable      r1   k55   k72
.line	199	gettable      r1    r0   k75
.line	199	settable      r1   k56   k57
.line	200	newtable      r1     0     0
.line	200	settable      r0   k64    r1
.line	201	gettable      r1    r0   k64
.line	201	gettabup      r2    u0   k49
.line	201	gettable      r2    r2   k36
.line	201	gettable      r2    r2   k51
.line	201	sub           r2    r2   k81
.line	201	settable      r1   k51    r2
.line	202	gettable      r1    r0   k64
.line	202	gettabup      r2    u0    k1
.line	202	gettable      r2    r2   k45
.line	202	settable      r1   k53    r2
.line	203	gettable      r1    r0   k64
.line	203	settable      r1   k55   k74
.line	204	gettable      r1    r0   k64
.line	204	settable      r1   k56   k57
.line	205	newtable      r1     0     0
.line	205	settable      r0   k78    r1
.line	206	gettable      r1    r0   k78
.line	206	gettabup      r2    u0   k49
.line	206	gettable      r2    r2   k36
.line	206	gettable      r2    r2   k51
.line	206	add           r2    r2   k79
.line	206	settable      r1   k51    r2
.line	207	gettable      r1    r0   k78
.line	207	gettabup      r2    u0    k1
.line	207	gettable      r2    r2   k45
.line	207	settable      r1   k53    r2
.line	208	gettable      r1    r0   k78
.line	208	settable      r1   k55   k80
.line	209	gettable      r1    r0   k78
.line	209	settable      r1   k56   k57
.line	210	newtable      r1     0     0
.line	210	settable      r0   k65    r1
.line	211	gettable      r1    r0   k65
.line	211	gettabup      r2    u0   k49
.line	211	gettable      r2    r2   k36
.line	211	gettable      r2    r2   k51
.line	211	add           r2    r2   k73
.line	211	settable      r1   k51    r2
.line	212	gettable      r1    r0   k65
.line	212	gettabup      r2    u0    k1
.line	212	gettable      r2    r2   k54
.line	212	settable      r1   k53    r2
.line	213	gettable      r1    r0   k65
.line	213	settable      r1   k55   k74
.line	214	gettable      r1    r0   k65
.line	214	settable      r1   k56   k57
.line	215	gettabup      r1    u0    k1
.line	215	gettable      r1    r1   k82
.line	215	move          r2    r0
.line	215	call          r1     2     1
.line	216	gettabup      r1    u0    k1
.line	216	gettable      r1    r1   k83
.line	216	move          r2    r0
.line	216	call          r1     2     1
.line	217	gettabup      r1    u0    k1
.line	217	gettable      r1    r1   k84
.line	217	call          r1     1     1
.line	218	gettabup      r1    u0    k1
.line	218	gettable      r1    r1   k34
.line	218	loadk         r2   k85
.line	218	call          r1     2     1
.label	l642
.line	221	gettabup      r0    u0    k0
.line	221	eq             0    r0   k60
.line	221	jmp            0  l732
.line	222	gettabup      r0    u0    k1
.line	222	gettable      r0    r0   k37
.line	222	gettabup      r1    u0    k1
.line	222	gettable      r1    r1   k38
.line	222	gettabup      r2    u0    k1
.line	222	gettable      r2    r2   k39
.line	222	bor           r1    r1    r2
.line	222	call          r0     2     1
.line	223	gettabup      r0    u0    k1
.line	223	gettable      r0    r0   k34
.line	223	loadk         r1   k40
.line	223	call          r0     2     1
.line	224	gettabup      r0    u0    k1
.line	224	gettable      r0    r0   k41
.line	224	loadk         r1   k42
.line	224	call          r0     2     1
.line	225	gettabup      r0    u0    k1
.line	225	gettable      r0    r0   k43
.line	225	loadk         r1   k44
.line	225	gettabup      r2    u0    k1
.line	225	gettable      r2    r2   k45
.line	225	call          r0     3     1
.line	226	gettabup      r0    u0    k1
.line	226	gettable      r0    r0   k34
.line	226	loadk         r1   k46
.line	226	call          r0     2     1
.line	227	gettabup      r0    u0    k1
.line	227	gettable      r0    r0   k41
.line	227	loadk         r1   k42
.line	227	call          r0     2     1
.line	228	gettabup      r0    u0    k1
.line	228	gettable      r0    r0   k47
.line	228	loadk         r1   k48
.line	228	gettabup      r2    u0    k1
.line	228	gettable      r2    r2   k45
.line	228	call          r0     3     1
.line	229	gettabup      r0    u0    k1
.line	229	gettable      r0    r0   k34
.line	229	loadk         r1   k40
.line	229	call          r0     2     1
.line	230	gettabup      r0    u0    k1
.line	230	gettable      r0    r0   k41
.line	230	loadk         r1   k42
.line	230	call          r0     2     1
.line	231	gettabup      r0    u0    k1
.line	231	gettable      r0    r0   k47
.line	231	loadk         r1   k44
.line	231	gettabup      r2    u0    k1
.line	231	gettable      r2    r2   k45
.line	231	call          r0     3     1
.line	232	gettabup      r0    u0    k1
.line	232	gettable      r0    r0   k50
.line	232	loadk         r1   k36
.line	232	call          r0     2     2
.line	232	settabup      u0   k49    r0
.line	233	newtable      r0     0     0
.line	234	newtable      r1     0     0
.line	234	settable      r0   k36    r1
.line	235	gettable      r1    r0   k36
.line	235	gettabup      r2    u0   k49
.line	235	gettable      r2    r2   k36
.line	235	gettable      r2    r2   k51
.line	235	sub           r2    r2   k87
.line	235	settable      r1   k51    r2
.line	236	gettable      r1    r0   k36
.line	236	gettabup      r2    u0    k1
.line	236	gettable      r2    r2   k45
.line	236	settable      r1   k53    r2
.line	237	gettable      r1    r0   k36
.line	237	settable      r1   k55   k36
.line	238	gettable      r1    r0   k36
.line	238	settable      r1   k56   k57
.line	239	gettabup      r1    u0    k1
.line	239	gettable      r1    r1   k82
.line	239	move          r2    r0
.line	239	call          r1     2     1
.line	240	gettabup      r1    u0    k1
.line	240	gettable      r1    r1   k83
.line	240	move          r2    r0
.line	240	call          r1     2     1
.line	241	gettabup      r1    u0    k1
.line	241	gettable      r1    r1   k84
.line	241	call          r1     1     1
.line	242	gettabup      r1    u0    k1
.line	242	gettable      r1    r1   k34
.line	242	loadk         r2   k85
.line	242	call          r1     2     1
.label	l732
.line	245	gettabup      r0    u0    k0
.line	245	eq             0    r0   k52
.line	245	jmp            0  l822
.line	246	gettabup      r0    u0    k1
.line	246	gettable      r0    r0   k37
.line	246	gettabup      r1    u0    k1
.line	246	gettable      r1    r1   k38
.line	246	gettabup      r2    u0    k1
.line	246	gettable      r2    r2   k39
.line	246	bor           r1    r1    r2
.line	246	call          r0     2     1
.line	247	gettabup      r0    u0    k1
.line	247	gettable      r0    r0   k34
.line	247	loadk         r1   k40
.line	247	call          r0     2     1
.line	248	gettabup      r0    u0    k1
.line	248	gettable      r0    r0   k41
.line	248	loadk         r1   k42
.line	248	call          r0     2     1
.line	249	gettabup      r0    u0    k1
.line	249	gettable      r0    r0   k43
.line	249	loadk         r1   k44
.line	249	gettabup      r2    u0    k1
.line	249	gettable      r2    r2   k45
.line	249	call          r0     3     1
.line	250	gettabup      r0    u0    k1
.line	250	gettable      r0    r0   k34
.line	250	loadk         r1   k46
.line	250	call          r0     2     1
.line	251	gettabup      r0    u0    k1
.line	251	gettable      r0    r0   k41
.line	251	loadk         r1   k42
.line	251	call          r0     2     1
.line	252	gettabup      r0    u0    k1
.line	252	gettable      r0    r0   k47
.line	252	loadk         r1   k48
.line	252	gettabup      r2    u0    k1
.line	252	gettable      r2    r2   k45
.line	252	call          r0     3     1
.line	253	gettabup      r0    u0    k1
.line	253	gettable      r0    r0   k34
.line	253	loadk         r1   k40
.line	253	call          r0     2     1
.line	254	gettabup      r0    u0    k1
.line	254	gettable      r0    r0   k41
.line	254	loadk         r1   k42
.line	254	call          r0     2     1
.line	255	gettabup      r0    u0    k1
.line	255	gettable      r0    r0   k47
.line	255	loadk         r1   k44
.line	255	gettabup      r2    u0    k1
.line	255	gettable      r2    r2   k45
.line	255	call          r0     3     1
.line	256	gettabup      r0    u0    k1
.line	256	gettable      r0    r0   k50
.line	256	loadk         r1   k36
.line	256	call          r0     2     2
.line	256	settabup      u0   k49    r0
.line	257	newtable      r0     0     0
.line	258	newtable      r1     0     0
.line	258	settable      r0   k36    r1
.line	259	gettable      r1    r0   k36
.line	259	gettabup      r2    u0   k49
.line	259	gettable      r2    r2   k36
.line	259	gettable      r2    r2   k51
.line	259	sub           r2    r2   k87
.line	259	settable      r1   k51    r2
.line	260	gettable      r1    r0   k36
.line	260	gettabup      r2    u0    k1
.line	260	gettable      r2    r2   k45
.line	260	settable      r1   k53    r2
.line	261	gettable      r1    r0   k36
.line	261	settable      r1   k55   k74
.line	262	gettable      r1    r0   k36
.line	262	settable      r1   k56   k57
.line	263	gettabup      r1    u0    k1
.line	263	gettable      r1    r1   k82
.line	263	move          r2    r0
.line	263	call          r1     2     1
.line	264	gettabup      r1    u0    k1
.line	264	gettable      r1    r1   k83
.line	264	move          r2    r0
.line	264	call          r1     2     1
.line	265	gettabup      r1    u0    k1
.line	265	gettable      r1    r1   k84
.line	265	call          r1     1     1
.line	266	gettabup      r1    u0    k1
.line	266	gettable      r1    r1   k34
.line	266	loadk         r2   k85
.line	266	call          r1     2     1
.label	l822
.line	269	gettabup      r0    u0    k0
.line	269	eq             0    r0   k63
.line	269	jmp            0 l1096
.line	270	gettabup      r0    u0    k1
.line	270	gettable      r0    r0   k37
.line	270	gettabup      r1    u0    k1
.line	270	gettable      r1    r1   k38
.line	270	gettabup      r2    u0    k1
.line	270	gettable      r2    r2   k39
.line	270	bor           r1    r1    r2
.line	270	call          r0     2     1
.line	271	gettabup      r0    u0    k1
.line	271	gettable      r0    r0   k34
.line	271	loadk         r1   k40
.line	271	call          r0     2     1
.line	272	gettabup      r0    u0    k1
.line	272	gettable      r0    r0   k41
.line	272	loadk         r1   k42
.line	272	call          r0     2     1
.line	273	gettabup      r0    u0    k1
.line	273	gettable      r0    r0   k43
.line	273	loadk         r1   k44
.line	273	gettabup      r2    u0    k1
.line	273	gettable      r2    r2   k45
.line	273	call          r0     3     1
.line	274	gettabup      r0    u0    k1
.line	274	gettable      r0    r0   k34
.line	274	loadk         r1   k46
.line	274	call          r0     2     1
.line	275	gettabup      r0    u0    k1
.line	275	gettable      r0    r0   k41
.line	275	loadk         r1   k42
.line	275	call          r0     2     1
.line	276	gettabup      r0    u0    k1
.line	276	gettable      r0    r0   k47
.line	276	loadk         r1   k48
.line	276	gettabup      r2    u0    k1
.line	276	gettable      r2    r2   k45
.line	276	call          r0     3     1
.line	277	gettabup      r0    u0    k1
.line	277	gettable      r0    r0   k34
.line	277	loadk         r1   k40
.line	277	call          r0     2     1
.line	278	gettabup      r0    u0    k1
.line	278	gettable      r0    r0   k41
.line	278	loadk         r1   k42
.line	278	call          r0     2     1
.line	279	gettabup      r0    u0    k1
.line	279	gettable      r0    r0   k47
.line	279	loadk         r1   k44
.line	279	gettabup      r2    u0    k1
.line	279	gettable      r2    r2   k45
.line	279	call          r0     3     1
.line	280	gettabup      r0    u0    k1
.line	280	gettable      r0    r0   k50
.line	280	loadk         r1   k36
.line	280	call          r0     2     2
.line	280	settabup      u0   k49    r0
.line	281	newtable      r0     0     0
.line	282	newtable      r1     0     0
.line	282	settable      r0   k36    r1
.line	283	gettable      r1    r0   k36
.line	283	gettabup      r2    u0   k49
.line	283	gettable      r2    r2   k36
.line	283	gettable      r2    r2   k51
.line	283	add           r2    r2   k52
.line	283	settable      r1   k51    r2
.line	284	gettable      r1    r0   k36
.line	284	gettabup      r2    u0    k1
.line	284	gettable      r2    r2   k54
.line	284	settable      r1   k53    r2
.line	285	gettable      r1    r0   k36
.line	285	settable      r1   k55   k88
.line	286	gettable      r1    r0   k36
.line	286	settable      r1   k56   k57
.line	287	newtable      r1     0     0
.line	287	settable      r0   k58    r1
.line	288	gettable      r1    r0   k58
.line	288	gettabup      r2    u0   k49
.line	288	gettable      r2    r2   k36
.line	288	gettable      r2    r2   k51
.line	288	add           r2    r2   k59
.line	288	settable      r1   k51    r2
.line	289	gettable      r1    r0   k58
.line	289	gettabup      r2    u0    k1
.line	289	gettable      r2    r2   k54
.line	289	settable      r1   k53    r2
.line	290	gettable      r1    r0   k58
.line	290	settable      r1   k55   k88
.line	291	gettable      r1    r0   k58
.line	291	settable      r1   k56   k57
.line	292	newtable      r1     0     0
.line	292	settable      r0   k60    r1
.line	293	gettable      r1    r0   k60
.line	293	gettabup      r2    u0   k49
.line	293	gettable      r2    r2   k36
.line	293	gettable      r2    r2   k51
.line	293	add           r2    r2   k61
.line	293	settable      r1   k51    r2
.line	294	gettable      r1    r0   k60
.line	294	gettabup      r2    u0    k1
.line	294	gettable      r2    r2   k54
.line	294	settable      r1   k53    r2
.line	295	gettable      r1    r0   k60
.line	295	settable      r1   k55   k88
.line	296	gettable      r1    r0   k60
.line	296	settable      r1   k56   k57
.line	297	newtable      r1     0     0
.line	297	settable      r0   k52    r1
.line	298	gettable      r1    r0   k52
.line	298	gettabup      r2    u0   k49
.line	298	gettable      r2    r2   k36
.line	298	gettable      r2    r2   k51
.line	298	add           r2    r2   k62
.line	298	settable      r1   k51    r2
.line	299	gettable      r1    r0   k52
.line	299	gettabup      r2    u0    k1
.line	299	gettable      r2    r2   k54
.line	299	settable      r1   k53    r2
.line	300	gettable      r1    r0   k52
.line	300	settable      r1   k55   k88
.line	301	gettable      r1    r0   k52
.line	301	settable      r1   k56   k57
.line	302	newtable      r1     0     0
.line	302	settable      r0   k63    r1
.line	303	gettable      r1    r0   k63
.line	303	gettabup      r2    u0   k49
.line	303	gettable      r2    r2   k36
.line	303	gettable      r2    r2   k51
.line	303	add           r2    r2   k64
.line	303	settable      r1   k51    r2
.line	304	gettable      r1    r0   k63
.line	304	gettabup      r2    u0    k1
.line	304	gettable      r2    r2   k54
.line	304	settable      r1   k53    r2
.line	305	gettable      r1    r0   k63
.line	305	settable      r1   k55   k88
.line	306	gettable      r1    r0   k63
.line	306	settable      r1   k56   k57
.line	307	newtable      r1     0     0
.line	307	settable      r0   k59    r1
.line	308	gettable      r1    r0   k59
.line	308	gettabup      r2    u0   k49
.line	308	gettable      r2    r2   k36
.line	308	gettable      r2    r2   k51
.line	308	add           r2    r2   k65
.line	308	settable      r1   k51    r2
.line	309	gettable      r1    r0   k59
.line	309	gettabup      r2    u0    k1
.line	309	gettable      r2    r2   k54
.line	309	settable      r1   k53    r2
.line	310	gettable      r1    r0   k59
.line	310	settable      r1   k55   k88
.line	311	gettable      r1    r0   k59
.line	311	settable      r1   k56   k57
.line	312	newtable      r1     0     0
.line	312	settable      r0   k66    r1
.line	313	gettable      r1    r0   k66
.line	313	gettabup      r2    u0   k49
.line	313	gettable      r2    r2   k36
.line	313	gettable      r2    r2   k51
.line	313	add           r2    r2   k67
.line	313	settable      r1   k51    r2
.line	314	gettable      r1    r0   k66
.line	314	gettabup      r2    u0    k1
.line	314	gettable      r2    r2   k54
.line	314	settable      r1   k53    r2
.line	315	gettable      r1    r0   k66
.line	315	settable      r1   k55   k88
.line	316	gettable      r1    r0   k66
.line	316	settable      r1   k56   k57
.line	317	newtable      r1     0     0
.line	317	settable      r0   k61    r1
.line	318	gettable      r1    r0   k61
.line	318	gettabup      r2    u0   k49
.line	318	gettable      r2    r2   k36
.line	318	gettable      r2    r2   k51
.line	318	add           r2    r2   k68
.line	318	settable      r1   k51    r2
.line	319	gettable      r1    r0   k61
.line	319	gettabup      r2    u0    k1
.line	319	gettable      r2    r2   k54
.line	319	settable      r1   k53    r2
.line	320	gettable      r1    r0   k61
.line	320	settable      r1   k55   k69
.line	321	gettable      r1    r0   k61
.line	321	settable      r1   k56   k57
.line	322	newtable      r1     0     0
.line	322	settable      r0   k70    r1
.line	323	gettable      r1    r0   k70
.line	323	gettabup      r2    u0   k49
.line	323	gettable      r2    r2   k36
.line	323	gettable      r2    r2   k51
.line	323	sub           r2    r2   k81
.line	323	settable      r1   k51    r2
.line	324	gettable      r1    r0   k70
.line	324	gettabup      r2    u0    k1
.line	324	gettable      r2    r2   k45
.line	324	settable      r1   k53    r2
.line	325	gettable      r1    r0   k70
.line	325	settable      r1   k55   k74
.line	326	gettable      r1    r0   k70
.line	326	settable      r1   k56   k57
.line	327	newtable      r1     0     0
.line	327	settable      r0   k62    r1
.line	328	gettable      r1    r0   k62
.line	328	gettabup      r2    u0   k49
.line	328	gettable      r2    r2   k36
.line	328	gettable      r2    r2   k51
.line	328	sub           r2    r2   k67
.line	328	settable      r1   k51    r2
.line	329	gettable      r1    r0   k62
.line	329	gettabup      r2    u0    k1
.line	329	gettable      r2    r2   k45
.line	329	settable      r1   k53    r2
.line	330	gettable      r1    r0   k62
.line	330	settable      r1   k55   k76
.line	331	gettable      r1    r0   k62
.line	331	settable      r1   k56   k57
.line	332	newtable      r1     0     0
.line	332	settable      r0   k75    r1
.line	333	gettable      r1    r0   k75
.line	333	gettabup      r2    u0   k49
.line	333	gettable      r2    r2   k36
.line	333	gettable      r2    r2   k51
.line	333	sub           r2    r2   k77
.line	333	settable      r1   k51    r2
.line	334	gettable      r1    r0   k75
.line	334	gettabup      r2    u0    k1
.line	334	gettable      r2    r2   k45
.line	334	settable      r1   k53    r2
.line	335	gettable      r1    r0   k75
.line	335	settable      r1   k55   k74
.line	336	gettable      r1    r0   k75
.line	336	settable      r1   k56   k57
.line	337	newtable      r1     0     0
.line	337	settable      r0   k64    r1
.line	338	gettable      r1    r0   k64
.line	338	gettabup      r2    u0   k49
.line	338	gettable      r2    r2   k36
.line	338	gettable      r2    r2   k51
.line	338	add           r2    r2   k89
.line	338	settable      r1   k51    r2
.line	339	gettable      r1    r0   k64
.line	339	gettabup      r2    u0    k1
.line	339	gettable      r2    r2   k45
.line	339	settable      r1   k53    r2
.line	340	gettable      r1    r0   k64
.line	340	settable      r1   k55   k74
.line	341	gettable      r1    r0   k64
.line	341	settable      r1   k56   k57
.line	342	gettable      r1    r0   k64
.line	342	gettabup      r2    u0    k1
.line	342	gettable      r2    r2   k91
.line	342	settable      r1   k90    r2
.line	343	gettable      r1    r0   k64
.line	343	settable      r1   k92   k48
.line	344	gettable      r1    r0   k64
.line	344	settable      r1   k93   k94
.line	345	gettabup      r1    u0    k1
.line	345	gettable      r1    r1   k82
.line	345	move          r2    r0
.line	345	call          r1     2     1
.line	346	gettabup      r1    u0    k1
.line	346	gettable      r1    r1   k83
.line	346	move          r2    r0
.line	346	call          r1     2     1
.line	347	gettabup      r1    u0    k1
.line	347	gettable      r1    r1   k84
.line	347	call          r1     1     1
.line	348	gettabup      r1    u0    k1
.line	348	gettable      r1    r1   k34
.line	348	loadk         r2   k85
.line	348	call          r1     2     1
.label	l1096
.line	351	gettabup      r0    u0    k0
.line	351	eq             0    r0   k59
.line	351	jmp            0 l1155
.line	352	gettabup      r0    u0    k1
.line	352	gettable      r0    r0   k37
.line	352	gettabup      r1    u0    k1
.line	352	gettable      r1    r1   k38
.line	352	gettabup      r2    u0    k1
.line	352	gettable      r2    r2   k39
.line	352	bor           r1    r1    r2
.line	352	call          r0     2     1
.line	353	gettabup      r0    u0    k1
.line	353	gettable      r0    r0   k43
.line	353	loadk         r1   k95
.line	353	gettabup      r2    u0    k1
.line	353	gettable      r2    r2   k45
.line	353	loadbool      r3     0     0
.line	353	gettabup      r4    u0    k1
.line	353	gettable      r4    r4   k96
.line	353	loadk         r5   k74
.line	353	loadk         r6   k80
.line	353	loadk         r7   k74
.line	353	call          r0     8     1
.line	355	gettabup      r0    u0    k1
.line	355	gettable      r0    r0   k50
.line	355	loadk         r1   k98
.line	355	loadnil       r2     7
.line	355	call          r0    10     2
.line	355	settabup      u0   k97    r0
.line	356	gettabup      r0    u0    k1
.line	356	gettable      r0    r0   k50
.line	356	loadk         r1   k98
.line	356	loadnil       r2     7
.line	356	call          r0    10     2
.line	357	gettabup      r1    u0   k99
.line	357	move          r2    r0
.line	357	call          r1     2     4
.line	357	jmp            0 l1141
.label	l1134
.line	358	gettable      r6    r5   k53
.line	358	gettabup      r7    u0    k1
.line	358	gettable      r7    r7   k45
.line	358	eq             0    r6    r7
.line	358	jmp            0 l1141
.line	359	settable      r5   k55   k48
.line	360	settable      r5   k56   k57
.label	l1141
.line	357	tforcall      r1     2
.line	357	tforloop      r3 l1134
.line	363	gettabup      r1    u0    k1
.line	363	gettable      r1    r1   k83
.line	363	move          r2    r0
.line	363	call          r1     2     1
.line	364	loadnil       r0     0
.line	365	gettabup      r1    u0    k1
.line	365	gettable      r1    r1   k84
.line	365	call          r1     1     1
.line	366	gettabup      r1    u0    k1
.line	366	gettable      r1    r1   k34
.line	366	loadk         r2   k85
.line	366	call          r1     2     1
.label	l1155
.line	369	gettabup      r0    u0    k0
.line	369	eq             0    r0   k66
.line	369	jmp            0 l1248
.line	370	gettabup      r0    u0    k1
.line	370	gettable      r0    r0   k43
.line	370	loadk         r1   k95
.line	370	gettabup      r2    u0    k1
.line	370	gettable      r2    r2   k45
.line	370	loadbool      r3     0     0
.line	370	gettabup      r4    u0    k1
.line	370	gettable      r4    r4   k96
.line	370	loadk         r5   k74
.line	370	loadk         r6   k80
.line	370	loadk         r7   k74
.line	370	call          r0     8     1
.line	371	gettabup      r0    u0    k1
.line	371	gettable      r0    r0  k100
.line	371	call          r0     1     1
.line	373	gettabup      r0    u0    k1
.line	373	gettable      r0    r0   k50
.line	373	loadk         r1  k101
.line	373	loadnil       r2     7
.line	373	call          r0    10     2
.line	373	settabup      u0   k97    r0
.line	374	gettabup      r0    u0    k1
.line	374	gettable      r0    r0   k50
.line	374	loadk         r1  k101
.line	374	loadnil       r2     7
.line	374	call          r0    10     2
.line	375	gettabup      r1    u0   k99
.line	375	move          r2    r0
.line	375	call          r1     2     4
.line	375	jmp            0 l1195
.label	l1188
.line	376	gettable      r6    r5   k53
.line	376	gettabup      r7    u0    k1
.line	376	gettable      r7    r7   k45
.line	376	eq             0    r6    r7
.line	376	jmp            0 l1195
.line	377	settable      r5   k55  k102
.line	378	settable      r5   k56   k57
.label	l1195
.line	375	tforcall      r1     2
.line	375	tforloop      r3 l1188
.line	381	gettabup      r1    u0    k1
.line	381	gettable      r1    r1   k83
.line	381	move          r2    r0
.line	381	call          r1     2     1
.line	382	gettabup      r1    u0    k1
.line	382	gettable      r1    r1  k103
.line	382	loadbool      r2     0     0
.line	382	call          r1     2     1
.line	383	gettabup      r1    u0    k1
.line	383	gettable      r1    r1   k41
.line	383	loadk         r2  k104
.line	383	call          r1     2     1
.line	384	gettabup      r1    u0    k1
.line	384	gettable      r1    r1   k50
.line	384	loadk         r2  k101
.line	384	loadnil       r3     7
.line	384	call          r1    10     2
.line	384	settabup      u0   k97    r1
.line	385	gettabup      r1    u0    k1
.line	385	gettable      r1    r1   k50
.line	385	loadk         r2  k101
.line	385	loadnil       r3     7
.line	385	call          r1    10     2
.line	386	gettabup      r2    u0   k99
.line	386	move          r3    r1
.line	386	call          r2     2     4
.line	386	jmp            0 l1231
.label	l1224
.line	387	gettable      r7    r6   k53
.line	387	gettabup      r8    u0    k1
.line	387	gettable      r8    r8   k45
.line	387	eq             0    r7    r8
.line	387	jmp            0 l1231
.line	388	settable      r6   k55   k95
.line	389	settable      r6   k56   k57
.label	l1231
.line	386	tforcall      r2     2
.line	386	tforloop      r4 l1224
.line	392	gettabup      r2    u0    k1
.line	392	gettable      r2    r2   k83
.line	392	move          r3    r1
.line	392	call          r2     2     1
.line	393	gettabup      r2    u0    k1
.line	393	gettable      r2    r2  k103
.line	393	loadbool      r3     0     0
.line	393	call          r2     2     1
.line	394	gettabup      r2    u0    k1
.line	394	gettable      r2    r2   k84
.line	394	call          r2     1     1
.line	395	gettabup      r2    u0    k1
.line	395	gettable      r2    r2   k34
.line	395	loadk         r3   k85
.line	395	call          r2     2     1
.label	l1248
.line	398	gettabup      r0    u0    k0
.line	398	eq             0    r0   k61
.line	398	jmp            0 l1314
.line	399	gettabup      r0    u0    k1
.line	399	gettable      r0    r0   k37
.line	399	gettabup      r1    u0    k1
.line	399	gettable      r1    r1   k38
.line	399	gettabup      r2    u0    k1
.line	399	gettable      r2    r2   k39
.line	399	bor           r1    r1    r2
.line	399	call          r0     2     1
.line	401	gettabup      r0    u0    k1
.line	401	gettable      r0    r0   k84
.line	401	call          r0     1     1
.line	402	gettabup      r0    u0    k1
.line	402	gettable      r0    r0   k43
.line	402	loadk         r1  k105
.line	402	gettabup      r2    u0    k1
.line	402	gettable      r2    r2   k45
.line	402	loadbool      r3     0     0
.line	402	gettabup      r4    u0    k1
.line	402	gettable      r4    r4   k96
.line	402	loadk         r5   k74
.line	402	loadk         r6   k80
.line	402	loadk         r7   k74
.line	402	call          r0     8     1
.line	405	gettabup      r0    u0    k1
.line	405	gettable      r0    r0   k50
.line	405	loadk         r1   k98
.line	405	loadnil       r2     7
.line	405	call          r0    10     2
.line	405	settabup      u0   k97    r0
.line	406	gettabup      r0    u0    k1
.line	406	gettable      r0    r0   k50
.line	406	loadk         r1   k98
.line	406	loadnil       r2     7
.line	406	call          r0    10     2
.line	407	gettabup      r1    u0   k99
.line	407	move          r2    r0
.line	407	call          r1     2     4
.line	407	jmp            0 l1296
.label	l1289
.line	408	gettable      r6    r5   k53
.line	408	gettabup      r7    u0    k1
.line	408	gettable      r7    r7   k45
.line	408	eq             0    r6    r7
.line	408	jmp            0 l1296
.line	409	settable      r5   k55  k102
.line	410	settable      r5   k56   k57
.label	l1296
.line	407	tforcall      r1     2
.line	407	tforloop      r3 l1289
.line	413	gettabup      r1    u0    k1
.line	413	gettable      r1    r1   k83
.line	413	move          r2    r0
.line	413	call          r1     2     1
.line	414	loadnil       r0     0
.line	415	gettabup      r1    u0    k1
.line	415	gettable      r1    r1   k84
.line	415	call          r1     1     1
.line	416	gettabup      r1    u0    k1
.line	416	gettable      r1    r1   k41
.line	416	loadk         r2  k106
.line	416	call          r1     2     1
.line	417	gettabup      r1    u0    k1
.line	417	gettable      r1    r1   k34
.line	417	loadk         r2   k85
.line	417	call          r1     2     1
.label	l1314
.line	420	gettabup      r0    u0    k0
.line	420	eq             0    r0   k70
.line	420	jmp            0 l1367
.line	421	gettabup      r0    u0    k1
.line	421	gettable      r0    r0   k37
.line	421	gettabup      r1    u0    k1
.line	421	gettable      r1    r1  k107
.line	421	call          r0     2     1
.line	422	gettabup      r0    u0    k1
.line	422	gettable      r0    r0   k43
.line	422	loadk         r1  k108
.line	422	gettabup      r2    u0    k1
.line	422	gettable      r2    r2   k45
.line	422	loadbool      r3     0     0
.line	422	gettabup      r4    u0    k1
.line	422	gettable      r4    r4   k96
.line	422	loadk         r5   k74
.line	422	loadk         r6   k80
.line	422	loadk         r7   k74
.line	422	call          r0     8     1
.line	423	gettabup      r0    u0    k1
.line	423	gettable      r0    r0   k50
.line	423	loadk         r1   k98
.line	423	loadnil       r2     7
.line	423	call          r0    10     2
.line	423	settabup      u0   k97    r0
.line	424	gettabup      r0    u0    k1
.line	424	gettable      r0    r0   k50
.line	424	loadk         r1   k98
.line	424	loadnil       r2     7
.line	424	call          r0    10     2
.line	425	gettabup      r1    u0   k99
.line	425	move          r2    r0
.line	425	call          r1     2     4
.line	425	jmp            0 l1356
.label	l1349
.line	426	gettable      r6    r5   k53
.line	426	gettabup      r7    u0    k1
.line	426	gettable      r7    r7   k45
.line	426	eq             0    r6    r7
.line	426	jmp            0 l1356
.line	427	settable      r5   k55  k109
.line	428	settable      r5   k56   k57
.label	l1356
.line	425	tforcall      r1     2
.line	425	tforloop      r3 l1349
.line	431	gettabup      r1    u0    k1
.line	431	gettable      r1    r1   k83
.line	431	move          r2    r0
.line	431	call          r1     2     1
.line	432	loadnil       r0     0
.line	433	gettabup      r1    u0    k1
.line	433	gettable      r1    r1   k34
.line	433	loadk         r2   k85
.line	433	call          r1     2     1
.label	l1367
.line	436	gettabup      r0    u0    k0
.line	436	eq             0    r0   k62
.line	436	jmp            0 l1420
.line	437	gettabup      r0    u0    k1
.line	437	gettable      r0    r0   k37
.line	437	gettabup      r1    u0    k1
.line	437	gettable      r1    r1  k107
.line	437	call          r0     2     1
.line	438	gettabup      r0    u0    k1
.line	438	gettable      r0    r0   k43
.line	438	loadk         r1  k109
.line	438	gettabup      r2    u0    k1
.line	438	gettable      r2    r2   k45
.line	438	loadbool      r3     0     0
.line	438	gettabup      r4    u0    k1
.line	438	gettable      r4    r4   k96
.line	438	loadk         r5   k74
.line	438	loadk         r6   k80
.line	438	loadk         r7   k74
.line	438	call          r0     8     1
.line	440	gettabup      r0    u0    k1
.line	440	gettable      r0    r0   k50
.line	440	loadk         r1   k98
.line	440	loadnil       r2     7
.line	440	call          r0    10     2
.line	440	settabup      u0   k97    r0
.line	441	gettabup      r0    u0    k1
.line	441	gettable      r0    r0   k50
.line	441	loadk         r1   k98
.line	441	loadnil       r2     7
.line	441	call          r0    10     2
.line	442	gettabup      r1    u0   k99
.line	442	move          r2    r0
.line	442	call          r1     2     4
.line	442	jmp            0 l1409
.label	l1402
.line	443	gettable      r6    r5   k53
.line	443	gettabup      r7    u0    k1
.line	443	gettable      r7    r7   k45
.line	443	eq             0    r6    r7
.line	443	jmp            0 l1409
.line	444	settable      r5   k55  k108
.line	445	settable      r5   k56   k57
.label	l1409
.line	442	tforcall      r1     2
.line	442	tforloop      r3 l1402
.line	448	gettabup      r1    u0    k1
.line	448	gettable      r1    r1   k83
.line	448	move          r2    r0
.line	448	call          r1     2     1
.line	449	loadnil       r0     0
.line	450	gettabup      r1    u0    k1
.line	450	gettable      r1    r1   k34
.line	450	loadk         r2   k85
.line	450	call          r1     2     1
.label	l1420
.line	453	gettabup      r0    u0    k0
.line	453	eq             0    r0   k75
.line	453	jmp            0 l1474
.line	454	gettabup      r0    u0    k1
.line	454	gettable      r0    r0   k37
.line	454	gettabup      r1    u0    k1
.line	454	gettable      r1    r1   k38
.line	454	gettabup      r2    u0    k1
.line	454	gettable      r2    r2   k39
.line	454	bor           r1    r1    r2
.line	454	call          r0     2     1
.line	455	gettabup      r0    u0    k1
.line	455	gettable      r0    r0   k43
.line	455	loadk         r1  k110
.line	455	gettabup      r2    u0    k1
.line	455	gettable      r2    r2   k45
.line	455	call          r0     3     1
.line	456	gettabup      r0    u0    k1
.line	456	gettable      r0    r0   k50
.line	456	loadk         r1   k36
.line	456	call          r0     2     2
.line	456	settabup      u0   k49    r0
.line	457	newtable      r0     0     0
.line	458	newtable      r1     0     0
.line	458	settable      r0   k36    r1
.line	459	gettable      r1    r0   k36
.line	459	gettabup      r2    u0   k49
.line	459	gettable      r2    r2   k36
.line	459	gettable      r2    r2   k51
.line	459	sub           r2    r2  k111
.line	459	settable      r1   k51    r2
.line	460	gettable      r1    r0   k36
.line	460	gettabup      r2    u0    k1
.line	460	gettable      r2    r2   k45
.line	460	settable      r1   k53    r2
.line	461	gettable      r1    r0   k36
.line	461	settable      r1   k55   k72
.line	462	gettable      r1    r0   k36
.line	462	settable      r1   k56   k57
.line	463	gettabup      r1    u0    k1
.line	463	gettable      r1    r1   k82
.line	463	move          r2    r0
.line	463	call          r1     2     1
.line	464	gettabup      r1    u0    k1
.line	464	gettable      r1    r1   k83
.line	464	move          r2    r0
.line	464	call          r1     2     1
.line	465	gettabup      r1    u0    k1
.line	465	gettable      r1    r1   k84
.line	465	call          r1     1     1
.line	466	gettabup      r1    u0    k1
.line	466	gettable      r1    r1   k34
.line	466	loadk         r2   k85
.line	466	call          r1     2     1
.label	l1474
.line	469	gettabup      r0    u0    k0
.line	469	eq             0    r0   k64
.line	469	jmp            0 l1544
.line	470	gettabup      r0    u0    k1
.line	470	gettable      r0    r0   k37
.line	470	gettabup      r1    u0    k1
.line	470	gettable      r1    r1   k38
.line	470	gettabup      r2    u0    k1
.line	470	gettable      r2    r2   k39
.line	470	bor           r1    r1    r2
.line	470	call          r0     2     1
.line	471	gettabup      r0    u0    k1
.line	471	gettable      r0    r0   k43
.line	471	loadk         r1  k112
.line	471	gettabup      r2    u0    k1
.line	471	gettable      r2    r2   k45
.line	471	call          r0     3     1
.line	472	gettabup      r0    u0    k1
.line	472	gettable      r0    r0   k50
.line	472	loadk         r1   k36
.line	472	call          r0     2     2
.line	472	settabup      u0   k49    r0
.line	473	newtable      r0     0     0
.line	474	newtable      r1     0     0
.line	474	settable      r0   k36    r1
.line	475	gettable      r1    r0   k36
.line	475	gettabup      r2    u0   k49
.line	475	gettable      r2    r2   k36
.line	475	gettable      r2    r2   k51
.line	475	add           r2    r2  k113
.line	475	settable      r1   k51    r2
.line	476	gettable      r1    r0   k36
.line	476	gettabup      r2    u0    k1
.line	476	gettable      r2    r2   k45
.line	476	settable      r1   k53    r2
.line	477	gettable      r1    r0   k36
.line	477	settable      r1   k55   k70
.line	478	gettable      r1    r0   k36
.line	478	settable      r1   k56   k57
.line	479	newtable      r1     0     0
.line	479	settable      r0   k58    r1
.line	480	gettable      r1    r0   k58
.line	480	gettabup      r2    u0   k49
.line	480	gettable      r2    r2   k36
.line	480	gettable      r2    r2   k51
.line	480	add           r2    r2  k114
.line	480	settable      r1   k51    r2
.line	481	gettable      r1    r0   k58
.line	481	gettabup      r2    u0    k1
.line	481	gettable      r2    r2   k45
.line	481	settable      r1   k53    r2
.line	482	gettable      r1    r0   k58
.line	482	settable      r1   k55   k59
.line	483	gettable      r1    r0   k58
.line	483	settable      r1   k56   k57
.line	484	gettabup      r1    u0    k1
.line	484	gettable      r1    r1   k82
.line	484	move          r2    r0
.line	484	call          r1     2     1
.line	485	gettabup      r1    u0    k1
.line	485	gettable      r1    r1   k83
.line	485	move          r2    r0
.line	485	call          r1     2     1
.line	486	gettabup      r1    u0    k1
.line	486	gettable      r1    r1   k84
.line	486	call          r1     1     1
.line	487	gettabup      r1    u0    k1
.line	487	gettable      r1    r1   k34
.line	487	loadk         r2   k85
.line	487	call          r1     2     1
.label	l1544
.line	490	gettabup      r0    u0    k0
.line	490	eq             0    r0   k78
.line	490	jmp            0 l1810
.line	491	gettabup      r0    u0    k1
.line	491	gettable      r0    r0   k37
.line	491	gettabup      r1    u0    k1
.line	491	gettable      r1    r1   k38
.line	491	gettabup      r2    u0    k1
.line	491	gettable      r2    r2   k39
.line	491	bor           r1    r1    r2
.line	491	call          r0     2     1
.line	492	gettabup      r0    u0    k1
.line	492	gettable      r0    r0   k34
.line	492	loadk         r1   k40
.line	492	call          r0     2     1
.line	493	gettabup      r0    u0    k1
.line	493	gettable      r0    r0   k41
.line	493	loadk         r1   k42
.line	493	call          r0     2     1
.line	494	gettabup      r0    u0    k1
.line	494	gettable      r0    r0   k43
.line	494	loadk         r1   k44
.line	494	gettabup      r2    u0    k1
.line	494	gettable      r2    r2   k45
.line	494	call          r0     3     1
.line	495	gettabup      r0    u0    k1
.line	495	gettable      r0    r0   k34
.line	495	loadk         r1   k46
.line	495	call          r0     2     1
.line	496	gettabup      r0    u0    k1
.line	496	gettable      r0    r0   k41
.line	496	loadk         r1   k42
.line	496	call          r0     2     1
.line	497	gettabup      r0    u0    k1
.line	497	gettable      r0    r0   k47
.line	497	loadk         r1   k48
.line	497	gettabup      r2    u0    k1
.line	497	gettable      r2    r2   k45
.line	497	call          r0     3     1
.line	498	gettabup      r0    u0    k1
.line	498	gettable      r0    r0   k34
.line	498	loadk         r1   k40
.line	498	call          r0     2     1
.line	499	gettabup      r0    u0    k1
.line	499	gettable      r0    r0   k41
.line	499	loadk         r1   k42
.line	499	call          r0     2     1
.line	500	gettabup      r0    u0    k1
.line	500	gettable      r0    r0   k47
.line	500	loadk         r1   k44
.line	500	gettabup      r2    u0    k1
.line	500	gettable      r2    r2   k45
.line	500	call          r0     3     1
.line	501	gettabup      r0    u0    k1
.line	501	gettable      r0    r0   k50
.line	501	loadk         r1   k36
.line	501	call          r0     2     2
.line	501	settabup      u0   k49    r0
.line	502	newtable      r0     0     0
.line	503	newtable      r1     0     0
.line	503	settable      r0   k36    r1
.line	504	gettable      r1    r0   k36
.line	504	gettabup      r2    u0   k49
.line	504	gettable      r2    r2   k36
.line	504	gettable      r2    r2   k51
.line	504	add           r2    r2   k52
.line	504	settable      r1   k51    r2
.line	505	gettable      r1    r0   k36
.line	505	gettabup      r2    u0    k1
.line	505	gettable      r2    r2   k54
.line	505	settable      r1   k53    r2
.line	506	gettable      r1    r0   k36
.line	506	settable      r1   k55   k42
.line	507	gettable      r1    r0   k36
.line	507	settable      r1   k56   k57
.line	508	newtable      r1     0     0
.line	508	settable      r0   k58    r1
.line	509	gettable      r1    r0   k58
.line	509	gettabup      r2    u0   k49
.line	509	gettable      r2    r2   k36
.line	509	gettable      r2    r2   k51
.line	509	add           r2    r2   k59
.line	509	settable      r1   k51    r2
.line	510	gettable      r1    r0   k58
.line	510	gettabup      r2    u0    k1
.line	510	gettable      r2    r2   k54
.line	510	settable      r1   k53    r2
.line	511	gettable      r1    r0   k58
.line	511	settable      r1   k55   k42
.line	512	gettable      r1    r0   k58
.line	512	settable      r1   k56   k57
.line	513	newtable      r1     0     0
.line	513	settable      r0   k60    r1
.line	514	gettable      r1    r0   k60
.line	514	gettabup      r2    u0   k49
.line	514	gettable      r2    r2   k36
.line	514	gettable      r2    r2   k51
.line	514	add           r2    r2   k61
.line	514	settable      r1   k51    r2
.line	515	gettable      r1    r0   k60
.line	515	gettabup      r2    u0    k1
.line	515	gettable      r2    r2   k54
.line	515	settable      r1   k53    r2
.line	516	gettable      r1    r0   k60
.line	516	settable      r1   k55   k42
.line	517	gettable      r1    r0   k60
.line	517	settable      r1   k56   k57
.line	518	newtable      r1     0     0
.line	518	settable      r0   k52    r1
.line	519	gettable      r1    r0   k52
.line	519	gettabup      r2    u0   k49
.line	519	gettable      r2    r2   k36
.line	519	gettable      r2    r2   k51
.line	519	add           r2    r2   k62
.line	519	settable      r1   k51    r2
.line	520	gettable      r1    r0   k52
.line	520	gettabup      r2    u0    k1
.line	520	gettable      r2    r2   k54
.line	520	settable      r1   k53    r2
.line	521	gettable      r1    r0   k52
.line	521	settable      r1   k55   k42
.line	522	gettable      r1    r0   k52
.line	522	settable      r1   k56   k57
.line	523	newtable      r1     0     0
.line	523	settable      r0   k63    r1
.line	524	gettable      r1    r0   k63
.line	524	gettabup      r2    u0   k49
.line	524	gettable      r2    r2   k36
.line	524	gettable      r2    r2   k51
.line	524	add           r2    r2   k64
.line	524	settable      r1   k51    r2
.line	525	gettable      r1    r0   k63
.line	525	gettabup      r2    u0    k1
.line	525	gettable      r2    r2   k54
.line	525	settable      r1   k53    r2
.line	526	gettable      r1    r0   k63
.line	526	settable      r1   k55   k42
.line	527	gettable      r1    r0   k63
.line	527	settable      r1   k56   k57
.line	528	newtable      r1     0     0
.line	528	settable      r0   k59    r1
.line	529	gettable      r1    r0   k59
.line	529	gettabup      r2    u0   k49
.line	529	gettable      r2    r2   k36
.line	529	gettable      r2    r2   k51
.line	529	add           r2    r2   k65
.line	529	settable      r1   k51    r2
.line	530	gettable      r1    r0   k59
.line	530	gettabup      r2    u0    k1
.line	530	gettable      r2    r2   k54
.line	530	settable      r1   k53    r2
.line	531	gettable      r1    r0   k59
.line	531	settable      r1   k55   k42
.line	532	gettable      r1    r0   k59
.line	532	settable      r1   k56   k57
.line	533	newtable      r1     0     0
.line	533	settable      r0   k66    r1
.line	534	gettable      r1    r0   k66
.line	534	gettabup      r2    u0   k49
.line	534	gettable      r2    r2   k36
.line	534	gettable      r2    r2   k51
.line	534	add           r2    r2   k67
.line	534	settable      r1   k51    r2
.line	535	gettable      r1    r0   k66
.line	535	gettabup      r2    u0    k1
.line	535	gettable      r2    r2   k54
.line	535	settable      r1   k53    r2
.line	536	gettable      r1    r0   k66
.line	536	settable      r1   k55   k42
.line	537	gettable      r1    r0   k66
.line	537	settable      r1   k56   k57
.line	538	newtable      r1     0     0
.line	538	settable      r0   k61    r1
.line	539	gettable      r1    r0   k61
.line	539	gettabup      r2    u0   k49
.line	539	gettable      r2    r2   k36
.line	539	gettable      r2    r2   k51
.line	539	add           r2    r2   k68
.line	539	settable      r1   k51    r2
.line	540	gettable      r1    r0   k61
.line	540	gettabup      r2    u0    k1
.line	540	gettable      r2    r2   k54
.line	540	settable      r1   k53    r2
.line	541	gettable      r1    r0   k61
.line	541	settable      r1   k55   k69
.line	542	gettable      r1    r0   k61
.line	542	settable      r1   k56   k57
.line	543	newtable      r1     0     0
.line	543	settable      r0   k70    r1
.line	544	gettable      r1    r0   k70
.line	544	gettabup      r2    u0   k49
.line	544	gettable      r2    r2   k36
.line	544	gettable      r2    r2   k51
.line	544	add           r2    r2   k71
.line	544	settable      r1   k51    r2
.line	545	gettable      r1    r0   k70
.line	545	gettabup      r2    u0    k1
.line	545	gettable      r2    r2   k45
.line	545	settable      r1   k53    r2
.line	546	gettable      r1    r0   k70
.line	546	settable      r1   k55   k72
.line	547	gettable      r1    r0   k70
.line	547	settable      r1   k56   k57
.line	548	newtable      r1     0     0
.line	548	settable      r0   k62    r1
.line	549	gettable      r1    r0   k62
.line	549	gettabup      r2    u0   k49
.line	549	gettable      r2    r2   k36
.line	549	gettable      r2    r2   k51
.line	549	add           r2    r2  k115
.line	549	settable      r1   k51    r2
.line	550	gettable      r1    r0   k62
.line	550	gettabup      r2    u0    k1
.line	550	gettable      r2    r2  k116
.line	550	settable      r1   k53    r2
.line	551	gettable      r1    r0   k62
.line	551	settable      r1   k55   k58
.line	552	gettable      r1    r0   k62
.line	552	settable      r1   k56   k57
.line	553	newtable      r1     0     0
.line	553	settable      r0   k75    r1
.line	554	gettable      r1    r0   k75
.line	554	gettabup      r2    u0   k49
.line	554	gettable      r2    r2   k36
.line	554	gettable      r2    r2   k51
.line	554	add           r2    r2   k73
.line	554	settable      r1   k51    r2
.line	555	gettable      r1    r0   k75
.line	555	gettabup      r2    u0    k1
.line	555	gettable      r2    r2   k54
.line	555	settable      r1   k53    r2
.line	556	gettable      r1    r0   k75
.line	556	settable      r1   k55  k117
.line	557	gettable      r1    r0   k75
.line	557	settable      r1   k56   k57
.line	558	newtable      r1     0     0
.line	558	settable      r0   k64    r1
.line	559	gettable      r1    r0   k64
.line	559	gettabup      r2    u0   k49
.line	559	gettable      r2    r2   k36
.line	559	gettable      r2    r2   k51
.line	559	sub           r2    r2   k81
.line	559	settable      r1   k51    r2
.line	560	gettable      r1    r0   k64
.line	560	gettabup      r2    u0    k1
.line	560	gettable      r2    r2   k45
.line	560	settable      r1   k53    r2
.line	561	gettable      r1    r0   k64
.line	561	settable      r1   k55   k74
.line	562	gettable      r1    r0   k64
.line	562	settable      r1   k56   k57
.line	563	gettabup      r1    u0    k1
.line	563	gettable      r1    r1   k82
.line	563	move          r2    r0
.line	563	call          r1     2     1
.line	564	gettabup      r1    u0    k1
.line	564	gettable      r1    r1   k83
.line	564	move          r2    r0
.line	564	call          r1     2     1
.line	565	gettabup      r1    u0    k1
.line	565	gettable      r1    r1   k84
.line	565	call          r1     1     1
.line	566	gettabup      r1    u0    k1
.line	566	gettable      r1    r1   k34
.line	566	loadk         r2   k85
.line	566	call          r1     2     1
.label	l1810
.line	569	gettabup      r0    u0    k0
.line	569	eq             0    r0   k65
.line	569	jmp            0 l2084
.line	570	gettabup      r0    u0    k1
.line	570	gettable      r0    r0   k37
.line	570	gettabup      r1    u0    k1
.line	570	gettable      r1    r1   k38
.line	570	gettabup      r2    u0    k1
.line	570	gettable      r2    r2   k39
.line	570	bor           r1    r1    r2
.line	570	call          r0     2     1
.line	571	gettabup      r0    u0    k1
.line	571	gettable      r0    r0   k34
.line	571	loadk         r1   k40
.line	571	call          r0     2     1
.line	572	gettabup      r0    u0    k1
.line	572	gettable      r0    r0   k41
.line	572	loadk         r1   k42
.line	572	call          r0     2     1
.line	573	gettabup      r0    u0    k1
.line	573	gettable      r0    r0   k43
.line	573	loadk         r1   k44
.line	573	gettabup      r2    u0    k1
.line	573	gettable      r2    r2   k45
.line	573	call          r0     3     1
.line	574	gettabup      r0    u0    k1
.line	574	gettable      r0    r0   k34
.line	574	loadk         r1   k46
.line	574	call          r0     2     1
.line	575	gettabup      r0    u0    k1
.line	575	gettable      r0    r0   k41
.line	575	loadk         r1   k42
.line	575	call          r0     2     1
.line	576	gettabup      r0    u0    k1
.line	576	gettable      r0    r0   k47
.line	576	loadk         r1   k48
.line	576	gettabup      r2    u0    k1
.line	576	gettable      r2    r2   k45
.line	576	call          r0     3     1
.line	577	gettabup      r0    u0    k1
.line	577	gettable      r0    r0   k34
.line	577	loadk         r1   k40
.line	577	call          r0     2     1
.line	578	gettabup      r0    u0    k1
.line	578	gettable      r0    r0   k41
.line	578	loadk         r1   k42
.line	578	call          r0     2     1
.line	579	gettabup      r0    u0    k1
.line	579	gettable      r0    r0   k47
.line	579	loadk         r1   k44
.line	579	gettabup      r2    u0    k1
.line	579	gettable      r2    r2   k45
.line	579	call          r0     3     1
.line	580	gettabup      r0    u0    k1
.line	580	gettable      r0    r0   k50
.line	580	loadk         r1   k36
.line	580	call          r0     2     2
.line	580	settabup      u0   k49    r0
.line	581	newtable      r0     0     0
.line	582	newtable      r1     0     0
.line	582	settable      r0   k36    r1
.line	583	gettable      r1    r0   k36
.line	583	gettabup      r2    u0   k49
.line	583	gettable      r2    r2   k36
.line	583	gettable      r2    r2   k51
.line	583	add           r2    r2   k52
.line	583	settable      r1   k51    r2
.line	584	gettable      r1    r0   k36
.line	584	gettabup      r2    u0    k1
.line	584	gettable      r2    r2   k54
.line	584	settable      r1   k53    r2
.line	585	gettable      r1    r0   k36
.line	585	settable      r1   k55   k42
.line	586	gettable      r1    r0   k36
.line	586	settable      r1   k56   k57
.line	587	newtable      r1     0     0
.line	587	settable      r0   k58    r1
.line	588	gettable      r1    r0   k58
.line	588	gettabup      r2    u0   k49
.line	588	gettable      r2    r2   k36
.line	588	gettable      r2    r2   k51
.line	588	add           r2    r2   k59
.line	588	settable      r1   k51    r2
.line	589	gettable      r1    r0   k58
.line	589	gettabup      r2    u0    k1
.line	589	gettable      r2    r2   k54
.line	589	settable      r1   k53    r2
.line	590	gettable      r1    r0   k58
.line	590	settable      r1   k55   k42
.line	591	gettable      r1    r0   k58
.line	591	settable      r1   k56   k57
.line	592	newtable      r1     0     0
.line	592	settable      r0   k60    r1
.line	593	gettable      r1    r0   k60
.line	593	gettabup      r2    u0   k49
.line	593	gettable      r2    r2   k36
.line	593	gettable      r2    r2   k51
.line	593	add           r2    r2   k61
.line	593	settable      r1   k51    r2
.line	594	gettable      r1    r0   k60
.line	594	gettabup      r2    u0    k1
.line	594	gettable      r2    r2   k54
.line	594	settable      r1   k53    r2
.line	595	gettable      r1    r0   k60
.line	595	settable      r1   k55   k42
.line	596	gettable      r1    r0   k60
.line	596	settable      r1   k56   k57
.line	597	newtable      r1     0     0
.line	597	settable      r0   k52    r1
.line	598	gettable      r1    r0   k52
.line	598	gettabup      r2    u0   k49
.line	598	gettable      r2    r2   k36
.line	598	gettable      r2    r2   k51
.line	598	add           r2    r2   k62
.line	598	settable      r1   k51    r2
.line	599	gettable      r1    r0   k52
.line	599	gettabup      r2    u0    k1
.line	599	gettable      r2    r2   k54
.line	599	settable      r1   k53    r2
.line	600	gettable      r1    r0   k52
.line	600	settable      r1   k55   k42
.line	601	gettable      r1    r0   k52
.line	601	settable      r1   k56   k57
.line	602	newtable      r1     0     0
.line	602	settable      r0   k63    r1
.line	603	gettable      r1    r0   k63
.line	603	gettabup      r2    u0   k49
.line	603	gettable      r2    r2   k36
.line	603	gettable      r2    r2   k51
.line	603	add           r2    r2   k64
.line	603	settable      r1   k51    r2
.line	604	gettable      r1    r0   k63
.line	604	gettabup      r2    u0    k1
.line	604	gettable      r2    r2   k54
.line	604	settable      r1   k53    r2
.line	605	gettable      r1    r0   k63
.line	605	settable      r1   k55   k42
.line	606	gettable      r1    r0   k63
.line	606	settable      r1   k56   k57
.line	607	newtable      r1     0     0
.line	607	settable      r0   k59    r1
.line	608	gettable      r1    r0   k59
.line	608	gettabup      r2    u0   k49
.line	608	gettable      r2    r2   k36
.line	608	gettable      r2    r2   k51
.line	608	add           r2    r2   k65
.line	608	settable      r1   k51    r2
.line	609	gettable      r1    r0   k59
.line	609	gettabup      r2    u0    k1
.line	609	gettable      r2    r2   k54
.line	609	settable      r1   k53    r2
.line	610	gettable      r1    r0   k59
.line	610	settable      r1   k55   k42
.line	611	gettable      r1    r0   k59
.line	611	settable      r1   k56   k57
.line	612	newtable      r1     0     0
.line	612	settable      r0   k66    r1
.line	613	gettable      r1    r0   k66
.line	613	gettabup      r2    u0   k49
.line	613	gettable      r2    r2   k36
.line	613	gettable      r2    r2   k51
.line	613	add           r2    r2   k67
.line	613	settable      r1   k51    r2
.line	614	gettable      r1    r0   k66
.line	614	gettabup      r2    u0    k1
.line	614	gettable      r2    r2   k54
.line	614	settable      r1   k53    r2
.line	615	gettable      r1    r0   k66
.line	615	settable      r1   k55   k42
.line	616	gettable      r1    r0   k66
.line	616	settable      r1   k56   k57
.line	617	newtable      r1     0     0
.line	617	settable      r0   k61    r1
.line	618	gettable      r1    r0   k61
.line	618	gettabup      r2    u0   k49
.line	618	gettable      r2    r2   k36
.line	618	gettable      r2    r2   k51
.line	618	add           r2    r2   k68
.line	618	settable      r1   k51    r2
.line	619	gettable      r1    r0   k61
.line	619	gettabup      r2    u0    k1
.line	619	gettable      r2    r2   k54
.line	619	settable      r1   k53    r2
.line	620	gettable      r1    r0   k61
.line	620	settable      r1   k55   k69
.line	621	gettable      r1    r0   k61
.line	621	settable      r1   k56   k57
.line	622	newtable      r1     0     0
.line	622	settable      r0   k70    r1
.line	623	gettable      r1    r0   k70
.line	623	gettabup      r2    u0   k49
.line	623	gettable      r2    r2   k36
.line	623	gettable      r2    r2   k51
.line	623	sub           r2    r2   k67
.line	623	settable      r1   k51    r2
.line	624	gettable      r1    r0   k70
.line	624	gettabup      r2    u0    k1
.line	624	gettable      r2    r2   k45
.line	624	settable      r1   k53    r2
.line	625	gettable      r1    r0   k70
.line	625	settable      r1   k55   k76
.line	626	gettable      r1    r0   k70
.line	626	settable      r1   k56   k57
.line	627	newtable      r1     0     0
.line	627	settable      r0   k62    r1
.line	628	gettable      r1    r0   k62
.line	628	gettabup      r2    u0   k49
.line	628	gettable      r2    r2   k36
.line	628	gettable      r2    r2   k51
.line	628	sub           r2    r2   k77
.line	628	settable      r1   k51    r2
.line	629	gettable      r1    r0   k62
.line	629	gettabup      r2    u0    k1
.line	629	gettable      r2    r2   k45
.line	629	settable      r1   k53    r2
.line	630	gettable      r1    r0   k62
.line	630	settable      r1   k55   k88
.line	631	gettable      r1    r0   k62
.line	631	settable      r1   k56   k57
.line	632	newtable      r1     0     0
.line	632	settable      r0   k75    r1
.line	633	gettable      r1    r0   k75
.line	633	gettabup      r2    u0   k49
.line	633	gettable      r2    r2   k36
.line	633	gettable      r2    r2   k51
.line	633	sub           r2    r2   k81
.line	633	settable      r1   k51    r2
.line	634	gettable      r1    r0   k75
.line	634	gettabup      r2    u0    k1
.line	634	gettable      r2    r2   k45
.line	634	settable      r1   k53    r2
.line	635	gettable      r1    r0   k75
.line	635	settable      r1   k55   k74
.line	636	gettable      r1    r0   k75
.line	636	settable      r1   k56   k57
.line	637	newtable      r1     0     0
.line	637	settable      r0   k64    r1
.line	638	gettable      r1    r0   k64
.line	638	gettabup      r2    u0   k49
.line	638	gettable      r2    r2   k36
.line	638	gettable      r2    r2   k51
.line	638	add           r2    r2   k89
.line	638	settable      r1   k51    r2
.line	639	gettable      r1    r0   k64
.line	639	gettabup      r2    u0    k1
.line	639	gettable      r2    r2   k45
.line	639	settable      r1   k53    r2
.line	640	gettable      r1    r0   k64
.line	640	settable      r1   k55   k74
.line	641	gettable      r1    r0   k64
.line	641	settable      r1   k56   k57
.line	642	gettable      r1    r0   k64
.line	642	gettabup      r2    u0    k1
.line	642	gettable      r2    r2   k91
.line	642	settable      r1   k90    r2
.line	643	gettable      r1    r0   k64
.line	643	settable      r1   k92   k48
.line	644	gettable      r1    r0   k64
.line	644	settable      r1   k93   k94
.line	645	gettabup      r1    u0    k1
.line	645	gettable      r1    r1   k82
.line	645	move          r2    r0
.line	645	call          r1     2     1
.line	646	gettabup      r1    u0    k1
.line	646	gettable      r1    r1   k83
.line	646	move          r2    r0
.line	646	call          r1     2     1
.line	647	gettabup      r1    u0    k1
.line	647	gettable      r1    r1   k84
.line	647	call          r1     1     1
.line	648	gettabup      r1    u0    k1
.line	648	gettable      r1    r1   k34
.line	648	loadk         r2   k85
.line	648	call          r1     2     1
.label	l2084
.line	651	gettabup      r0    u0    k0
.line	651	eq             0    r0  k118
.line	651	jmp            0 l2135
.line	652	gettabup      r0    u0    k1
.line	652	gettable      r0    r0   k37
.line	652	gettabup      r1    u0    k1
.line	652	gettable      r1    r1  k119
.line	652	call          r0     2     1
.line	653	gettabup      r0    u0    k1
.line	653	gettable      r0    r0   k43
.line	653	loadk         r1  k120
.line	653	gettabup      r2    u0    k1
.line	653	gettable      r2    r2   k45
.line	653	call          r0     3     1
.line	654	gettabup      r0    u0    k1
.line	654	gettable      r0    r0   k50
.line	654	loadk         r1   k36
.line	654	call          r0     2     2
.line	654	settabup      u0   k49    r0
.line	655	newtable      r0     0     0
.line	656	newtable      r1     0     0
.line	656	settable      r0   k36    r1
.line	657	gettable      r1    r0   k36
.line	657	gettabup      r2    u0   k49
.line	657	gettable      r2    r2   k36
.line	657	gettable      r2    r2   k51
.line	657	sub           r2    r2  k121
.line	657	settable      r1   k51    r2
.line	658	gettable      r1    r0   k36
.line	658	gettabup      r2    u0    k1
.line	658	gettable      r2    r2   k45
.line	658	settable      r1   k53    r2
.line	659	gettable      r1    r0   k36
.line	659	settable      r1   k55   k98
.line	660	gettable      r1    r0   k36
.line	660	settable      r1   k56   k57
.line	661	gettabup      r1    u0    k1
.line	661	gettable      r1    r1   k82
.line	661	move          r2    r0
.line	661	call          r1     2     1
.line	662	gettabup      r1    u0    k1
.line	662	gettable      r1    r1   k83
.line	662	move          r2    r0
.line	662	call          r1     2     1
.line	663	gettabup      r1    u0    k1
.line	663	gettable      r1    r1   k84
.line	663	call          r1     1     1
.line	664	gettabup      r1    u0    k1
.line	664	gettable      r1    r1   k34
.line	664	loadk         r2   k85
.line	664	call          r1     2     1
.label	l2135
.line	667	gettabup      r0    u0    k0
.line	667	eq             0    r0   k67
.line	667	jmp            0 l2225
.line	668	gettabup      r0    u0    k1
.line	668	gettable      r0    r0   k37
.line	668	gettabup      r1    u0    k1
.line	668	gettable      r1    r1   k38
.line	668	gettabup      r2    u0    k1
.line	668	gettable      r2    r2   k39
.line	668	bor           r1    r1    r2
.line	668	call          r0     2     1
.line	669	gettabup      r0    u0    k1
.line	669	gettable      r0    r0   k34
.line	669	loadk         r1   k40
.line	669	call          r0     2     1
.line	670	gettabup      r0    u0    k1
.line	670	gettable      r0    r0   k41
.line	670	loadk         r1   k42
.line	670	call          r0     2     1
.line	671	gettabup      r0    u0    k1
.line	671	gettable      r0    r0   k43
.line	671	loadk         r1   k44
.line	671	gettabup      r2    u0    k1
.line	671	gettable      r2    r2   k45
.line	671	call          r0     3     1
.line	672	gettabup      r0    u0    k1
.line	672	gettable      r0    r0   k34
.line	672	loadk         r1   k46
.line	672	call          r0     2     1
.line	673	gettabup      r0    u0    k1
.line	673	gettable      r0    r0   k41
.line	673	loadk         r1   k42
.line	673	call          r0     2     1
.line	674	gettabup      r0    u0    k1
.line	674	gettable      r0    r0   k47
.line	674	loadk         r1   k48
.line	674	gettabup      r2    u0    k1
.line	674	gettable      r2    r2   k45
.line	674	call          r0     3     1
.line	675	gettabup      r0    u0    k1
.line	675	gettable      r0    r0   k34
.line	675	loadk         r1   k40
.line	675	call          r0     2     1
.line	676	gettabup      r0    u0    k1
.line	676	gettable      r0    r0   k41
.line	676	loadk         r1   k42
.line	676	call          r0     2     1
.line	677	gettabup      r0    u0    k1
.line	677	gettable      r0    r0   k47
.line	677	loadk         r1   k44
.line	677	gettabup      r2    u0    k1
.line	677	gettable      r2    r2   k45
.line	677	call          r0     3     1
.line	678	gettabup      r0    u0    k1
.line	678	gettable      r0    r0   k50
.line	678	loadk         r1   k36
.line	678	call          r0     2     2
.line	678	settabup      u0   k49    r0
.line	679	newtable      r0     0     0
.line	680	newtable      r1     0     0
.line	680	settable      r0   k36    r1
.line	681	gettable      r1    r0   k36
.line	681	gettabup      r2    u0   k49
.line	681	gettable      r2    r2   k36
.line	681	gettable      r2    r2   k51
.line	681	sub           r2    r2  k122
.line	681	settable      r1   k51    r2
.line	682	gettable      r1    r0   k36
.line	682	gettabup      r2    u0    k1
.line	682	gettable      r2    r2   k45
.line	682	settable      r1   k53    r2
.line	683	gettable      r1    r0   k36
.line	683	settable      r1   k55   k74
.line	684	gettable      r1    r0   k36
.line	684	settable      r1   k56   k57
.line	685	gettabup      r1    u0    k1
.line	685	gettable      r1    r1   k82
.line	685	move          r2    r0
.line	685	call          r1     2     1
.line	686	gettabup      r1    u0    k1
.line	686	gettable      r1    r1   k83
.line	686	move          r2    r0
.line	686	call          r1     2     1
.line	687	gettabup      r1    u0    k1
.line	687	gettable      r1    r1   k84
.line	687	call          r1     1     1
.line	688	gettabup      r1    u0    k1
.line	688	gettable      r1    r1   k34
.line	688	loadk         r2   k85
.line	688	call          r1     2     1
.label	l2225
.line	691	gettabup      r0    u0    k0
.line	691	eq             0    r0  k123
.line	691	jmp            0 l2263
.line	692	gettabup      r0    u0    k1
.line	692	gettable      r0    r0   k37
.line	692	gettabup      r1    u0    k1
.line	692	gettable      r1    r1  k119
.line	692	call          r0     2     1
.line	693	gettabup      r0    u0    k1
.line	693	gettable      r0    r0   k43
.line	693	loadk         r1  k124
.line	693	gettabup      r2    u0    k1
.line	693	gettable      r2    r2  k125
.line	693	loadbool      r3     0     0
.line	693	gettabup      r4    u0    k1
.line	693	gettable      r4    r4   k96
.line	693	loadk         r5   k74
.line	693	loadk         r6   k80
.line	693	call          r0     7     1
.line	694	gettabup      r0    u0    k1
.line	694	gettable      r0    r0   k50
.line	694	loadk         r1  k126
.line	694	loadnil       r2     7
.line	694	call          r0    10     2
.line	694	settabup      u0   k97    r0
.line	695	gettabup      r0    u0    k1
.line	695	gettable      r0    r0  k127
.line	695	loadk         r1  k128
.line	695	gettabup      r2    u0    k1
.line	695	gettable      r2    r2  k125
.line	695	call          r0     3     1
.line	696	gettabup      r0    u0    k1
.line	696	gettable      r0    r0   k84
.line	696	call          r0     1     1
.line	697	gettabup      r0    u0    k1
.line	697	gettable      r0    r0   k34
.line	697	loadk         r1   k85
.line	697	call          r0     2     1
.label	l2263
.line	700	gettabup      r0    u0    k0
.line	700	eq             0    r0   k68
.line	700	jmp            0 l2305
.line	701	gettabup      r0    u0    k1
.line	701	gettable      r0    r0   k37
.line	701	gettabup      r1    u0    k1
.line	701	gettable      r1    r1  k129
.line	701	call          r0     2     1
.line	702	gettabup      r0    u0    k1
.line	702	gettable      r0    r0   k43
.line	702	loadk         r1  k130
.line	702	gettabup      r2    u0    k1
.line	702	gettable      r2    r2   k45
.line	702	loadbool      r3     0     0
.line	702	gettabup      r4    u0    k1
.line	702	gettable      r4    r4   k96
.line	702	loadk         r5   k74
.line	702	loadk         r6   k80
.line	702	loadk         r7   k74
.line	702	call          r0     8     1
.line	703	gettabup      r0    u0    k1
.line	703	gettable      r0    r0   k50
.line	703	loadk         r1   k62
.line	703	call          r0     2     1
.line	704	gettabup      r0    u0    k1
.line	704	gettable      r0    r0  k127
.line	704	loadk         r1  k131
.line	704	gettabup      r2    u0    k1
.line	704	gettable      r2    r2  k125
.line	704	call          r0     3     1
.line	705	gettabup      r0    u0    k1
.line	705	gettable      r0    r0   k84
.line	705	call          r0     1     1
.line	706	gettabup      r0    u0    k1
.line	706	gettable      r0    r0   k37
.line	706	gettabup      r1    u0    k1
.line	706	gettable      r1    r1   k39
.line	706	call          r0     2     1
.line	707	gettabup      r0    u0    k1
.line	707	gettable      r0    r0   k34
.line	707	loadk         r1   k85
.line	707	call          r0     2     1
.label	l2305
.line	710	gettabup      r0    u0    k0
.line	710	eq             0    r0  k132
.line	710	jmp            0 l2359
.line	711	gettabup      r0    u0    k1
.line	711	gettable      r0    r0   k37
.line	711	gettabup      r1    u0    k1
.line	711	gettable      r1    r1   k38
.line	711	gettabup      r2    u0    k1
.line	711	gettable      r2    r2   k39
.line	711	bor           r1    r1    r2
.line	711	call          r0     2     1
.line	712	gettabup      r0    u0    k1
.line	712	gettable      r0    r0   k43
.line	712	loadk         r1  k105
.line	712	gettabup      r2    u0    k1
.line	712	gettable      r2    r2   k45
.line	712	call          r0     3     1
.line	713	gettabup      r0    u0    k1
.line	713	gettable      r0    r0   k50
.line	713	loadk         r1   k36
.line	713	call          r0     2     2
.line	713	settabup      u0   k49    r0
.line	714	newtable      r0     0     0
.line	715	newtable      r1     0     0
.line	715	settable      r0   k36    r1
.line	716	gettable      r1    r0   k36
.line	716	gettabup      r2    u0   k49
.line	716	gettable      r2    r2   k36
.line	716	gettable      r2    r2   k51
.line	716	sub           r2    r2   k67
.line	716	settable      r1   k51    r2
.line	717	gettable      r1    r0   k36
.line	717	gettabup      r2    u0    k1
.line	717	gettable      r2    r2   k45
.line	717	settable      r1   k53    r2
.line	718	gettable      r1    r0   k36
.line	718	settable      r1   k55  k133
.line	719	gettable      r1    r0   k36
.line	719	settable      r1   k56   k57
.line	720	gettabup      r1    u0    k1
.line	720	gettable      r1    r1   k82
.line	720	move          r2    r0
.line	720	call          r1     2     1
.line	721	gettabup      r1    u0    k1
.line	721	gettable      r1    r1   k83
.line	721	move          r2    r0
.line	721	call          r1     2     1
.line	722	gettabup      r1    u0    k1
.line	722	gettable      r1    r1   k84
.line	722	call          r1     1     1
.line	723	gettabup      r1    u0    k1
.line	723	gettable      r1    r1   k34
.line	723	loadk         r2   k85
.line	723	call          r1     2     1
.label	l2359
.line	726	gettabup      r0    u0    k0
.line	726	eq             0    r0   k79
.line	726	jmp            0 l2415
.line	727	gettabup      r0    u0    k1
.line	727	gettable      r0    r0   k37
.line	727	gettabup      r1    u0    k1
.line	727	gettable      r1    r1  k129
.line	727	call          r0     2     1
.line	728	gettabup      r0    u0    k1
.line	728	gettable      r0    r0   k43
.line	728	loadk         r1  k134
.line	728	gettabup      r2    u0    k1
.line	728	gettable      r2    r2  k125
.line	728	loadbool      r3     0     0
.line	728	gettabup      r4    u0    k1
.line	728	gettable      r4    r4   k96
.line	728	loadk         r5   k74
.line	728	loadk         r6   k80
.line	728	loadk         r7   k74
.line	728	call          r0     8     1
.line	730	gettabup      r0    u0    k1
.line	730	gettable      r0    r0   k50
.line	730	loadk         r1   k98
.line	730	loadnil       r2     7
.line	730	call          r0    10     2
.line	730	settabup      u0   k97    r0
.line	731	gettabup      r0    u0    k1
.line	731	gettable      r0    r0   k50
.line	731	loadk         r1   k98
.line	731	loadnil       r2     7
.line	731	call          r0    10     2
.line	732	gettabup      r1    u0   k99
.line	732	move          r2    r0
.line	732	call          r1     2     4
.line	732	jmp            0 l2401
.label	l2394
.line	733	gettable      r6    r5   k53
.line	733	gettabup      r7    u0    k1
.line	733	gettable      r7    r7  k125
.line	733	eq             0    r6    r7
.line	733	jmp            0 l2401
.line	734	settable      r5   k55  k135
.line	735	settable      r5   k56   k57
.label	l2401
.line	732	tforcall      r1     2
.line	732	tforloop      r3 l2394
.line	738	gettabup      r1    u0    k1
.line	738	gettable      r1    r1   k83
.line	738	move          r2    r0
.line	738	call          r1     2     1
.line	739	loadnil       r0     0
.line	740	gettabup      r1    u0    k1
.line	740	gettable      r1    r1   k84
.line	740	call          r1     1     1
.line	741	gettabup      r1    u0    k1
.line	741	gettable      r1    r1   k34
.line	741	loadk         r2   k85
.line	741	call          r1     2     1
.label	l2415
.line	744	gettabup      r0    u0    k0
.line	744	eq             0    r0  k136
.line	744	jmp            0 l2497
.line	745	gettabup      r0    u0    k1
.line	745	gettable      r0    r0   k34
.line	745	loadk         r1   k40
.line	745	call          r0     2     1
.line	746	gettabup      r0    u0    k1
.line	746	gettable      r0    r0   k41
.line	746	loadk         r1   k42
.line	746	call          r0     2     1
.line	747	gettabup      r0    u0    k1
.line	747	gettable      r0    r0   k43
.line	747	loadk         r1   k44
.line	747	gettabup      r2    u0    k1
.line	747	gettable      r2    r2   k45
.line	747	call          r0     3     1
.line	748	gettabup      r0    u0    k1
.line	748	gettable      r0    r0   k34
.line	748	loadk         r1   k46
.line	748	call          r0     2     1
.line	749	gettabup      r0    u0    k1
.line	749	gettable      r0    r0   k41
.line	749	loadk         r1   k42
.line	749	call          r0     2     1
.line	750	gettabup      r0    u0    k1
.line	750	gettable      r0    r0   k47
.line	750	loadk         r1   k48
.line	750	gettabup      r2    u0    k1
.line	750	gettable      r2    r2   k45
.line	750	call          r0     3     1
.line	751	gettabup      r0    u0    k1
.line	751	gettable      r0    r0   k34
.line	751	loadk         r1   k40
.line	751	call          r0     2     1
.line	752	gettabup      r0    u0    k1
.line	752	gettable      r0    r0   k41
.line	752	loadk         r1   k42
.line	752	call          r0     2     1
.line	753	gettabup      r0    u0    k1
.line	753	gettable      r0    r0   k47
.line	753	loadk         r1   k44
.line	753	gettabup      r2    u0    k1
.line	753	gettable      r2    r2   k45
.line	753	call          r0     3     1
.line	754	gettabup      r0    u0    k1
.line	754	gettable      r0    r0   k50
.line	754	loadk         r1   k36
.line	754	call          r0     2     2
.line	754	settabup      u0   k49    r0
.line	755	newtable      r0     0     0
.line	756	newtable      r1     0     0
.line	756	settable      r0   k36    r1
.line	757	gettable      r1    r0   k36
.line	757	gettabup      r2    u0   k49
.line	757	gettable      r2    r2   k36
.line	757	gettable      r2    r2   k51
.line	757	sub           r2    r2  k137
.line	757	settable      r1   k51    r2
.line	758	gettable      r1    r0   k36
.line	758	gettabup      r2    u0    k1
.line	758	gettable      r2    r2   k45
.line	758	settable      r1   k53    r2
.line	759	gettable      r1    r0   k36
.line	759	settable      r1   k55   k59
.line	760	gettable      r1    r0   k36
.line	760	settable      r1   k56   k57
.line	761	gettabup      r1    u0    k1
.line	761	gettable      r1    r1   k82
.line	761	move          r2    r0
.line	761	call          r1     2     1
.line	762	gettabup      r1    u0    k1
.line	762	gettable      r1    r1   k83
.line	762	move          r2    r0
.line	762	call          r1     2     1
.line	763	gettabup      r1    u0    k1
.line	763	gettable      r1    r1   k84
.line	763	call          r1     1     1
.line	764	gettabup      r1    u0    k1
.line	764	gettable      r1    r1   k34
.line	764	loadk         r2   k85
.line	764	call          r1     2     1
.label	l2497
.line	767	gettabup      r0    u0    k0
.line	767	eq             0    r0  k138
.line	767	jmp            0 l2556
.line	768	gettabup      r0    u0    k1
.line	768	gettable      r0    r0   k37
.line	768	gettabup      r1    u0    k1
.line	768	gettable      r1    r1   k38
.line	768	gettabup      r2    u0    k1
.line	768	gettable      r2    r2   k39
.line	768	bor           r1    r1    r2
.line	768	call          r0     2     1
.line	769	gettabup      r0    u0    k1
.line	769	gettable      r0    r0   k43
.line	769	loadk         r1  k139
.line	769	gettabup      r2    u0    k1
.line	769	gettable      r2    r2  k125
.line	769	loadbool      r3     0     0
.line	769	gettabup      r4    u0    k1
.line	769	gettable      r4    r4   k96
.line	769	loadk         r5   k74
.line	769	loadk         r6   k80
.line	769	loadk         r7   k74
.line	769	call          r0     8     1
.line	771	gettabup      r0    u0    k1
.line	771	gettable      r0    r0   k50
.line	771	loadk         r1   k98
.line	771	loadnil       r2     7
.line	771	call          r0    10     2
.line	771	settabup      u0   k97    r0
.line	772	gettabup      r0    u0    k1
.line	772	gettable      r0    r0   k50
.line	772	loadk         r1   k98
.line	772	loadnil       r2     7
.line	772	call          r0    10     2
.line	773	gettabup      r1    u0   k99
.line	773	move          r2    r0
.line	773	call          r1     2     4
.line	773	jmp            0 l2542
.label	l2535
.line	774	gettable      r6    r5   k53
.line	774	gettabup      r7    u0    k1
.line	774	gettable      r7    r7  k125
.line	774	eq             0    r6    r7
.line	774	jmp            0 l2542
.line	775	settable      r5   k55  k140
.line	776	settable      r5   k56   k57
.label	l2542
.line	773	tforcall      r1     2
.line	773	tforloop      r3 l2535
.line	779	gettabup      r1    u0    k1
.line	779	gettable      r1    r1   k83
.line	779	move          r2    r0
.line	779	call          r1     2     1
.line	780	loadnil       r0     0
.line	781	gettabup      r1    u0    k1
.line	781	gettable      r1    r1   k84
.line	781	call          r1     1     1
.line	782	gettabup      r1    u0    k1
.line	782	gettable      r1    r1   k34
.line	782	loadk         r2   k85
.line	782	call          r1     2     1
.label	l2556
.line	785	gettabup      r0    u0    k0
.line	785	eq             0    r0  k141
.line	785	jmp            0 l2600
.line	786	gettabup      r0    u0    k1
.line	786	gettable      r0    r0   k37
.line	786	gettabup      r1    u0    k1
.line	786	gettable      r1    r1  k107
.line	786	gettabup      r2    u0    k1
.line	786	gettable      r2    r2   k39
.line	786	bor           r1    r1    r2
.line	786	gettabup      r2    u0    k1
.line	786	gettable      r2    r2   k38
.line	786	bor           r1    r1    r2
.line	786	call          r0     2     1
.line	787	gettabup      r0    u0    k1
.line	787	gettable      r0    r0   k43
.line	787	loadk         r1  k142
.line	787	gettabup      r2    u0    k1
.line	787	gettable      r2    r2  k125
.line	787	loadbool      r3     0     0
.line	787	gettabup      r4    u0    k1
.line	787	gettable      r4    r4   k96
.line	787	loadk         r5   k74
.line	787	loadk         r6   k80
.line	787	call          r0     7     1
.line	788	gettabup      r0    u0    k1
.line	788	gettable      r0    r0   k50
.line	788	loadk         r1  k126
.line	788	loadnil       r2     7
.line	788	call          r0    10     2
.line	788	settabup      u0   k97    r0
.line	789	gettabup      r0    u0    k1
.line	789	gettable      r0    r0  k127
.line	789	loadk         r1  k143
.line	789	gettabup      r2    u0    k1
.line	789	gettable      r2    r2  k125
.line	789	call          r0     3     1
.line	790	gettabup      r0    u0    k1
.line	790	gettable      r0    r0   k84
.line	790	call          r0     1     1
.line	791	gettabup      r0    u0    k1
.line	791	gettable      r0    r0   k34
.line	791	loadk         r1   k85
.line	791	call          r0     2     1
.label	l2600
.line	794	gettabup      r0    u0    k0
.line	794	eq             0    r0  k144
.line	794	jmp            0 l2662
.line	795	gettabup      r0    u0    k1
.line	795	gettable      r0    r0   k37
.line	795	gettabup      r1    u0    k1
.line	795	gettable      r1    r1  k129
.line	795	call          r0     2     1
.line	796	gettabup      r0    u0    k1
.line	796	gettable      r0    r0   k43
.line	796	loadk         r1  k145
.line	796	gettabup      r2    u0    k1
.line	796	gettable      r2    r2   k45
.line	796	call          r0     3     1
.line	798	gettabup      r0    u0    k1
.line	798	gettable      r0    r0   k50
.line	798	loadk         r1   k36
.line	798	loadnil       r2     7
.line	798	call          r0    10     2
.line	798	settabup      u0   k97    r0
.line	799	gettabup      r0    u0    k1
.line	799	gettable      r0    r0   k50
.line	799	loadk         r1   k36
.line	799	loadnil       r2     7
.line	799	call          r0    10     2
.line	800	gettabup      r1    u0    k1
.line	800	gettable      r1    r1   k50
.line	800	loadk         r2   k36
.line	800	call          r1     2     1
.line	801	gettabup      r1    u0   k99
.line	801	move          r2    r0
.line	801	call          r1     2     4
.line	801	jmp            0 l2645
.label	l2633
.line	802	gettable      r6    r5   k53
.line	802	gettabup      r7    u0    k1
.line	802	gettable      r7    r7  k125
.line	802	eq             0    r6    r7
.line	802	jmp            0 l2645
.line	803	settable      r5   k55  k146
.line	804	settable      r5   k56   k57
.line	805	gettabup      r6    u0    k1
.line	805	gettable      r6    r6   k37
.line	805	gettabup      r7    u0    k1
.line	805	gettable      r7    r7   k39
.line	805	call          r6     2     1
.label	l2645
.line	801	tforcall      r1     2
.line	801	tforloop      r3 l2633
.line	808	gettabup      r1    u0    k1
.line	808	gettable      r1    r1   k83
.line	808	move          r2    r0
.line	808	call          r1     2     1
.line	809	gettabup      r1    u0    k1
.line	809	gettable      r1    r1  k103
.line	809	loadbool      r2     0     0
.line	809	call          r1     2     1
.line	810	gettabup      r1    u0    k1
.line	810	gettable      r1    r1   k84
.line	810	call          r1     1     1
.line	811	gettabup      r1    u0    k1
.line	811	gettable      r1    r1   k34
.line	811	loadk         r2   k85
.line	811	call          r1     2     1
.label	l2662
.line	814	gettabup      r0    u0    k0
.line	814	eq             0    r0  k147
.line	814	jmp            0 l3745
.line	815	gettabup      r0    u0    k1
.line	815	gettable      r0    r0   k37
.line	815	gettabup      r1    u0    k1
.line	815	gettable      r1    r1   k38
.line	815	gettabup      r2    u0    k1
.line	815	gettable      r2    r2   k39
.line	815	bor           r1    r1    r2
.line	815	call          r0     2     1
.line	816	gettabup      r0    u0    k1
.line	816	gettable      r0    r0   k84
.line	816	call          r0     1     1
.line	817	gettabup      r0    u0    k1
.line	817	gettable      r0    r0   k43
.line	817	loadk         r1  k148
.line	817	gettabup      r2    u0    k1
.line	817	gettable      r2    r2   k45
.line	817	loadbool      r3     0     0
.line	817	gettabup      r4    u0    k1
.line	817	gettable      r4    r4   k96
.line	817	loadk         r5   k74
.line	817	loadk         r6   k80
.line	817	loadk         r7   k74
.line	817	call          r0     8     1
.line	818	gettabup      r0    u0    k1
.line	818	gettable      r0    r0   k50
.line	818	loadk         r1   k36
.line	818	call          r0     2     2
.line	818	settabup      u0   k49    r0
.line	819	newtable      r0     0     0
.line	820	newtable      r1     0     0
.line	820	settable      r0   k36    r1
.line	821	gettable      r1    r0   k36
.line	821	gettabup      r2    u0   k49
.line	821	gettable      r2    r2   k36
.line	821	gettable      r2    r2   k51
.line	821	sub           r2    r2  k149
.line	821	settable      r1   k51    r2
.line	822	gettable      r1    r0   k36
.line	822	gettabup      r2    u0    k1
.line	822	gettable      r2    r2   k45
.line	822	settable      r1   k53    r2
.line	823	gettable      r1    r0   k36
.line	823	settable      r1   k55   k74
.line	824	gettable      r1    r0   k36
.line	824	settable      r1   k56   k57
.line	825	gettabup      r1    u0    k1
.line	825	gettable      r1    r1   k82
.line	825	move          r2    r0
.line	825	call          r1     2     1
.line	826	gettabup      r1    u0    k1
.line	826	gettable      r1    r1   k83
.line	826	move          r2    r0
.line	826	call          r1     2     1
.line	827	gettabup      r1    u0    k1
.line	827	gettable      r1    r1   k50
.line	827	loadk         r2   k58
.line	827	call          r1     2     2
.line	827	settabup      u0   k49    r1
.line	828	newtable      r1     0     0
.line	829	newtable      r2     0     0
.line	829	settable      r1   k36    r2
.line	830	gettable      r2    r1   k36
.line	830	gettabup      r3    u0   k49
.line	830	gettable      r3    r3   k58
.line	830	gettable      r3    r3   k51
.line	830	sub           r3    r3  k149
.line	830	settable      r2   k51    r3
.line	831	gettable      r2    r1   k36
.line	831	gettabup      r3    u0    k1
.line	831	gettable      r3    r3   k45
.line	831	settable      r2   k53    r3
.line	832	gettable      r2    r1   k36
.line	832	settable      r2   k55   k74
.line	833	gettable      r2    r1   k36
.line	833	settable      r2   k56   k57
.line	834	gettabup      r2    u0    k1
.line	834	gettable      r2    r2   k82
.line	834	move          r3    r1
.line	834	call          r2     2     1
.line	835	gettabup      r2    u0    k1
.line	835	gettable      r2    r2   k83
.line	835	move          r3    r1
.line	835	call          r2     2     1
.line	836	gettabup      r2    u0    k1
.line	836	gettable      r2    r2   k50
.line	836	loadk         r3   k60
.line	836	call          r2     2     2
.line	836	settabup      u0   k49    r2
.line	837	newtable      r2     0     0
.line	838	newtable      r3     0     0
.line	838	settable      r2   k36    r3
.line	839	gettable      r3    r2   k36
.line	839	gettabup      r4    u0   k49
.line	839	gettable      r4    r4   k60
.line	839	gettable      r4    r4   k51
.line	839	sub           r4    r4  k149
.line	839	settable      r3   k51    r4
.line	840	gettable      r3    r2   k36
.line	840	gettabup      r4    u0    k1
.line	840	gettable      r4    r4   k45
.line	840	settable      r3   k53    r4
.line	841	gettable      r3    r2   k36
.line	841	settable      r3   k55   k74
.line	842	gettable      r3    r2   k36
.line	842	settable      r3   k56   k57
.line	843	gettabup      r3    u0    k1
.line	843	gettable      r3    r3   k82
.line	843	move          r4    r2
.line	843	call          r3     2     1
.line	844	gettabup      r3    u0    k1
.line	844	gettable      r3    r3   k83
.line	844	move          r4    r2
.line	844	call          r3     2     1
.line	845	gettabup      r3    u0    k1
.line	845	gettable      r3    r3   k50
.line	845	loadk         r4   k52
.line	845	call          r3     2     2
.line	845	settabup      u0   k49    r3
.line	846	newtable      r3     0     0
.line	847	newtable      r4     0     0
.line	847	settable      r3   k36    r4
.line	848	gettable      r4    r3   k36
.line	848	gettabup      r5    u0   k49
.line	848	gettable      r5    r5   k52
.line	848	gettable      r5    r5   k51
.line	848	sub           r5    r5  k149
.line	848	settable      r4   k51    r5
.line	849	gettable      r4    r3   k36
.line	849	gettabup      r5    u0    k1
.line	849	gettable      r5    r5   k45
.line	849	settable      r4   k53    r5
.line	850	gettable      r4    r3   k36
.line	850	settable      r4   k55   k74
.line	851	gettable      r4    r3   k36
.line	851	settable      r4   k56   k57
.line	852	gettabup      r4    u0    k1
.line	852	gettable      r4    r4   k82
.line	852	move          r5    r3
.line	852	call          r4     2     1
.line	853	gettabup      r4    u0    k1
.line	853	gettable      r4    r4   k83
.line	853	move          r5    r3
.line	853	call          r4     2     1
.line	854	gettabup      r4    u0    k1
.line	854	gettable      r4    r4   k50
.line	854	loadk         r5   k63
.line	854	call          r4     2     2
.line	854	settabup      u0   k49    r4
.line	855	newtable      r4     0     0
.line	856	newtable      r5     0     0
.line	856	settable      r4   k36    r5
.line	857	gettable      r5    r4   k36
.line	857	gettabup      r6    u0   k49
.line	857	gettable      r6    r6   k63
.line	857	gettable      r6    r6   k51
.line	857	sub           r6    r6  k149
.line	857	settable      r5   k51    r6
.line	858	gettable      r5    r4   k36
.line	858	gettabup      r6    u0    k1
.line	858	gettable      r6    r6   k45
.line	858	settable      r5   k53    r6
.line	859	gettable      r5    r4   k36
.line	859	settable      r5   k55   k74
.line	860	gettable      r5    r4   k36
.line	860	settable      r5   k56   k57
.line	861	gettabup      r5    u0    k1
.line	861	gettable      r5    r5   k82
.line	861	move          r6    r4
.line	861	call          r5     2     1
.line	862	gettabup      r5    u0    k1
.line	862	gettable      r5    r5   k83
.line	862	move          r6    r4
.line	862	call          r5     2     1
.line	863	gettabup      r5    u0    k1
.line	863	gettable      r5    r5   k50
.line	863	loadk         r6   k59
.line	863	call          r5     2     2
.line	863	settabup      u0   k49    r5
.line	864	newtable      r5     0     0
.line	865	newtable      r6     0     0
.line	865	settable      r5   k36    r6
.line	866	gettable      r6    r5   k36
.line	866	gettabup      r7    u0   k49
.line	866	gettable      r7    r7   k59
.line	866	gettable      r7    r7   k51
.line	866	sub           r7    r7  k149
.line	866	settable      r6   k51    r7
.line	867	gettable      r6    r5   k36
.line	867	gettabup      r7    u0    k1
.line	867	gettable      r7    r7   k45
.line	867	settable      r6   k53    r7
.line	868	gettable      r6    r5   k36
.line	868	settable      r6   k55   k74
.line	869	gettable      r6    r5   k36
.line	869	settable      r6   k56   k57
.line	870	gettabup      r6    u0    k1
.line	870	gettable      r6    r6   k82
.line	870	move          r7    r5
.line	870	call          r6     2     1
.line	871	gettabup      r6    u0    k1
.line	871	gettable      r6    r6   k83
.line	871	move          r7    r5
.line	871	call          r6     2     1
.line	872	gettabup      r6    u0    k1
.line	872	gettable      r6    r6   k50
.line	872	loadk         r7   k66
.line	872	call          r6     2     2
.line	872	settabup      u0   k49    r6
.line	873	newtable      r6     0     0
.line	874	newtable      r7     0     0
.line	874	settable      r6   k36    r7
.line	875	gettable      r7    r6   k36
.line	875	gettabup      r8    u0   k49
.line	875	gettable      r8    r8   k66
.line	875	gettable      r8    r8   k51
.line	875	sub           r8    r8  k149
.line	875	settable      r7   k51    r8
.line	876	gettable      r7    r6   k36
.line	876	gettabup      r8    u0    k1
.line	876	gettable      r8    r8   k45
.line	876	settable      r7   k53    r8
.line	877	gettable      r7    r6   k36
.line	877	settable      r7   k55   k74
.line	878	gettable      r7    r6   k36
.line	878	settable      r7   k56   k57
.line	879	gettabup      r7    u0    k1
.line	879	gettable      r7    r7   k82
.line	879	move          r8    r6
.line	879	call          r7     2     1
.line	880	gettabup      r7    u0    k1
.line	880	gettable      r7    r7   k83
.line	880	move          r8    r6
.line	880	call          r7     2     1
.line	881	gettabup      r7    u0    k1
.line	881	gettable      r7    r7   k50
.line	881	loadk         r8   k61
.line	881	call          r7     2     2
.line	881	settabup      u0   k49    r7
.line	882	newtable      r7     0     0
.line	883	newtable      r8     0     0
.line	883	settable      r7   k36    r8
.line	884	gettable      r8    r7   k36
.line	884	gettabup      r9    u0   k49
.line	884	gettable      r9    r9   k61
.line	884	gettable      r9    r9   k51
.line	884	sub           r9    r9  k149
.line	884	settable      r8   k51    r9
.line	885	gettable      r8    r7   k36
.line	885	gettabup      r9    u0    k1
.line	885	gettable      r9    r9   k45
.line	885	settable      r8   k53    r9
.line	886	gettable      r8    r7   k36
.line	886	settable      r8   k55   k74
.line	887	gettable      r8    r7   k36
.line	887	settable      r8   k56   k57
.line	888	gettabup      r8    u0    k1
.line	888	gettable      r8    r8   k82
.line	888	move          r9    r7
.line	888	call          r8     2     1
.line	889	gettabup      r8    u0    k1
.line	889	gettable      r8    r8   k83
.line	889	move          r9    r7
.line	889	call          r8     2     1
.line	890	gettabup      r8    u0    k1
.line	890	gettable      r8    r8   k50
.line	890	loadk         r9   k70
.line	890	call          r8     2     2
.line	890	settabup      u0   k49    r8
.line	891	newtable      r8     0     0
.line	892	newtable      r9     0     0
.line	892	settable      r8   k36    r9
.line	893	gettable      r9    r8   k36
.line	893	gettabup     r10    u0   k49
.line	893	gettable     r10   r10   k70
.line	893	gettable     r10   r10   k51
.line	893	sub          r10   r10  k149
.line	893	settable      r9   k51   r10
.line	894	gettable      r9    r8   k36
.line	894	gettabup     r10    u0    k1
.line	894	gettable     r10   r10   k45
.line	894	settable      r9   k53   r10
.line	895	gettable      r9    r8   k36
.line	895	settable      r9   k55   k74
.line	896	gettable      r9    r8   k36
.line	896	settable      r9   k56   k57
.line	897	gettabup      r9    u0    k1
.line	897	gettable      r9    r9   k82
.line	897	move         r10    r8
.line	897	call          r9     2     1
.line	898	gettabup      r9    u0    k1
.line	898	gettable      r9    r9   k83
.line	898	move         r10    r8
.line	898	call          r9     2     1
.line	899	gettabup      r9    u0    k1
.line	899	gettable      r9    r9   k50
.line	899	loadk        r10   k62
.line	899	call          r9     2     2
.line	899	settabup      u0   k49    r9
.line	900	newtable      r9     0     0
.line	901	newtable     r10     0     0
.line	901	settable      r9   k36   r10
.line	902	gettable     r10    r9   k36
.line	902	gettabup     r11    u0   k49
.line	902	gettable     r11   r11   k62
.line	902	gettable     r11   r11   k51
.line	902	sub          r11   r11  k149
.line	902	settable     r10   k51   r11
.line	903	gettable     r10    r9   k36
.line	903	gettabup     r11    u0    k1
.line	903	gettable     r11   r11   k45
.line	903	settable     r10   k53   r11
.line	904	gettable     r10    r9   k36
.line	904	settable     r10   k55   k74
.line	905	gettable     r10    r9   k36
.line	905	settable     r10   k56   k57
.line	906	gettabup     r10    u0    k1
.line	906	gettable     r10   r10   k82
.line	906	move         r11    r9
.line	906	call         r10     2     1
.line	907	gettabup     r10    u0    k1
.line	907	gettable     r10   r10   k83
.line	907	move         r11    r9
.line	907	call         r10     2     1
.line	908	gettabup     r10    u0    k1
.line	908	gettable     r10   r10   k50
.line	908	loadk        r11   k75
.line	908	call         r10     2     2
.line	908	settabup      u0   k49   r10
.line	909	newtable     r10     0     0
.line	910	newtable     r11     0     0
.line	910	settable     r10   k36   r11
.line	911	gettable     r11   r10   k36
.line	911	gettabup     r12    u0   k49
.line	911	gettable     r12   r12   k75
.line	911	gettable     r12   r12   k51
.line	911	sub          r12   r12  k149
.line	911	settable     r11   k51   r12
.line	912	gettable     r11   r10   k36
.line	912	gettabup     r12    u0    k1
.line	912	gettable     r12   r12   k45
.line	912	settable     r11   k53   r12
.line	913	gettable     r11   r10   k36
.line	913	settable     r11   k55   k74
.line	914	gettable     r11   r10   k36
.line	914	settable     r11   k56   k57
.line	915	gettabup     r11    u0    k1
.line	915	gettable     r11   r11   k82
.line	915	move         r12   r10
.line	915	call         r11     2     1
.line	916	gettabup     r11    u0    k1
.line	916	gettable     r11   r11   k83
.line	916	move         r12   r10
.line	916	call         r11     2     1
.line	917	gettabup     r11    u0    k1
.line	917	gettable     r11   r11   k50
.line	917	loadk        r12   k64
.line	917	call         r11     2     2
.line	917	settabup      u0   k49   r11
.line	918	newtable     r11     0     0
.line	919	newtable     r12     0     0
.line	919	settable     r11   k36   r12
.line	920	gettable     r12   r11   k36
.line	920	gettabup     r13    u0   k49
.line	920	gettable     r13   r13   k64
.line	920	gettable     r13   r13   k51
.line	920	sub          r13   r13  k149
.line	920	settable     r12   k51   r13
.line	921	gettable     r12   r11   k36
.line	921	gettabup     r13    u0    k1
.line	921	gettable     r13   r13   k45
.line	921	settable     r12   k53   r13
.line	922	gettable     r12   r11   k36
.line	922	settable     r12   k55   k74
.line	923	gettable     r12   r11   k36
.line	923	settable     r12   k56   k57
.line	924	gettabup     r12    u0    k1
.line	924	gettable     r12   r12   k82
.line	924	move         r13   r11
.line	924	call         r12     2     1
.line	925	gettabup     r12    u0    k1
.line	925	gettable     r12   r12   k83
.line	925	move         r13   r11
.line	925	call         r12     2     1
.line	926	gettabup     r12    u0    k1
.line	926	gettable     r12   r12   k50
.line	926	loadk        r13   k78
.line	926	call         r12     2     2
.line	926	settabup      u0   k49   r12
.line	927	newtable     r12     0     0
.line	928	newtable     r13     0     0
.line	928	settable     r12   k36   r13
.line	929	gettable     r13   r12   k36
.line	929	gettabup     r14    u0   k49
.line	929	gettable     r14   r14   k78
.line	929	gettable     r14   r14   k51
.line	929	sub          r14   r14  k149
.line	929	settable     r13   k51   r14
.line	930	gettable     r13   r12   k36
.line	930	gettabup     r14    u0    k1
.line	930	gettable     r14   r14   k45
.line	930	settable     r13   k53   r14
.line	931	gettable     r13   r12   k36
.line	931	settable     r13   k55   k74
.line	932	gettable     r13   r12   k36
.line	932	settable     r13   k56   k57
.line	933	gettabup     r13    u0    k1
.line	933	gettable     r13   r13   k82
.line	933	move         r14   r12
.line	933	call         r13     2     1
.line	934	gettabup     r13    u0    k1
.line	934	gettable     r13   r13   k83
.line	934	move         r14   r12
.line	934	call         r13     2     1
.line	935	gettabup     r13    u0    k1
.line	935	gettable     r13   r13   k50
.line	935	loadk        r14   k65
.line	935	call         r13     2     2
.line	935	settabup      u0   k49   r13
.line	936	newtable     r13     0     0
.line	937	newtable     r14     0     0
.line	937	settable     r13   k36   r14
.line	938	gettable     r14   r13   k36
.line	938	gettabup     r15    u0   k49
.line	938	gettable     r15   r15   k65
.line	938	gettable     r15   r15   k51
.line	938	sub          r15   r15  k149
.line	938	settable     r14   k51   r15
.line	939	gettable     r14   r13   k36
.line	939	gettabup     r15    u0    k1
.line	939	gettable     r15   r15   k45
.line	939	settable     r14   k53   r15
.line	940	gettable     r14   r13   k36
.line	940	settable     r14   k55   k74
.line	941	gettable     r14   r13   k36
.line	941	settable     r14   k56   k57
.line	942	gettabup     r14    u0    k1
.line	942	gettable     r14   r14   k82
.line	942	move         r15   r13
.line	942	call         r14     2     1
.line	943	gettabup     r14    u0    k1
.line	943	gettable     r14   r14   k83
.line	943	move         r15   r13
.line	943	call         r14     2     1
.line	944	gettabup     r14    u0    k1
.line	944	gettable     r14   r14   k50
.line	944	loadk        r15  k118
.line	944	call         r14     2     2
.line	944	settabup      u0   k49   r14
.line	945	newtable     r14     0     0
.line	946	newtable     r15     0     0
.line	946	settable     r14   k36   r15
.line	947	gettable     r15   r14   k36
.line	947	gettabup     r16    u0   k49
.line	947	gettable     r16   r16  k118
.line	947	gettable     r16   r16   k51
.line	947	sub          r16   r16  k149
.line	947	settable     r15   k51   r16
.line	948	gettable     r15   r14   k36
.line	948	gettabup     r16    u0    k1
.line	948	gettable     r16   r16   k45
.line	948	settable     r15   k53   r16
.line	949	gettable     r15   r14   k36
.line	949	settable     r15   k55   k74
.line	950	gettable     r15   r14   k36
.line	950	settable     r15   k56   k57
.line	951	gettabup     r15    u0    k1
.line	951	gettable     r15   r15   k82
.line	951	move         r16   r14
.line	951	call         r15     2     1
.line	952	gettabup     r15    u0    k1
.line	952	gettable     r15   r15   k83
.line	952	move         r16   r14
.line	952	call         r15     2     1
.line	953	gettabup     r15    u0    k1
.line	953	gettable     r15   r15   k50
.line	953	loadk        r16   k67
.line	953	call         r15     2     2
.line	953	settabup      u0   k49   r15
.line	954	newtable     r15     0     0
.line	955	newtable     r16     0     0
.line	955	settable     r15   k36   r16
.line	956	gettable     r16   r15   k36
.line	956	gettabup     r17    u0   k49
.line	956	gettable     r17   r17   k67
.line	956	gettable     r17   r17   k51
.line	956	sub          r17   r17  k149
.line	956	settable     r16   k51   r17
.line	957	gettable     r16   r15   k36
.line	957	gettabup     r17    u0    k1
.line	957	gettable     r17   r17   k45
.line	957	settable     r16   k53   r17
.line	958	gettable     r16   r15   k36
.line	958	settable     r16   k55   k74
.line	959	gettable     r16   r15   k36
.line	959	settable     r16   k56   k57
.line	960	gettabup     r16    u0    k1
.line	960	gettable     r16   r16   k82
.line	960	move         r17   r15
.line	960	call         r16     2     1
.line	961	gettabup     r16    u0    k1
.line	961	gettable     r16   r16   k83
.line	961	move         r17   r15
.line	961	call         r16     2     1
.line	962	gettabup     r16    u0    k1
.line	962	gettable     r16   r16   k50
.line	962	loadk        r17  k123
.line	962	call         r16     2     2
.line	962	settabup      u0   k49   r16
.line	963	newtable     r16     0     0
.line	964	newtable     r17     0     0
.line	964	settable     r16   k36   r17
.line	965	gettable     r17   r16   k36
.line	965	gettabup     r18    u0   k49
.line	965	gettable     r18   r18  k123
.line	965	gettable     r18   r18   k51
.line	965	sub          r18   r18  k149
.line	965	settable     r17   k51   r18
.line	966	gettable     r17   r16   k36
.line	966	gettabup     r18    u0    k1
.line	966	gettable     r18   r18   k45
.line	966	settable     r17   k53   r18
.line	967	gettable     r17   r16   k36
.line	967	settable     r17   k55   k74
.line	968	gettable     r17   r16   k36
.line	968	settable     r17   k56   k57
.line	969	gettabup     r17    u0    k1
.line	969	gettable     r17   r17   k82
.line	969	move         r18   r16
.line	969	call         r17     2     1
.line	970	gettabup     r17    u0    k1
.line	970	gettable     r17   r17   k83
.line	970	move         r18   r16
.line	970	call         r17     2     1
.line	971	gettabup     r17    u0    k1
.line	971	gettable     r17   r17   k50
.line	971	loadk        r18   k68
.line	971	call         r17     2     2
.line	971	settabup      u0   k49   r17
.line	972	newtable     r17     0     0
.line	973	newtable     r18     0     0
.line	973	settable     r17   k36   r18
.line	974	gettable     r18   r17   k36
.line	974	gettabup     r19    u0   k49
.line	974	gettable     r19   r19   k68
.line	974	gettable     r19   r19   k51
.line	974	sub          r19   r19  k149
.line	974	settable     r18   k51   r19
.line	975	gettable     r18   r17   k36
.line	975	gettabup     r19    u0    k1
.line	975	gettable     r19   r19   k45
.line	975	settable     r18   k53   r19
.line	976	gettable     r18   r17   k36
.line	976	settable     r18   k55   k74
.line	977	gettable     r18   r17   k36
.line	977	settable     r18   k56   k57
.line	978	gettabup     r18    u0    k1
.line	978	gettable     r18   r18   k82
.line	978	move         r19   r17
.line	978	call         r18     2     1
.line	979	gettabup     r18    u0    k1
.line	979	gettable     r18   r18   k83
.line	979	move         r19   r17
.line	979	call         r18     2     1
.line	980	gettabup     r18    u0    k1
.line	980	gettable     r18   r18   k50
.line	980	loadk        r19   k68
.line	980	call         r18     2     2
.line	980	settabup      u0   k49   r18
.line	981	newtable     r18     0     0
.line	982	newtable     r19     0     0
.line	982	settable     r18   k36   r19
.line	983	gettable     r19   r18   k36
.line	983	gettabup     r20    u0   k49
.line	983	gettable     r20   r20   k68
.line	983	gettable     r20   r20   k51
.line	983	sub          r20   r20  k149
.line	983	settable     r19   k51   r20
.line	984	gettable     r19   r18   k36
.line	984	gettabup     r20    u0    k1
.line	984	gettable     r20   r20   k45
.line	984	settable     r19   k53   r20
.line	985	gettable     r19   r18   k36
.line	985	settable     r19   k55   k74
.line	986	gettable     r19   r18   k36
.line	986	settable     r19   k56   k57
.line	987	gettabup     r19    u0    k1
.line	987	gettable     r19   r19   k82
.line	987	move         r20   r18
.line	987	call         r19     2     1
.line	988	gettabup     r19    u0    k1
.line	988	gettable     r19   r19   k83
.line	988	move         r20   r18
.line	988	call         r19     2     1
.line	989	gettabup     r19    u0    k1
.line	989	gettable     r19   r19   k50
.line	989	loadk        r20  k132
.line	989	call         r19     2     2
.line	989	settabup      u0   k49   r19
.line	990	newtable     r19     0     0
.line	991	newtable     r20     0     0
.line	991	settable     r19   k36   r20
.line	992	gettable     r20   r19   k36
.line	992	gettabup     r21    u0   k49
.line	992	gettable     r21   r21  k132
.line	992	gettable     r21   r21   k51
.line	992	sub          r21   r21  k149
.line	992	settable     r20   k51   r21
.line	993	gettable     r20   r19   k36
.line	993	gettabup     r21    u0    k1
.line	993	gettable     r21   r21   k45
.line	993	settable     r20   k53   r21
.line	994	gettable     r20   r19   k36
.line	994	settable     r20   k55   k74
.line	995	gettable     r20   r19   k36
.line	995	settable     r20   k56   k57
.line	996	gettabup     r20    u0    k1
.line	996	gettable     r20   r20   k82
.line	996	move         r21   r19
.line	996	call         r20     2     1
.line	997	gettabup     r20    u0    k1
.line	997	gettable     r20   r20   k83
.line	997	move         r21   r19
.line	997	call         r20     2     1
.line	998	gettabup     r20    u0    k1
.line	998	gettable     r20   r20   k50
.line	998	loadk        r21   k79
.line	998	call         r20     2     2
.line	998	settabup      u0   k49   r20
.line	999	newtable     r20     0     0
.line	1000	newtable     r21     0     0
.line	1000	settable     r20   k36   r21
.line	1001	gettable     r21   r20   k36
.line	1001	gettabup     r22    u0   k49
.line	1001	gettable     r22   r22   k79
.line	1001	gettable     r22   r22   k51
.line	1001	sub          r22   r22  k149
.line	1001	settable     r21   k51   r22
.line	1002	gettable     r21   r20   k36
.line	1002	gettabup     r22    u0    k1
.line	1002	gettable     r22   r22   k45
.line	1002	settable     r21   k53   r22
.line	1003	gettable     r21   r20   k36
.line	1003	settable     r21   k55   k74
.line	1004	gettable     r21   r20   k36
.line	1004	settable     r21   k56   k57
.line	1005	gettabup     r21    u0    k1
.line	1005	gettable     r21   r21   k82
.line	1005	move         r22   r20
.line	1005	call         r21     2     1
.line	1006	gettabup     r21    u0    k1
.line	1006	gettable     r21   r21   k83
.line	1006	move         r22   r20
.line	1006	call         r21     2     1
.line	1007	gettabup     r21    u0    k1
.line	1007	gettable     r21   r21   k50
.line	1007	loadk        r22  k136
.line	1007	call         r21     2     2
.line	1007	settabup      u0   k49   r21
.line	1008	newtable     r21     0     0
.line	1009	newtable     r22     0     0
.line	1009	settable     r21   k36   r22
.line	1010	gettable     r22   r21   k36
.line	1010	gettabup     r23    u0   k49
.line	1010	gettable     r23   r23  k136
.line	1010	gettable     r23   r23   k51
.line	1010	sub          r23   r23  k149
.line	1010	settable     r22   k51   r23
.line	1011	gettable     r22   r21   k36
.line	1011	gettabup     r23    u0    k1
.line	1011	gettable     r23   r23   k45
.line	1011	settable     r22   k53   r23
.line	1012	gettable     r22   r21   k36
.line	1012	settable     r22   k55   k74
.line	1013	gettable     r22   r21   k36
.line	1013	settable     r22   k56   k57
.line	1014	gettabup     r22    u0    k1
.line	1014	gettable     r22   r22   k82
.line	1014	move         r23   r21
.line	1014	call         r22     2     1
.line	1015	gettabup     r22    u0    k1
.line	1015	gettable     r22   r22   k83
.line	1015	move         r23   r21
.line	1015	call         r22     2     1
.line	1016	gettabup     r22    u0    k1
.line	1016	gettable     r22   r22   k50
.line	1016	loadk        r23  k138
.line	1016	call         r22     2     2
.line	1016	settabup      u0   k49   r22
.line	1017	newtable     r22     0     0
.line	1018	newtable     r23     0     0
.line	1018	settable     r22   k36   r23
.line	1019	gettable     r23   r22   k36
.line	1019	gettabup     r24    u0   k49
.line	1019	gettable     r24   r24  k138
.line	1019	gettable     r24   r24   k51
.line	1019	sub          r24   r24  k149
.line	1019	settable     r23   k51   r24
.line	1020	gettable     r23   r22   k36
.line	1020	gettabup     r24    u0    k1
.line	1020	gettable     r24   r24   k45
.line	1020	settable     r23   k53   r24
.line	1021	gettable     r23   r22   k36
.line	1021	settable     r23   k55   k74
.line	1022	gettable     r23   r22   k36
.line	1022	settable     r23   k56   k57
.line	1023	gettabup     r23    u0    k1
.line	1023	gettable     r23   r23   k82
.line	1023	move         r24   r22
.line	1023	call         r23     2     1
.line	1024	gettabup     r23    u0    k1
.line	1024	gettable     r23   r23   k83
.line	1024	move         r24   r22
.line	1024	call         r23     2     1
.line	1025	gettabup     r23    u0    k1
.line	1025	gettable     r23   r23   k50
.line	1025	loadk        r24  k141
.line	1025	call         r23     2     2
.line	1025	settabup      u0   k49   r23
.line	1026	newtable     r23     0     0
.line	1027	newtable     r24     0     0
.line	1027	settable     r23   k36   r24
.line	1028	gettable     r24   r23   k36
.line	1028	gettabup     r25    u0   k49
.line	1028	gettable     r25   r25  k141
.line	1028	gettable     r25   r25   k51
.line	1028	sub          r25   r25  k149
.line	1028	settable     r24   k51   r25
.line	1029	gettable     r24   r23   k36
.line	1029	gettabup     r25    u0    k1
.line	1029	gettable     r25   r25   k45
.line	1029	settable     r24   k53   r25
.line	1030	gettable     r24   r23   k36
.line	1030	settable     r24   k55   k74
.line	1031	gettable     r24   r23   k36
.line	1031	settable     r24   k56   k57
.line	1032	gettabup     r24    u0    k1
.line	1032	gettable     r24   r24   k82
.line	1032	move         r25   r23
.line	1032	call         r24     2     1
.line	1033	gettabup     r24    u0    k1
.line	1033	gettable     r24   r24   k83
.line	1033	move         r25   r23
.line	1033	call         r24     2     1
.line	1034	gettabup     r24    u0    k1
.line	1034	gettable     r24   r24   k50
.line	1034	loadk        r25  k144
.line	1034	call         r24     2     2
.line	1034	settabup      u0   k49   r24
.line	1035	newtable     r24     0     0
.line	1036	newtable     r25     0     0
.line	1036	settable     r24   k36   r25
.line	1037	gettable     r25   r24   k36
.line	1037	gettabup     r26    u0   k49
.line	1037	gettable     r26   r26  k144
.line	1037	gettable     r26   r26   k51
.line	1037	sub          r26   r26  k149
.line	1037	settable     r25   k51   r26
.line	1038	gettable     r25   r24   k36
.line	1038	gettabup     r26    u0    k1
.line	1038	gettable     r26   r26   k45
.line	1038	settable     r25   k53   r26
.line	1039	gettable     r25   r24   k36
.line	1039	settable     r25   k55   k74
.line	1040	gettable     r25   r24   k36
.line	1040	settable     r25   k56   k57
.line	1041	gettabup     r25    u0    k1
.line	1041	gettable     r25   r25   k82
.line	1041	move         r26   r24
.line	1041	call         r25     2     1
.line	1042	gettabup     r25    u0    k1
.line	1042	gettable     r25   r25   k83
.line	1042	move         r26   r24
.line	1042	call         r25     2     1
.line	1043	gettabup     r25    u0    k1
.line	1043	gettable     r25   r25   k50
.line	1043	loadk        r26  k147
.line	1043	call         r25     2     2
.line	1043	settabup      u0   k49   r25
.line	1044	newtable     r25     0     0
.line	1045	newtable     r26     0     0
.line	1045	settable     r25   k36   r26
.line	1046	gettable     r26   r25   k36
.line	1046	gettabup     r27    u0   k49
.line	1046	gettable     r27   r27  k147
.line	1046	gettable     r27   r27   k51
.line	1046	sub          r27   r27  k149
.line	1046	settable     r26   k51   r27
.line	1047	gettable     r26   r25   k36
.line	1047	gettabup     r27    u0    k1
.line	1047	gettable     r27   r27   k45
.line	1047	settable     r26   k53   r27
.line	1048	gettable     r26   r25   k36
.line	1048	settable     r26   k55   k74
.line	1049	gettable     r26   r25   k36
.line	1049	settable     r26   k56   k57
.line	1050	gettabup     r26    u0    k1
.line	1050	gettable     r26   r26   k82
.line	1050	move         r27   r25
.line	1050	call         r26     2     1
.line	1051	gettabup     r26    u0    k1
.line	1051	gettable     r26   r26   k83
.line	1051	move         r27   r25
.line	1051	call         r26     2     1
.line	1052	gettabup     r26    u0    k1
.line	1052	gettable     r26   r26   k50
.line	1052	loadk        r27  k150
.line	1052	call         r26     2     2
.line	1052	settabup      u0   k49   r26
.line	1053	newtable     r26     0     0
.line	1054	newtable     r27     0     0
.line	1054	settable     r26   k36   r27
.line	1055	gettable     r27   r26   k36
.line	1055	gettabup     r28    u0   k49
.line	1055	gettable     r28   r28  k150
.line	1055	gettable     r28   r28   k51
.line	1055	sub          r28   r28  k149
.line	1055	settable     r27   k51   r28
.line	1056	gettable     r27   r26   k36
.line	1056	gettabup     r28    u0    k1
.line	1056	gettable     r28   r28   k45
.line	1056	settable     r27   k53   r28
.line	1057	gettable     r27   r26   k36
.line	1057	settable     r27   k55   k74
.line	1058	gettable     r27   r26   k36
.line	1058	settable     r27   k56   k57
.line	1059	gettabup     r27    u0    k1
.line	1059	gettable     r27   r27   k82
.line	1059	move         r28   r26
.line	1059	call         r27     2     1
.line	1060	gettabup     r27    u0    k1
.line	1060	gettable     r27   r27   k83
.line	1060	move         r28   r26
.line	1060	call         r27     2     1
.line	1061	gettabup     r27    u0    k1
.line	1061	gettable     r27   r27   k50
.line	1061	loadk        r28  k151
.line	1061	call         r27     2     2
.line	1061	settabup      u0   k49   r27
.line	1062	newtable     r27     0     0
.line	1063	newtable     r28     0     0
.line	1063	settable     r27   k36   r28
.line	1064	gettable     r28   r27   k36
.line	1064	gettabup     r29    u0   k49
.line	1064	gettable     r29   r29  k151
.line	1064	gettable     r29   r29   k51
.line	1064	sub          r29   r29  k149
.line	1064	settable     r28   k51   r29
.line	1065	gettable     r28   r27   k36
.line	1065	gettabup     r29    u0    k1
.line	1065	gettable     r29   r29   k45
.line	1065	settable     r28   k53   r29
.line	1066	gettable     r28   r27   k36
.line	1066	settable     r28   k55   k74
.line	1067	gettable     r28   r27   k36
.line	1067	settable     r28   k56   k57
.line	1068	gettabup     r28    u0    k1
.line	1068	gettable     r28   r28   k82
.line	1068	move         r29   r27
.line	1068	call         r28     2     1
.line	1069	gettabup     r28    u0    k1
.line	1069	gettable     r28   r28   k83
.line	1069	move         r29   r27
.line	1069	call         r28     2     1
.line	1070	gettabup     r28    u0    k1
.line	1070	gettable     r28   r28   k50
.line	1070	loadk        r29   k77
.line	1070	call         r28     2     2
.line	1070	settabup      u0   k49   r28
.line	1071	newtable     r28     0     0
.line	1072	newtable     r29     0     0
.line	1072	settable     r28   k36   r29
.line	1073	gettable     r29   r28   k36
.line	1073	gettabup     r30    u0   k49
.line	1073	gettable     r30   r30   k77
.line	1073	gettable     r30   r30   k51
.line	1073	sub          r30   r30  k149
.line	1073	settable     r29   k51   r30
.line	1074	gettable     r29   r28   k36
.line	1074	gettabup     r30    u0    k1
.line	1074	gettable     r30   r30   k45
.line	1074	settable     r29   k53   r30
.line	1075	gettable     r29   r28   k36
.line	1075	settable     r29   k55   k74
.line	1076	gettable     r29   r28   k36
.line	1076	settable     r29   k56   k57
.line	1077	gettabup     r29    u0    k1
.line	1077	gettable     r29   r29   k82
.line	1077	move         r30   r28
.line	1077	call         r29     2     1
.line	1078	gettabup     r29    u0    k1
.line	1078	gettable     r29   r29   k83
.line	1078	move         r30   r28
.line	1078	call         r29     2     1
.line	1079	gettabup     r29    u0    k1
.line	1079	gettable     r29   r29   k50
.line	1079	loadk        r30  k152
.line	1079	call         r29     2     2
.line	1079	settabup      u0   k49   r29
.line	1080	newtable     r29     0     0
.line	1081	newtable     r30     0     0
.line	1081	settable     r29   k36   r30
.line	1082	gettable     r30   r29   k36
.line	1082	gettabup     r31    u0   k49
.line	1082	gettable     r31   r31  k152
.line	1082	gettable     r31   r31   k51
.line	1082	sub          r31   r31  k149
.line	1082	settable     r30   k51   r31
.line	1083	gettable     r30   r29   k36
.line	1083	gettabup     r31    u0    k1
.line	1083	gettable     r31   r31   k45
.line	1083	settable     r30   k53   r31
.line	1084	gettable     r30   r29   k36
.line	1084	settable     r30   k55   k74
.line	1085	gettable     r30   r29   k36
.line	1085	settable     r30   k56   k57
.line	1086	gettabup     r30    u0    k1
.line	1086	gettable     r30   r30   k82
.line	1086	move         r31   r29
.line	1086	call         r30     2     1
.line	1087	gettabup     r30    u0    k1
.line	1087	gettable     r30   r30   k83
.line	1087	move         r31   r29
.line	1087	call         r30     2     1
.line	1088	gettabup     r30    u0    k1
.line	1088	gettable     r30   r30   k50
.line	1088	loadk        r31  k153
.line	1088	call         r30     2     2
.line	1088	settabup      u0   k49   r30
.line	1089	newtable     r30     0     0
.line	1090	newtable     r31     0     0
.line	1090	settable     r30   k36   r31
.line	1091	gettable     r31   r30   k36
.line	1091	gettabup     r32    u0   k49
.line	1091	gettable     r32   r32  k153
.line	1091	gettable     r32   r32   k51
.line	1091	sub          r32   r32  k149
.line	1091	settable     r31   k51   r32
.line	1092	gettable     r31   r30   k36
.line	1092	gettabup     r32    u0    k1
.line	1092	gettable     r32   r32   k45
.line	1092	settable     r31   k53   r32
.line	1093	gettable     r31   r30   k36
.line	1093	settable     r31   k55   k74
.line	1094	gettable     r31   r30   k36
.line	1094	settable     r31   k56   k57
.line	1095	gettabup     r31    u0    k1
.line	1095	gettable     r31   r31   k82
.line	1095	move         r32   r30
.line	1095	call         r31     2     1
.line	1096	gettabup     r31    u0    k1
.line	1096	gettable     r31   r31   k83
.line	1096	move         r32   r30
.line	1096	call         r31     2     1
.line	1097	gettabup     r31    u0    k1
.line	1097	gettable     r31   r31   k50
.line	1097	loadk        r32  k154
.line	1097	call         r31     2     2
.line	1097	settabup      u0   k49   r31
.line	1098	newtable     r31     0     0
.line	1099	newtable     r32     0     0
.line	1099	settable     r31   k36   r32
.line	1100	gettable     r32   r31   k36
.line	1100	gettabup     r33    u0   k49
.line	1100	gettable     r33   r33  k154
.line	1100	gettable     r33   r33   k51
.line	1100	sub          r33   r33  k149
.line	1100	settable     r32   k51   r33
.line	1101	gettable     r32   r31   k36
.line	1101	gettabup     r33    u0    k1
.line	1101	gettable     r33   r33   k45
.line	1101	settable     r32   k53   r33
.line	1102	gettable     r32   r31   k36
.line	1102	settable     r32   k55   k74
.line	1103	gettable     r32   r31   k36
.line	1103	settable     r32   k56   k57
.line	1104	gettabup     r32    u0    k1
.line	1104	gettable     r32   r32   k82
.line	1104	move         r33   r31
.line	1104	call         r32     2     1
.line	1105	gettabup     r32    u0    k1
.line	1105	gettable     r32   r32   k83
.line	1105	move         r33   r31
.line	1105	call         r32     2     1
.line	1106	gettabup     r32    u0    k1
.line	1106	gettable     r32   r32   k50
.line	1106	loadk        r33  k155
.line	1106	call         r32     2     2
.line	1106	settabup      u0   k49   r32
.line	1107	newtable     r32     0     0
.line	1108	newtable     r33     0     0
.line	1108	settable     r32   k36   r33
.line	1109	gettable     r33   r32   k36
.line	1109	gettabup     r34    u0   k49
.line	1109	gettable     r34   r34  k155
.line	1109	gettable     r34   r34   k51
.line	1109	sub          r34   r34  k149
.line	1109	settable     r33   k51   r34
.line	1110	gettable     r33   r32   k36
.line	1110	gettabup     r34    u0    k1
.line	1110	gettable     r34   r34   k45
.line	1110	settable     r33   k53   r34
.line	1111	gettable     r33   r32   k36
.line	1111	settable     r33   k55   k74
.line	1112	gettable     r33   r32   k36
.line	1112	settable     r33   k56   k57
.line	1113	gettabup     r33    u0    k1
.line	1113	gettable     r33   r33   k82
.line	1113	move         r34   r32
.line	1113	call         r33     2     1
.line	1114	gettabup     r33    u0    k1
.line	1114	gettable     r33   r33   k83
.line	1114	move         r34   r32
.line	1114	call         r33     2     1
.line	1115	gettabup     r33    u0    k1
.line	1115	gettable     r33   r33   k50
.line	1115	loadk        r34  k156
.line	1115	call         r33     2     2
.line	1115	settabup      u0   k49   r33
.line	1116	newtable     r33     0     0
.line	1117	newtable     r34     0     0
.line	1117	settable     r33   k36   r34
.line	1118	gettable     r34   r33   k36
.line	1118	gettabup     r35    u0   k49
.line	1118	gettable     r35   r35  k156
.line	1118	gettable     r35   r35   k51
.line	1118	sub          r35   r35  k149
.line	1118	settable     r34   k51   r35
.line	1119	gettable     r34   r33   k36
.line	1119	gettabup     r35    u0    k1
.line	1119	gettable     r35   r35   k45
.line	1119	settable     r34   k53   r35
.line	1120	gettable     r34   r33   k36
.line	1120	settable     r34   k55   k74
.line	1121	gettable     r34   r33   k36
.line	1121	settable     r34   k56   k57
.line	1122	gettabup     r34    u0    k1
.line	1122	gettable     r34   r34   k82
.line	1122	move         r35   r33
.line	1122	call         r34     2     1
.line	1123	gettabup     r34    u0    k1
.line	1123	gettable     r34   r34   k83
.line	1123	move         r35   r33
.line	1123	call         r34     2     1
.line	1124	gettabup     r34    u0    k1
.line	1124	gettable     r34   r34   k50
.line	1124	loadk        r35  k157
.line	1124	call         r34     2     2
.line	1124	settabup      u0   k49   r34
.line	1125	newtable     r34     0     0
.line	1126	newtable     r35     0     0
.line	1126	settable     r34   k36   r35
.line	1127	gettable     r35   r34   k36
.line	1127	gettabup     r36    u0   k49
.line	1127	gettable     r36   r36  k157
.line	1127	gettable     r36   r36   k51
.line	1127	sub          r36   r36  k149
.line	1127	settable     r35   k51   r36
.line	1128	gettable     r35   r34   k36
.line	1128	gettabup     r36    u0    k1
.line	1128	gettable     r36   r36   k45
.line	1128	settable     r35   k53   r36
.line	1129	gettable     r35   r34   k36
.line	1129	settable     r35   k55   k74
.line	1130	gettable     r35   r34   k36
.line	1130	settable     r35   k56   k57
.line	1131	gettabup     r35    u0    k1
.line	1131	gettable     r35   r35   k82
.line	1131	move         r36   r34
.line	1131	call         r35     2     1
.line	1132	gettabup     r35    u0    k1
.line	1132	gettable     r35   r35   k83
.line	1132	move         r36   r34
.line	1132	call         r35     2     1
.line	1133	gettabup     r35    u0    k1
.line	1133	gettable     r35   r35   k84
.line	1133	call         r35     1     1
.line	1134	gettabup     r35    u0    k1
.line	1134	gettable     r35   r35   k34
.line	1134	loadk        r36   k85
.line	1134	call         r35     2     1
.label	l3745
.line	1137	gettabup      r0    u0    k0
.line	1137	eq             0    r0  k150
.line	1137	jmp            0 l3802
.line	1138	gettabup      r0    u0    k1
.line	1138	gettable      r0    r0   k37
.line	1138	gettabup      r1    u0    k1
.line	1138	gettable      r1    r1   k38
.line	1138	gettabup      r2    u0    k1
.line	1138	gettable      r2    r2   k39
.line	1138	bor           r1    r1    r2
.line	1138	call          r0     2     1
.line	1139	gettabup      r0    u0    k1
.line	1139	gettable      r0    r0  k159
.line	1139	newtable      r1     2     0
.line	1140	loadk         r2  k160
.line	1142	loadk         r3  k161
.line	1142	setlist       r1     2     1
.line	1142	newtable      r2     2     0
.line	1142	loadk         r3  k162
.line	1142	loadk         r4  k162
.line	1142	setlist       r2     2     1
.line	1142	newtable      r3     2     0
.line	1142	loadk         r4  k163
.line	1142	loadk         r5  k163
.line	1142	setlist       r3     2     1
.line	1139	call          r0     4     2
.line	1142	settabup      u0  k158    r0
.line	1143	gettabup      r0    u0    k1
.line	1143	gettable      r0    r0   k43
.line	1143	loadk         r1  k164
.line	1143	gettabup      r2    u0  k158
.line	1143	gettable      r2    r2   k36
.line	1143	concat        r1    r1    r2
.line	1143	gettabup      r2    u0    k1
.line	1143	gettable      r2    r2  k165
.line	1143	call          r0     3     1
.line	1144	gettabup      r0    u0    k1
.line	1144	gettable      r0    r0   k50
.line	1144	loadk         r1  k166
.line	1144	call          r0     2     2
.line	1144	settabup      u0   k97    r0
.line	1145	gettabup      r0    u0    k1
.line	1145	gettable      r0    r0  k127
.line	1145	loadk         r1  k164
.line	1145	gettabup      r2    u0  k158
.line	1145	gettable      r2    r2   k58
.line	1145	concat        r1    r1    r2
.line	1145	gettabup      r2    u0    k1
.line	1145	gettable      r2    r2  k165
.line	1145	call          r0     3     1
.line	1146	gettabup      r0    u0    k1
.line	1146	gettable      r0    r0   k84
.line	1146	call          r0     1     1
.line	1147	gettabup      r0    u0    k1
.line	1147	gettable      r0    r0   k34
.line	1147	loadk         r1   k85
.line	1147	call          r0     2     1
.label	l3802
.line	1150	gettabup      r0    u0    k0
.line	1150	eq             0    r0  k151
.line	1150	jmp            0 l3856
.line	1151	gettabup      r0    u0    k1
.line	1151	gettable      r0    r0   k37
.line	1151	gettabup      r1    u0    k1
.line	1151	gettable      r1    r1   k38
.line	1151	gettabup      r2    u0    k1
.line	1151	gettable      r2    r2   k39
.line	1151	bor           r1    r1    r2
.line	1151	call          r0     2     1
.line	1152	gettabup      r0    u0    k1
.line	1152	gettable      r0    r0   k43
.line	1152	loadk         r1  k110
.line	1152	gettabup      r2    u0    k1
.line	1152	gettable      r2    r2   k45
.line	1152	call          r0     3     1
.line	1153	gettabup      r0    u0    k1
.line	1153	gettable      r0    r0   k50
.line	1153	loadk         r1   k36
.line	1153	call          r0     2     2
.line	1153	settabup      u0   k49    r0
.line	1154	newtable      r0     0     0
.line	1155	newtable      r1     0     0
.line	1155	settable      r0   k36    r1
.line	1156	gettable      r1    r0   k36
.line	1156	gettabup      r2    u0   k49
.line	1156	gettable      r2    r2   k36
.line	1156	gettable      r2    r2   k51
.line	1156	sub           r2    r2  k167
.line	1156	settable      r1   k51    r2
.line	1157	gettable      r1    r0   k36
.line	1157	gettabup      r2    u0    k1
.line	1157	gettable      r2    r2   k45
.line	1157	settable      r1   k53    r2
.line	1158	gettable      r1    r0   k36
.line	1158	settable      r1   k55  k168
.line	1159	gettable      r1    r0   k36
.line	1159	settable      r1   k56   k57
.line	1160	gettabup      r1    u0    k1
.line	1160	gettable      r1    r1   k82
.line	1160	move          r2    r0
.line	1160	call          r1     2     1
.line	1161	gettabup      r1    u0    k1
.line	1161	gettable      r1    r1   k83
.line	1161	move          r2    r0
.line	1161	call          r1     2     1
.line	1162	gettabup      r1    u0    k1
.line	1162	gettable      r1    r1   k84
.line	1162	call          r1     1     1
.line	1163	gettabup      r1    u0    k1
.line	1163	gettable      r1    r1   k34
.line	1163	loadk         r2   k85
.line	1163	call          r1     2     1
.label	l3856
.line	1166	gettabup      r0    u0    k0
.line	1166	eq             0    r0   k77
.line	1166	jmp            0 l3872
.line	1167	gettabup      r0    u0    k1
.line	1167	gettable      r0    r0  k103
.line	1167	loadbool      r1     0     0
.line	1167	call          r0     2     1
.line	1168	gettabup      r0    u0    k1
.line	1168	gettable      r0    r0  k169
.line	1168	loadk         r1  k170
.line	1168	loadk         r2  k171
.line	1168	call          r0     3     1
.line	1169	gettabup      r0    u0    k1
.line	1169	gettable      r0    r0  k103
.line	1169	loadbool      r1     1     0
.line	1169	call          r0     2     1
.label	l3872
.line	1172	gettabup      r0    u0    k0
.line	1172	eq             0    r0  k152
.line	1172	jmp            0 l3915
.line	1173	gettabup      r0    u0  k172
.line	1173	loadk         r1  k173
.line	1173	call          r0     2     1
.line	1174	gettabup      r0    u0  k172
.line	1174	gettabup      r1    u0  k174
.line	1174	gettable      r1    r1  k175
.line	1174	loadk         r2  k176
.line	1174	call          r1     2     0
.line	1174	call          r0     0     1
.line	1175	gettabup      r0    u0  k172
.line	1175	loadk         r1  k173
.line	1175	call          r0     2     1
.line	1176	gettabup      r0    u0  k172
.line	1176	loadk         r1  k177
.line	1176	call          r0     2     1
.line	1177	gettabup      r0    u0  k172
.line	1177	loadk         r1  k173
.line	1177	call          r0     2     1
.line	1178	gettabup      r0    u0  k172
.line	1178	loadk         r1  k178
.line	1178	call          r0     2     1
.line	1179	gettabup      r0    u0  k172
.line	1179	loadk         r1  k173
.line	1179	call          r0     2     1
.line	1180	gettabup      r0    u0  k172
.line	1180	loadk         r1  k179
.line	1180	call          r0     2     1
.line	1181	gettabup      r0    u0  k172
.line	1181	loadk         r1  k173
.line	1181	call          r0     2     1
.line	1182	gettabup      r0    u0    k1
.line	1182	gettable      r0    r0  k180
.line	1182	call          r0     1     1
.line	1183	gettabup      r0    u0    k1
.line	1183	gettable      r0    r0  k103
.line	1183	loadbool      r1     1     0
.line	1183	call          r0     2     1
.line	1184	gettabup      r0    u0  k174
.line	1184	gettable      r0    r0  k181
.line	1184	call          r0     1     1
.label	l3915
.line	1187	settabup      u0  k182   k80
.label	l3916
.line	1189	return        r0     1

.function	main/f1

.linedefined	1191
.lastlinedefined	1194
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	"_ENV"	0	false

.constant	k0	"gg"
.constant	k1	"clearResults"
.constant	k2	"os"
.constant	k3	"exit"

.line	1192	gettabup      r0    u0    k0
.line	1192	gettable      r0    r0    k1
.line	1192	call          r0     1     1
.line	1193	gettabup      r0    u0    k2
.line	1193	gettable      r0    r0    k3
.line	1193	call          r0     1     1
.line	1194	return        r0     1
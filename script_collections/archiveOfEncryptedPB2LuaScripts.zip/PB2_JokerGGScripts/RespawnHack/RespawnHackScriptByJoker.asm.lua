.version	5.2

.format	0
.endianness	LITTLE
.int_size	4
.size_t_size	4
.instruction_size	4
.number_format	float	8

.function	main

.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	3
.source	null

.upvalue	"_ENV"	0	true

.constant	k0	"Nothing Here Remove Me Pls"
.constant	k1	"Q"

loadk         r0    k0
newtable      r1     0     0
closure       r2    f0
settable      r1    k1    r2
gettable      r2    r1    k1
call          r2     1     1
return        r0     1

.function	main/f0

.linedefined	3
.lastlinedefined	637
.numparams	0
.is_vararg	0
.maxstacksize	155
.source	null

.upvalue	null	0	false

.constant	k0	"PG"
.constant	k1	"PGPRO"
.constant	k2	"fPGPRO"
.constant	k3	"PGPROAQ"
.constant	k4	"AQ"
.constant	k5	"PGPROPG"
.constant	k6	"PGPROAQyPG"
.constant	k7	"sPGPRO"
.constant	k8	"PGPROi"
.constant	k9	"PGPROAQAQ"
.constant	k10	"PGPROw"
.constant	k11	"PGPROAQPG"
.constant	k12	"PGPRObAQ"
.constant	k13	1
.constant	k14	2
.constant	k15	3
.constant	k16	"i"
.constant	k17	nil
.constant	k18	"ipairs"
.constant	k19	200
.constant	k20	"Key10"
.constant	k21	8271
.constant	k22	4817
.constant	k23	72
.constant	k24	9272
.constant	k25	2727
.constant	k26	3727
.constant	k27	4783
.constant	k28	9473
.constant	k29	8363
.constant	k30	85
.constant	k31	3073
.constant	k32	8362
.constant	k33	7392
.constant	k34	100
.constant	k35	7494
.constant	k36	210
.constant	k37	3728
.constant	k38	122
.constant	k39	5
.constant	k40	4
.constant	k41	"PGFC"
.constant	k42	"PGPRON"
.constant	k43	"PGENC_1"
.constant	k44	215
.constant	k45	"keyy10"
.constant	k46	252
.constant	k47	87
.constant	k48	209
.constant	k49	213
.constant	k50	108
.constant	k51	"PGFC1"
.constant	k52	"PGPRON1"
.constant	k53	"PGENC_2"
.constant	k54	99
.constant	k55	"keyyy10"
.constant	k56	41
.constant	k57	26
.constant	k58	180
.constant	k59	22
.constant	k60	248
.constant	k61	"PGFC2"
.constant	k62	"PGPRON2"
.constant	k63	"PGENC_3"
.constant	k64	60
.constant	k65	"keyyyy10"
.constant	k66	143
.constant	k67	157
.constant	k68	156
.constant	k69	171
.constant	k70	37
.constant	k71	"PGFC3"
.constant	k72	"PGPRON3"
.constant	k73	"PGENC_4"
.constant	k74	"PGENC_5"
.constant	k75	"PGENC_6"
.constant	k76	"PGENC_7"
.constant	k77	"PGENC_8"
.constant	k78	"PGENC"
.constant	k79	"fPGENC"
.constant	k80	"PGENCAQ"
.constant	k81	"PGENCPG"
.constant	k82	"PGENCAQyPG"
.constant	k83	"sPGENC"
.constant	k84	"PGENCi"
.constant	k85	"PGENCAQAQ"
.constant	k86	"PGENCw"
.constant	k87	"PGENCAQPG"
.constant	k88	"PGENCbAQ"
.constant	k89	"loadfile"
.constant	k90	"gg"
.constant	k91	"getFile"
.constant	k92	"io"
.constant	k93	"output"
.constant	k94	"write"
.constant	k95	"read"
.constant	k96	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k97	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k98	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k99	true
.constant	k100	false
.constant	k101	0
.constant	k102	"sel"
.constant	k103	"data"
.constant	k104	"_1"
.constant	k105	"_3"
.constant	k106	"_4"
.constant	k107	"_5"
.constant	k108	"_6"
.constant	k109	"_7"
.constant	k110	"_8"
.constant	k111	"_9"
.constant	k112	"_10"
.constant	k113	"_11"
.constant	k114	"_12"
.constant	k115	"_13"
.constant	k116	"_14"
.constant	k117	"_15"
.constant	k118	"_16"
.constant	k119	"_17"
.constant	k120	"_18"
.constant	k121	"_19"
.constant	k122	"_20"
.constant	k123	12
.constant	k124	91
.constant	k125	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k126	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k127	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k128	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k129	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k130	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k131	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k132	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k133	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k134	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k135	6
.constant	k136	7
.constant	k137	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k138	8
.constant	k139	9
.constant	k140	10
.constant	k141	11
.constant	k142	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k143	13
.constant	k144	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k145	14
.constant	k146	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k147	15
.constant	k148	16
.constant	k149	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k150	17
.constant	k151	18
.constant	k152	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k153	19
.constant	k154	20
.constant	k155	21
.constant	k156	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k157	23
.constant	k158	24
.constant	k159	25
.constant	k160	27
.constant	k161	28
.constant	k162	29
.constant	k163	30
.constant	k164	31
.constant	k165	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k166	32
.constant	k167	33
.constant	k168	34
.constant	k169	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k170	35
.constant	k171	36
.constant	k172	38
.constant	k173	39
.constant	k174	40
.constant	k175	42
.constant	k176	43
.constant	k177	44
.constant	k178	45
.constant	k179	46
.constant	k180	47
.constant	k181	48
.constant	k182	49
.constant	k183	50
.constant	k184	51
.constant	k185	52
.constant	k186	53
.constant	k187	54
.constant	k188	55
.constant	k189	56
.constant	k190	57
.constant	k191	58
.constant	k192	59
.constant	k193	61
.constant	k194	62
.constant	k195	63
.constant	k196	64
.constant	k197	65
.constant	k198	66
.constant	k199	67
.constant	k200	68
.constant	k201	69
.constant	k202	70
.constant	k203	71
.constant	k204	"LOG"
.constant	k205	"string"
.constant	k206	"char"
.constant	k207	"rep"
.constant	k208	1000000
.constant	k209	24871
.constant	k210	24452
.constant	k211	24041
.constant	k212	23649
.constant	k213	23223
.constant	k214	22815
.constant	k215	22374
.constant	k216	21996
.constant	k217	21569
.constant	k218	21137
.constant	k219	20717
.constant	k220	20305
.constant	k221	"debug"
.constant	k222	"traceback"
.constant	k223	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k224	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k225	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k226	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k227	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k228	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k229	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k230	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k231	16420
.constant	k232	51366
.constant	k233	51247
.constant	k234	51143
.constant	k235	50988
.constant	k236	50884
.constant	k237	50773
.constant	k238	50648
.constant	k239	50510
.constant	k240	50387
.constant	k241	50253
.constant	k242	5000
.constant	k243	"setValues"
.constant	k244	"tostring"
.constant	k245	"match"
.constant	k246	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k247	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k248	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k249	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k250	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k251	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k252	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k253	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k254	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k255	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k256	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k257	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k258	"print"
.constant	k259	73
.constant	k260	74
.constant	k261	75
.constant	k262	76
.constant	k263	77
.constant	k264	78
.constant	k265	79
.constant	k266	80
.constant	k267	81
.constant	k268	82
.constant	k269	83
.constant	k270	84
.constant	k271	86
.constant	k272	88
.constant	k273	89
.constant	k274	90
.constant	k275	92
.constant	k276	93
.constant	k277	94
.constant	k278	95
.constant	k279	96
.constant	k280	97
.constant	k281	98
.constant	k282	101
.constant	k283	102
.constant	k284	103
.constant	k285	104
.constant	k286	105
.constant	k287	106
.constant	k288	107
.constant	k289	109
.constant	k290	110
.constant	k291	111
.constant	k292	112
.constant	k293	113
.constant	k294	114
.constant	k295	115
.constant	k296	116
.constant	k297	117
.constant	k298	118
.constant	k299	119
.constant	k300	120
.constant	k301	121
.constant	k302	123
.constant	k303	124
.constant	k304	125
.constant	k305	126
.constant	k306	127
.constant	k307	128
.constant	k308	129
.constant	k309	130
.constant	k310	131
.constant	k311	132
.constant	k312	133
.constant	k313	134
.constant	k314	"os"
.constant	k315	"exit"
.constant	k316	"gmatch"
.constant	k317	"Pass"
.constant	k318	"PW"
.constant	k319	24868
.constant	k320	24465
.constant	k321	24055
.constant	k322	23644
.constant	k323	23236
.constant	k324	22827
.constant	k325	51360
.constant	k326	51254
.constant	k327	51128
.constant	k328	51020
.constant	k329	50899
.constant	k330	"exi"
.constant	k331	"Home"
.constant	k332	"Exit"
.constant	k333	"isVisible"
.constant	k334	"joker"
.constant	k335	"setVisible"
.constant	k336	-1

.label	l1
loadbool      r0     0     0
test          r0     0
jmp            0  l267
newtable      r0     9     0
gettabup      r1    u0    k0
gettabup      r2    u0    k1
gettable      r2    r2    k1
gettabup      r3    u0    k2
gettable      r3    r3    k3
gettable      r3    r3    k4
gettabup      r4    u0    k1
gettable      r4    r4    k1
gettabup      r5    u0    k1
gettable      r5    r5    k5
gettabup      r6    u0    k1
gettable      r6    r6    k1
gettabup      r7    u0    k1
gettable      r7    r7    k3
gettable      r7    r7    k4
gettabup      r8    u0    k1
gettable      r8    r8    k1
gettabup      r9    u0    k1
gettable      r9    r9    k1
setlist       r0     9     1
newtable      r1     9     0
gettable      r2    r0    k4
gettabup      r3    u0    k1
gettable      r3    r3    k1
gettabup      r4    u0    k1
gettable      r4    r4    k6
gettabup      r5    u0    k1
gettable      r5    r5    k1
gettabup      r6    u0    k1
gettable      r6    r6    k3
gettable      r6    r6    k4
gettabup      r7    u0    k1
gettable      r7    r7    k1
gettabup      r8    u0    k1
gettable      r8    r8    k1
gettable      r8    r8    k4
gettabup      r9    u0    k1
gettable      r9    r9    k7
gettabup     r10    u0    k1
gettable     r10   r10    k1
setlist       r1     9     1
newtable      r2     9     0
gettable      r3    r0    k4
gettable      r4    r1    k1
gettable      r5    r1    k5
gettable      r6    r1    k1
gettable      r7    r1    k3
gettable      r7    r7    k4
gettable      r8    r1    k1
gettable      r9    r1    k3
gettable      r9    r9    k4
gettable     r10    r1    k1
gettable     r11    r1    k8
setlist       r2     9     1
newtable      r3     9     0
gettabup      r4    u0    k0
gettable      r5    r2    k1
gettable      r6    r2    k3
gettable      r6    r6    k4
gettable      r7    r2    k9
gettable      r8    r2    k5
gettable      r9    r2    k1
gettable     r10    r2    k3
gettable     r10   r10    k4
gettable     r11    r2    k1
gettable     r12    r2    k1
setlist       r3     9     1
newtable      r4     9     0
gettable      r5    r3    k4
gettable      r6    r2    k1
gettabup      r7    u0   k10
gettable      r7    r7   k11
gettable      r8    r2    k1
gettable      r9    r2    k3
gettable      r9    r9    k4
gettable     r10    r2    k1
gettable     r11    r2    k1
gettable     r11   r11    k4
gettable     r12    r2    k7
gettable     r13    r2    k1
setlist       r4     9     1
newtable      r5     9     0
gettable      r6    r3    k4
gettable      r7    r4    k1
gettable      r8    r4    k5
gettable      r9    r4    k1
gettable     r10    r4   k12
gettable     r10   r10    k4
gettable     r11    r4    k1
gettable     r12    r4    k3
gettable     r12   r12    k4
gettable     r13    r4    k1
gettable     r14    r4    k8
setlist       r5     9     1
gettable      r6    r3    k4
test          r6     0
jmp            0    l1
gettable      r6    r3    k4
gettable      r6    r6    k4
test          r6     0
jmp            0    l1
gettable      r6    r3    k4
gettable      r6    r6    k4
gettable      r6    r6    k4
test          r6     0
jmp            0    l1
gettable      r6    r3    k4
gettable      r6    r6    k4
gettable      r6    r6    k4
gettable      r6    r6    k4
test          r6     0
jmp            0    l1
gettable      r6    r5    k1
test          r6     0
jmp            0    l1
gettable      r6    r5    k1
gettable      r6    r6    k1
test          r6     0
jmp            0    l1
gettable      r6    r5    k1
gettable      r6    r6    k1
gettable      r6    r6    k1
test          r6     0
jmp            0    l1
gettable      r6    r5    k1
test          r6     0
jmp            0    l1
gettable      r6    r5    k1
gettable      r6    r6    k1
test          r6     0
jmp            0    l1
gettable      r6    r5    k1
gettable      r6    r6    k1
gettable      r6    r6    k1
test          r6     0
jmp            0    l1
gettable      r6    r3    k4
move          r7    r3
call          r6     2     2
settable      r3    k4    r6
gettable      r6    r3    k4
gettable      r7    r3    k4
gettable      r7    r7    k4
gettable      r8    r3    k4
move          r9    r3
call          r8     2     0
call          r7     0     0
call          r6     0     2
settable      r3    k4    r6
gettable      r6    r5    k1
move          r7    r5
call          r6     2     2
settable      r5    k1    r6
gettable      r6    r5    k1
gettable      r7    r5    k1
gettable      r7    r7    k1
gettable      r8    r5    k1
gettable      r8    r8    k1
gettable      r8    r8    k1
gettable      r9    r5    k1
gettable      r9    r9    k1
gettable     r10    r5    k1
gettable     r11    r5    k1
call         r10     2     0
call          r9     0     0
call          r8     0     0
call          r7     0     0
call          r6     0     2
settable      r5    k1    r6
gettable      r6    r5    k1
gettable      r7    r5    k1
gettable      r7    r7    k1
gettable      r8    r5    k1
gettable      r8    r8    k1
gettable      r8    r8    k1
gettable      r9    r5    k1
gettable      r9    r9    k1
gettable     r10    r5    k1
gettable     r11    r5    k1
call         r10     2     0
call          r9     0     0
call          r8     0     0
call          r7     0     0
call          r6     0     2
settable      r5    k1    r6
gettable      r6    r3    k4
move          r7    r3
call          r6     2     2
settable      r3    k4    r6
gettable      r6    r3    k4
gettable      r7    r3    k4
gettable      r7    r7    k4
gettable      r8    r3    k4
move          r9    r3
call          r8     2     0
call          r7     0     0
call          r6     0     2
settable      r3    k4    r6
gettable      r6    r5    k1
move          r7    r5
call          r6     2     2
settable      r5    k1    r6
gettable      r6    r5    k1
gettable      r7    r5    k1
gettable      r7    r7    k1
gettable      r8    r5    k1
gettable      r8    r8    k1
gettable      r8    r8    k1
gettable      r9    r5    k1
gettable      r9    r9    k1
gettable     r10    r5    k1
gettable     r11    r5    k1
call         r10     2     0
call          r9     0     0
call          r8     0     0
call          r7     0     0
call          r6     0     2
settable      r5    k1    r6
gettable      r6    r5    k1
gettable      r7    r5    k1
gettable      r7    r7    k1
gettable      r8    r5    k1
gettable      r8    r8    k1
gettable      r8    r8    k1
gettable      r9    r5    k1
gettable      r9    r9    k1
gettable     r10    r5    k1
gettable     r11    r5    k1
call         r10     2     0
call          r9     0     0
call          r8     0     0
call          r7     0     0
call          r6     0     2
settable      r5    k1    r6
newtable      r6     5     0
gettable      r7    r3    k4
gettable      r8    r5    k1
gettable      r9    r5    k3
gettable      r9    r9    k4
gettable     r10    r5    k1
gettable     r11    r5    k1
setlist       r6     5     1
gettable      r7    r6   k13
gettable      r8    r6   k14
gettable      r9    r6   k15
concat        r7    r7    r9
settable      r6    k9    r7
gettable      r7    r6    k9
gettable      r8    r6    k9
gettable      r9    r6    k9
gettable     r10    r6    k9
gettable     r11    r6    k9
gettable     r12    r6    k9
gettable     r13    r6    k9
call         r12     2     0
call         r11     0     0
call         r10     0     0
call          r9     0     0
call          r8     0     0
call          r7     0     2
settable      r6   k16    r7
jmp            0    l1
.label	l267
loadbool      r0     0     0
test          r0     0
jmp            0  l295
newtable      r0     1     0
mod           r1   k17   k17
setlist       r0     1     1
settabup      u0   k16    r0
gettabup      r0    u0   k18
gettabup      r1    u0   k16
call          r0     2     4
jmp            0  l292
.label	l278
newtable      r4     2     0
newtable      r5     1     0
mod           r6   k17   k17
setlist       r5     1     1
newtable      r6     1     0
mod           r7   k17   k17
setlist       r6     1     1
setlist       r4     2     1
move          r3    r4
newtable      r4     1     0
mod           r5   k17   k17
setlist       r4     1     1
gettabup      r4    u0    r4
settable      r3   k16    r4
.label	l292
tforcall      r0     1
tforloop      r2  l278
jmp            0  l267
.label	l295
loadk         r0   k19
gettabup      r1    u0   k20
loadk         r2   k21
loadk         r3   k22
loadk         r4   k23
loadk         r5   k24
loadk         r6   k25
loadk         r7   k26
loadk         r8   k27
loadk         r9   k28
loadk        r10   k27
loadk        r11   k29
loadk        r12   k30
loadk        r13   k31
loadk        r14   k32
loadk        r15   k33
loadk        r16   k34
loadk        r17   k35
loadk        r18   k36
loadk        r19   k37
loadk        r20   k38
newtable     r21     5     0
mul          r22    r4   r12
add          r22    r0   r22
sub          r22   r22   r16
move         r23    r4
mul          r24   r12   k14
add          r25   r16   r12
move         r26   r18
setlist      r21     5     1
gettable     r22   r21   k39
gettable     r23   r21   k14
add          r22   r22   r23
gettable     r23   r21   k13
gettable     r24   r21   k40
mul          r23   r23   r24
add          r22   r22   r23
gettable     r23   r21   k13
sub          r22   r22   r23
gettable     r23   r21   k14
gettable     r24   r21   k15
mul          r24   r24   k13
add          r23   r23   r24
gettable     r24   r21   k40
sub          r23   r23   r24
gettable     r24   r21   k15
gettable     r25   r21   k13
gettable     r26   r21   k14
mul          r25   r25   r26
add          r24   r24   r25
gettable     r25   r21   k40
add          r24   r24   r25
gettable     r25   r21   k13
gettable     r26   r21   k14
gettable     r27   r21   k39
mul          r26   r26   r27
gettable     r27   r21   k39
mul          r26   r26   r27
add          r25   r25   r26
gettable     r26   r21   k13
add          r25   r25   r26
gettable     r26   r21   k13
gettable     r27   r21   k39
add          r26   r26   r27
gettable     r27   r21   k15
sub          r26   r26   r27
gettable     r27   r21   k40
add          r26   r26   r27
gettable     r27   r21   k39
gettable     r28   r21   k14
add          r27   r27   r28
gettable     r28   r21   k13
gettable     r29   r21   k40
mul          r28   r28   r29
add          r27   r27   r28
gettable     r28   r21   k13
sub          r27   r27   r28
gettable     r28   r21   k14
gettable     r29   r21   k15
mul          r29   r29   k13
add          r28   r28   r29
gettable     r29   r21   k40
sub          r28   r28   r29
gettable     r29   r21   k39
gettable     r30   r21   k13
gettable     r31   r21   k14
mul          r30   r30   r31
add          r29   r29   r30
gettable     r30   r21   k15
add          r29   r29   r30
gettable     r30   r21   k15
gettable     r31   r21   k40
add          r30   r30   r31
gettable     r31   r21   k13
gettable     r32   r21   k14
mul          r31   r31   r32
sub          r30   r30   r31
gettable     r31   r21   k39
add          r30   r30   r31
gettable     r31   r21   k39
gettable     r32   r21   k13
add          r31   r31   r32
gettable     r32   r21   k14
sub          r31   r31   r32
gettable     r32   r21   k15
add          r31   r31   r32
newtable     r32    19     0
move         r33   r22
move         r34   r23
move         r35   r24
move         r36   r25
move         r37   r26
move         r38   r27
move         r39   r28
move         r40   r29
move         r41   r30
move         r42   r31
move         r43   r30
move         r44   r28
move         r45   r26
move         r46   r25
move         r47   r24
move         r48   r31
move         r49   r26
move         r50   r25
move         r51   r23
move         r52   r24
move         r53   r22
move         r54   r30
setlist      r32    22     1
settabup      u0   k41   r32
.label	l426
loadbool     r32     0     0
test         r32     0
jmp            0  l454
newtable     r32     1     0
mod          r33   k17   k17
setlist      r32     1     1
settabup      u0   k16   r32
gettabup     r32    u0   k18
gettabup     r33    u0   k16
call         r32     2     4
jmp            0  l451
.label	l437
newtable     r36     2     0
newtable     r37     1     0
mod          r38   k17   k17
setlist      r37     1     1
newtable     r38     1     0
mod          r39   k17   k17
setlist      r38     1     1
setlist      r36     2     1
move         r35   r36
newtable     r36     1     0
mod          r37   k17   k17
setlist      r36     1     1
gettabup     r36    u0   r36
settable     r35   k16   r36
.label	l451
tforcall     r32     1
tforloop     r34  l437
jmp            0  l426
.label	l454
closure      r32    f0
settabup      u0   k42   r32
gettabup     r32    u0   k42
gettabup     r33    u0   k41
call         r32     2     1
closure      r32    f1
settabup      u0   k43   r32
.label	l461
loadbool     r32     0     0
test         r32     0
jmp            0  l489
newtable     r32     1     0
mod          r33   k17   k17
setlist      r32     1     1
settabup      u0   k16   r32
gettabup     r32    u0   k18
gettabup     r33    u0   k16
call         r32     2     4
jmp            0  l486
.label	l472
newtable     r36     2     0
newtable     r37     1     0
mod          r38   k17   k17
setlist      r37     1     1
newtable     r38     1     0
mod          r39   k17   k17
setlist      r38     1     1
setlist      r36     2     1
move         r35   r36
newtable     r36     1     0
mod          r37   k17   k17
setlist      r36     1     1
gettabup     r36    u0   r36
settable     r35   k16   r36
.label	l486
tforcall     r32     1
tforloop     r34  l472
jmp            0  l461
.label	l489
loadk        r32   k44
gettabup     r33    u0   k45
loadk        r34   k21
loadk        r35   k22
loadk        r36   k46
loadk        r37   k24
loadk        r38   k25
loadk        r39   k26
loadk        r40   k27
loadk        r41   k28
loadk        r42   k27
loadk        r43   k29
loadk        r44   k47
loadk        r45   k31
loadk        r46   k32
loadk        r47   k33
loadk        r48   k48
loadk        r49   k35
loadk        r50   k49
loadk        r51   k37
loadk        r52   k50
newtable     r53     5     0
mul          r54   r36   r44
add          r54   r32   r54
sub          r54   r54   r48
move         r55   r36
mul          r56   r44   k14
add          r57   r48   r44
move         r58   r50
setlist      r53     5     1
gettable     r54   r53   k39
gettable     r55   r53   k14
add          r54   r54   r55
gettable     r55   r53   k13
gettable     r56   r53   k40
mul          r55   r55   r56
add          r54   r54   r55
gettable     r55   r53   k13
sub          r54   r54   r55
gettable     r55   r53   k14
gettable     r56   r53   k15
mul          r56   r56   k13
add          r55   r55   r56
gettable     r56   r53   k40
sub          r55   r55   r56
gettable     r56   r53   k15
gettable     r57   r53   k13
gettable     r58   r53   k14
mul          r57   r57   r58
add          r56   r56   r57
gettable     r57   r53   k40
add          r56   r56   r57
gettable     r57   r53   k13
gettable     r58   r53   k14
gettable     r59   r53   k39
mul          r58   r58   r59
gettable     r59   r53   k39
mul          r58   r58   r59
add          r57   r57   r58
gettable     r58   r53   k13
add          r57   r57   r58
gettable     r58   r53   k13
gettable     r59   r53   k39
add          r58   r58   r59
gettable     r59   r53   k15
sub          r58   r58   r59
gettable     r59   r53   k40
add          r58   r58   r59
gettable     r59   r53   k39
gettable     r60   r53   k14
add          r59   r59   r60
gettable     r60   r53   k13
gettable     r61   r53   k40
mul          r60   r60   r61
add          r59   r59   r60
gettable     r60   r53   k13
sub          r59   r59   r60
gettable     r60   r53   k14
gettable     r61   r53   k15
mul          r61   r61   k13
add          r60   r60   r61
gettable     r61   r53   k40
sub          r60   r60   r61
gettable     r61   r53   k39
gettable     r62   r53   k13
gettable     r63   r53   k14
mul          r62   r62   r63
add          r61   r61   r62
gettable     r62   r53   k15
add          r61   r61   r62
gettable     r62   r53   k15
gettable     r63   r53   k40
add          r62   r62   r63
gettable     r63   r53   k13
gettable     r64   r53   k14
mul          r63   r63   r64
sub          r62   r62   r63
gettable     r63   r53   k39
add          r62   r62   r63
gettable     r63   r53   k39
gettable     r64   r53   k13
add          r63   r63   r64
gettable     r64   r53   k14
sub          r63   r63   r64
gettable     r64   r53   k15
add          r63   r63   r64
newtable     r64    19     0
move         r65   r54
move         r66   r55
move         r67   r56
move         r68   r57
move         r69   r58
move         r70   r59
move         r71   r60
move         r72   r61
move         r73   r62
move         r74   r63
move         r75   r62
move         r76   r60
move         r77   r58
move         r78   r57
move         r79   r56
move         r80   r63
move         r81   r58
move         r82   r57
move         r83   r55
move         r84   r56
move         r85   r54
move         r86   r62
setlist      r64    22     1
settabup      u0   k51   r64
.label	l620
loadbool     r64     0     0
test         r64     0
jmp            0  l648
newtable     r64     1     0
mod          r65   k17   k17
setlist      r64     1     1
settabup      u0   k16   r64
gettabup     r64    u0   k18
gettabup     r65    u0   k16
call         r64     2     4
jmp            0  l645
.label	l631
newtable     r68     2     0
newtable     r69     1     0
mod          r70   k17   k17
setlist      r69     1     1
newtable     r70     1     0
mod          r71   k17   k17
setlist      r70     1     1
setlist      r68     2     1
move         r67   r68
newtable     r68     1     0
mod          r69   k17   k17
setlist      r68     1     1
gettabup     r68    u0   r68
settable     r67   k16   r68
.label	l645
tforcall     r64     1
tforloop     r66  l631
jmp            0  l620
.label	l648
closure      r64    f2
settabup      u0   k52   r64
gettabup     r64    u0   k52
gettabup     r65    u0   k51
call         r64     2     1
closure      r64    f3
settabup      u0   k53   r64
.label	l655
loadbool     r64     0     0
test         r64     0
jmp            0  l683
newtable     r64     1     0
mod          r65   k17   k17
setlist      r64     1     1
settabup      u0   k16   r64
gettabup     r64    u0   k18
gettabup     r65    u0   k16
call         r64     2     4
jmp            0  l680
.label	l666
newtable     r68     2     0
newtable     r69     1     0
mod          r70   k17   k17
setlist      r69     1     1
newtable     r70     1     0
mod          r71   k17   k17
setlist      r70     1     1
setlist      r68     2     1
move         r67   r68
newtable     r68     1     0
mod          r69   k17   k17
setlist      r68     1     1
gettabup     r68    u0   r68
settable     r67   k16   r68
.label	l680
tforcall     r64     1
tforloop     r66  l666
jmp            0  l655
.label	l683
loadk        r64   k54
gettabup     r65    u0   k55
loadk        r66   k21
loadk        r67   k22
loadk        r68   k56
loadk        r69   k24
loadk        r70   k25
loadk        r71   k26
loadk        r72   k27
loadk        r73   k28
loadk        r74   k27
loadk        r75   k29
loadk        r76   k57
loadk        r77   k31
loadk        r78   k32
loadk        r79   k33
loadk        r80   k58
loadk        r81   k35
loadk        r82   k59
loadk        r83   k37
loadk        r84   k60
newtable     r85     5     0
mul          r86   r68   r76
add          r86   r64   r86
sub          r86   r86   r80
move         r87   r68
mul          r88   r76   k14
add          r89   r80   r76
move         r90   r82
setlist      r85     5     1
gettable     r86   r85   k39
gettable     r87   r85   k14
add          r86   r86   r87
gettable     r87   r85   k13
gettable     r88   r85   k40
mul          r87   r87   r88
add          r86   r86   r87
gettable     r87   r85   k13
sub          r86   r86   r87
gettable     r87   r85   k14
gettable     r88   r85   k15
mul          r88   r88   k13
add          r87   r87   r88
gettable     r88   r85   k40
sub          r87   r87   r88
gettable     r88   r85   k15
gettable     r89   r85   k13
gettable     r90   r85   k14
mul          r89   r89   r90
add          r88   r88   r89
gettable     r89   r85   k40
add          r88   r88   r89
gettable     r89   r85   k13
gettable     r90   r85   k14
gettable     r91   r85   k39
mul          r90   r90   r91
gettable     r91   r85   k39
mul          r90   r90   r91
add          r89   r89   r90
gettable     r90   r85   k13
add          r89   r89   r90
gettable     r90   r85   k13
gettable     r91   r85   k39
add          r90   r90   r91
gettable     r91   r85   k15
sub          r90   r90   r91
gettable     r91   r85   k40
add          r90   r90   r91
gettable     r91   r85   k39
gettable     r92   r85   k14
add          r91   r91   r92
gettable     r92   r85   k13
gettable     r93   r85   k40
mul          r92   r92   r93
add          r91   r91   r92
gettable     r92   r85   k13
sub          r91   r91   r92
gettable     r92   r85   k14
gettable     r93   r85   k15
mul          r93   r93   k13
add          r92   r92   r93
gettable     r93   r85   k40
sub          r92   r92   r93
gettable     r93   r85   k39
gettable     r94   r85   k13
gettable     r95   r85   k14
mul          r94   r94   r95
add          r93   r93   r94
gettable     r94   r85   k15
add          r93   r93   r94
gettable     r94   r85   k15
gettable     r95   r85   k40
add          r94   r94   r95
gettable     r95   r85   k13
gettable     r96   r85   k14
mul          r95   r95   r96
sub          r94   r94   r95
gettable     r95   r85   k39
add          r94   r94   r95
gettable     r95   r85   k39
gettable     r96   r85   k13
add          r95   r95   r96
gettable     r96   r85   k14
sub          r95   r95   r96
gettable     r96   r85   k15
add          r95   r95   r96
newtable     r96    19     0
move         r97   r86
move         r98   r87
move         r99   r88
move        r100   r89
move        r101   r90
move        r102   r91
move        r103   r92
move        r104   r93
move        r105   r94
move        r106   r95
move        r107   r94
move        r108   r92
move        r109   r90
move        r110   r89
move        r111   r88
move        r112   r95
move        r113   r90
move        r114   r89
move        r115   r87
move        r116   r88
move        r117   r86
move        r118   r94
setlist      r96    22     1
settabup      u0   k61   r96
.label	l814
loadbool     r96     0     0
test         r96     0
jmp            0  l842
newtable     r96     1     0
mod          r97   k17   k17
setlist      r96     1     1
settabup      u0   k16   r96
gettabup     r96    u0   k18
gettabup     r97    u0   k16
call         r96     2     4
jmp            0  l839
.label	l825
newtable    r100     2     0
newtable    r101     1     0
mod         r102   k17   k17
setlist     r101     1     1
newtable    r102     1     0
mod         r103   k17   k17
setlist     r102     1     1
setlist     r100     2     1
move         r99  r100
newtable    r100     1     0
mod         r101   k17   k17
setlist     r100     1     1
gettabup    r100    u0  r100
settable     r99   k16  r100
.label	l839
tforcall     r96     1
tforloop     r98  l825
jmp            0  l814
.label	l842
closure      r96    f4
settabup      u0   k62   r96
gettabup     r96    u0   k62
gettabup     r97    u0   k61
call         r96     2     1
closure      r96    f5
settabup      u0   k63   r96
.label	l849
loadbool     r96     0     0
test         r96     0
jmp            0  l877
newtable     r96     1     0
mod          r97   k17   k17
setlist      r96     1     1
settabup      u0   k16   r96
gettabup     r96    u0   k18
gettabup     r97    u0   k16
call         r96     2     4
jmp            0  l874
.label	l860
newtable    r100     2     0
newtable    r101     1     0
mod         r102   k17   k17
setlist     r101     1     1
newtable    r102     1     0
mod         r103   k17   k17
setlist     r102     1     1
setlist     r100     2     1
move         r99  r100
newtable    r100     1     0
mod         r101   k17   k17
setlist     r100     1     1
gettabup    r100    u0  r100
settable     r99   k16  r100
.label	l874
tforcall     r96     1
tforloop     r98  l860
jmp            0  l849
.label	l877
loadk        r96   k64
gettabup     r97    u0   k65
loadk        r98   k21
loadk        r99   k22
loadk       r100   k66
loadk       r101   k24
loadk       r102   k25
loadk       r103   k26
loadk       r104   k27
loadk       r105   k28
loadk       r106   k27
loadk       r107   k29
loadk       r108   k67
loadk       r109   k31
loadk       r110   k32
loadk       r111   k33
loadk       r112   k68
loadk       r113   k35
loadk       r114   k69
loadk       r115   k37
loadk       r116   k70
newtable    r117     5     0
mul         r118  r100  r108
add         r118   r96  r118
sub         r118  r118  r112
move        r119  r100
mul         r120  r108   k14
add         r121  r112  r108
move        r122  r114
setlist     r117     5     1
gettable    r118  r117   k39
gettable    r119  r117   k14
add         r118  r118  r119
gettable    r119  r117   k13
gettable    r120  r117   k40
mul         r119  r119  r120
add         r118  r118  r119
gettable    r119  r117   k13
sub         r118  r118  r119
gettable    r119  r117   k14
gettable    r120  r117   k15
mul         r120  r120   k13
add         r119  r119  r120
gettable    r120  r117   k40
sub         r119  r119  r120
gettable    r120  r117   k15
gettable    r121  r117   k13
gettable    r122  r117   k14
mul         r121  r121  r122
add         r120  r120  r121
gettable    r121  r117   k40
add         r120  r120  r121
gettable    r121  r117   k13
gettable    r122  r117   k14
gettable    r123  r117   k39
mul         r122  r122  r123
gettable    r123  r117   k39
mul         r122  r122  r123
add         r121  r121  r122
gettable    r122  r117   k13
add         r121  r121  r122
gettable    r122  r117   k13
gettable    r123  r117   k39
add         r122  r122  r123
gettable    r123  r117   k15
sub         r122  r122  r123
gettable    r123  r117   k40
add         r122  r122  r123
gettable    r123  r117   k39
gettable    r124  r117   k14
add         r123  r123  r124
gettable    r124  r117   k13
gettable    r125  r117   k40
mul         r124  r124  r125
add         r123  r123  r124
gettable    r124  r117   k13
sub         r123  r123  r124
gettable    r124  r117   k14
gettable    r125  r117   k15
mul         r125  r125   k13
add         r124  r124  r125
gettable    r125  r117   k40
sub         r124  r124  r125
gettable    r125  r117   k39
gettable    r126  r117   k13
gettable    r127  r117   k14
mul         r126  r126  r127
add         r125  r125  r126
gettable    r126  r117   k15
add         r125  r125  r126
gettable    r126  r117   k15
gettable    r127  r117   k40
add         r126  r126  r127
gettable    r127  r117   k13
gettable    r128  r117   k14
mul         r127  r127  r128
sub         r126  r126  r127
gettable    r127  r117   k39
add         r126  r126  r127
gettable    r127  r117   k39
gettable    r128  r117   k13
add         r127  r127  r128
gettable    r128  r117   k14
sub         r127  r127  r128
gettable    r128  r117   k15
add         r127  r127  r128
newtable    r128    19     0
move        r129  r118
move        r130  r119
move        r131  r120
move        r132  r121
move        r133  r122
move        r134  r123
move        r135  r124
move        r136  r125
move        r137  r126
move        r138  r127
move        r139  r126
move        r140  r124
move        r141  r122
move        r142  r121
move        r143  r120
move        r144  r127
move        r145  r122
move        r146  r121
move        r147  r119
move        r148  r120
move        r149  r118
move        r150  r126
setlist     r128    22     1
settabup      u0   k71  r128
.label	l1008
loadbool    r128     0     0
test        r128     0
jmp            0 l1036
newtable    r128     1     0
mod         r129   k17   k17
setlist     r128     1     1
settabup      u0   k16  r128
gettabup    r128    u0   k18
gettabup    r129    u0   k16
call        r128     2     4
jmp            0 l1033
.label	l1019
newtable    r132     2     0
newtable    r133     1     0
mod         r134   k17   k17
setlist     r133     1     1
newtable    r134     1     0
mod         r135   k17   k17
setlist     r134     1     1
setlist     r132     2     1
move        r131  r132
newtable    r132     1     0
mod         r133   k17   k17
setlist     r132     1     1
gettabup    r132    u0  r132
settable    r131   k16  r132
.label	l1033
tforcall    r128     1
tforloop    r130 l1019
jmp            0 l1008
.label	l1036
closure     r128    f6
settabup      u0   k72  r128
gettabup    r128    u0   k72
gettabup    r129    u0   k71
call        r128     2     1
closure     r128    f7
settabup      u0   k73  r128
closure     r128    f8
settabup      u0   k74  r128
closure     r128    f9
settabup      u0   k75  r128
closure     r128   f10
settabup      u0   k76  r128
closure     r128   f11
move        r129  r128
call        r129     1     2
move        r128  r129
closure     r129   f12
settabup      u0   k77  r129
.label	l1055
loadbool    r129     0     0
test        r129     0
jmp            0 l1321
newtable    r129     9     0
gettabup    r130    u0    k0
gettabup    r131    u0   k78
gettable    r131  r131   k78
gettabup    r132    u0   k79
gettable    r132  r132   k80
gettable    r132  r132    k4
gettabup    r133    u0   k78
gettable    r133  r133   k78
gettabup    r134    u0   k78
gettable    r134  r134   k81
gettabup    r135    u0   k78
gettable    r135  r135   k78
gettabup    r136    u0   k78
gettable    r136  r136   k80
gettable    r136  r136    k4
gettabup    r137    u0   k78
gettable    r137  r137   k78
gettabup    r138    u0   k78
gettable    r138  r138   k78
setlist     r129     9     1
newtable    r130     9     0
gettable    r131  r129    k4
gettabup    r132    u0   k78
gettable    r132  r132   k78
gettabup    r133    u0   k78
gettable    r133  r133   k82
gettabup    r134    u0   k78
gettable    r134  r134   k78
gettabup    r135    u0   k78
gettable    r135  r135   k80
gettable    r135  r135    k4
gettabup    r136    u0   k78
gettable    r136  r136   k78
gettabup    r137    u0   k78
gettable    r137  r137   k78
gettable    r137  r137    k4
gettabup    r138    u0   k78
gettable    r138  r138   k83
gettabup    r139    u0   k78
gettable    r139  r139   k78
setlist     r130     9     1
newtable    r131     9     0
gettable    r132  r129    k4
gettable    r133  r130   k78
gettable    r134  r130   k81
gettable    r135  r130   k78
gettable    r136  r130   k80
gettable    r136  r136    k4
gettable    r137  r130   k78
gettable    r138  r130   k80
gettable    r138  r138    k4
gettable    r139  r130   k78
gettable    r140  r130   k84
setlist     r131     9     1
newtable    r132     9     0
gettabup    r133    u0    k0
gettable    r134  r131   k78
gettable    r135  r131   k80
gettable    r135  r135    k4
gettable    r136  r131   k85
gettable    r137  r131   k81
gettable    r138  r131   k78
gettable    r139  r131   k80
gettable    r139  r139    k4
gettable    r140  r131   k78
gettable    r141  r131   k78
setlist     r132     9     1
newtable    r133     9     0
gettable    r134  r132    k4
gettable    r135  r131   k78
gettabup    r136    u0   k86
gettable    r136  r136   k87
gettable    r137  r131   k78
gettable    r138  r131   k80
gettable    r138  r138    k4
gettable    r139  r131   k78
gettable    r140  r131   k78
gettable    r140  r140    k4
gettable    r141  r131   k83
gettable    r142  r131   k78
setlist     r133     9     1
newtable    r134     9     0
gettable    r135  r132    k4
gettable    r136  r133   k78
gettable    r137  r133   k81
gettable    r138  r133   k78
gettable    r139  r133   k88
gettable    r139  r139    k4
gettable    r140  r133   k78
gettable    r141  r133   k80
gettable    r141  r141    k4
gettable    r142  r133   k78
gettable    r143  r133   k84
setlist     r134     9     1
gettable    r135  r132    k4
test        r135     0
jmp            0 l1055
gettable    r135  r132    k4
gettable    r135  r135    k4
test        r135     0
jmp            0 l1055
gettable    r135  r132    k4
gettable    r135  r135    k4
gettable    r135  r135    k4
test        r135     0
jmp            0 l1055
gettable    r135  r132    k4
gettable    r135  r135    k4
gettable    r135  r135    k4
gettable    r135  r135    k4
test        r135     0
jmp            0 l1055
gettable    r135  r134   k78
test        r135     0
jmp            0 l1055
gettable    r135  r134   k78
gettable    r135  r135   k78
test        r135     0
jmp            0 l1055
gettable    r135  r134   k78
gettable    r135  r135   k78
gettable    r135  r135   k78
test        r135     0
jmp            0 l1055
gettable    r135  r134   k78
test        r135     0
jmp            0 l1055
gettable    r135  r134   k78
gettable    r135  r135   k78
test        r135     0
jmp            0 l1055
gettable    r135  r134   k78
gettable    r135  r135   k78
gettable    r135  r135   k78
test        r135     0
jmp            0 l1055
gettable    r135  r132    k4
move        r136  r132
call        r135     2     2
settable    r132    k4  r135
gettable    r135  r132    k4
gettable    r136  r132    k4
gettable    r136  r136    k4
gettable    r137  r132    k4
move        r138  r132
call        r137     2     0
call        r136     0     0
call        r135     0     2
settable    r132    k4  r135
gettable    r135  r134   k78
move        r136  r134
call        r135     2     2
settable    r134   k78  r135
gettable    r135  r134   k78
gettable    r136  r134   k78
gettable    r136  r136   k78
gettable    r137  r134   k78
gettable    r137  r137   k78
gettable    r137  r137   k78
gettable    r138  r134   k78
gettable    r138  r138   k78
gettable    r139  r134   k78
gettable    r140  r134   k78
call        r139     2     0
call        r138     0     0
call        r137     0     0
call        r136     0     0
call        r135     0     2
settable    r134   k78  r135
gettable    r135  r134   k78
gettable    r136  r134   k78
gettable    r136  r136   k78
gettable    r137  r134   k78
gettable    r137  r137   k78
gettable    r137  r137   k78
gettable    r138  r134   k78
gettable    r138  r138   k78
gettable    r139  r134   k78
gettable    r140  r134   k78
call        r139     2     0
call        r138     0     0
call        r137     0     0
call        r136     0     0
call        r135     0     2
settable    r134   k78  r135
gettable    r135  r132    k4
move        r136  r132
call        r135     2     2
settable    r132    k4  r135
gettable    r135  r132    k4
gettable    r136  r132    k4
gettable    r136  r136    k4
gettable    r137  r132    k4
move        r138  r132
call        r137     2     0
call        r136     0     0
call        r135     0     2
settable    r132    k4  r135
gettable    r135  r134   k78
move        r136  r134
call        r135     2     2
settable    r134   k78  r135
gettable    r135  r134   k78
gettable    r136  r134   k78
gettable    r136  r136   k78
gettable    r137  r134   k78
gettable    r137  r137   k78
gettable    r137  r137   k78
gettable    r138  r134   k78
gettable    r138  r138   k78
gettable    r139  r134   k78
gettable    r140  r134   k78
call        r139     2     0
call        r138     0     0
call        r137     0     0
call        r136     0     0
call        r135     0     2
settable    r134   k78  r135
gettable    r135  r134   k78
gettable    r136  r134   k78
gettable    r136  r136   k78
gettable    r137  r134   k78
gettable    r137  r137   k78
gettable    r137  r137   k78
gettable    r138  r134   k78
gettable    r138  r138   k78
gettable    r139  r134   k78
gettable    r140  r134   k78
call        r139     2     0
call        r138     0     0
call        r137     0     0
call        r136     0     0
call        r135     0     2
settable    r134   k78  r135
newtable    r135     5     0
gettable    r136  r132    k4
gettable    r137  r134   k78
gettable    r138  r134   k80
gettable    r138  r138    k4
gettable    r139  r134   k78
gettable    r140  r134   k78
setlist     r135     5     1
gettable    r136  r135   k13
gettable    r137  r135   k14
gettable    r138  r135   k15
concat      r136  r136  r138
settable    r135   k85  r136
gettable    r136  r135   k85
gettable    r137  r135   k85
gettable    r138  r135   k85
gettable    r139  r135   k85
gettable    r140  r135   k85
gettable    r141  r135   k85
gettable    r142  r135   k85
call        r141     2     0
call        r140     0     0
call        r139     0     0
call        r138     0     0
call        r137     0     0
call        r136     0     2
settable    r135   k16  r136
jmp            0 l1055
.label	l1321
gettabup    r129    u0   k89
gettabup    r130    u0   k90
gettable    r130  r130   k91
call        r130     1     0
call        r129     0     2
test        r129     1
jmp            0 l1363
gettabup    r129    u0   k92
gettable    r129  r129   k93
gettabup    r130    u0   k90
gettable    r130  r130   k91
call        r130     1     0
call        r129     0     1
gettabup    r129    u0   k92
gettable    r129  r129   k94
gettabup    r130    u0   k92
gettable    r130  r130   k95
gettabup    r131    u0   k77
newtable    r132     0     1
newtable    r133     0     2
newtable    r134     1     0
loadk       r135   k96
setlist     r134     1     1
settable    r133   k13  r134
newtable    r134     1     0
loadk       r135   k97
setlist     r134     1     1
settable    r133   k14  r134
settable    r132    k0  r133
call        r131     2     0
call        r130     0     2
gettabup    r131    u0   k77
newtable    r132     0     1
newtable    r133     0     1
newtable    r134     1     0
loadk       r135   k98
setlist     r134     1     1
settable    r133   k13  r134
settable    r132    k0  r133
call        r131     2     0
call        r129     0     1
return        r0     1
.label	l1363
loadbool    r129     0     0
test        r129     0
jmp            0 l1462
gettabup    r129    u0   k16
gettabup    r130    u0   k16
loadk       r131   k13
forprep     r129 l1459
.label	l1370
newtable    r133     0     0
gettable    r134  r133   k16
test        r134     0
jmp            0 l1378
gettable    r134  r133   k16
move        r135  r133
call        r134     2     2
settable    r133   k16  r134
.label	l1378
gettable    r134  r133   k16
gettable    r135  r133   k16
gettable    r136  r133   k16
forprep     r134 l1445
.label	l1382
newtable    r138     0     0
gettable    r139  r138   k16
test        r139     0
jmp            0 l1389
gettable    r139  r138   k16
call        r139     1     2
settable    r138   k16  r139
.label	l1389
move        r139  r133
gettable    r140  r138   k16
move        r141  r133
forprep     r139 l1434
.label	l1393
newtable    r143     0     0
gettable    r144  r143   k16
test        r144     0
jmp            0 l1401
gettable    r144  r143   k16
move        r145  r133
call        r144     2     2
settable    r143   k16  r144
.label	l1401
move        r144  r133
move        r145  r138
gettable    r146  r143   k16
forprep     r144 l1423
.label	l1405
newtable    r148     0     0
gettable    r149  r148   k16
test        r149     0
jmp            0 l1413
gettable    r149  r148   k16
move        r150  r133
call        r149     2     2
settable    r148   k16  r149
.label	l1413
newtable    r149     0     0
gettable    r150  r149   k16
test        r150     0
jmp            0 l1423
bor         r150  r149  r143
bor         r150  r150  r138
bor         r150  r150  r133
move        r151  r133
call        r150     2     2
settable    r149   k16  r150
.label	l1423
forloop     r144 l1405
newtable    r144     0     0
gettable    r145  r144   k16
test        r145     0
jmp            0 l1434
bor         r145   k99  r144
bor         r145  r145  r138
bor         r145  r145  r133
move        r146  r133
call        r145     2     2
settable    r144   k16  r145
.label	l1434
forloop     r139 l1393
newtable    r139     0     0
gettable    r140  r139   k16
test        r140     0
jmp            0 l1445
bor         r140   k99  k100
bor         r140  r140  r139
bor         r140  r140  r133
move        r141  r133
call        r140     2     2
settable    r139   k16  r140
.label	l1445
forloop     r134 l1382
newtable    r134     0     0
gettable    r135  r134   k16
test        r135     0
jmp            0 l1456
bor         r135   k99  k100
bor         r135  r135   k17
bor         r135  r135  r134
move        r136  r134
call        r135     2     2
settable    r134   k16  r135
.label	l1456
bor         r135   k99  k100
bor         r135  r135   k17
return      r135     2
.label	l1459
forloop     r129 l1370
return        r0     1
jmp            0 l1363
.label	l1462
loadk       r129   k13
loadk       r130  k101
loadk       r131   k13
forprep     r129 l1477
.label	l1466
newtable    r133     0     0
gettable    r134  r133  k103
call        r134     1     2
settable    r133  k102  r134
gettable    r134  r133  k103
eq             1  r134   k17
jmp            0 l1476
gettable    r134  r133  k103
call        r134     1     2
settable    r133  k102  r134
.label	l1476
loadnil     r133     0
.label	l1477
forloop     r129 l1466
closure     r129   f13
settabup      u0  k104  r129
closure     r129   f14
settabup      u0  k105  r129
closure     r129   f15
settabup      u0  k105  r129
closure     r129   f16
settabup      u0  k106  r129
closure     r129   f17
settabup      u0  k107  r129
closure     r129   f18
settabup      u0  k108  r129
closure     r129   f19
settabup      u0  k109  r129
closure     r129   f20
settabup      u0  k110  r129
closure     r129   f21
settabup      u0  k111  r129
closure     r129   f22
settabup      u0  k112  r129
closure     r129   f23
settabup      u0  k113  r129
closure     r129   f24
settabup      u0  k114  r129
closure     r129   f25
settabup      u0  k115  r129
closure     r129   f26
settabup      u0  k116  r129
closure     r129   f27
settabup      u0  k117  r129
closure     r129   f28
settabup      u0  k118  r129
closure     r129   f29
settabup      u0  k119  r129
closure     r129   f30
settabup      u0  k120  r129
closure     r129   f31
settabup      u0  k121  r129
closure     r129   f32
settabup      u0  k122  r129
loadk       r129  k123
loadk       r130  k124
loadnil     r131     0
closure     r132   f33
settabup      u0  k104  r132
closure     r132   f34
settabup      u0  k105  r132
closure     r132   f35
settabup      u0  k105  r132
closure     r132   f36
settabup      u0  k106  r132
closure     r132   f37
settabup      u0  k107  r132
closure     r132   f38
settabup      u0  k108  r132
closure     r132   f39
settabup      u0  k109  r132
closure     r132   f40
settabup      u0  k110  r132
closure     r132   f41
settabup      u0  k111  r132
closure     r132   f42
settabup      u0  k112  r132
closure     r132   f43
settabup      u0  k113  r132
closure     r132   f44
settabup      u0  k114  r132
closure     r132   f45
settabup      u0  k115  r132
closure     r132   f46
settabup      u0  k116  r132
closure     r132   f47
settabup      u0  k117  r132
closure     r132   f48
settabup      u0  k118  r132
closure     r132   f49
settabup      u0  k119  r132
closure     r132   f50
settabup      u0  k120  r132
closure     r132   f51
settabup      u0  k121  r132
closure     r132   f52
settabup      u0  k122  r132
loadk       r132   k13
loadk       r133  k101
loadk       r134   k13
forprep     r132 l1576
.label	l1565
newtable    r136     0     0
gettable    r137  r136  k103
call        r137     1     2
settable    r136  k102  r137
gettable    r137  r136  k103
eq             1  r137   k17
jmp            0 l1575
gettable    r137  r136  k103
call        r137     1     2
settable    r136  k102  r137
.label	l1575
loadnil     r136     0
.label	l1576
forloop     r132 l1565
.label	l1577
loadbool    r132     0     0
test        r132     0
jmp            0 l1676
gettabup    r132    u0   k16
gettabup    r133    u0   k16
loadk       r134   k13
forprep     r132 l1673
.label	l1584
newtable    r136     0     0
gettable    r137  r136   k16
test        r137     0
jmp            0 l1592
gettable    r137  r136   k16
move        r138  r136
call        r137     2     2
settable    r136   k16  r137
.label	l1592
gettable    r137  r136   k16
gettable    r138  r136   k16
gettable    r139  r136   k16
forprep     r137 l1659
.label	l1596
newtable    r141     0     0
gettable    r142  r141   k16
test        r142     0
jmp            0 l1603
gettable    r142  r141   k16
call        r142     1     2
settable    r141   k16  r142
.label	l1603
move        r142  r136
gettable    r143  r141   k16
move        r144  r136
forprep     r142 l1648
.label	l1607
newtable    r146     0     0
gettable    r147  r146   k16
test        r147     0
jmp            0 l1615
gettable    r147  r146   k16
move        r148  r136
call        r147     2     2
settable    r146   k16  r147
.label	l1615
move        r147  r136
move        r148  r141
gettable    r149  r146   k16
forprep     r147 l1637
.label	l1619
newtable    r151     0     0
gettable    r152  r151   k16
test        r152     0
jmp            0 l1627
gettable    r152  r151   k16
move        r153  r136
call        r152     2     2
settable    r151   k16  r152
.label	l1627
newtable    r152     0     0
gettable    r153  r152   k16
test        r153     0
jmp            0 l1637
bor         r153  r152  r146
bor         r153  r153  r141
bor         r153  r153  r136
move        r154  r136
call        r153     2     2
settable    r152   k16  r153
.label	l1637
forloop     r147 l1619
newtable    r147     0     0
gettable    r148  r147   k16
test        r148     0
jmp            0 l1648
bor         r148   k99  r147
bor         r148  r148  r141
bor         r148  r148  r136
move        r149  r136
call        r148     2     2
settable    r147   k16  r148
.label	l1648
forloop     r142 l1607
newtable    r142     0     0
gettable    r143  r142   k16
test        r143     0
jmp            0 l1659
bor         r143   k99  k100
bor         r143  r143  r142
bor         r143  r143  r136
move        r144  r136
call        r143     2     2
settable    r142   k16  r143
.label	l1659
forloop     r137 l1596
newtable    r137     0     0
gettable    r138  r137   k16
test        r138     0
jmp            0 l1670
bor         r138   k99  k100
bor         r138  r138   k17
bor         r138  r138  r137
move        r139  r137
call        r138     2     2
settable    r137   k16  r138
.label	l1670
bor         r138   k99  k100
bor         r138  r138   k17
return      r138     2
.label	l1673
forloop     r132 l1584
return        r0     1
jmp            0 l1577
.label	l1676
closure     r132   f53
gettabup    r133    u0   k90
gettabup    r134    u0   k63
newtable    r135     0     1
newtable    r136     0     5
settable    r136   k13  k125
settable    r136   k14  k126
settable    r136   k15  k127
settable    r136   k40  k128
settable    r136   k39  k129
settable    r135    k0  r136
call        r134     2     2
gettable    r133  r133  r134
move        r134  r132
gettabup    r135    u0   k77
newtable    r136     0     1
newtable    r137     0    33
newtable    r138     1     0
loadk       r139  k130
setlist     r138     1     1
settable    r137   k13  r138
newtable    r138     1     0
loadk       r139  k131
setlist     r138     1     1
settable    r137   k14  r138
newtable    r138     1     0
loadk       r139  k132
setlist     r138     1     1
settable    r137   k15  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137   k40  r138
newtable    r138     1     0
loadk       r139  k134
setlist     r138     1     1
settable    r137   k39  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137  k135  r138
newtable    r138     1     0
loadk       r139  k137
setlist     r138     1     1
settable    r137  k136  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137  k138  r138
newtable    r138     1     0
loadk       r139  k134
setlist     r138     1     1
settable    r137  k139  r138
newtable    r138     1     0
loadk       r139  k137
setlist     r138     1     1
settable    r137  k140  r138
newtable    r138     1     0
loadk       r139   k97
setlist     r138     1     1
settable    r137  k141  r138
newtable    r138     1     0
loadk       r139  k142
setlist     r138     1     1
settable    r137  k123  r138
newtable    r138     1     0
loadk       r139  k144
setlist     r138     1     1
settable    r137  k143  r138
newtable    r138     1     0
loadk       r139  k146
setlist     r138     1     1
settable    r137  k145  r138
newtable    r138     1     0
loadk       r139  k130
setlist     r138     1     1
settable    r137  k147  r138
newtable    r138     1     0
loadk       r139  k149
setlist     r138     1     1
settable    r137  k148  r138
newtable    r138     1     0
loadk       r139  k146
setlist     r138     1     1
settable    r137  k150  r138
newtable    r138     1     0
loadk       r139  k152
setlist     r138     1     1
settable    r137  k151  r138
newtable    r138     1     0
loadk       r139  k137
setlist     r138     1     1
settable    r137  k153  r138
newtable    r138     1     0
loadk       r139  k142
setlist     r138     1     1
settable    r137  k154  r138
newtable    r138     1     0
loadk       r139  k142
setlist     r138     1     1
settable    r137  k155  r138
newtable    r138     1     0
loadk       r139  k156
setlist     r138     1     1
settable    r137   k59  r138
newtable    r138     1     0
loadk       r139  k132
setlist     r138     1     1
settable    r137  k157  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137  k158  r138
newtable    r138     1     0
loadk       r139  k131
setlist     r138     1     1
settable    r137  k159  r138
newtable    r138     1     0
loadk       r139  k142
setlist     r138     1     1
settable    r137   k57  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137  k160  r138
newtable    r138     1     0
loadk       r139  k137
setlist     r138     1     1
settable    r137  k161  r138
newtable    r138     1     0
loadk       r139  k146
setlist     r138     1     1
settable    r137  k162  r138
newtable    r138     1     0
loadk       r139  k146
setlist     r138     1     1
settable    r137  k163  r138
newtable    r138     1     0
loadk       r139  k165
setlist     r138     1     1
settable    r137  k164  r138
newtable    r138     1     0
loadk       r139  k142
setlist     r138     1     1
settable    r137  k166  r138
newtable    r138     1     0
loadk       r139  k146
setlist     r138     1     1
settable    r137  k167  r138
newtable    r138     1     0
loadk       r139  k169
setlist     r138     1     1
settable    r137  k168  r138
newtable    r138     1     0
loadk       r139  k156
setlist     r138     1     1
settable    r137  k170  r138
newtable    r138     1     0
loadk       r139  k152
setlist     r138     1     1
settable    r137  k171  r138
newtable    r138     1     0
loadk       r139   k97
setlist     r138     1     1
settable    r137   k70  r138
newtable    r138     1     0
loadk       r139  k152
setlist     r138     1     1
settable    r137  k172  r138
newtable    r138     1     0
loadk       r139  k149
setlist     r138     1     1
settable    r137  k173  r138
newtable    r138     1     0
loadk       r139  k169
setlist     r138     1     1
settable    r137  k174  r138
newtable    r138     1     0
loadk       r139  k130
setlist     r138     1     1
settable    r137   k56  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137  k175  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137  k176  r138
newtable    r138     1     0
loadk       r139  k146
setlist     r138     1     1
settable    r137  k177  r138
newtable    r138     1     0
loadk       r139  k144
setlist     r138     1     1
settable    r137  k178  r138
newtable    r138     1     0
loadk       r139  k131
setlist     r138     1     1
settable    r137  k179  r138
newtable    r138     1     0
loadk       r139  k142
setlist     r138     1     1
settable    r137  k180  r138
newtable    r138     1     0
loadk       r139  k137
setlist     r138     1     1
settable    r137  k181  r138
newtable    r138     1     0
loadk       r139  k169
setlist     r138     1     1
settable    r137  k182  r138
newtable    r138     1     0
loadk       r139  k137
setlist     r138     1     1
settable    r137  k183  r138
newtable    r138     1     0
loadk       r139  k152
setlist     r138     1     1
settable    r137  k184  r138
newtable    r138     1     0
loadk       r139  k132
setlist     r138     1     1
settable    r137  k185  r138
newtable    r138     1     0
loadk       r139  k169
setlist     r138     1     1
settable    r137  k186  r138
newtable    r138     1     0
loadk       r139  k144
setlist     r138     1     1
settable    r137  k187  r138
newtable    r138     1     0
loadk       r139   k97
setlist     r138     1     1
settable    r137  k188  r138
newtable    r138     1     0
loadk       r139  k149
setlist     r138     1     1
settable    r137  k189  r138
newtable    r138     1     0
loadk       r139  k149
setlist     r138     1     1
settable    r137  k190  r138
newtable    r138     1     0
loadk       r139  k169
setlist     r138     1     1
settable    r137  k191  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137  k192  r138
newtable    r138     1     0
loadk       r139  k152
setlist     r138     1     1
settable    r137   k64  r138
newtable    r138     1     0
loadk       r139  k130
setlist     r138     1     1
settable    r137  k193  r138
newtable    r138     1     0
loadk       r139  k142
setlist     r138     1     1
settable    r137  k194  r138
newtable    r138     1     0
loadk       r139  k126
setlist     r138     1     1
settable    r137  k195  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137  k196  r138
newtable    r138     1     0
loadk       r139  k144
setlist     r138     1     1
settable    r137  k197  r138
newtable    r138     1     0
loadk       r139  k152
setlist     r138     1     1
settable    r137  k198  r138
newtable    r138     1     0
loadk       r139  k144
setlist     r138     1     1
settable    r137  k199  r138
newtable    r138     1     0
loadk       r139  k131
setlist     r138     1     1
settable    r137  k200  r138
newtable    r138     1     0
loadk       r139  k133
setlist     r138     1     1
settable    r137  k201  r138
newtable    r138     1     0
loadk       r139  k165
setlist     r138     1     1
settable    r137  k202  r138
newtable    r138     1     0
loadk       r139  k165
setlist     r138     1     1
settable    r137  k203  r138
newtable    r138     1     0
loadk       r139  k165
setlist     r138     1     1
settable    r137   k23  r138
settable    r136    k0  r137
call        r135     2     0
call        r134     0     0
call        r133     0     1
gettabup    r133    u0  k205
gettable    r133  r133  k206
loadk       r134  k101
call        r133     2     2
settabup      u0  k204  r133
gettabup    r133    u0  k204
self        r133  r133  k207
loadk       r135  k208
call        r133     3     2
settabup      u0  k204  r133
loadk       r133   k13
loadk       r134  k138
loadk       r135   k13
forprep     r133 l2031
.label	l1999
gettabup    r137    u0   k90
gettabup    r138    u0   k53
newtable    r139     0     1
newtable    r140     0    12
settable    r140   k13  k209
settable    r140   k14  k210
settable    r140   k15  k211
settable    r140   k40  k212
settable    r140   k39  k213
settable    r140  k135  k214
settable    r140  k136  k215
settable    r140  k138  k216
settable    r140  k139  k217
settable    r140  k140  k218
settable    r140  k141  k219
settable    r140  k123  k220
settable    r139    k0  r140
call        r138     2     2
gettable    r137  r137  r138
gettabup    r138    u0  k204
call        r137     2     1
loadk       r137   k13
loadk       r138   k34
loadk       r139   k13
forprep     r137 l2030
.label	l2024
gettabup    r141    u0  k221
gettable    r141  r141  k222
loadk       r142   k13
loadnil     r143     0
gettabup    r144    u0  k204
call        r141     4     1
.label	l2030
forloop     r137 l2024
.label	l2031
forloop     r133 l1999
gettabup    r133    u0   k90
gettabup    r134    u0   k43
newtable    r135     0     1
newtable    r136     0     9
settable    r136   k13  k223
settable    r136   k14  k224
settable    r136   k15  k225
settable    r136   k40  k226
settable    r136   k39  k227
settable    r136  k135  k228
settable    r136  k136  k229
settable    r136  k138  k230
settable    r136  k139   k97
settable    r135    k0  r136
call        r134     2     2
gettable    r133  r133  r134
loadk       r134  k231
call        r133     2     1
gettabup    r133    u0   k90
gettable    r133  r133   k91
call        r133     1     2
gettabup    r134    u0   k90
gettabup    r135    u0   k73
newtable    r136     0     1
newtable    r137     0    10
settable    r137   k13  k232
settable    r137   k14  k233
settable    r137   k15  k234
settable    r137   k40  k235
settable    r137   k39  k236
settable    r137  k135  k237
settable    r137  k136  k238
settable    r137  k138  k239
settable    r137  k139  k240
settable    r137  k140  k241
settable    r136    k0  r137
call        r135     2     2
gettable    r134  r134  r135
loadk       r135  k242
call        r134     2     2
gettabup    r135    u0   k90
gettable    r135  r135  k243
move        r136  r134
call        r135     2     1
gettabup    r135    u0   k90
gettable    r135  r135   k91
call        r135     1     2
gettabup    r136    u0  k244
gettabup    r137    u0   k90
call        r136     2     2
self        r136  r136  k245
gettabup    r138    u0   k77
newtable    r139     0     1
newtable    r140     0    16
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140   k13  r141
newtable    r141     1     0
loadk       r142  k246
setlist     r141     1     1
settable    r140   k14  r141
newtable    r141     1     0
loadk       r142  k247
setlist     r141     1     1
settable    r140   k15  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140   k40  r141
newtable    r141     1     0
loadk       r142  k248
setlist     r141     1     1
settable    r140   k39  r141
newtable    r141     1     0
loadk       r142  k249
setlist     r141     1     1
settable    r140  k135  r141
newtable    r141     1     0
loadk       r142  k250
setlist     r141     1     1
settable    r140  k136  r141
newtable    r141     1     0
loadk       r142  k247
setlist     r141     1     1
settable    r140  k138  r141
newtable    r141     1     0
loadk       r142  k251
setlist     r141     1     1
settable    r140  k139  r141
newtable    r141     1     0
loadk       r142  k252
setlist     r141     1     1
settable    r140  k140  r141
newtable    r141     1     0
loadk       r142  k253
setlist     r141     1     1
settable    r140  k141  r141
newtable    r141     1     0
loadk       r142  k254
setlist     r141     1     1
settable    r140  k123  r141
newtable    r141     1     0
loadk       r142  k255
setlist     r141     1     1
settable    r140  k143  r141
newtable    r141     1     0
loadk       r142  k256
setlist     r141     1     1
settable    r140  k145  r141
newtable    r141     1     0
loadk       r142  k257
setlist     r141     1     1
settable    r140  k147  r141
newtable    r141     1     0
loadk       r142  k251
setlist     r141     1     1
settable    r140  k148  r141
settable    r139    k0  r140
call        r138     2     0
call        r136     0     2
test        r136     0
jmp            0 l2762
loadk       r136  k258
gettabup    r136    u0  r136
move        r137  r132
gettabup    r138    u0   k77
newtable    r139     0     1
newtable    r140     0    41
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140   k13  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140   k14  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140   k15  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140   k40  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140   k39  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k135  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k136  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k138  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140  k139  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k140  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140  k141  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k123  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k143  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140  k145  r141
newtable    r141     1     0
loadk       r142  k132
setlist     r141     1     1
settable    r140  k147  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k148  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k150  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k151  r141
newtable    r141     1     0
loadk       r142  k131
setlist     r141     1     1
settable    r140  k153  r141
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140  k154  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k155  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140   k59  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140  k157  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k158  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k159  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140   k57  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k160  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k161  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140  k162  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140  k163  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k164  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k166  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k167  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k168  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k170  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k171  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140   k70  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k172  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k173  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k174  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140   k56  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k175  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140  k176  r141
newtable    r141     1     0
loadk       r142  k132
setlist     r141     1     1
settable    r140  k177  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k178  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k179  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k180  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k181  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k182  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k183  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140  k184  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k185  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140  k186  r141
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140  k187  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k188  r141
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140  k189  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k190  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k191  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k192  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140   k64  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k193  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k194  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k195  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k196  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k197  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k198  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k199  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k200  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k201  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k202  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k203  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140   k23  r141
loadk       r141  k259
newtable    r142     1     0
loadk       r143  k156
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k260
newtable    r142     1     0
loadk       r143  k165
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k261
newtable    r142     1     0
loadk       r143  k134
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k262
newtable    r142     1     0
loadk       r143  k133
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k263
newtable    r142     1     0
loadk       r143  k130
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k264
newtable    r142     1     0
loadk       r143  k133
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k265
newtable    r142     1     0
loadk       r143  k165
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k266
newtable    r142     1     0
loadk       r143   k97
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k267
newtable    r142     1     0
loadk       r143  k144
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k268
newtable    r142     1     0
loadk       r143  k133
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k269
newtable    r142     1     0
loadk       r143  k131
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k270
newtable    r142     1     0
loadk       r143  k152
setlist     r142     1     1
settable    r140  r141  r142
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140   k30  r141
loadk       r141  k271
newtable    r142     1     0
loadk       r143  k132
setlist     r142     1     1
settable    r140  r141  r142
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k47  r141
loadk       r141  k272
newtable    r142     1     0
loadk       r143  k142
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k273
newtable    r142     1     0
loadk       r143  k137
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k274
newtable    r142     1     0
loadk       r143  k130
setlist     r142     1     1
settable    r140  r141  r142
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k124  r141
loadk       r141  k275
newtable    r142     1     0
loadk       r143  k146
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k276
newtable    r142     1     0
loadk       r143  k132
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k277
newtable    r142     1     0
loadk       r143   k97
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k278
newtable    r142     1     0
loadk       r143  k132
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k279
newtable    r142     1     0
loadk       r143  k133
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k280
newtable    r142     1     0
loadk       r143  k142
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k281
newtable    r142     1     0
loadk       r143  k133
setlist     r142     1     1
settable    r140  r141  r142
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140   k54  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140   k34  r141
loadk       r141  k282
newtable    r142     1     0
loadk       r143  k134
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k283
newtable    r142     1     0
loadk       r143  k132
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k284
newtable    r142     1     0
loadk       r143  k149
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k285
newtable    r142     1     0
loadk       r143  k142
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k286
newtable    r142     1     0
loadk       r143  k126
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k287
newtable    r142     1     0
loadk       r143  k130
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k288
newtable    r142     1     0
loadk       r143  k132
setlist     r142     1     1
settable    r140  r141  r142
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140   k50  r141
loadk       r141  k289
newtable    r142     1     0
loadk       r143   k97
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k290
newtable    r142     1     0
loadk       r143  k133
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k291
newtable    r142     1     0
loadk       r143  k126
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k292
newtable    r142     1     0
loadk       r143  k156
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k293
newtable    r142     1     0
loadk       r143  k130
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k294
newtable    r142     1     0
loadk       r143  k144
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k295
newtable    r142     1     0
loadk       r143  k131
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k296
newtable    r142     1     0
loadk       r143  k156
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k297
newtable    r142     1     0
loadk       r143  k169
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k298
newtable    r142     1     0
loadk       r143  k133
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k299
newtable    r142     1     0
loadk       r143  k126
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k300
newtable    r142     1     0
loadk       r143  k165
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k301
newtable    r142     1     0
loadk       r143  k126
setlist     r142     1     1
settable    r140  r141  r142
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140   k38  r141
loadk       r141  k302
newtable    r142     1     0
loadk       r143  k137
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k303
newtable    r142     1     0
loadk       r143  k169
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k304
newtable    r142     1     0
loadk       r143  k156
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k305
newtable    r142     1     0
loadk       r143  k156
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k306
newtable    r142     1     0
loadk       r143  k146
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k307
newtable    r142     1     0
loadk       r143  k133
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k308
newtable    r142     1     0
loadk       r143  k156
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k309
newtable    r142     1     0
loadk       r143  k144
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k310
newtable    r142     1     0
loadk       r143  k132
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k311
newtable    r142     1     0
loadk       r143  k133
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k312
newtable    r142     1     0
loadk       r143  k149
setlist     r142     1     1
settable    r140  r141  r142
loadk       r141  k313
newtable    r142     1     0
loadk       r143  k152
setlist     r142     1     1
settable    r140  r141  r142
settable    r139    k0  r140
call        r138     2     0
call        r137     0     0
call        r136     0     1
loadk       r136  k314
gettabup    r136    u0  r136
loadk       r137  k315
gettable    r136  r136  r137
call        r136     1     1
jmp            0 l3452
.label	l2762
gettabup    r136    u0  k244
getupval    r137    u0
call        r136     2     2
loadk       r138  k316
self        r136  r136  r138
gettabup    r138    u0   k77
newtable    r139     0     1
newtable    r140     0    16
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140   k13  r141
newtable    r141     1     0
loadk       r142  k246
setlist     r141     1     1
settable    r140   k14  r141
newtable    r141     1     0
loadk       r142  k247
setlist     r141     1     1
settable    r140   k15  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140   k40  r141
newtable    r141     1     0
loadk       r142  k248
setlist     r141     1     1
settable    r140   k39  r141
newtable    r141     1     0
loadk       r142  k249
setlist     r141     1     1
settable    r140  k135  r141
newtable    r141     1     0
loadk       r142  k250
setlist     r141     1     1
settable    r140  k136  r141
newtable    r141     1     0
loadk       r142  k247
setlist     r141     1     1
settable    r140  k138  r141
newtable    r141     1     0
loadk       r142  k251
setlist     r141     1     1
settable    r140  k139  r141
newtable    r141     1     0
loadk       r142  k252
setlist     r141     1     1
settable    r140  k140  r141
newtable    r141     1     0
loadk       r142  k253
setlist     r141     1     1
settable    r140  k141  r141
newtable    r141     1     0
loadk       r142  k254
setlist     r141     1     1
settable    r140  k123  r141
newtable    r141     1     0
loadk       r142  k255
setlist     r141     1     1
settable    r140  k143  r141
newtable    r141     1     0
loadk       r142  k256
setlist     r141     1     1
settable    r140  k145  r141
newtable    r141     1     0
loadk       r142  k257
setlist     r141     1     1
settable    r140  k147  r141
newtable    r141     1     0
loadk       r142  k251
setlist     r141     1     1
settable    r140  k148  r141
settable    r139    k0  r140
call        r138     2     0
call        r136     0     2
loadnil     r137     1
jmp            0 l3450
.label	l2839
gettabup    r140    u0   k90
gettable    r140  r140   k91
call        r140     1     2
eq             1  r139  r140
jmp            0 l3450
loadk       r140  k258
gettabup    r140    u0  r140
move        r141  r132
gettabup    r142    u0   k77
newtable    r143     0     1
newtable    r144     0    41
newtable    r145     1     0
loadk       r146  k130
setlist     r145     1     1
settable    r144   k13  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144   k14  r145
newtable    r145     1     0
loadk       r146   k97
setlist     r145     1     1
settable    r144   k15  r145
newtable    r145     1     0
loadk       r146  k126
setlist     r145     1     1
settable    r144   k40  r145
newtable    r145     1     0
loadk       r146  k134
setlist     r145     1     1
settable    r144   k39  r145
newtable    r145     1     0
loadk       r146  k169
setlist     r145     1     1
settable    r144  k135  r145
newtable    r145     1     0
loadk       r146  k130
setlist     r145     1     1
settable    r144  k136  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k138  r145
newtable    r145     1     0
loadk       r146   k97
setlist     r145     1     1
settable    r144  k139  r145
newtable    r145     1     0
loadk       r146  k152
setlist     r145     1     1
settable    r144  k140  r145
newtable    r145     1     0
loadk       r146  k134
setlist     r145     1     1
settable    r144  k141  r145
newtable    r145     1     0
loadk       r146  k144
setlist     r145     1     1
settable    r144  k123  r145
newtable    r145     1     0
loadk       r146  k149
setlist     r145     1     1
settable    r144  k143  r145
newtable    r145     1     0
loadk       r146   k97
setlist     r145     1     1
settable    r144  k145  r145
newtable    r145     1     0
loadk       r146  k132
setlist     r145     1     1
settable    r144  k147  r145
newtable    r145     1     0
loadk       r146  k156
setlist     r145     1     1
settable    r144  k148  r145
newtable    r145     1     0
loadk       r146  k146
setlist     r145     1     1
settable    r144  k150  r145
newtable    r145     1     0
loadk       r146  k152
setlist     r145     1     1
settable    r144  k151  r145
newtable    r145     1     0
loadk       r146  k131
setlist     r145     1     1
settable    r144  k153  r145
newtable    r145     1     0
loadk       r146  k165
setlist     r145     1     1
settable    r144  k154  r145
newtable    r145     1     0
loadk       r146  k152
setlist     r145     1     1
settable    r144  k155  r145
newtable    r145     1     0
loadk       r146  k126
setlist     r145     1     1
settable    r144   k59  r145
newtable    r145     1     0
loadk       r146  k134
setlist     r145     1     1
settable    r144  k157  r145
newtable    r145     1     0
loadk       r146  k130
setlist     r145     1     1
settable    r144  k158  r145
newtable    r145     1     0
loadk       r146  k156
setlist     r145     1     1
settable    r144  k159  r145
newtable    r145     1     0
loadk       r146  k152
setlist     r145     1     1
settable    r144   k57  r145
newtable    r145     1     0
loadk       r146  k146
setlist     r145     1     1
settable    r144  k160  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k161  r145
newtable    r145     1     0
loadk       r146  k137
setlist     r145     1     1
settable    r144  k162  r145
newtable    r145     1     0
loadk       r146  k134
setlist     r145     1     1
settable    r144  k163  r145
newtable    r145     1     0
loadk       r146  k142
setlist     r145     1     1
settable    r144  k164  r145
newtable    r145     1     0
loadk       r146  k142
setlist     r145     1     1
settable    r144  k166  r145
newtable    r145     1     0
loadk       r146  k146
setlist     r145     1     1
settable    r144  k167  r145
newtable    r145     1     0
loadk       r146  k146
setlist     r145     1     1
settable    r144  k168  r145
newtable    r145     1     0
loadk       r146  k146
setlist     r145     1     1
settable    r144  k170  r145
newtable    r145     1     0
loadk       r146  k144
setlist     r145     1     1
settable    r144  k171  r145
newtable    r145     1     0
loadk       r146  k134
setlist     r145     1     1
settable    r144   k70  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k172  r145
newtable    r145     1     0
loadk       r146  k156
setlist     r145     1     1
settable    r144  k173  r145
newtable    r145     1     0
loadk       r146  k169
setlist     r145     1     1
settable    r144  k174  r145
newtable    r145     1     0
loadk       r146  k130
setlist     r145     1     1
settable    r144   k56  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k175  r145
newtable    r145     1     0
loadk       r146  k134
setlist     r145     1     1
settable    r144  k176  r145
newtable    r145     1     0
loadk       r146  k132
setlist     r145     1     1
settable    r144  k177  r145
newtable    r145     1     0
loadk       r146  k156
setlist     r145     1     1
settable    r144  k178  r145
newtable    r145     1     0
loadk       r146  k149
setlist     r145     1     1
settable    r144  k179  r145
newtable    r145     1     0
loadk       r146  k169
setlist     r145     1     1
settable    r144  k180  r145
newtable    r145     1     0
loadk       r146  k149
setlist     r145     1     1
settable    r144  k181  r145
newtable    r145     1     0
loadk       r146  k146
setlist     r145     1     1
settable    r144  k182  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k183  r145
newtable    r145     1     0
loadk       r146  k134
setlist     r145     1     1
settable    r144  k184  r145
newtable    r145     1     0
loadk       r146  k142
setlist     r145     1     1
settable    r144  k185  r145
newtable    r145     1     0
loadk       r146  k137
setlist     r145     1     1
settable    r144  k186  r145
newtable    r145     1     0
loadk       r146  k165
setlist     r145     1     1
settable    r144  k187  r145
newtable    r145     1     0
loadk       r146  k149
setlist     r145     1     1
settable    r144  k188  r145
newtable    r145     1     0
loadk       r146  k165
setlist     r145     1     1
settable    r144  k189  r145
newtable    r145     1     0
loadk       r146  k142
setlist     r145     1     1
settable    r144  k190  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k191  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k192  r145
newtable    r145     1     0
loadk       r146  k134
setlist     r145     1     1
settable    r144   k64  r145
newtable    r145     1     0
loadk       r146  k146
setlist     r145     1     1
settable    r144  k193  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k194  r145
newtable    r145     1     0
loadk       r146  k130
setlist     r145     1     1
settable    r144  k195  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k196  r145
newtable    r145     1     0
loadk       r146  k130
setlist     r145     1     1
settable    r144  k197  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k198  r145
newtable    r145     1     0
loadk       r146  k126
setlist     r145     1     1
settable    r144  k199  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k200  r145
newtable    r145     1     0
loadk       r146  k130
setlist     r145     1     1
settable    r144  k201  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144  k202  r145
newtable    r145     1     0
loadk       r146  k156
setlist     r145     1     1
settable    r144  k203  r145
newtable    r145     1     0
loadk       r146  k126
setlist     r145     1     1
settable    r144   k23  r145
loadk       r145  k259
newtable    r146     1     0
loadk       r147  k156
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k260
newtable    r146     1     0
loadk       r147  k165
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k261
newtable    r146     1     0
loadk       r147  k134
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k262
newtable    r146     1     0
loadk       r147  k133
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k263
newtable    r146     1     0
loadk       r147  k130
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k264
newtable    r146     1     0
loadk       r147  k133
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k265
newtable    r146     1     0
loadk       r147  k165
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k266
newtable    r146     1     0
loadk       r147   k97
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k267
newtable    r146     1     0
loadk       r147  k144
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k268
newtable    r146     1     0
loadk       r147  k133
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k269
newtable    r146     1     0
loadk       r147  k131
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k270
newtable    r146     1     0
loadk       r147  k152
setlist     r146     1     1
settable    r144  r145  r146
newtable    r145     1     0
loadk       r146  k146
setlist     r145     1     1
settable    r144   k30  r145
loadk       r145  k271
newtable    r146     1     0
loadk       r147  k132
setlist     r146     1     1
settable    r144  r145  r146
newtable    r145     1     0
loadk       r146  k169
setlist     r145     1     1
settable    r144   k47  r145
loadk       r145  k272
newtable    r146     1     0
loadk       r147  k142
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k273
newtable    r146     1     0
loadk       r147  k137
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k274
newtable    r146     1     0
loadk       r147  k130
setlist     r146     1     1
settable    r144  r145  r146
newtable    r145     1     0
loadk       r146  k149
setlist     r145     1     1
settable    r144  k124  r145
loadk       r145  k275
newtable    r146     1     0
loadk       r147  k146
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k276
newtable    r146     1     0
loadk       r147  k132
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k277
newtable    r146     1     0
loadk       r147   k97
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k278
newtable    r146     1     0
loadk       r147  k132
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k279
newtable    r146     1     0
loadk       r147  k133
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k280
newtable    r146     1     0
loadk       r147  k142
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k281
newtable    r146     1     0
loadk       r147  k133
setlist     r146     1     1
settable    r144  r145  r146
newtable    r145     1     0
loadk       r146  k130
setlist     r145     1     1
settable    r144   k54  r145
newtable    r145     1     0
loadk       r146  k133
setlist     r145     1     1
settable    r144   k34  r145
loadk       r145  k282
newtable    r146     1     0
loadk       r147  k134
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k283
newtable    r146     1     0
loadk       r147  k132
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k284
newtable    r146     1     0
loadk       r147  k149
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k285
newtable    r146     1     0
loadk       r147  k142
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k286
newtable    r146     1     0
loadk       r147  k126
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k287
newtable    r146     1     0
loadk       r147  k130
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k288
newtable    r146     1     0
loadk       r147  k132
setlist     r146     1     1
settable    r144  r145  r146
newtable    r145     1     0
loadk       r146  k134
setlist     r145     1     1
settable    r144   k50  r145
loadk       r145  k289
newtable    r146     1     0
loadk       r147   k97
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k290
newtable    r146     1     0
loadk       r147  k133
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k291
newtable    r146     1     0
loadk       r147  k126
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k292
newtable    r146     1     0
loadk       r147  k156
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k293
newtable    r146     1     0
loadk       r147  k130
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k294
newtable    r146     1     0
loadk       r147  k144
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k295
newtable    r146     1     0
loadk       r147  k131
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k296
newtable    r146     1     0
loadk       r147  k156
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k297
newtable    r146     1     0
loadk       r147  k169
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k298
newtable    r146     1     0
loadk       r147  k133
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k299
newtable    r146     1     0
loadk       r147  k126
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k300
newtable    r146     1     0
loadk       r147  k165
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k301
newtable    r146     1     0
loadk       r147  k126
setlist     r146     1     1
settable    r144  r145  r146
newtable    r145     1     0
loadk       r146  k165
setlist     r145     1     1
settable    r144   k38  r145
loadk       r145  k302
newtable    r146     1     0
loadk       r147  k137
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k303
newtable    r146     1     0
loadk       r147  k169
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k304
newtable    r146     1     0
loadk       r147  k156
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k305
newtable    r146     1     0
loadk       r147  k156
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k306
newtable    r146     1     0
loadk       r147  k146
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k307
newtable    r146     1     0
loadk       r147  k133
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k308
newtable    r146     1     0
loadk       r147  k156
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k309
newtable    r146     1     0
loadk       r147  k144
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k310
newtable    r146     1     0
loadk       r147  k132
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k311
newtable    r146     1     0
loadk       r147  k133
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k312
newtable    r146     1     0
loadk       r147  k149
setlist     r146     1     1
settable    r144  r145  r146
loadk       r145  k313
newtable    r146     1     0
loadk       r147  k152
setlist     r146     1     1
settable    r144  r145  r146
settable    r143    k0  r144
call        r142     2     0
call        r141     0     0
call        r140     0     1
loadk       r140  k314
gettabup    r140    u0  r140
loadk       r141  k315
gettable    r140  r140  r141
call        r140     1     1
.label	l3450
tforcall    r136     1
tforloop    r138 l2839
.label	l3452
loadk       r136  k317
move        r137  r132
gettabup    r138    u0   k77
newtable    r139     0     1
newtable    r140     0    23
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k13  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140   k14  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140   k15  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140   k40  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140   k39  r141
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140  k135  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k136  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k138  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k139  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k140  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140  k141  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140  k123  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k143  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k145  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k147  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k148  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k150  r141
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140  k151  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k153  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k154  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k155  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140   k59  r141
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140  k157  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k158  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k159  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k57  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k160  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k161  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k162  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k163  r141
settable    r139    k0  r140
call        r138     2     0
call        r137     0     2
settabup      u0  r136  r137
loadk       r136  k318
gettabup    r137    u0   k90
gettabup    r138    u0   k53
newtable    r139     0     1
newtable    r140     0     6
loadk       r141  k319
settable    r140   k13  r141
loadk       r141  k320
settable    r140   k14  r141
loadk       r141  k321
settable    r140   k15  r141
loadk       r141  k322
settable    r140   k40  r141
loadk       r141  k323
settable    r140   k39  r141
loadk       r141  k324
settable    r140  k135  r141
settable    r139    k0  r140
call        r138     2     2
gettable    r137  r137  r138
newtable    r138     0     0
move        r139  r132
gettabup    r140    u0   k77
newtable    r141     0     1
newtable    r142     0    22
newtable    r143     1     0
loadk       r144  k169
setlist     r143     1     1
settable    r142   k13  r143
newtable    r143     1     0
loadk       r144  k142
setlist     r143     1     1
settable    r142   k14  r143
newtable    r143     1     0
loadk       r144  k169
setlist     r143     1     1
settable    r142   k15  r143
newtable    r143     1     0
loadk       r144  k130
setlist     r143     1     1
settable    r142   k40  r143
newtable    r143     1     0
loadk       r144  k142
setlist     r143     1     1
settable    r142   k39  r143
newtable    r143     1     0
loadk       r144  k169
setlist     r143     1     1
settable    r142  k135  r143
newtable    r143     1     0
loadk       r144  k169
setlist     r143     1     1
settable    r142  k136  r143
newtable    r143     1     0
loadk       r144  k142
setlist     r143     1     1
settable    r142  k138  r143
newtable    r143     1     0
loadk       r144  k142
setlist     r143     1     1
settable    r142  k139  r143
newtable    r143     1     0
loadk       r144  k146
setlist     r143     1     1
settable    r142  k140  r143
newtable    r143     1     0
loadk       r144  k130
setlist     r143     1     1
settable    r142  k141  r143
newtable    r143     1     0
loadk       r144  k133
setlist     r143     1     1
settable    r142  k123  r143
newtable    r143     1     0
loadk       r144  k144
setlist     r143     1     1
settable    r142  k143  r143
newtable    r143     1     0
loadk       r144  k133
setlist     r143     1     1
settable    r142  k145  r143
newtable    r143     1     0
loadk       r144  k152
setlist     r143     1     1
settable    r142  k147  r143
newtable    r143     1     0
loadk       r144  k156
setlist     r143     1     1
settable    r142  k148  r143
newtable    r143     1     0
loadk       r144  k133
setlist     r143     1     1
settable    r142  k150  r143
newtable    r143     1     0
loadk       r144  k137
setlist     r143     1     1
settable    r142  k151  r143
newtable    r143     1     0
loadk       r144  k156
setlist     r143     1     1
settable    r142  k153  r143
newtable    r143     1     0
loadk       r144  k131
setlist     r143     1     1
settable    r142  k154  r143
newtable    r143     1     0
loadk       r144  k165
setlist     r143     1     1
settable    r142  k155  r143
newtable    r143     1     0
loadk       r144  k134
setlist     r143     1     1
settable    r142   k59  r143
newtable    r143     1     0
loadk       r144  k126
setlist     r143     1     1
settable    r142  k157  r143
newtable    r143     1     0
loadk       r144  k137
setlist     r143     1     1
settable    r142  k158  r143
newtable    r143     1     0
loadk       r144  k137
setlist     r143     1     1
settable    r142  k159  r143
newtable    r143     1     0
loadk       r144  k130
setlist     r143     1     1
settable    r142   k57  r143
newtable    r143     1     0
loadk       r144  k165
setlist     r143     1     1
settable    r142  k160  r143
newtable    r143     1     0
loadk       r144  k131
setlist     r143     1     1
settable    r142  k161  r143
settable    r141    k0  r142
call        r140     2     0
call        r139     0     0
setlist     r138     0     1
newtable    r139     0     1
move        r140  r132
gettabup    r141    u0   k77
newtable    r142     0     1
newtable    r143     0     0
settable    r142    k0  r143
call        r141     2     0
call        r140     0     2
settable    r139   k13  r140
newtable    r140     0     1
move        r141  r132
gettabup    r142    u0   k77
newtable    r143     0     1
newtable    r144     0     8
newtable    r145     1     0
loadk       r146  k152
setlist     r145     1     1
settable    r144   k13  r145
newtable    r145     1     0
loadk       r146  k169
setlist     r145     1     1
settable    r144   k14  r145
newtable    r145     1     0
loadk       r146  k126
setlist     r145     1     1
settable    r144   k15  r145
newtable    r145     1     0
loadk       r146  k142
setlist     r145     1     1
settable    r144   k40  r145
newtable    r145     1     0
loadk       r146  k152
setlist     r145     1     1
settable    r144   k39  r145
newtable    r145     1     0
loadk       r146  k132
setlist     r145     1     1
settable    r144  k135  r145
newtable    r145     1     0
loadk       r146  k152
setlist     r145     1     1
settable    r144  k136  r145
newtable    r145     1     0
loadk       r146  k169
setlist     r145     1     1
settable    r144  k138  r145
settable    r143    k0  r144
call        r142     2     0
call        r141     0     2
settable    r140   k13  r141
call        r137     4     2
settabup      u0  r136  r137
loadk       r136  k318
gettabup    r136    u0  r136
test        r136     1
jmp            0 l3779
return        r0     1
.label	l3779
loadk       r136  k318
gettabup    r136    u0  r136
gettable    r136  r136   k13
move        r137  r132
gettabup    r138    u0   k77
newtable    r139     0     1
newtable    r140     0     0
settable    r139    k0  r140
call        r138     2     0
call        r137     0     2
eq             0  r136  r137
jmp            0 l4045
gettabup    r136    u0   k90
gettabup    r137    u0   k73
newtable    r138     0     1
newtable    r139     0     5
loadk       r140  k325
settable    r139   k13  r140
loadk       r140  k326
settable    r139   k14  r140
loadk       r140  k327
settable    r139   k15  r140
loadk       r140  k328
settable    r139   k40  r140
loadk       r140  k329
settable    r139   k39  r140
settable    r138    k0  r139
call        r137     2     2
gettable    r136  r136  r137
move        r137  r132
gettabup    r138    u0   k77
newtable    r139     0     1
newtable    r140     0    30
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k13  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140   k14  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k15  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140   k40  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140   k39  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k135  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k136  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k138  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k139  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k140  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k141  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k123  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k143  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k145  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k147  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k148  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k150  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k151  r141
newtable    r141     1     0
loadk       r142  k131
setlist     r141     1     1
settable    r140  k153  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k154  r141
newtable    r141     1     0
loadk       r142  k132
setlist     r141     1     1
settable    r140  k155  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k59  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k157  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k158  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k159  r141
newtable    r141     1     0
loadk       r142  k132
setlist     r141     1     1
settable    r140   k57  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k160  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k161  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k162  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k163  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k164  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k166  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140  k167  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k168  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k170  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140  k171  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140   k70  r141
newtable    r141     1     0
loadk       r142  k131
setlist     r141     1     1
settable    r140  k172  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k173  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140  k174  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140   k56  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k175  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140  k176  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k177  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140  k178  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k179  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k180  r141
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140  k181  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k182  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k183  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k184  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k185  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k186  r141
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140  k187  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k188  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140  k189  r141
settable    r139    k0  r140
call        r138     2     0
call        r137     0     0
call        r136     0     1
loadk       r136  k314
gettabup    r136    u0  r136
loadk       r137  k330
gettable    r136  r136  r137
call        r136     1     1
.label	l4045
loadk       r136  k318
gettabup    r136    u0  r136
gettable    r136  r136   k13
loadk       r137  k317
gettabup    r137    u0  r137
eq             0  r136  r137
jmp            0 l4129
gettabup    r136    u0   k90
gettabup    r137    u0   k63
newtable    r138     0     1
newtable    r139     0     5
settable    r139   k13  k125
settable    r139   k14  k126
settable    r139   k15  k127
settable    r139   k40  k128
settable    r139   k39  k129
settable    r138    k0  r139
call        r137     2     2
gettable    r136  r136  r137
move        r137  r132
gettabup    r138    u0   k77
newtable    r139     0     1
newtable    r140     0    14
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140   k13  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140   k14  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k15  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140   k40  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k39  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k135  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k136  r141
newtable    r141     1     0
loadk       r142  k131
setlist     r141     1     1
settable    r140  k138  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k139  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140  k140  r141
newtable    r141     1     0
loadk       r142  k152
setlist     r141     1     1
settable    r140  k141  r141
newtable    r141     1     0
loadk       r142  k131
setlist     r141     1     1
settable    r140  k123  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k143  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k145  r141
settable    r139    k0  r140
call        r138     2     0
call        r137     0     0
call        r136     0     1
jmp            0 l4299
.label	l4129
gettabup    r136    u0   k90
gettabup    r137    u0   k73
newtable    r138     0     1
newtable    r139     0     5
loadk       r140  k325
settable    r139   k13  r140
loadk       r140  k326
settable    r139   k14  r140
loadk       r140  k327
settable    r139   k15  r140
loadk       r140  k328
settable    r139   k40  r140
loadk       r140  k329
settable    r139   k39  r140
settable    r138    k0  r139
call        r137     2     2
gettable    r136  r136  r137
move        r137  r132
gettabup    r138    u0   k77
newtable    r139     0     1
newtable    r140     0    25
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k13  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140   k14  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k15  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140   k40  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140   k39  r141
newtable    r141     1     0
loadk       r142  k131
setlist     r141     1     1
settable    r140  k135  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k136  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140  k138  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k139  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k140  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k141  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k123  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k143  r141
newtable    r141     1     0
loadk       r142  k165
setlist     r141     1     1
settable    r140  k145  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k147  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k148  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k150  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k151  r141
newtable    r141     1     0
loadk       r142  k146
setlist     r141     1     1
settable    r140  k153  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k154  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k155  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140   k59  r141
newtable    r141     1     0
loadk       r142  k126
setlist     r141     1     1
settable    r140  k157  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140  k158  r141
newtable    r141     1     0
loadk       r142  k137
setlist     r141     1     1
settable    r140  k159  r141
newtable    r141     1     0
loadk       r142  k134
setlist     r141     1     1
settable    r140   k57  r141
newtable    r141     1     0
loadk       r142  k133
setlist     r141     1     1
settable    r140  k160  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k161  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k162  r141
newtable    r141     1     0
loadk       r142  k144
setlist     r141     1     1
settable    r140  k163  r141
newtable    r141     1     0
loadk       r142  k169
setlist     r141     1     1
settable    r140  k164  r141
newtable    r141     1     0
loadk       r142  k149
setlist     r141     1     1
settable    r140  k166  r141
newtable    r141     1     0
loadk       r142  k130
setlist     r141     1     1
settable    r140  k167  r141
newtable    r141     1     0
loadk       r142   k97
setlist     r141     1     1
settable    r140  k168  r141
newtable    r141     1     0
loadk       r142  k142
setlist     r141     1     1
settable    r140  k170  r141
newtable    r141     1     0
loadk       r142  k156
setlist     r141     1     1
settable    r140  k171  r141
settable    r139    k0  r140
call        r138     2     0
call        r137     0     0
call        r136     0     1
return        r0     1
.label	l4299
loadk       r136  k331
closure     r137   f54
settabup      u0  r136  r137
loadk       r136  k332
closure     r137   f55
settabup      u0  r136  r137
.label	l4305
gettabup    r136    u0   k90
loadk       r137  k333
gettable    r136  r136  r137
loadbool    r137     1     0
call        r136     2     2
test        r136     0
jmp            0 l4305
loadk       r136  k334
settabup      u0  r136   k13
gettabup    r136    u0   k90
loadk       r137  k335
gettable    r136  r136  r137
loadbool    r137     0     0
call        r136     2     1
loadk       r136  k334
loadk       r137  k336
settabup      u0  r136  r137
loadk       r136  k331
gettabup    r136    u0  r136
call        r136     1     1
jmp            0 l4305
return        r0     1

.function	main/f0/f0

.linedefined	28
.lastlinedefined	35
.numparams	1
.is_vararg	0
.maxstacksize	8
.source	null

.upvalue	null	0	false

.constant	k0	"KEY"
.constant	k1	"ipairs"
.constant	k2	"PGFUNCTION"
.constant	k3	"PGFC"
.constant	k4	1
.constant	k5	2
.constant	k6	6
.constant	k7	3
.constant	k8	8
.constant	k9	4
.constant	k10	7
.constant	k11	5
.constant	k12	10
.constant	k13	9
.constant	k14	11
.constant	k15	12
.constant	k16	13
.constant	k17	14
.constant	k18	15
.constant	k19	16
.constant	k20	17
.constant	k21	18
.constant	k22	19
.constant	k23	20
.constant	k24	256
.constant	k25	"table"
.constant	k26	"insert"

newtable      r1     0     0
settabup      u0    k0    r1
gettabup      r1    u0    k1
move          r2    r0
call          r1     2     4
jmp            0   l75
.label	l7
gettable      r5    r0    r4
gettabup      r6    u0    k3
gettable      r6    r6    k4
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k5
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k6
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k7
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k8
gettabup      r7    u0    k3
gettable      r7    r7    k9
mul           r6    r6    r7
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k10
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k11
gettabup      r7    u0    k3
gettable      r7    r7   k12
mul           r6    r6    r7
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k13
gettabup      r7    u0    k3
gettable      r7    r7   k14
mul           r6    r6    r7
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k15
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k16
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k17
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k18
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k19
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k20
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k21
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k22
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k23
sub           r5    r5    r6
mod           r5    r5   k24
settabup      u0    k2    r5
gettabup      r5    u0   k25
gettable      r5    r5   k26
gettabup      r6    u0    k0
gettabup      r7    u0    k2
call          r5     3     1
.label	l75
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k0
return        r1     2
return        r0     1

.function	main/f0/f1

.linedefined	37
.lastlinedefined	44
.numparams	1
.is_vararg	0
.maxstacksize	10
.source	null

.upvalue	null	0	false

.constant	k0	"PG"
.constant	k1	"res"
.constant	k2	""
.constant	k3	"ipairs"
.constant	k4	"string"
.constant	k5	"char"
.constant	k6	"KEY"
.constant	k7	4
.constant	k8	7
.constant	k9	9
.constant	k10	256

gettable      r0    r0    k0
settabup      u0    k1    k2
gettabup      r1    u0    k3
move          r2    r0
call          r1     2     4
jmp            0   l27
.label	l7
gettabup      r5    u0    k1
gettabup      r6    u0    k4
gettable      r6    r6    k5
gettable      r7    r0    r4
len           r7    r7
gettabup      r8    u0    k6
gettable      r8    r8    k7
add           r7    r7    r8
gettabup      r8    u0    k6
gettable      r8    r8    k8
add           r8    r8    r4
gettabup      r9    u0    k6
gettable      r9    r9    k9
add           r9    r9    r4
mul           r8    r8    r9
add           r7    r7    r8
mod           r7    r7   k10
call          r6     2     2
concat        r5    r5    r6
settabup      u0    k1    r5
.label	l27
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k1
return        r1     2
return        r0     1

.function	main/f0/f2

.linedefined	49
.lastlinedefined	56
.numparams	1
.is_vararg	0
.maxstacksize	8
.source	null

.upvalue	null	0	false

.constant	k0	"KEY1"
.constant	k1	"ipairs"
.constant	k2	"PGFUNCTION"
.constant	k3	"PGFC1"
.constant	k4	1
.constant	k5	2
.constant	k6	6
.constant	k7	3
.constant	k8	8
.constant	k9	4
.constant	k10	7
.constant	k11	5
.constant	k12	10
.constant	k13	9
.constant	k14	11
.constant	k15	12
.constant	k16	13
.constant	k17	14
.constant	k18	15
.constant	k19	16
.constant	k20	17
.constant	k21	18
.constant	k22	19
.constant	k23	20
.constant	k24	256
.constant	k25	"table"
.constant	k26	"insert"

newtable      r1     0     0
settabup      u0    k0    r1
gettabup      r1    u0    k1
move          r2    r0
call          r1     2     4
jmp            0   l75
.label	l7
gettable      r5    r0    r4
gettabup      r6    u0    k3
gettable      r6    r6    k4
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k5
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k6
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k7
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k8
gettabup      r7    u0    k3
gettable      r7    r7    k9
mul           r6    r6    r7
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k10
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k11
gettabup      r7    u0    k3
gettable      r7    r7   k12
mul           r6    r6    r7
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k13
gettabup      r7    u0    k3
gettable      r7    r7   k14
mul           r6    r6    r7
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k15
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k16
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k17
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k18
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k19
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k20
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k21
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k22
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k23
sub           r5    r5    r6
mod           r5    r5   k24
settabup      u0    k2    r5
gettabup      r5    u0   k25
gettable      r5    r5   k26
gettabup      r6    u0    k0
gettabup      r7    u0    k2
call          r5     3     1
.label	l75
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k0
return        r1     2
return        r0     1

.function	main/f0/f3

.linedefined	58
.lastlinedefined	65
.numparams	1
.is_vararg	0
.maxstacksize	10
.source	null

.upvalue	null	0	false

.constant	k0	"PG"
.constant	k1	"res"
.constant	k2	""
.constant	k3	"ipairs"
.constant	k4	"string"
.constant	k5	"char"
.constant	k6	"KEY1"
.constant	k7	1
.constant	k8	2
.constant	k9	3
.constant	k10	63836

gettable      r0    r0    k0
settabup      u0    k1    k2
gettabup      r1    u0    k3
move          r2    r0
call          r1     2     4
jmp            0   l26
.label	l7
gettabup      r5    u0    k1
gettabup      r6    u0    k4
gettable      r6    r6    k5
gettable      r7    r0    r4
gettabup      r8    u0    k6
gettable      r8    r8    k7
add           r7    r7    r8
gettabup      r8    u0    k6
gettable      r8    r8    k8
add           r8    r8    r4
gettabup      r9    u0    k6
gettable      r9    r9    k9
add           r9    r9    r4
mul           r8    r8    r9
add           r7    r7    r8
mod           r7    r7   k10
call          r6     2     2
concat        r5    r5    r6
settabup      u0    k1    r5
.label	l26
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k1
return        r1     2
return        r0     1

.function	main/f0/f4

.linedefined	70
.lastlinedefined	77
.numparams	1
.is_vararg	0
.maxstacksize	8
.source	null

.upvalue	null	0	false

.constant	k0	"KEY2"
.constant	k1	"ipairs"
.constant	k2	"PGFUNCTION"
.constant	k3	"PGFC2"
.constant	k4	1
.constant	k5	2
.constant	k6	6
.constant	k7	3
.constant	k8	8
.constant	k9	4
.constant	k10	7
.constant	k11	5
.constant	k12	10
.constant	k13	9
.constant	k14	11
.constant	k15	12
.constant	k16	13
.constant	k17	14
.constant	k18	15
.constant	k19	16
.constant	k20	17
.constant	k21	18
.constant	k22	19
.constant	k23	20
.constant	k24	256
.constant	k25	"table"
.constant	k26	"insert"

newtable      r1     0     0
settabup      u0    k0    r1
gettabup      r1    u0    k1
move          r2    r0
call          r1     2     4
jmp            0   l75
.label	l7
gettable      r5    r0    r4
gettabup      r6    u0    k3
gettable      r6    r6    k4
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k5
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k6
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k7
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k8
gettabup      r7    u0    k3
gettable      r7    r7    k9
mul           r6    r6    r7
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k10
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k11
gettabup      r7    u0    k3
gettable      r7    r7   k12
mul           r6    r6    r7
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k13
gettabup      r7    u0    k3
gettable      r7    r7   k14
mul           r6    r6    r7
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k15
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k16
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k17
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k18
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k19
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k20
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k21
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k22
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k23
sub           r5    r5    r6
mod           r5    r5   k24
settabup      u0    k2    r5
gettabup      r5    u0   k25
gettable      r5    r5   k26
gettabup      r6    u0    k0
gettabup      r7    u0    k2
call          r5     3     1
.label	l75
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k0
return        r1     2
return        r0     1

.function	main/f0/f5

.linedefined	79
.lastlinedefined	86
.numparams	1
.is_vararg	0
.maxstacksize	10
.source	null

.upvalue	null	0	false

.constant	k0	"PG"
.constant	k1	"res"
.constant	k2	""
.constant	k3	"ipairs"
.constant	k4	"string"
.constant	k5	"char"
.constant	k6	"KEY2"
.constant	k7	1
.constant	k8	2
.constant	k9	3
.constant	k10	256

gettable      r0    r0    k0
settabup      u0    k1    k2
gettabup      r1    u0    k3
move          r2    r0
call          r1     2     4
jmp            0   l27
.label	l7
gettabup      r5    u0    k1
gettabup      r6    u0    k4
gettable      r6    r6    k5
gettable      r7    r0    r4
len           r7    r7
gettabup      r8    u0    k6
gettable      r8    r8    k7
add           r7    r7    r8
gettabup      r8    u0    k6
gettable      r8    r8    k8
add           r8    r8    r4
gettabup      r9    u0    k6
gettable      r9    r9    k9
add           r9    r9    r4
mul           r8    r8    r9
add           r7    r7    r8
mod           r7    r7   k10
call          r6     2     2
concat        r5    r5    r6
settabup      u0    k1    r5
.label	l27
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k1
return        r1     2
return        r0     1

.function	main/f0/f6

.linedefined	91
.lastlinedefined	98
.numparams	1
.is_vararg	0
.maxstacksize	8
.source	null

.upvalue	null	0	false

.constant	k0	"KEY3"
.constant	k1	"ipairs"
.constant	k2	"PGFUNCTION"
.constant	k3	"PGFC3"
.constant	k4	1
.constant	k5	2
.constant	k6	6
.constant	k7	3
.constant	k8	8
.constant	k9	4
.constant	k10	7
.constant	k11	5
.constant	k12	10
.constant	k13	9
.constant	k14	11
.constant	k15	12
.constant	k16	13
.constant	k17	14
.constant	k18	15
.constant	k19	16
.constant	k20	17
.constant	k21	18
.constant	k22	19
.constant	k23	20
.constant	k24	256
.constant	k25	"table"
.constant	k26	"insert"

newtable      r1     0     0
settabup      u0    k0    r1
gettabup      r1    u0    k1
move          r2    r0
call          r1     2     4
jmp            0   l75
.label	l7
gettable      r5    r0    r4
gettabup      r6    u0    k3
gettable      r6    r6    k4
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k5
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k6
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k7
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6    k8
gettabup      r7    u0    k3
gettable      r7    r7    k9
mul           r6    r6    r7
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k10
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k11
gettabup      r7    u0    k3
gettable      r7    r7   k12
mul           r6    r6    r7
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k13
gettabup      r7    u0    k3
gettable      r7    r7   k14
mul           r6    r6    r7
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k15
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k16
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k17
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k18
add           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k19
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k20
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k21
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k22
sub           r5    r5    r6
gettabup      r6    u0    k3
gettable      r6    r6   k23
sub           r5    r5    r6
mod           r5    r5   k24
settabup      u0    k2    r5
gettabup      r5    u0   k25
gettable      r5    r5   k26
gettabup      r6    u0    k0
gettabup      r7    u0    k2
call          r5     3     1
.label	l75
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k0
return        r1     2
return        r0     1

.function	main/f0/f7

.linedefined	100
.lastlinedefined	107
.numparams	1
.is_vararg	0
.maxstacksize	10
.source	null

.upvalue	null	0	false

.constant	k0	"PG"
.constant	k1	"res"
.constant	k2	""
.constant	k3	"ipairs"
.constant	k4	"string"
.constant	k5	"char"
.constant	k6	"KEY3"
.constant	k7	1
.constant	k8	2
.constant	k9	3
.constant	k10	53838

gettable      r0    r0    k0
settabup      u0    k1    k2
gettabup      r1    u0    k3
move          r2    r0
call          r1     2     4
jmp            0   l26
.label	l7
gettabup      r5    u0    k1
gettabup      r6    u0    k4
gettable      r6    r6    k5
gettable      r7    r0    r4
gettabup      r8    u0    k6
gettable      r8    r8    k7
add           r7    r7    r8
gettabup      r8    u0    k6
gettable      r8    r8    k8
add           r8    r8    r4
gettabup      r9    u0    k6
gettable      r9    r9    k9
add           r9    r9    r4
mul           r8    r8    r9
add           r7    r7    r8
mod           r7    r7   k10
call          r6     2     2
concat        r5    r5    r6
settabup      u0    k1    r5
.label	l26
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k1
return        r1     2
return        r0     1

.function	main/f0/f8

.linedefined	109
.lastlinedefined	116
.numparams	1
.is_vararg	0
.maxstacksize	10
.source	null

.upvalue	null	0	false

.constant	k0	"PG"
.constant	k1	"res"
.constant	k2	""
.constant	k3	"ipairs"
.constant	k4	"string"
.constant	k5	"char"
.constant	k6	"KEY"
.constant	k7	5
.constant	k8	6
.constant	k9	7
.constant	k10	256

gettable      r0    r0    k0
settabup      u0    k1    k2
gettabup      r1    u0    k3
move          r2    r0
call          r1     2     4
jmp            0   l27
.label	l7
gettabup      r5    u0    k1
gettabup      r6    u0    k4
gettable      r6    r6    k5
gettable      r7    r0    r4
len           r7    r7
gettabup      r8    u0    k6
gettable      r8    r8    k7
add           r7    r7    r8
gettabup      r8    u0    k6
gettable      r8    r8    k8
add           r8    r8    r4
gettabup      r9    u0    k6
gettable      r9    r9    k9
add           r9    r9    r4
mul           r8    r8    r9
add           r7    r7    r8
mod           r7    r7   k10
call          r6     2     2
concat        r5    r5    r6
settabup      u0    k1    r5
.label	l27
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k1
return        r1     2
return        r0     1

.function	main/f0/f9

.linedefined	118
.lastlinedefined	125
.numparams	1
.is_vararg	0
.maxstacksize	10
.source	null

.upvalue	null	0	false

.constant	k0	"PG"
.constant	k1	"res"
.constant	k2	""
.constant	k3	"ipairs"
.constant	k4	"string"
.constant	k5	"char"
.constant	k6	"KEY1"
.constant	k7	3
.constant	k8	4
.constant	k9	6
.constant	k10	53838

gettable      r0    r0    k0
settabup      u0    k1    k2
gettabup      r1    u0    k3
move          r2    r0
call          r1     2     4
jmp            0   l26
.label	l7
gettabup      r5    u0    k1
gettabup      r6    u0    k4
gettable      r6    r6    k5
gettable      r7    r0    r4
gettabup      r8    u0    k6
gettable      r8    r8    k7
add           r7    r7    r8
gettabup      r8    u0    k6
gettable      r8    r8    k8
add           r8    r8    r4
gettabup      r9    u0    k6
gettable      r9    r9    k9
add           r9    r9    r4
mul           r8    r8    r9
add           r7    r7    r8
mod           r7    r7   k10
call          r6     2     2
concat        r5    r5    r6
settabup      u0    k1    r5
.label	l26
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k1
return        r1     2
return        r0     1

.function	main/f0/f10

.linedefined	127
.lastlinedefined	134
.numparams	1
.is_vararg	0
.maxstacksize	10
.source	null

.upvalue	null	0	false

.constant	k0	"PG"
.constant	k1	"res"
.constant	k2	""
.constant	k3	"ipairs"
.constant	k4	"string"
.constant	k5	"char"
.constant	k6	"KEY3"
.constant	k7	3
.constant	k8	4
.constant	k9	5
.constant	k10	256

gettable      r0    r0    k0
settabup      u0    k1    k2
gettabup      r1    u0    k3
move          r2    r0
call          r1     2     4
jmp            0   l27
.label	l7
gettabup      r5    u0    k1
gettabup      r6    u0    k4
gettable      r6    r6    k5
gettable      r7    r0    r4
len           r7    r7
gettabup      r8    u0    k6
gettable      r8    r8    k7
add           r7    r7    r8
gettabup      r8    u0    k6
gettable      r8    r8    k8
add           r8    r8    r4
gettabup      r9    u0    k6
gettable      r9    r9    k9
add           r9    r9    r4
mul           r8    r8    r9
add           r7    r7    r8
mod           r7    r7   k10
call          r6     2     2
concat        r5    r5    r6
settabup      u0    k1    r5
.label	l27
tforcall      r1     1
tforloop      r3    l7
gettabup      r1    u0    k1
return        r1     2
return        r0     1

.function	main/f0/f11

.linedefined	135
.lastlinedefined	155
.numparams	1
.is_vararg	0
.maxstacksize	4
.source	null

.upvalue	null	0	false

.constant	k0	1
.constant	k1	155
.constant	k2	2
.constant	k3	255
.constant	k4	3
.constant	k5	55
.constant	k6	4
.constant	k7	71
.constant	k8	5
.constant	k9	6
.constant	k10	59
.constant	k11	7
.constant	k12	251
.constant	k13	8
.constant	k14	227
.constant	k15	9
.constant	k16	87
.constant	k17	10
.constant	k18	163
.constant	k19	"Dc"

loadnil       r1     0
test          r1     0
jmp            0    l6
closure       r1    f0
call          r1     1     1
.label	l6
newtable      r1     0    10
newtable      r2     1     0
loadk         r3    k1
setlist       r2     1     1
settable      r1    k0    r2
newtable      r2     1     0
loadk         r3    k3
setlist       r2     1     1
settable      r1    k2    r2
newtable      r2     1     0
loadk         r3    k5
setlist       r2     1     1
settable      r1    k4    r2
newtable      r2     1     0
loadk         r3    k7
setlist       r2     1     1
settable      r1    k6    r2
newtable      r2     1     0
loadk         r3    k4
setlist       r2     1     1
settable      r1    k8    r2
newtable      r2     1     0
loadk         r3   k10
setlist       r2     1     1
settable      r1    k9    r2
newtable      r2     1     0
loadk         r3   k12
setlist       r2     1     1
settable      r1   k11    r2
newtable      r2     1     0
loadk         r3   k14
setlist       r2     1     1
settable      r1   k13    r2
newtable      r2     1     0
loadk         r3   k16
setlist       r2     1     1
settable      r1   k15    r2
newtable      r2     1     0
loadk         r3   k18
setlist       r2     1     1
settable      r1   k17    r2
closure       r2    f1
settabup      u0   k19    r2
gettabup      r2    u0   k19
move          r3    r1
tailcall      r2     2
return        r2     0
return        r0     1

.function	main/f0/f11/f0

.linedefined	136
.lastlinedefined	136
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f11/f1

.linedefined	138
.lastlinedefined	153
.numparams	1
.is_vararg	0
.maxstacksize	21
.source	null

.upvalue	null	0	false

.constant	k0	9
.constant	k1	7
.constant	k2	1
.constant	k3	0
.constant	k4	75271
.constant	k5	41
.constant	k6	"O"
.constant	k7	"KEY3"
.constant	k8	5
.constant	k9	2
.constant	k10	256
.constant	k11	"table"
.constant	k12	"insert"

loadnil       r1     0
test          r1     0
jmp            0    l6
closure       r1    f0
call          r1     1     1
.label	l6
closure       r1    f1
closure       r2    f2
loadk         r3    k0
loadk         r4    k1
loadk         r5    k2
loadk         r6    k3
loadk         r7    k4
loadk         r8    k5
loadk         r9    k3
move         r10    r1
move         r11    r3
move         r12    r4
call         r10     3     2
move         r11    r2
move         r12    r6
move         r13    r5
call         r11     3     2
sub          r12   r10   r11
add          r12   r12    r5
sub          r12   r12    r5
newtable     r13     0     0
loadk        r14    k2
len          r15    r0
loadk        r16    k2
forprep      r14   l58
.label	l31
gettable     r18    r0   r17
gettable     r18   r18   r12
gettabup     r19    u0    k7
gettable     r19   r19    k8
sub          r18   r18   r19
gettabup     r19    u0    k7
gettable     r19   r19    k1
add          r18   r18   r19
gettabup     r19    u0    k7
gettable     r19   r19    k0
gettabup     r20    u0    k7
gettable     r20   r20    k8
mul          r19   r19   r20
sub          r18   r18   r19
gettabup     r19    u0    k7
gettable     r19   r19    k9
sub          r18   r18   r19
gettabup     r19    u0    k7
gettable     r19   r19    k2
add          r18   r18   r19
mod          r18   r18   k10
settable     r13    k6   r18
gettabup     r18    u0   k11
gettable     r18   r18   k12
move         r19   r13
gettable     r20   r13    k6
call         r18     3     1
.label	l58
forloop      r14   l31
return       r13     2
return        r0     1

.function	main/f0/f11/f1/f0

.linedefined	139
.lastlinedefined	139
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f11/f1/f1

.linedefined	140
.lastlinedefined	140
.numparams	2
.is_vararg	0
.maxstacksize	3
.source	null

sub           r2    r0    r1
return        r2     2
return        r0     1

.function	main/f0/f11/f1/f2

.linedefined	141
.lastlinedefined	141
.numparams	2
.is_vararg	0
.maxstacksize	3
.source	null

add           r2    r0    r1
return        r2     2
return        r0     1

.function	main/f0/f12

.linedefined	157
.lastlinedefined	172
.numparams	1
.is_vararg	0
.maxstacksize	21
.source	null

.upvalue	null	0	false
.upvalue	null	128	true

.constant	k0	9
.constant	k1	7
.constant	k2	1
.constant	k3	0
.constant	k4	75271
.constant	k5	41
.constant	k6	"PG"
.constant	k7	"ipairs"
.constant	k8	"hi"
.constant	k9	2
.constant	k10	6
.constant	k11	3
.constant	k12	8
.constant	k13	4
.constant	k14	5
.constant	k15	10
.constant	k16	256
.constant	k17	"table"
.constant	k18	"insert"
.constant	k19	"string"
.constant	k20	"char"
.constant	k21	"unpack"

loadnil       r1     0
test          r1     0
jmp            0    l6
closure       r1    f0
call          r1     1     1
.label	l6
closure       r1    f1
closure       r2    f2
loadk         r3    k0
loadk         r4    k1
loadk         r5    k2
loadk         r6    k3
loadk         r7    k4
loadk         r8    k5
loadk         r9    k3
move         r10    r1
move         r11    r3
move         r12    r4
call         r10     3     2
move         r11    r2
move         r12    r6
move         r13    r5
call         r11     3     2
sub          r12   r10   r11
add          r12   r12    r5
sub          r12   r12    r5
gettable      r0    r0    k6
newtable     r13     0     0
gettabup     r14    u0    k7
move         r15    r0
call         r14     2     4
jmp            0   l62
.label	l32
gettable     r18    r0   r17
gettable     r18   r18   r12
len          r18   r18
gettabup     r19    u1    k2
sub          r18   r18   r19
gettabup     r19    u1    k9
add          r18   r18   r19
gettabup     r19    u1   k10
sub          r18   r18   r19
gettabup     r19    u1   k11
add          r18   r18   r19
gettabup     r19    u1   k12
gettabup     r20    u1   k13
mul          r19   r19   r20
sub          r18   r18   r19
gettabup     r19    u1    k1
add          r18   r18   r19
gettabup     r19    u1   k14
gettabup     r20    u1   k15
mul          r19   r19   r20
sub          r18   r18   r19
gettabup     r19    u1    k0
add          r18   r18   r19
mod          r18   r18   k16
settable     r13    k8   r18
gettabup     r18    u0   k17
gettable     r18   r18   k18
move         r19   r13
gettable     r20   r13    k8
call         r18     3     1
.label	l62
tforcall     r14     1
tforloop     r16   l32
gettabup     r14    u0   k19
gettable     r14   r14   k20
gettabup     r15    u0   k17
gettable     r15   r15   k21
move         r16   r13
call         r15     2     0
tailcall     r14     0
return       r14     0
return        r0     1

.function	main/f0/f12/f0

.linedefined	158
.lastlinedefined	158
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f12/f1

.linedefined	159
.lastlinedefined	159
.numparams	2
.is_vararg	0
.maxstacksize	3
.source	null

sub           r2    r0    r1
return        r2     2
return        r0     1

.function	main/f0/f12/f2

.linedefined	160
.lastlinedefined	160
.numparams	2
.is_vararg	0
.maxstacksize	3
.source	null

loadnil       r2     0
test          r2     0
jmp            0    l6
closure       r2    f0
call          r2     1     1
.label	l6
add           r2    r0    r1
return        r2     2
return        r0     1

.function	main/f0/f12/f2/f0

.linedefined	160
.lastlinedefined	160
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f13

.linedefined	221
.lastlinedefined	221
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f13/f0

.linedefined	221
.lastlinedefined	221
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f13/f0/f0

.linedefined	221
.lastlinedefined	221
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f14

.linedefined	222
.lastlinedefined	222
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f14/f0

.linedefined	222
.lastlinedefined	222
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f14/f0/f0

.linedefined	222
.lastlinedefined	222
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f15

.linedefined	223
.lastlinedefined	223
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f15/f0

.linedefined	223
.lastlinedefined	223
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f15/f0/f0

.linedefined	223
.lastlinedefined	223
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f16

.linedefined	224
.lastlinedefined	224
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f16/f0

.linedefined	224
.lastlinedefined	224
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f16/f0/f0

.linedefined	224
.lastlinedefined	224
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f17

.linedefined	225
.lastlinedefined	225
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f17/f0

.linedefined	225
.lastlinedefined	225
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f17/f0/f0

.linedefined	225
.lastlinedefined	225
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f18

.linedefined	226
.lastlinedefined	226
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f18/f0

.linedefined	226
.lastlinedefined	226
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f18/f0/f0

.linedefined	226
.lastlinedefined	226
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f19

.linedefined	227
.lastlinedefined	227
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f19/f0

.linedefined	227
.lastlinedefined	227
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f19/f0/f0

.linedefined	227
.lastlinedefined	227
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f20

.linedefined	228
.lastlinedefined	228
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f20/f0

.linedefined	228
.lastlinedefined	228
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f20/f0/f0

.linedefined	228
.lastlinedefined	228
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f21

.linedefined	229
.lastlinedefined	229
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f21/f0

.linedefined	229
.lastlinedefined	229
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f21/f0/f0

.linedefined	229
.lastlinedefined	229
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f22

.linedefined	230
.lastlinedefined	230
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f22/f0

.linedefined	230
.lastlinedefined	230
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f22/f0/f0

.linedefined	230
.lastlinedefined	230
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f23

.linedefined	231
.lastlinedefined	231
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f23/f0

.linedefined	231
.lastlinedefined	231
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f23/f0/f0

.linedefined	231
.lastlinedefined	231
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f24

.linedefined	232
.lastlinedefined	232
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f24/f0

.linedefined	232
.lastlinedefined	232
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f24/f0/f0

.linedefined	232
.lastlinedefined	232
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f25

.linedefined	233
.lastlinedefined	233
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f25/f0

.linedefined	233
.lastlinedefined	233
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f25/f0/f0

.linedefined	233
.lastlinedefined	233
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f26

.linedefined	234
.lastlinedefined	234
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f26/f0

.linedefined	234
.lastlinedefined	234
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f26/f0/f0

.linedefined	234
.lastlinedefined	234
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f27

.linedefined	235
.lastlinedefined	235
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f27/f0

.linedefined	235
.lastlinedefined	235
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f27/f0/f0

.linedefined	235
.lastlinedefined	235
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f28

.linedefined	236
.lastlinedefined	236
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f28/f0

.linedefined	236
.lastlinedefined	236
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f28/f0/f0

.linedefined	236
.lastlinedefined	236
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f29

.linedefined	237
.lastlinedefined	237
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f29/f0

.linedefined	237
.lastlinedefined	237
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f29/f0/f0

.linedefined	237
.lastlinedefined	237
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f30

.linedefined	238
.lastlinedefined	238
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f30/f0

.linedefined	238
.lastlinedefined	238
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f30/f0/f0

.linedefined	238
.lastlinedefined	238
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f31

.linedefined	239
.lastlinedefined	239
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f31/f0

.linedefined	239
.lastlinedefined	239
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f31/f0/f0

.linedefined	239
.lastlinedefined	239
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f32

.linedefined	240
.lastlinedefined	240
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f32/f0

.linedefined	240
.lastlinedefined	240
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f32/f0/f0

.linedefined	240
.lastlinedefined	240
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f33

.linedefined	245
.lastlinedefined	245
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f33/f0

.linedefined	245
.lastlinedefined	245
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f33/f0/f0

.linedefined	245
.lastlinedefined	245
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f34

.linedefined	246
.lastlinedefined	246
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f34/f0

.linedefined	246
.lastlinedefined	246
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f34/f0/f0

.linedefined	246
.lastlinedefined	246
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f35

.linedefined	247
.lastlinedefined	247
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f35/f0

.linedefined	247
.lastlinedefined	247
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f35/f0/f0

.linedefined	247
.lastlinedefined	247
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f36

.linedefined	248
.lastlinedefined	248
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f36/f0

.linedefined	248
.lastlinedefined	248
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f36/f0/f0

.linedefined	248
.lastlinedefined	248
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f37

.linedefined	249
.lastlinedefined	249
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f37/f0

.linedefined	249
.lastlinedefined	249
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f37/f0/f0

.linedefined	249
.lastlinedefined	249
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f38

.linedefined	250
.lastlinedefined	250
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f38/f0

.linedefined	250
.lastlinedefined	250
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f38/f0/f0

.linedefined	250
.lastlinedefined	250
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f39

.linedefined	251
.lastlinedefined	251
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f39/f0

.linedefined	251
.lastlinedefined	251
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f39/f0/f0

.linedefined	251
.lastlinedefined	251
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f40

.linedefined	252
.lastlinedefined	252
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f40/f0

.linedefined	252
.lastlinedefined	252
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f40/f0/f0

.linedefined	252
.lastlinedefined	252
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f41

.linedefined	253
.lastlinedefined	253
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f41/f0

.linedefined	253
.lastlinedefined	253
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f41/f0/f0

.linedefined	253
.lastlinedefined	253
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f42

.linedefined	254
.lastlinedefined	254
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f42/f0

.linedefined	254
.lastlinedefined	254
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f42/f0/f0

.linedefined	254
.lastlinedefined	254
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f43

.linedefined	255
.lastlinedefined	255
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f43/f0

.linedefined	255
.lastlinedefined	255
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f43/f0/f0

.linedefined	255
.lastlinedefined	255
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f44

.linedefined	256
.lastlinedefined	256
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f44/f0

.linedefined	256
.lastlinedefined	256
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f44/f0/f0

.linedefined	256
.lastlinedefined	256
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f45

.linedefined	257
.lastlinedefined	257
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f45/f0

.linedefined	257
.lastlinedefined	257
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f45/f0/f0

.linedefined	257
.lastlinedefined	257
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f46

.linedefined	258
.lastlinedefined	258
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f46/f0

.linedefined	258
.lastlinedefined	258
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f46/f0/f0

.linedefined	258
.lastlinedefined	258
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f47

.linedefined	259
.lastlinedefined	259
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f47/f0

.linedefined	259
.lastlinedefined	259
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f47/f0/f0

.linedefined	259
.lastlinedefined	259
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f48

.linedefined	260
.lastlinedefined	260
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f48/f0

.linedefined	260
.lastlinedefined	260
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f48/f0/f0

.linedefined	260
.lastlinedefined	260
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f49

.linedefined	261
.lastlinedefined	261
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f49/f0

.linedefined	261
.lastlinedefined	261
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f49/f0/f0

.linedefined	261
.lastlinedefined	261
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f50

.linedefined	262
.lastlinedefined	262
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f50/f0

.linedefined	262
.lastlinedefined	262
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f50/f0/f0

.linedefined	262
.lastlinedefined	262
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f51

.linedefined	263
.lastlinedefined	263
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f51/f0

.linedefined	263
.lastlinedefined	263
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f51/f0/f0

.linedefined	263
.lastlinedefined	263
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f52

.linedefined	264
.lastlinedefined	264
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f52/f0

.linedefined	264
.lastlinedefined	264
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f52/f0/f0

.linedefined	264
.lastlinedefined	264
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53

.linedefined	280
.lastlinedefined	325
.numparams	1
.is_vararg	0
.maxstacksize	24
.source	null

.upvalue	null	0	false
.upvalue	null	129	true
.upvalue	null	130	true

.constant	k0	"_1"
.constant	k1	"_3"
.constant	k2	"_4"
.constant	k3	"_5"
.constant	k4	"_6"
.constant	k5	"_7"
.constant	k6	"_8"
.constant	k7	"_9"
.constant	k8	"_10"
.constant	k9	"_11"
.constant	k10	"_12"
.constant	k11	"_13"
.constant	k12	"_14"
.constant	k13	"_15"
.constant	k14	"_16"
.constant	k15	"_17"
.constant	k16	"_18"
.constant	k17	"_19"
.constant	k18	"_20"
.constant	k19	1
.constant	k20	0
.constant	k21	"sel"
.constant	k22	"data"
.constant	k23	nil
.constant	k24	"i"
.constant	k25	true
.constant	k26	false
.constant	k27	69
.constant	k28	"gsub"
.constant	k29	"PGENC_8"
.constant	k30	"PG"
.constant	k31	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k32	2
.constant	k33	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k34	3
.constant	k35	4

closure       r1    f0
settabup      u0    k0    r1
closure       r1    f1
settabup      u0    k1    r1
closure       r1    f2
settabup      u0    k1    r1
closure       r1    f3
settabup      u0    k2    r1
closure       r1    f4
settabup      u0    k3    r1
closure       r1    f5
settabup      u0    k4    r1
closure       r1    f6
settabup      u0    k5    r1
closure       r1    f7
settabup      u0    k6    r1
closure       r1    f8
settabup      u0    k7    r1
closure       r1    f9
settabup      u0    k8    r1
closure       r1   f10
settabup      u0    k9    r1
closure       r1   f11
settabup      u0   k10    r1
closure       r1   f12
settabup      u0   k11    r1
closure       r1   f13
settabup      u0   k12    r1
closure       r1   f14
settabup      u0   k13    r1
closure       r1   f15
settabup      u0   k14    r1
closure       r1   f16
settabup      u0   k15    r1
closure       r1   f17
settabup      u0   k16    r1
closure       r1   f18
settabup      u0   k17    r1
closure       r1   f19
settabup      u0   k18    r1
loadk         r1   k19
loadk         r2   k20
loadk         r3   k19
forprep       r1   l56
.label	l45
newtable      r5     0     0
gettable      r6    r5   k22
call          r6     1     2
settable      r5   k21    r6
gettable      r6    r5   k22
eq             1    r6   k23
jmp            0   l55
gettable      r6    r5   k22
call          r6     1     2
settable      r5   k21    r6
.label	l55
loadnil       r5     0
.label	l56
forloop       r1   l45
.label	l57
loadbool      r1     0     0
test          r1     0
jmp            0  l156
gettabup      r1    u0   k24
gettabup      r2    u0   k24
loadk         r3   k19
forprep       r1  l153
.label	l64
newtable      r5     0     0
gettable      r6    r5   k24
test          r6     0
jmp            0   l72
gettable      r6    r5   k24
move          r7    r5
call          r6     2     2
settable      r5   k24    r6
.label	l72
gettable      r6    r5   k24
gettable      r7    r5   k24
gettable      r8    r5   k24
forprep       r6  l139
.label	l76
newtable     r10     0     0
gettable     r11   r10   k24
test         r11     0
jmp            0   l83
gettable     r11   r10   k24
call         r11     1     2
settable     r10   k24   r11
.label	l83
move         r11    r5
gettable     r12   r10   k24
move         r13    r5
forprep      r11  l128
.label	l87
newtable     r15     0     0
gettable     r16   r15   k24
test         r16     0
jmp            0   l95
gettable     r16   r15   k24
move         r17    r5
call         r16     2     2
settable     r15   k24   r16
.label	l95
move         r16    r5
move         r17   r10
gettable     r18   r15   k24
forprep      r16  l117
.label	l99
newtable     r20     0     0
gettable     r21   r20   k24
test         r21     0
jmp            0  l107
gettable     r21   r20   k24
move         r22    r5
call         r21     2     2
settable     r20   k24   r21
.label	l107
newtable     r21     0     0
gettable     r22   r21   k24
test         r22     0
jmp            0  l117
bor          r22   r21   r15
bor          r22   r22   r10
bor          r22   r22    r5
move         r23    r5
call         r22     2     2
settable     r21   k24   r22
.label	l117
forloop      r16   l99
newtable     r16     0     0
gettable     r17   r16   k24
test         r17     0
jmp            0  l128
bor          r17   k25   r16
bor          r17   r17   r10
bor          r17   r17    r5
move         r18    r5
call         r17     2     2
settable     r16   k24   r17
.label	l128
forloop      r11   l87
newtable     r11     0     0
gettable     r12   r11   k24
test         r12     0
jmp            0  l139
bor          r12   k25   k26
bor          r12   r12   r11
bor          r12   r12    r5
move         r13    r5
call         r12     2     2
settable     r11   k24   r12
.label	l139
forloop       r6   l76
newtable      r6     0     0
gettable      r7    r6   k24
test          r7     0
jmp            0  l150
bor           r7   k25   k26
bor           r7    r7   k23
bor           r7    r7    r6
move          r8    r6
call          r7     2     2
settable      r6   k24    r7
.label	l150
bor           r7   k25   k26
bor           r7    r7   k23
return        r7     2
.label	l153
forloop       r1   l64
return        r0     1
jmp            0   l57
.label	l156
getupval      r1    u1
add           r1   k27    r1
getupval      r2    u2
add           r2   k27    r2
self          r3    r0   k28
gettabup      r5    u0   k29
newtable      r6     0     1
newtable      r7     0     4
newtable      r8     1     0
loadk         r9   k31
setlist       r8     1     1
settable      r7   k19    r8
newtable      r8     1     0
loadk         r9   k33
setlist       r8     1     1
settable      r7   k32    r8
newtable      r8     1     0
loadk         r9   k31
setlist       r8     1     1
settable      r7   k34    r8
newtable      r8     1     0
loadk         r9   k33
setlist       r8     1     1
settable      r7   k35    r8
settable      r6   k30    r7
call          r5     2     2
closure       r6   f20
call          r3     4     2
return        r3     2
return        r0     1

.function	main/f0/f53/f0

.linedefined	284
.lastlinedefined	284
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f0/f0

.linedefined	284
.lastlinedefined	284
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f0/f0/f0

.linedefined	284
.lastlinedefined	284
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f1

.linedefined	285
.lastlinedefined	285
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f1/f0

.linedefined	285
.lastlinedefined	285
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f1/f0/f0

.linedefined	285
.lastlinedefined	285
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f2

.linedefined	286
.lastlinedefined	286
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f2/f0

.linedefined	286
.lastlinedefined	286
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f2/f0/f0

.linedefined	286
.lastlinedefined	286
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f3

.linedefined	287
.lastlinedefined	287
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f3/f0

.linedefined	287
.lastlinedefined	287
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f3/f0/f0

.linedefined	287
.lastlinedefined	287
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f4

.linedefined	288
.lastlinedefined	288
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f4/f0

.linedefined	288
.lastlinedefined	288
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f4/f0/f0

.linedefined	288
.lastlinedefined	288
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f5

.linedefined	289
.lastlinedefined	289
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f5/f0

.linedefined	289
.lastlinedefined	289
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f5/f0/f0

.linedefined	289
.lastlinedefined	289
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f6

.linedefined	290
.lastlinedefined	290
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f6/f0

.linedefined	290
.lastlinedefined	290
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f6/f0/f0

.linedefined	290
.lastlinedefined	290
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f7

.linedefined	291
.lastlinedefined	291
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f7/f0

.linedefined	291
.lastlinedefined	291
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f7/f0/f0

.linedefined	291
.lastlinedefined	291
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f8

.linedefined	292
.lastlinedefined	292
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f8/f0

.linedefined	292
.lastlinedefined	292
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f8/f0/f0

.linedefined	292
.lastlinedefined	292
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f9

.linedefined	293
.lastlinedefined	293
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f9/f0

.linedefined	293
.lastlinedefined	293
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f9/f0/f0

.linedefined	293
.lastlinedefined	293
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f10

.linedefined	294
.lastlinedefined	294
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f10/f0

.linedefined	294
.lastlinedefined	294
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f10/f0/f0

.linedefined	294
.lastlinedefined	294
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f11

.linedefined	295
.lastlinedefined	295
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f11/f0

.linedefined	295
.lastlinedefined	295
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f11/f0/f0

.linedefined	295
.lastlinedefined	295
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f12

.linedefined	296
.lastlinedefined	296
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f12/f0

.linedefined	296
.lastlinedefined	296
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f12/f0/f0

.linedefined	296
.lastlinedefined	296
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f13

.linedefined	297
.lastlinedefined	297
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f13/f0

.linedefined	297
.lastlinedefined	297
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f13/f0/f0

.linedefined	297
.lastlinedefined	297
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f14

.linedefined	298
.lastlinedefined	298
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f14/f0

.linedefined	298
.lastlinedefined	298
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f14/f0/f0

.linedefined	298
.lastlinedefined	298
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f15

.linedefined	299
.lastlinedefined	299
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f15/f0

.linedefined	299
.lastlinedefined	299
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f15/f0/f0

.linedefined	299
.lastlinedefined	299
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f16

.linedefined	300
.lastlinedefined	300
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f16/f0

.linedefined	300
.lastlinedefined	300
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f16/f0/f0

.linedefined	300
.lastlinedefined	300
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f17

.linedefined	301
.lastlinedefined	301
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f17/f0

.linedefined	301
.lastlinedefined	301
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f17/f0/f0

.linedefined	301
.lastlinedefined	301
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f18

.linedefined	302
.lastlinedefined	302
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f18/f0

.linedefined	302
.lastlinedefined	302
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f18/f0/f0

.linedefined	302
.lastlinedefined	302
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f19

.linedefined	303
.lastlinedefined	303
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k0    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f19/f0

.linedefined	303
.lastlinedefined	303
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

.upvalue	null	0	false

.constant	k0	"e"
.constant	k1	"d"

jmp            0    l5
return        r0     1
.label	l3
gettabup      r0    u0    k0
call          r0     1     1
.label	l5
closure       r0    f0
settabup      u0    k1    r0
jmp            0    l3
return        r0     1

.function	main/f0/f53/f19/f0/f0

.linedefined	303
.lastlinedefined	303
.numparams	0
.is_vararg	0
.maxstacksize	2
.source	null

return        r0     1

.function	main/f0/f53/f20

.linedefined	325
.lastlinedefined	325
.numparams	1
.is_vararg	0
.maxstacksize	7
.source	null

.upvalue	null	1	true
.upvalue	null	0	false
.upvalue	null	2	true

.constant	k0	274877906944
.constant	k1	128
.constant	k2	"tonumber"
.constant	k3	16
.constant	k4	2
.constant	k5	1
.constant	k6	256
.constant	k7	"string"
.constant	k8	"char"

getupval      r1    u0
mod           r1    r1    k0
getupval      r2    u0
sub           r2    r2    r1
div           r2    r2    k0
mod           r3    r2    k1
gettabup      r4    u1    k2
move          r5    r0
loadk         r6    k3
call          r4     3     2
move          r0    r4
sub           r4    r2    r3
div           r4    r4    k1
add           r4    r0    r4
mul           r5    k4    r3
add           r5    r5    k5
mul           r4    r4    r5
mod           r4    r4    k6
getupval      r5    u2
mul           r5    r1    r5
add           r5    r5    r2
add           r5    r5    r0
add           r5    r5    r4
setupval      r5    u0
gettabup      r5    u1    k7
gettable      r5    r5    k8
move          r6    r4
tailcall      r5     2
return        r5     0
return        r0     1

.function	main/f0/f54

.linedefined	482
.lastlinedefined	617
.numparams	0
.is_vararg	0
.maxstacksize	12
.source	null

.upvalue	null	0	false
.upvalue	null	132	true

.constant	k0	"menu"
.constant	k1	"gg"
.constant	k2	"PGENC_7"
.constant	k3	"PG"
.constant	k4	1
.constant	k5	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k6	2
.constant	k7	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k8	3
.constant	k9	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k10	4
.constant	k11	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k12	5
.constant	k13	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k14	6
.constant	k15	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k16	"PGENC_8"
.constant	k17	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k18	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k19	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k20	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k21	7
.constant	k22	8
.constant	k23	9
.constant	k24	10
.constant	k25	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k26	11
.constant	k27	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k28	12
.constant	k29	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k30	13
.constant	k31	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k32	14
.constant	k33	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k34	15
.constant	k35	16
.constant	k36	17
.constant	k37	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k38	18
.constant	k39	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k40	19
.constant	k41	20
.constant	k42	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k43	21
.constant	k44	22
.constant	k45	23
.constant	k46	24
.constant	k47	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k48	25
.constant	k49	26
.constant	k50	27
.constant	k51	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k52	28
.constant	k53	29
.constant	k54	30
.constant	k55	31
.constant	k56	32
.constant	k57	33
.constant	k58	34
.constant	k59	35
.constant	k60	36
.constant	k61	37
.constant	k62	38
.constant	k63	39
.constant	k64	40
.constant	k65	41
.constant	k66	42
.constant	k67	43
.constant	k68	44
.constant	k69	45
.constant	k70	46
.constant	k71	47
.constant	k72	48
.constant	k73	49
.constant	k74	50
.constant	k75	51
.constant	k76	52
.constant	k77	53
.constant	k78	54
.constant	k79	55
.constant	k80	56
.constant	k81	57
.constant	k82	58
.constant	k83	59
.constant	k84	60
.constant	k85	61
.constant	k86	62
.constant	k87	nil
.constant	k88	"PGENC_3"
.constant	k89	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k90	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k91	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k92	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k93	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k94	"sleep"
.constant	k95	500
.constant	k96	"PGENC_1"
.constant	k97	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k98	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k99	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k100	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k101	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k102	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k103	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k104	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k105	"REGION_ANONYMOUS"
.constant	k106	"PGENC_5"
.constant	k107	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k108	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k109	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k110	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k111	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k112	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k113	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k114	"\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k115	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k116	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k117	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k118	"PGENC_2"
.constant	k119	24871
.constant	k120	24452
.constant	k121	24041
.constant	k122	23649
.constant	k123	23223
.constant	k124	22815
.constant	k125	22374
.constant	k126	21996
.constant	k127	21569
.constant	k128	21137
.constant	k129	20717
.constant	k130	20305
.constant	k131	"TYPE_DWORD"
.constant	k132	"SIGN_EQUAL"
.constant	k133	0
.constant	k134	-1
.constant	k135	"revert"
.constant	k136	"PGENC_4"
.constant	k137	51366
.constant	k138	51247
.constant	k139	51143
.constant	k140	50988
.constant	k141	50884
.constant	k142	50773
.constant	k143	50648
.constant	k144	50510
.constant	k145	50387
.constant	k146	50253
.constant	k147	100
.constant	k148	"ipairs"
.constant	k149	"flags"
.constant	k150	"value"
.constant	k151	"freeze"
.constant	k152	true
.constant	k153	"addListItems"
.constant	k154	2000
.constant	k155	"Exit"
.constant	k156	"joker"

gettabup      r0    u0    k1
gettabup      r1    u0    k2
newtable      r2     0     1
newtable      r3     0     6
settable      r3    k4    k5
settable      r3    k6    k7
settable      r3    k8    k9
settable      r3   k10   k11
settable      r3   k12   k13
settable      r3   k14   k15
settable      r2    k3    r3
call          r1     2     2
gettable      r0    r0    r1
newtable      r1     1     0
getupval      r2    u1
gettabup      r3    u0   k16
newtable      r4     0     1
newtable      r5     0    20
newtable      r6     1     0
loadk         r7   k17
setlist       r6     1     1
settable      r5    k4    r6
newtable      r6     1     0
loadk         r7   k18
setlist       r6     1     1
settable      r5    k6    r6
newtable      r6     1     0
loadk         r7   k19
setlist       r6     1     1
settable      r5    k8    r6
newtable      r6     1     0
loadk         r7   k17
setlist       r6     1     1
settable      r5   k10    r6
newtable      r6     1     0
loadk         r7   k17
setlist       r6     1     1
settable      r5   k12    r6
newtable      r6     1     0
loadk         r7   k20
setlist       r6     1     1
settable      r5   k14    r6
newtable      r6     1     0
loadk         r7   k17
setlist       r6     1     1
settable      r5   k21    r6
newtable      r6     1     0
loadk         r7   k15
setlist       r6     1     1
settable      r5   k22    r6
newtable      r6     1     0
loadk         r7   k19
setlist       r6     1     1
settable      r5   k23    r6
newtable      r6     1     0
loadk         r7   k25
setlist       r6     1     1
settable      r5   k24    r6
newtable      r6     1     0
loadk         r7   k27
setlist       r6     1     1
settable      r5   k26    r6
newtable      r6     1     0
loadk         r7   k29
setlist       r6     1     1
settable      r5   k28    r6
newtable      r6     1     0
loadk         r7   k31
setlist       r6     1     1
settable      r5   k30    r6
newtable      r6     1     0
loadk         r7   k33
setlist       r6     1     1
settable      r5   k32    r6
newtable      r6     1     0
loadk         r7   k31
setlist       r6     1     1
settable      r5   k34    r6
newtable      r6     1     0
loadk         r7   k15
setlist       r6     1     1
settable      r5   k35    r6
newtable      r6     1     0
loadk         r7   k37
setlist       r6     1     1
settable      r5   k36    r6
newtable      r6     1     0
loadk         r7   k39
setlist       r6     1     1
settable      r5   k38    r6
newtable      r6     1     0
loadk         r7   k37
setlist       r6     1     1
settable      r5   k40    r6
newtable      r6     1     0
loadk         r7   k42
setlist       r6     1     1
settable      r5   k41    r6
newtable      r6     1     0
loadk         r7   k18
setlist       r6     1     1
settable      r5   k43    r6
newtable      r6     1     0
loadk         r7   k29
setlist       r6     1     1
settable      r5   k44    r6
newtable      r6     1     0
loadk         r7   k25
setlist       r6     1     1
settable      r5   k45    r6
newtable      r6     1     0
loadk         r7   k39
setlist       r6     1     1
settable      r5   k46    r6
settable      r4    k3    r5
call          r3     2     0
call          r2     0     2
getupval      r3    u1
gettabup      r4    u0   k16
newtable      r5     0     1
newtable      r6     0     8
newtable      r7     1     0
loadk         r8   k19
setlist       r7     1     1
settable      r6    k4    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6    k6    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6    k8    r7
newtable      r7     1     0
loadk         r8   k39
setlist       r7     1     1
settable      r6   k10    r7
newtable      r7     1     0
loadk         r8   k19
setlist       r7     1     1
settable      r6   k12    r7
newtable      r7     1     0
loadk         r8   k29
setlist       r7     1     1
settable      r6   k14    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6   k21    r7
newtable      r7     1     0
loadk         r8   k19
setlist       r7     1     1
settable      r6   k22    r7
settable      r5    k3    r6
call          r4     2     0
call          r3     0     0
setlist       r1     0     1
loadnil       r2     0
getupval      r3    u1
gettabup      r4    u0   k16
newtable      r5     0     1
newtable      r6     0    32
newtable      r7     1     0
loadk         r8   k15
setlist       r7     1     1
settable      r6    k4    r7
newtable      r7     1     0
loadk         r8   k31
setlist       r7     1     1
settable      r6    k6    r7
newtable      r7     1     0
loadk         r8   k18
setlist       r7     1     1
settable      r6    k8    r7
newtable      r7     1     0
loadk         r8   k15
setlist       r7     1     1
settable      r6   k10    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6   k12    r7
newtable      r7     1     0
loadk         r8   k18
setlist       r7     1     1
settable      r6   k14    r7
newtable      r7     1     0
loadk         r8   k19
setlist       r7     1     1
settable      r6   k21    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6   k22    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6   k23    r7
newtable      r7     1     0
loadk         r8   k20
setlist       r7     1     1
settable      r6   k24    r7
newtable      r7     1     0
loadk         r8   k29
setlist       r7     1     1
settable      r6   k26    r7
newtable      r7     1     0
loadk         r8   k15
setlist       r7     1     1
settable      r6   k28    r7
newtable      r7     1     0
loadk         r8   k39
setlist       r7     1     1
settable      r6   k30    r7
newtable      r7     1     0
loadk         r8   k27
setlist       r7     1     1
settable      r6   k32    r7
newtable      r7     1     0
loadk         r8   k18
setlist       r7     1     1
settable      r6   k34    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6   k35    r7
newtable      r7     1     0
loadk         r8   k27
setlist       r7     1     1
settable      r6   k36    r7
newtable      r7     1     0
loadk         r8   k31
setlist       r7     1     1
settable      r6   k38    r7
newtable      r7     1     0
loadk         r8   k31
setlist       r7     1     1
settable      r6   k40    r7
newtable      r7     1     0
loadk         r8   k15
setlist       r7     1     1
settable      r6   k41    r7
newtable      r7     1     0
loadk         r8   k25
setlist       r7     1     1
settable      r6   k43    r7
newtable      r7     1     0
loadk         r8   k47
setlist       r7     1     1
settable      r6   k44    r7
newtable      r7     1     0
loadk         r8   k29
setlist       r7     1     1
settable      r6   k45    r7
newtable      r7     1     0
loadk         r8   k20
setlist       r7     1     1
settable      r6   k46    r7
newtable      r7     1     0
loadk         r8   k31
setlist       r7     1     1
settable      r6   k48    r7
newtable      r7     1     0
loadk         r8   k39
setlist       r7     1     1
settable      r6   k49    r7
newtable      r7     1     0
loadk         r8   k51
setlist       r7     1     1
settable      r6   k50    r7
newtable      r7     1     0
loadk         r8   k25
setlist       r7     1     1
settable      r6   k52    r7
newtable      r7     1     0
loadk         r8   k29
setlist       r7     1     1
settable      r6   k53    r7
newtable      r7     1     0
loadk         r8   k51
setlist       r7     1     1
settable      r6   k54    r7
newtable      r7     1     0
loadk         r8   k18
setlist       r7     1     1
settable      r6   k55    r7
newtable      r7     1     0
loadk         r8   k37
setlist       r7     1     1
settable      r6   k56    r7
newtable      r7     1     0
loadk         r8   k27
setlist       r7     1     1
settable      r6   k57    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6   k58    r7
newtable      r7     1     0
loadk         r8   k15
setlist       r7     1     1
settable      r6   k59    r7
newtable      r7     1     0
loadk         r8   k18
setlist       r7     1     1
settable      r6   k60    r7
newtable      r7     1     0
loadk         r8   k39
setlist       r7     1     1
settable      r6   k61    r7
newtable      r7     1     0
loadk         r8   k47
setlist       r7     1     1
settable      r6   k62    r7
newtable      r7     1     0
loadk         r8   k20
setlist       r7     1     1
settable      r6   k63    r7
newtable      r7     1     0
loadk         r8   k15
setlist       r7     1     1
settable      r6   k64    r7
newtable      r7     1     0
loadk         r8   k19
setlist       r7     1     1
settable      r6   k65    r7
newtable      r7     1     0
loadk         r8   k19
setlist       r7     1     1
settable      r6   k66    r7
newtable      r7     1     0
loadk         r8   k27
setlist       r7     1     1
settable      r6   k67    r7
newtable      r7     1     0
loadk         r8   k15
setlist       r7     1     1
settable      r6   k68    r7
newtable      r7     1     0
loadk         r8   k51
setlist       r7     1     1
settable      r6   k69    r7
newtable      r7     1     0
loadk         r8   k18
setlist       r7     1     1
settable      r6   k70    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6   k71    r7
newtable      r7     1     0
loadk         r8   k39
setlist       r7     1     1
settable      r6   k72    r7
newtable      r7     1     0
loadk         r8   k18
setlist       r7     1     1
settable      r6   k73    r7
newtable      r7     1     0
loadk         r8   k15
setlist       r7     1     1
settable      r6   k74    r7
newtable      r7     1     0
loadk         r8   k19
setlist       r7     1     1
settable      r6   k75    r7
newtable      r7     1     0
loadk         r8   k29
setlist       r7     1     1
settable      r6   k76    r7
newtable      r7     1     0
loadk         r8   k19
setlist       r7     1     1
settable      r6   k77    r7
newtable      r7     1     0
loadk         r8   k17
setlist       r7     1     1
settable      r6   k78    r7
newtable      r7     1     0
loadk         r8   k47
setlist       r7     1     1
settable      r6   k79    r7
newtable      r7     1     0
loadk         r8   k29
setlist       r7     1     1
settable      r6   k80    r7
newtable      r7     1     0
loadk         r8   k25
setlist       r7     1     1
settable      r6   k81    r7
newtable      r7     1     0
loadk         r8   k31
setlist       r7     1     1
settable      r6   k82    r7
newtable      r7     1     0
loadk         r8   k39
setlist       r7     1     1
settable      r6   k83    r7
newtable      r7     1     0
loadk         r8   k33
setlist       r7     1     1
settable      r6   k84    r7
newtable      r7     1     0
loadk         r8   k31
setlist       r7     1     1
settable      r6   k85    r7
newtable      r7     1     0
loadk         r8   k15
setlist       r7     1     1
settable      r6   k86    r7
settable      r5    k3    r6
call          r4     2     0
call          r3     0     0
call          r0     0     2
settabup      u0    k0    r0
gettabup      r0    u0    k0
eq             0    r0   k87
jmp            0  l488
gettabup      r0    u0    k1
gettabup      r1    u0   k88
newtable      r2     0     1
newtable      r3     0     5
settable      r3    k4   k89
settable      r3    k6   k33
settable      r3    k8   k90
settable      r3   k10   k91
settable      r3   k12   k92
settable      r2    k3    r3
call          r1     2     2
gettable      r0    r0    r1
getupval      r1    u1
gettabup      r2    u0   k16
newtable      r3     0     1
newtable      r4     0    12
newtable      r5     1     0
loadk         r6   k19
setlist       r5     1     1
settable      r4    k4    r5
newtable      r5     1     0
loadk         r6   k20
setlist       r5     1     1
settable      r4    k6    r5
newtable      r5     1     0
loadk         r6   k19
setlist       r5     1     1
settable      r4    k8    r5
newtable      r5     1     0
loadk         r6   k93
setlist       r5     1     1
settable      r4   k10    r5
newtable      r5     1     0
loadk         r6   k19
setlist       r5     1     1
settable      r4   k12    r5
newtable      r5     1     0
loadk         r6   k51
setlist       r5     1     1
settable      r4   k14    r5
newtable      r5     1     0
loadk         r6   k17
setlist       r5     1     1
settable      r4   k21    r5
newtable      r5     1     0
loadk         r6   k20
setlist       r5     1     1
settable      r4   k22    r5
newtable      r5     1     0
loadk         r6   k19
setlist       r5     1     1
settable      r4   k23    r5
newtable      r5     1     0
loadk         r6   k17
setlist       r5     1     1
settable      r4   k24    r5
newtable      r5     1     0
loadk         r6   k42
setlist       r5     1     1
settable      r4   k26    r5
newtable      r5     1     0
loadk         r6   k93
setlist       r5     1     1
settable      r4   k28    r5
settable      r3    k3    r4
call          r2     2     0
call          r1     0     0
call          r0     0     1
jmp            0 l1065
.label	l488
gettabup      r0    u0    k0
eq             0    r0    k4
jmp            0 l1059
gettabup      r0    u0    k1
gettabup      r1    u0   k88
newtable      r2     0     1
newtable      r3     0     5
settable      r3    k4   k89
settable      r3    k6   k33
settable      r3    k8   k90
settable      r3   k10   k91
settable      r3   k12   k92
settable      r2    k3    r3
call          r1     2     2
gettable      r0    r0    r1
getupval      r1    u1
gettabup      r2    u0   k16
newtable      r3     0     1
newtable      r4     0    27
newtable      r5     1     0
loadk         r6   k17
setlist       r5     1     1
settable      r4    k4    r5
newtable      r5     1     0
loadk         r6   k18
setlist       r5     1     1
settable      r4    k6    r5
newtable      r5     1     0
loadk         r6   k19
setlist       r5     1     1
settable      r4    k8    r5
newtable      r5     1     0
loadk         r6   k17
setlist       r5     1     1
settable      r4   k10    r5
newtable      r5     1     0
loadk         r6   k17
setlist       r5     1     1
settable      r4   k12    r5
newtable      r5     1     0
loadk         r6   k20
setlist       r5     1     1
settable      r4   k14    r5
newtable      r5     1     0
loadk         r6   k17
setlist       r5     1     1
settable      r4   k21    r5
newtable      r5     1     0
loadk         r6   k15
setlist       r5     1     1
settable      r4   k22    r5
newtable      r5     1     0
loadk         r6   k19
setlist       r5     1     1
settable      r4   k23    r5
newtable      r5     1     0
loadk         r6   k25
setlist       r5     1     1
settable      r4   k24    r5
newtable      r5     1     0
loadk         r6   k27
setlist       r5     1     1
settable      r4   k26    r5
newtable      r5     1     0
loadk         r6   k29
setlist       r5     1     1
settable      r4   k28    r5
newtable      r5     1     0
loadk         r6   k31
setlist       r5     1     1
settable      r4   k30    r5
newtable      r5     1     0
loadk         r6   k33
setlist       r5     1     1
settable      r4   k32    r5
newtable      r5     1     0
loadk         r6   k31
setlist       r5     1     1
settable      r4   k34    r5
newtable      r5     1     0
loadk         r6   k15
setlist       r5     1     1
settable      r4   k35    r5
newtable      r5     1     0
loadk         r6   k37
setlist       r5     1     1
settable      r4   k36    r5
newtable      r5     1     0
loadk         r6   k39
setlist       r5     1     1
settable      r4   k38    r5
newtable      r5     1     0
loadk         r6   k37
setlist       r5     1     1
settable      r4   k40    r5
newtable      r5     1     0
loadk         r6   k42
setlist       r5     1     1
settable      r4   k41    r5
newtable      r5     1     0
loadk         r6   k18
setlist       r5     1     1
settable      r4   k43    r5
newtable      r5     1     0
loadk         r6   k29
setlist       r5     1     1
settable      r4   k44    r5
newtable      r5     1     0
loadk         r6   k25
setlist       r5     1     1
settable      r4   k45    r5
newtable      r5     1     0
loadk         r6   k39
setlist       r5     1     1
settable      r4   k46    r5
newtable      r5     1     0
loadk         r6   k33
setlist       r5     1     1
settable      r4   k48    r5
newtable      r5     1     0
loadk         r6   k15
setlist       r5     1     1
settable      r4   k49    r5
newtable      r5     1     0
loadk         r6   k42
setlist       r5     1     1
settable      r4   k50    r5
newtable      r5     1     0
loadk         r6   k17
setlist       r5     1     1
settable      r4   k52    r5
newtable      r5     1     0
loadk         r6   k37
setlist       r5     1     1
settable      r4   k53    r5
newtable      r5     1     0
loadk         r6   k42
setlist       r5     1     1
settable      r4   k54    r5
newtable      r5     1     0
loadk         r6   k33
setlist       r5     1     1
settable      r4   k55    r5
newtable      r5     1     0
loadk         r6   k15
setlist       r5     1     1
settable      r4   k56    r5
newtable      r5     1     0
loadk         r6   k47
setlist       r5     1     1
settable      r4   k57    r5
newtable      r5     1     0
loadk         r6   k33
setlist       r5     1     1
settable      r4   k58    r5
newtable      r5     1     0
loadk         r6   k37
setlist       r5     1     1
settable      r4   k59    r5
newtable      r5     1     0
loadk         r6   k42
setlist       r5     1     1
settable      r4   k60    r5
newtable      r5     1     0
loadk         r6   k19
setlist       r5     1     1
settable      r4   k61    r5
newtable      r5     1     0
loadk         r6   k47
setlist       r5     1     1
settable      r4   k62    r5
newtable      r5     1     0
loadk         r6   k37
setlist       r5     1     1
settable      r4   k63    r5
newtable      r5     1     0
loadk         r6   k15
setlist       r5     1     1
settable      r4   k64    r5
newtable      r5     1     0
loadk         r6   k39
setlist       r5     1     1
settable      r4   k65    r5
newtable      r5     1     0
loadk         r6   k31
setlist       r5     1     1
settable      r4   k66    r5
settable      r3    k3    r4
call          r2     2     0
call          r1     0     0
call          r0     0     1
gettabup      r0    u0    k1
gettable      r0    r0   k94
loadk         r1   k95
call          r0     2     1
gettabup      r0    u0    k1
gettabup      r1    u0   k96
newtable      r2     0     1
newtable      r3     0     9
settable      r3    k4   k97
settable      r3    k6   k98
settable      r3    k8   k99
settable      r3   k10  k100
settable      r3   k12  k101
settable      r3   k14  k102
settable      r3   k21  k103
settable      r3   k22  k104
settable      r3   k23   k31
settable      r2    k3    r3
call          r1     2     2
gettable      r0    r0    r1
gettabup      r1    u0    k1
gettable      r1    r1  k105
call          r0     2     1
gettabup      r0    u0    k1
gettabup      r1    u0  k106
newtable      r2     0     1
newtable      r3     0    12
settable      r3    k4  k107
settable      r3    k6  k108
settable      r3    k8  k109
settable      r3   k10  k110
settable      r3   k12  k111
settable      r3   k14  k112
settable      r3   k21  k113
settable      r3   k22  k114
settable      r3   k23  k115
settable      r3   k24  k116
settable      r3   k26  k117
settable      r3   k28   k15
settable      r2    k3    r3
call          r1     2     2
gettable      r0    r0    r1
call          r0     1     1
gettabup      r0    u0    k1
gettabup      r1    u0  k118
newtable      r2     0     1
newtable      r3     0    12
settable      r3    k4  k119
settable      r3    k6  k120
settable      r3    k8  k121
settable      r3   k10  k122
settable      r3   k12  k123
settable      r3   k14  k124
settable      r3   k21  k125
settable      r3   k22  k126
settable      r3   k23  k127
settable      r3   k24  k128
settable      r3   k26  k129
settable      r3   k28  k130
settable      r2    k3    r3
call          r1     2     2
gettable      r0    r0    r1
getupval      r1    u1
gettabup      r2    u0   k16
newtable      r3     0     1
newtable      r4     0    16
newtable      r5     1     0
loadk         r6   k20
setlist       r5     1     1
settable      r4    k4    r5
newtable      r5     1     0
loadk         r6   k17
setlist       r5     1     1
settable      r4    k6    r5
newtable      r5     1     0
loadk         r6   k20
setlist       r5     1     1
settable      r4    k8    r5
newtable      r5     1     0
loadk         r6   k18
setlist       r5     1     1
settable      r4   k10    r5
newtable      r5     1     0
loadk         r6   k20
setlist       r5     1     1
settable      r4   k12    r5
newtable      r5     1     0
loadk         r6   k19
setlist       r5     1     1
settable      r4   k14    r5
newtable      r5     1     0
loadk         r6   k20
setlist       r5     1     1
settable      r4   k21    r5
newtable      r5     1     0
loadk         r6   k18
setlist       r5     1     1
settable      r4   k22    r5
newtable      r5     1     0
loadk         r6   k20
setlist       r5     1     1
settable      r4   k23    r5
newtable      r5     1     0
loadk         r6   k39
setlist       r5     1     1
settable      r4   k24    r5
newtable      r5     1     0
loadk         r6   k93
setlist       r5     1     1
settable      r4   k26    r5
newtable      r5     1     0
loadk         r6   k39
setlist       r5     1     1
settable      r4   k28    r5
newtable      r5     1     0
loadk         r6   k20
setlist       r5     1     1
settable      r4   k30    r5
newtable      r5     1     0
loadk         r6   k15
setlist       r5     1     1
settable      r4   k32    r5
newtable      r5     1     0
loadk         r6   k17
setlist       r5     1     1
settable      r4   k34    r5
newtable      r5     1     0
loadk         r6   k15
setlist       r5     1     1
settable      r4   k35    r5
settable      r3    k3    r4
call          r2     2     0
call          r1     0     2
gettabup      r2    u0    k1
gettable      r2    r2  k131
loadbool      r3     0     0
gettabup      r4    u0    k1
gettable      r4    r4  k132
loadk         r5  k133
loadk         r6  k134
loadk         r7  k133
call          r0     8     1
gettabup      r0    u0    k1
gettabup      r1    u0  k136
newtable      r2     0     1
newtable      r3     0    10
settable      r3    k4  k137
settable      r3    k6  k138
settable      r3    k8  k139
settable      r3   k10  k140
settable      r3   k12  k141
settable      r3   k14  k142
settable      r3   k21  k143
settable      r3   k22  k144
settable      r3   k23  k145
settable      r3   k24  k146
settable      r2    k3    r3
call          r1     2     2
gettable      r0    r0    r1
loadk         r1  k147
loadnil       r2     7
call          r0    10     2
settabup      u0  k135    r0
gettabup      r0    u0    k1
gettabup      r1    u0  k136
newtable      r2     0     1
newtable      r3     0    10
settable      r3    k4  k137
settable      r3    k6  k138
settable      r3    k8  k139
settable      r3   k10  k140
settable      r3   k12  k141
settable      r3   k14  k142
settable      r3   k21  k143
settable      r3   k22  k144
settable      r3   k23  k145
settable      r3   k24  k146
settable      r2    k3    r3
call          r1     2     2
gettable      r0    r0    r1
loadk         r1  k147
loadnil       r2     7
call          r0    10     2
gettabup      r1    u0  k148
move          r2    r0
call          r1     2     4
jmp            0  l888
.label	l866
gettable      r6    r5  k149
gettabup      r7    u0    k1
gettable      r7    r7  k131
eq             0    r6    r7
jmp            0  l888
getupval      r6    u1
gettabup      r7    u0   k16
newtable      r8     0     1
newtable      r9     0     2
newtable     r10     1     0
loadk        r11   k20
setlist      r10     1     1
settable      r9    k4   r10
newtable     r10     1     0
loadk        r11   k25
setlist      r10     1     1
settable      r9    k6   r10
settable      r8    k3    r9
call          r7     2     0
call          r6     0     2
settable      r5  k150    r6
settable      r5  k151  k152
.label	l888
tforcall      r1     2
tforloop      r3  l866
gettabup      r1    u0    k1
gettable      r1    r1  k153
move          r2    r0
call          r1     2     1
loadnil       r0     0
gettabup      r1    u0    k1
gettabup      r2    u0  k106
newtable      r3     0     1
newtable      r4     0    12
settable      r4    k4  k107
settable      r4    k6  k108
settable      r4    k8  k109
settable      r4   k10  k110
settable      r4   k12  k111
settable      r4   k14  k112
settable      r4   k21  k113
settable      r4   k22  k114
settable      r4   k23  k115
settable      r4   k24  k116
settable      r4   k26  k117
settable      r4   k28   k15
settable      r3    k3    r4
call          r2     2     2
gettable      r1    r1    r2
call          r1     1     1
gettabup      r1    u0    k1
gettable      r1    r1   k94
loadk         r2  k154
call          r1     2     1
gettabup      r1    u0    k1
gettabup      r2    u0   k88
newtable      r3     0     1
newtable      r4     0     5
settable      r4    k4   k89
settable      r4    k6   k33
settable      r4    k8   k90
settable      r4   k10   k91
settable      r4   k12   k92
settable      r3    k3    r4
call          r2     2     2
gettable      r1    r1    r2
getupval      r2    u1
gettabup      r3    u0   k16
newtable      r4     0     1
newtable      r5     0    23
newtable      r6     1     0
loadk         r7   k17
setlist       r6     1     1
settable      r5    k4    r6
newtable      r6     1     0
loadk         r7   k18
setlist       r6     1     1
settable      r5    k6    r6
newtable      r6     1     0
loadk         r7   k19
setlist       r6     1     1
settable      r5    k8    r6
newtable      r6     1     0
loadk         r7   k17
setlist       r6     1     1
settable      r5   k10    r6
newtable      r6     1     0
loadk         r7   k17
setlist       r6     1     1
settable      r5   k12    r6
newtable      r6     1     0
loadk         r7   k20
setlist       r6     1     1
settable      r5   k14    r6
newtable      r6     1     0
loadk         r7   k17
setlist       r6     1     1
settable      r5   k21    r6
newtable      r6     1     0
loadk         r7   k15
setlist       r6     1     1
settable      r5   k22    r6
newtable      r6     1     0
loadk         r7   k19
setlist       r6     1     1
settable      r5   k23    r6
newtable      r6     1     0
loadk         r7   k25
setlist       r6     1     1
settable      r5   k24    r6
newtable      r6     1     0
loadk         r7   k27
setlist       r6     1     1
settable      r5   k26    r6
newtable      r6     1     0
loadk         r7   k29
setlist       r6     1     1
settable      r5   k28    r6
newtable      r6     1     0
loadk         r7   k31
setlist       r6     1     1
settable      r5   k30    r6
newtable      r6     1     0
loadk         r7   k33
setlist       r6     1     1
settable      r5   k32    r6
newtable      r6     1     0
loadk         r7   k19
setlist       r6     1     1
settable      r5   k34    r6
newtable      r6     1     0
loadk         r7   k37
setlist       r6     1     1
settable      r5   k35    r6
newtable      r6     1     0
loadk         r7   k31
setlist       r6     1     1
settable      r5   k36    r6
newtable      r6     1     0
loadk         r7   k31
setlist       r6     1     1
settable      r5   k38    r6
newtable      r6     1     0
loadk         r7   k47
setlist       r6     1     1
settable      r5   k40    r6
newtable      r6     1     0
loadk         r7   k37
setlist       r6     1     1
settable      r5   k41    r6
newtable      r6     1     0
loadk         r7   k19
setlist       r6     1     1
settable      r5   k43    r6
newtable      r6     1     0
loadk         r7   k31
setlist       r6     1     1
settable      r5   k44    r6
newtable      r6     1     0
loadk         r7   k42
setlist       r6     1     1
settable      r5   k45    r6
newtable      r6     1     0
loadk         r7   k29
setlist       r6     1     1
settable      r5   k46    r6
newtable      r6     1     0
loadk         r7   k25
setlist       r6     1     1
settable      r5   k48    r6
newtable      r6     1     0
loadk         r7   k31
setlist       r6     1     1
settable      r5   k49    r6
newtable      r6     1     0
loadk         r7   k37
setlist       r6     1     1
settable      r5   k50    r6
newtable      r6     1     0
loadk         r7   k29
setlist       r6     1     1
settable      r5   k52    r6
newtable      r6     1     0
loadk         r7   k20
setlist       r6     1     1
settable      r5   k53    r6
newtable      r6     1     0
loadk         r7   k33
setlist       r6     1     1
settable      r5   k54    r6
settable      r4    k3    r5
call          r3     2     0
call          r2     0     0
call          r1     0     1
.label	l1059
gettabup      r0    u0    k0
eq             0    r0    k6
jmp            0 l1064
gettabup      r0    u0  k155
call          r0     1     1
.label	l1064
settabup      u0  k156  k134
.label	l1065
return        r0     1

.function	main/f0/f55

.linedefined	620
.lastlinedefined	628
.numparams	0
.is_vararg	0
.maxstacksize	4
.source	null

.upvalue	null	0	false

.constant	k0	"gg"
.constant	k1	"PGENC_5"
.constant	k2	"PG"
.constant	k3	1
.constant	k4	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k5	2
.constant	k6	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k7	3
.constant	k8	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k9	4
.constant	k10	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k11	5
.constant	k12	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k13	6
.constant	k14	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k15	7
.constant	k16	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k17	8
.constant	k18	"\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k19	9
.constant	k20	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k21	10
.constant	k22	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k23	11
.constant	k24	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k25	12
.constant	k26	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
.constant	k27	"os"
.constant	k28	"exit"

gettabup      r0    u0    k0
gettabup      r1    u0    k1
newtable      r2     0     1
newtable      r3     0    12
settable      r3    k3    k4
settable      r3    k5    k6
settable      r3    k7    k8
settable      r3    k9   k10
settable      r3   k11   k12
settable      r3   k13   k14
settable      r3   k15   k16
settable      r3   k17   k18
settable      r3   k19   k20
settable      r3   k21   k22
settable      r3   k23   k24
settable      r3   k25   k26
settable      r2    k2    r3
call          r1     2     2
gettable      r0    r0    r1
call          r0     1     1
gettabup      r0    u0   k27
gettable      r0    r0   k28
call          r0     1     1
return        r0     1


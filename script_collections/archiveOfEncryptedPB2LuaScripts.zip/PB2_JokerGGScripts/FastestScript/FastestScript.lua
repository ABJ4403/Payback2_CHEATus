function Home()
menu = gg.choice({
	"ALL POWERS GOD",
	"FULL HACKING CAR",
	"FLOAT (ON)",
	"FLOAT (OFF)",
	"RAGDOLL",
	"CLONE",
	"RESPAWN",
	"WALL HACK (ON)",
	"WALL HACK (OFF)",
	"999999999xp",
	"VOID MODE (LONG)",
	"SPEED HACK GRENADE",
	"INDESTRUCTIBLE FIRE BODY",
	"UNLIMITED COINS",
	"Exit"
},nil," Script by Joker GG Scripter ")
if menu == nil then
toast("CANCELLED")
else

if menu == 1 then
w = findEntityAnchr()
local q = {}
q[1] = {}
q[1].address = w + 0x4
q[1].flags = gg.TYPE_WORD
q[1].value = 1000
q[1].freeze = true
q[2] = {}
q[2].address = w + 0x6
q[2].flags = gg.TYPE_WORD
q[2].value = 1000
q[2].freeze = true
q[3] = {}
q[3].address = w + 0x8
q[3].flags = gg.TYPE_WORD
q[3].value = 1000
q[3].freeze = true
q[4] = {}
q[4].address = w + 0xA
q[4].flags = gg.TYPE_WORD
q[4].value = 1000
q[4].freeze = true
q[5] = {}
q[5].address = w + 0xC
q[5].flags = gg.TYPE_WORD
q[5].value = 1000
q[5].freeze = true
q[6] = {}
q[6].address = w + 0xE
q[6].flags = gg.TYPE_WORD
q[6].value = 1000
q[6].freeze = true
q[7] = {}
q[7].address = w + 0x10
q[7].flags = gg.TYPE_WORD
q[7].value = 1000
q[7].freeze = true
q[8] = {}
q[8].address = w + 0x12
q[8].flags = gg.TYPE_WORD
q[8].value = 32000
q[8].freeze = true
q[9] = {}
q[9].address = w + 0x140
q[9].flags = gg.TYPE_DWORD
q[9].value = 999999999
q[9].freeze = true
q[10] = {}
q[10].address = w + 0x6C
q[10].flags = gg.TYPE_WORD
q[10].value = 0
q[10].freeze = true
q[11] = {}
q[11].address = w - 0x10
q[11].flags = gg.TYPE_DWORD
q[11].value = 800
q[11].freeze = true
q[12] = {}
q[12].address = w - 0x1C
q[12].flags = gg.TYPE_DWORD
q[12].value = 0
q[12].freeze = true
q[13] = {}
q[13].address = w + 0x14
q[13].flags = gg.TYPE_DWORD
q[13].value = -1
q[13].freeze = true
q[14] = {}
q[14].address = w - 0x628
q[14].flags = gg.TYPE_DWORD
q[14].value = 0
q[14].freeze = true
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast(" ALL GOD POWERS ARE NOW YOURS ")
end

if menu == 2 then
w = findEntityAnchr()
local q = {}
q[1] = {}
q[1].address = w + 0x4
q[1].flags = gg.TYPE_WORD
q[1].value = 1000
q[1].freeze = true
q[2] = {}
q[2].address = w + 0x6
q[2].flags = gg.TYPE_WORD
q[2].value = 1000
q[2].freeze = true
q[3] = {}
q[3].address = w + 0x8
q[3].flags = gg.TYPE_WORD
q[3].value = 1000
q[3].freeze = true
q[4] = {}
q[4].address = w + 0xA
q[4].flags = gg.TYPE_WORD
q[4].value = 1000
q[4].freeze = true
q[5] = {}
q[5].address = w + 0xC
q[5].flags = gg.TYPE_WORD
q[5].value = 1000
q[5].freeze = true
q[6] = {}
q[6].address = w + 0xE
q[6].flags = gg.TYPE_WORD
q[6].value = 1000
q[6].freeze = true
q[7] = {}
q[7].address = w + 0x10
q[7].flags = gg.TYPE_WORD
q[7].value = 1000
q[7].freeze = true
q[8] = {}
q[8].address = w + 0x12
q[8].flags = gg.TYPE_WORD
q[8].value = 32000
q[8].freeze = true
q[9] = {}
q[9].address = w - 0x1C
q[9].flags = gg.TYPE_DWORD
q[9].value = 55685
q[9].freeze = true
q[10] = {}
q[10].address = w - 0x10
q[10].flags = gg.TYPE_DWORD
q[10].value = 0
q[10].freeze = true
q[11] = {}
q[11].address = w + 0x140
q[11].flags = gg.TYPE_DWORD
q[11].value = 999999999
q[11].freeze = true
q[12] = {}
q[12].address = w - 0x628
q[12].flags = gg.TYPE_DWORD
q[12].value = 0
q[12].freeze = true
q[13] = {}
q[13].address = w + 0x14
q[13].flags = gg.TYPE_DWORD
q[13].value = -1
q[13].freeze = true
q[14] = {}
q[14].address = w + 0x6C
q[14].flags = gg.TYPE_WORD
q[14].value = 0
q[14].freeze = true
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast("CAR FULL HACKED")
end

if menu == 3 then
w = findEntityAnchr()
local q = {}
q[1] = {}
q[1].address = w - 0x420
q[1].flags = gg.TYPE_DWORD
q[1].value = 1
q[1].freeze = true
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast(" FLOATING (ON) ")
end

if menu == 4 then
w = findEntityAnchr()
local q = {}
q[1] = {}
q[1].address = w - 0x420
q[1].flags = gg.TYPE_DWORD
q[1].value = 0
q[1].freeze = true
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast(" FLOATING (OFF) ")
end

if menu == 5 then
w = findEntityAnchr()
local q = {}
q[1] = {}
q[1].address = w + 0x4
q[1].flags = gg.TYPE_WORD
q[1].value = 30000
q[1].freeze = true
q[2] = {}
q[2].address = w + 0x6
q[2].flags = gg.TYPE_WORD
q[2].value = 30000
q[2].freeze = true
q[3] = {}
q[3].address = w + 0x8
q[3].flags = gg.TYPE_WORD
q[3].value = 30000
q[3].freeze = true
q[4] = {}
q[4].address = w + 0xA
q[4].flags = gg.TYPE_WORD
q[4].value = 30000
q[4].freeze = true
q[5] = {}
q[5].address = w + 0xC
q[5].flags = gg.TYPE_WORD
q[5].value = 30000
q[5].freeze = true
q[6] = {}
q[6].address = w + 0xE
q[6].flags = gg.TYPE_WORD
q[6].value = 30000
q[6].freeze = true
q[7] = {}
q[7].address = w + 0x10
q[7].flags = gg.TYPE_WORD
q[7].value = 30000
q[7].freeze = true
q[8] = {}
q[8].address = w + 0x12
q[8].flags = gg.TYPE_WORD
q[8].value = 32000
q[8].freeze = true
q[9] = {}
q[9].address = w - 0x628
q[9].flags = gg.TYPE_DWORD
q[9].value = 0
q[9].freeze = true
q[10] = {}
q[10].address = w - 0x10
q[10].flags = gg.TYPE_DWORD
q[10].value = 800
q[10].freeze = true
q[11] = {}
q[11].address = w - 0x1C
q[11].flags = gg.TYPE_DWORD
q[11].value = 0
q[11].freeze = true
q[12] = {}
q[12].address = w + 0x110
q[12].flags = gg.TYPE_DWORD
q[12].value = 0
q[12].freeze = true
q[12].freezeType = gg.FREEZE_IN_RANGE
q[12].freezeFrom = "0"
q[12].freezeTo = "120"
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast(" RAAAAGDOLLL BOOIII ")
end

if menu == 6 then
gg.setRanges(gg.REGION_ANONYMOUS + gg.REGION_OTHER)
gg.searchNumber("33554688", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)

revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
for i, v in ipairs(t) do
	if v.flags == gg.TYPE_DWORD then
		v.value = "0"
		v.freeze = true
	end
end
gg.addListItems(t)
t = nil
gg.clearResults()
toast(" YOU ARE CLONED ")
end

if menu == 7 then
gg.setRanges(gg.REGION_ANONYMOUS + gg.REGION_OTHER)

gg.clearResults()
gg.searchNumber("52428800", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)

revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
for i, v in ipairs(t) do
	if v.flags == gg.TYPE_DWORD then
		v.value = "1"
		v.freeze = true
	end
end
gg.addListItems(t)
t = nil
gg.clearResults()
gg.sleep(2000)
toast(" RESPAWNING..... ")
end

if menu == 8 then
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("1140457472", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
for i, v in ipairs(t) do
	if v.flags == gg.TYPE_DWORD then
		v.value = "-5000"
		v.freeze = true
	end
end
gg.addListItems(t)
t = nil
toast(" WALL HACK (ON) ")
end

if menu == 9 then
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("-5000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)

revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
for i, v in ipairs(t) do
	if v.flags == gg.TYPE_DWORD then
		v.value = "1140457472"
		v.freeze = true
	end
end
gg.addListItems(t)
t = nil
toast(" WALL HACK (OFF) ")
end

if menu == 10 then
gg.setRanges(gg.REGION_ANONYMOUS + gg.REGION_OTHER)
gg.searchNumber("1,014,817,001",gg.TYPE_DWORD)
w = gg.getResults(1)
local q = {}
q[1] = {}
q[1].address = w - 0x804
q[1].flags = gg.TYPE_DWORD
q[1].value = 999999999
q[1].freeze = true
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast("999999999xp")
end

if menu == 11 then
gg.setRanges(gg.REGION_ANONYMOUS + gg.REGION_OTHER)
gg.searchNumber("1,217,115,234",gg.TYPE_DWORD)
w = gg.getResults(1)
local q = {}
q[1] = {}
q[1].address = w + 0x1C4
q[1].flags = gg.TYPE_DWORD
q[1].value = 9
q[1].freeze = true
q[2] = {}
q[2].address = w + 0x1E0
q[2].flags = gg.TYPE_DWORD
q[2].value = 6
q[2].freeze = true
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast("VOID ACTIVATED")
end

if menu == 12 then
w = findEntityAnchr()
local q = {}
q[1] = {}
q[1].address = w + 0x4
q[1].flags = gg.TYPE_WORD
q[1].value = 1000
q[1].freeze = true
q[2] = {}
q[2].address = w + 0x6
q[2].flags = gg.TYPE_WORD
q[2].value = 1000
q[2].freeze = true
q[3] = {}
q[3].address = w + 0x8
q[3].flags = gg.TYPE_WORD
q[3].value = 1000
q[3].freeze = true
q[4] = {}
q[4].address = w + 0xA
q[4].flags = gg.TYPE_WORD
q[4].value = 1000
q[4].freeze = true
q[5] = {}
q[5].address = w + 0xC
q[5].flags = gg.TYPE_WORD
q[5].value = 1000
q[5].freeze = true
q[6] = {}
q[6].address = w + 0xE
q[6].flags = gg.TYPE_WORD
q[6].value = 1000
q[6].freeze = true
q[7] = {}
q[7].address = w + 0x10
q[7].flags = gg.TYPE_WORD
q[7].value = 1000
q[7].freeze = true
q[8] = {}
q[8].address = w + 0x12
q[8].flags = gg.TYPE_WORD
q[8].value = 32000
q[8].freeze = true
q[9] = {}
q[9].address = w + 0x140
q[9].flags = gg.TYPE_DWORD
q[9].value = 999999999
q[9].freeze = true
q[10] = {}
q[10].address = w + 0x68
q[10].flags = gg.TYPE_DOUBLE
q[10].value = 2
q[10].freeze = true
q[11] = {}
q[11].address = w + 0x6C
q[11].flags = gg.TYPE_WORD
q[11].value = -66
q[11].freeze = true
q[12] = {}
q[12].address = w - 0x628
q[12].flags = gg.TYPE_DWORD
q[12].value = 0
q[12].freeze = true
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast("GRENATE RUN ACTIVATED")
end

if menu == 13 then
w = findEntityAnchr()
local q = {}
q[1] = {}
q[1].address = w + 0x4
q[1].flags = gg.TYPE_WORD
q[1].value = 1000
q[1].freeze = true
q[2] = {}
q[2].address = w + 0x6
q[2].flags = gg.TYPE_WORD
q[2].value = 1000
q[2].freeze = true
q[3] = {}
q[3].address = w + 0x8
q[3].flags = gg.TYPE_WORD
q[3].value = 1000
q[3].freeze = true
q[4] = {}
q[4].address = w + 0xA
q[4].flags = gg.TYPE_WORD
q[4].value = 1000
q[4].freeze = true
q[5] = {}
q[5].address = w + 0xC
q[5].flags = gg.TYPE_WORD
q[5].value = 1000
q[5].freeze = true
q[6] = {}
q[6].address = w + 0xE
q[6].flags = gg.TYPE_WORD
q[6].value = 1000
q[6].freeze = true
q[7] = {}
q[7].address = w + 0x10
q[7].flags = gg.TYPE_WORD
q[7].value = 1000
q[7].freeze = true
q[8] = {}
q[8].address = w + 0x12
q[8].flags = gg.TYPE_WORD
q[8].value = 32000
q[8].freeze = true
q[9] = {}
q[9].address = w - 0x10
q[9].flags = gg.TYPE_DWORD
q[9].value = 800
q[9].freeze = true
q[10] = {}
q[10].address = w - 0x1C
q[10].flags = gg.TYPE_DWORD
q[10].value = 30000
q[10].freeze = true
q[11] = {}
q[11].address = w - 0x628
q[11].flags = gg.TYPE_DWORD
q[11].value = 0
q[11].freeze = true
q[12] = {}
q[12].address = w + 0x110
q[12].flags = gg.TYPE_DWORD
q[12].value = 0
q[12].freeze = true
q[12].freezeType = gg.FREEZE_IN_RANGE
q[12].freezeFrom = "0"
q[12].freezeTo = "120"
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast(" INDESTRUCTIBLE FIRE BODY ")
end

if menu == 14 then
gg.setRanges(gg.REGION_ANONYMOUS + gg.REGION_OTHER)
gg.searchNumber(1014817001,gg.TYPE_DWORD)
w = gg.getResults(1)
local q = {}
q[1] = {}
q[1].address = w - 0x608
q[1].flags = gg.TYPE_DWORD
q[1].value = 9999
q[1].freeze = true
gg.setValues(q)
gg.addListItems(q)
gg.clearResults()
toast(" UNLIMITED COINS ")
end

if menu == 15 then
exit()
end

JokerGGScripter = -1
end
end

function toast(str,fastmode)
	if fastmode == nil then fastmode = true end
	gg.toast(str,fastmode)
end
function findEntityAnchr()
	gg.setRanges(gg.REGION_OTHER)
	toast("Hold your pistol")
	gg.sleep(2e3)
	gg.searchNumber(13,gg.TYPE_DWORD,nil,nil,0xB0000000,0xD0000000)
	t = gg.getResults(200)
	while gg.getResultCount() > 1 do
		toast("Hold your knife")
		gg.sleep(2e3)
		gg.refineNumber(0)
		t = gg.getResults(200)
		if gg.getResultCount() == 1 then break
		elseif gg.getResultCount() == 0 then return
		elseif gg.getResultCount() == 2 then
			t = gg.getResults(2)
			if t[1].value == t[2].value then
				t = {t[1]}
				break
			end
		end
		toast("Hold your pistol")
		gg.sleep(2e3)
		gg.refineNumber(13)
		t = gg.getResults(200)
		if gg.getResultCount() == 0 then return
		elseif gg.getResultCount() == 2 then
			t = gg.getResults(2)
			if t[1].value == t[2].value then
				t = {t[1]}
				break
			end
		end
	end
	gg.clearResults()
	return t[1].address
	-- 0x18
end
function Exit()
gg.clearResults()
print(" Script made by Joker GG Scripter ")
os.exit()
end

while true do
if gg.isVisible(true) then
JokerGGScripter = 1
gg.setVisible(false)
JokerGGScripter = -1
Home()
end
end
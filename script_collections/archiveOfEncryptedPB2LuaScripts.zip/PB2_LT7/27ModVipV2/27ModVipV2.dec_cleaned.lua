L0_2 = gg
print"Script V2 The LT7 Pro 27\nBy MinFRE\n\nDecrypted by ABJ4403 using LuaTools."
function Home()
	local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3, L23_3
	L0_3 = gg.choice
	L1_3 = {}
	L2_3 = "1   💰UNLIMITED COINS💰"
	L3_3 = "2   💣GRANDA CORRIENDO💣"
	L4_3 = "3   😈SUPER MOD (VIP)😈"
	L5_3 = "4   ✌CARRO INDESTRUCTIBLE✌"
	L6_3 = "5   👑GRAFICOS RTX👑"
	L7_3 = "6      💪AUTO APARESER💪 + 🔫ARMAS🔫"
	L8_3 = "7.     :O ENTRAR EN TODO:O "
	L9_3 = "8.     :O ENTRAR EN TODO OFF:O"
	L10_3 = "9.      ⚠️EXPLOSION MASIVA⚠️ "
	L11_3 = "10.       DAÑAR CARROS"
	L12_3 = "11.       EXPLOSION MASIVA OFF"
	L13_3 = "12        VOLAR"
	L14_3 = "13.        MODO OSCURO"
	L15_3 = "14.        MOD OCURO OFF"
	L16_3 = "15.        99999999999999XP"
	L17_3 = "16.        MODO VOID"
	L18_3 = "17.        SALIR DEL SCRIPT"
	L19_3 = "18.        FLOTAR"
	L20_3 = "19.        FLOTAR OFF"
	L21_3 = "20.        FLOTAR2"
	L22_3 = "21.        FLOTAR OFF2"
	L23_3 = "E X I T"
	L1_3[1] = L2_3
	L1_3[2] = L3_3
	L1_3[3] = L4_3
	L1_3[4] = L5_3
	L1_3[5] = L6_3
	L1_3[6] = L7_3
	L1_3[7] = L8_3
	L1_3[8] = L9_3
	L1_3[9] = L10_3
	L1_3[10] = L11_3
	L1_3[11] = L12_3
	L1_3[12] = L13_3
	L1_3[13] = L14_3
	L1_3[14] = L15_3
	L1_3[15] = L16_3
	L1_3[16] = L17_3
	L1_3[17] = L18_3
	L1_3[18] = L19_3
	L1_3[19] = L20_3
	L1_3[20] = L21_3
	L1_3[21] = L22_3
	L1_3[22] = L23_3
	L2_3 = nil
	L3_3 = [[
Script by Joker GG Scripter MINFRE THE LT7 PRO 27

V2. ]]
	L0_3 = L0_3(L1_3, L2_3, L3_3)
	menu = L0_3
	L0_3 = menu
	if L0_3 == nil then
		L0_3 = gg
		L0_3 = L0_3.toast
		L1_3 = " CANCELLED "
		L0_3(L1_3)
	else
		L0_3 = menu
		if L0_3 == 1 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "1,014,817,001"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1544
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 9999
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = " ACTIVADO "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 2 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "KNIFE"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 4
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 1000
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[2] = L1_3
			L1_3 = L0_3[2]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 6
			L1_3.address = L2_3
			L1_3 = L0_3[2]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[2]
			L1_3.value = 1000
			L1_3 = L0_3[2]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[3] = L1_3
			L1_3 = L0_3[3]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 8
			L1_3.address = L2_3
			L1_3 = L0_3[3]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[3]
			L1_3.value = 1000
			L1_3 = L0_3[3]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[4] = L1_3
			L1_3 = L0_3[4]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 10
			L1_3.address = L2_3
			L1_3 = L0_3[4]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[4]
			L1_3.value = 1000
			L1_3 = L0_3[4]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[5] = L1_3
			L1_3 = L0_3[5]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 12
			L1_3.address = L2_3
			L1_3 = L0_3[5]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[5]
			L1_3.value = 1000
			L1_3 = L0_3[5]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[6] = L1_3
			L1_3 = L0_3[6]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 14
			L1_3.address = L2_3
			L1_3 = L0_3[6]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[6]
			L1_3.value = 1000
			L1_3 = L0_3[6]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[7] = L1_3
			L1_3 = L0_3[7]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 16
			L1_3.address = L2_3
			L1_3 = L0_3[7]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[7]
			L1_3.value = 1000
			L1_3 = L0_3[7]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[8] = L1_3
			L1_3 = L0_3[8]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 18
			L1_3.address = L2_3
			L1_3 = L0_3[8]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[8]
			L1_3.value = 32000
			L1_3 = L0_3[8]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[9] = L1_3
			L1_3 = L0_3[9]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 320
			L1_3.address = L2_3
			L1_3 = L0_3[9]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[9]
			L1_3.value = 999999999
			L1_3 = L0_3[9]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[10] = L1_3
			L1_3 = L0_3[10]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 104
			L1_3.address = L2_3
			L1_3 = L0_3[10]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DOUBLE
			L1_3.flags = L2_3
			L1_3 = L0_3[10]
			L1_3.value = 2
			L1_3 = L0_3[10]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[11] = L1_3
			L1_3 = L0_3[11]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 108
			L1_3.address = L2_3
			L1_3 = L0_3[11]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[11]
			L1_3.value = -66
			L1_3 = L0_3[11]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[12] = L1_3
			L1_3 = L0_3[12]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1576
			L1_3.address = L2_3
			L1_3 = L0_3[12]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[12]
			L1_3.value = 0
			L1_3 = L0_3[12]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = "GRENATE RUN ACTIVATED"
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 3 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "KNIFE"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 4
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 1000
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[2] = L1_3
			L1_3 = L0_3[2]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 6
			L1_3.address = L2_3
			L1_3 = L0_3[2]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[2]
			L1_3.value = 1000
			L1_3 = L0_3[2]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[3] = L1_3
			L1_3 = L0_3[3]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 8
			L1_3.address = L2_3
			L1_3 = L0_3[3]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[3]
			L1_3.value = 1000
			L1_3 = L0_3[3]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[4] = L1_3
			L1_3 = L0_3[4]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 10
			L1_3.address = L2_3
			L1_3 = L0_3[4]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[4]
			L1_3.value = 1000
			L1_3 = L0_3[4]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[5] = L1_3
			L1_3 = L0_3[5]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 12
			L1_3.address = L2_3
			L1_3 = L0_3[5]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[5]
			L1_3.value = 1000
			L1_3 = L0_3[5]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[6] = L1_3
			L1_3 = L0_3[6]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 14
			L1_3.address = L2_3
			L1_3 = L0_3[6]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[6]
			L1_3.value = 1000
			L1_3 = L0_3[6]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[7] = L1_3
			L1_3 = L0_3[7]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 16
			L1_3.address = L2_3
			L1_3 = L0_3[7]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[7]
			L1_3.value = 1000
			L1_3 = L0_3[7]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[8] = L1_3
			L1_3 = L0_3[8]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 18
			L1_3.address = L2_3
			L1_3 = L0_3[8]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[8]
			L1_3.value = 32000
			L1_3 = L0_3[8]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[9] = L1_3
			L1_3 = L0_3[9]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 320
			L1_3.address = L2_3
			L1_3 = L0_3[9]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[9]
			L1_3.value = 999999999
			L1_3 = L0_3[9]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[10] = L1_3
			L1_3 = L0_3[10]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 108
			L1_3.address = L2_3
			L1_3 = L0_3[10]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[10]
			L1_3.value = 0
			L1_3 = L0_3[10]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[11] = L1_3
			L1_3 = L0_3[11]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 16
			L1_3.address = L2_3
			L1_3 = L0_3[11]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[11]
			L1_3.value = 800
			L1_3 = L0_3[11]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[12] = L1_3
			L1_3 = L0_3[12]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 28
			L1_3.address = L2_3
			L1_3 = L0_3[12]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[12]
			L1_3.value = 0
			L1_3 = L0_3[12]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[13] = L1_3
			L1_3 = L0_3[13]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 20
			L1_3.address = L2_3
			L1_3 = L0_3[13]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[13]
			L1_3.value = -1
			L1_3 = L0_3[13]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[14] = L1_3
			L1_3 = L0_3[14]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1576
			L1_3.address = L2_3
			L1_3 = L0_3[14]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[14]
			L1_3.value = 0
			L1_3 = L0_3[14]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = " ACTIVADO "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 4 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "KNIFE"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 4
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 1000
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[2] = L1_3
			L1_3 = L0_3[2]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 6
			L1_3.address = L2_3
			L1_3 = L0_3[2]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[2]
			L1_3.value = 1000
			L1_3 = L0_3[2]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[3] = L1_3
			L1_3 = L0_3[3]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 8
			L1_3.address = L2_3
			L1_3 = L0_3[3]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[3]
			L1_3.value = 1000
			L1_3 = L0_3[3]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[4] = L1_3
			L1_3 = L0_3[4]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 10
			L1_3.address = L2_3
			L1_3 = L0_3[4]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[4]
			L1_3.value = 1000
			L1_3 = L0_3[4]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[5] = L1_3
			L1_3 = L0_3[5]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 12
			L1_3.address = L2_3
			L1_3 = L0_3[5]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[5]
			L1_3.value = 1000
			L1_3 = L0_3[5]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[6] = L1_3
			L1_3 = L0_3[6]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 14
			L1_3.address = L2_3
			L1_3 = L0_3[6]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[6]
			L1_3.value = 1000
			L1_3 = L0_3[6]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[7] = L1_3
			L1_3 = L0_3[7]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 16
			L1_3.address = L2_3
			L1_3 = L0_3[7]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[7]
			L1_3.value = 1000
			L1_3 = L0_3[7]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[8] = L1_3
			L1_3 = L0_3[8]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 18
			L1_3.address = L2_3
			L1_3 = L0_3[8]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[8]
			L1_3.value = 32000
			L1_3 = L0_3[8]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[9] = L1_3
			L1_3 = L0_3[9]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 28
			L1_3.address = L2_3
			L1_3 = L0_3[9]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[9]
			L1_3.value = 55685
			L1_3 = L0_3[9]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[10] = L1_3
			L1_3 = L0_3[10]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 16
			L1_3.address = L2_3
			L1_3 = L0_3[10]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[10]
			L1_3.value = 0
			L1_3 = L0_3[10]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[11] = L1_3
			L1_3 = L0_3[11]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 320
			L1_3.address = L2_3
			L1_3 = L0_3[11]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[11]
			L1_3.value = 999999999
			L1_3 = L0_3[11]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[12] = L1_3
			L1_3 = L0_3[12]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1576
			L1_3.address = L2_3
			L1_3 = L0_3[12]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[12]
			L1_3.value = 0
			L1_3 = L0_3[12]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[13] = L1_3
			L1_3 = L0_3[13]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 20
			L1_3.address = L2_3
			L1_3 = L0_3[13]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[13]
			L1_3.value = -1
			L1_3 = L0_3[13]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[14] = L1_3
			L1_3 = L0_3[14]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 108
			L1_3.address = L2_3
			L1_3 = L0_3[14]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[14]
			L1_3.value = 0
			L1_3 = L0_3[14]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = "ACTIVADO"
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 5 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_C_DATA
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "49"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L7_3 = 0
			L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			revert = L0_3
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			L1_3 = ipairs
			L2_3 = L0_3
			L1_3, L2_3, L3_3 = L1_3(L2_3)
			for L4_3, L5_3 in L1_3, L2_3, L3_3 do
				L6_3 = L5_3.flags
				L7_3 = gg
				L7_3 = L7_3.TYPE_DWORD
				if L6_3 == L7_3 then
					L5_3.value = "1"
					L5_3.freeze = true
				end
			end
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L0_3 = nil
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = " RXT ACTIVADO "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 6 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "KNIFE"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 4
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 30000
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[2] = L1_3
			L1_3 = L0_3[2]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 6
			L1_3.address = L2_3
			L1_3 = L0_3[2]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[2]
			L1_3.value = 30000
			L1_3 = L0_3[2]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[3] = L1_3
			L1_3 = L0_3[3]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 8
			L1_3.address = L2_3
			L1_3 = L0_3[3]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[3]
			L1_3.value = 30000
			L1_3 = L0_3[3]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[4] = L1_3
			L1_3 = L0_3[4]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 10
			L1_3.address = L2_3
			L1_3 = L0_3[4]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[4]
			L1_3.value = 30000
			L1_3 = L0_3[4]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[5] = L1_3
			L1_3 = L0_3[5]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 12
			L1_3.address = L2_3
			L1_3 = L0_3[5]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[5]
			L1_3.value = 30000
			L1_3 = L0_3[5]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[6] = L1_3
			L1_3 = L0_3[6]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 14
			L1_3.address = L2_3
			L1_3 = L0_3[6]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[6]
			L1_3.value = 30000
			L1_3 = L0_3[6]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[7] = L1_3
			L1_3 = L0_3[7]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 16
			L1_3.address = L2_3
			L1_3 = L0_3[7]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[7]
			L1_3.value = 30000
			L1_3 = L0_3[7]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[8] = L1_3
			L1_3 = L0_3[8]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 18
			L1_3.address = L2_3
			L1_3 = L0_3[8]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[8]
			L1_3.value = 32000
			L1_3 = L0_3[8]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[9] = L1_3
			L1_3 = L0_3[9]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1576
			L1_3.address = L2_3
			L1_3 = L0_3[9]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[9]
			L1_3.value = 0
			L1_3 = L0_3[9]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[10] = L1_3
			L1_3 = L0_3[10]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 16
			L1_3.address = L2_3
			L1_3 = L0_3[10]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[10]
			L1_3.value = 800
			L1_3 = L0_3[10]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[11] = L1_3
			L1_3 = L0_3[11]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 28
			L1_3.address = L2_3
			L1_3 = L0_3[11]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[11]
			L1_3.value = 0
			L1_3 = L0_3[11]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[12] = L1_3
			L1_3 = L0_3[12]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 272
			L1_3.address = L2_3
			L1_3 = L0_3[12]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[12]
			L1_3.value = 0
			L1_3 = L0_3[12]
			L1_3.freeze = true
			L1_3 = L0_3[12]
			L2_3 = gg
			L2_3 = L2_3.FREEZE_IN_RANGE
			L1_3.freezeType = L2_3
			L1_3 = L0_3[12]
			L1_3.freezeFrom = "0"
			L1_3 = L0_3[12]
			L1_3.freezeTo = "120"
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = " ACTIVADO "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 7 then
			gg.setRanges(gg.REGION_C_ALLOC)
			gg.searchNumber(1140457472,gg.TYPE_DWORD)
			revert = gg.getResults(100)
			for _,v in ipairs(L0_3) do
				if v.flags == gg.TYPE_DWORD then
					v.value = "-5000"
					v.freeze = true
				end
			end
			gg.addListItems(L0_3)
			L0_3 = nil
			L1_3 = gg.toast" ACTIVATED "
		end
		L0_3 = menu
		if L0_3 == 8 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_C_ALLOC
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "-5000"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L7_3 = 0
			L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			revert = L0_3
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			L1_3 = ipairs
			L2_3 = L0_3
			L1_3, L2_3, L3_3 = L1_3(L2_3)
			for L4_3, L5_3 in L1_3, L2_3, L3_3 do
				L6_3 = L5_3.flags
				L7_3 = gg
				L7_3 = L7_3.TYPE_DWORD
				if L6_3 == L7_3 then
					L5_3.value = "1140457472"
					L5_3.freeze = true
				end
			end
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L0_3 = nil
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = " WALL HACK (OFF) "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 9 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_CODE_APP
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "10,000,000.0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_FLOAT
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L7_3 = 0
			L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			revert = L0_3
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			L1_3 = ipairs
			L2_3 = L0_3
			L1_3, L2_3, L3_3 = L1_3(L2_3)
			for L4_3, L5_3 in L1_3, L2_3, L3_3 do
				L6_3 = L5_3.flags
				L7_3 = gg
				L7_3 = L7_3.TYPE_FLOAT
				if L6_3 == L7_3 then
					L5_3.value = "3000"
					L5_3.freeze = true
				end
			end
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L0_3 = nil
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = "\n ⚠️ ACTIVADO ⚠️"
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 10 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_CODE_APP
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "125"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L7_3 = 0
			L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			revert = L0_3
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			L1_3 = ipairs
			L2_3 = L0_3
			L1_3, L2_3, L3_3 = L1_3(L2_3)
			for L4_3, L5_3 in L1_3, L2_3, L3_3 do
				L6_3 = L5_3.flags
				L7_3 = gg
				L7_3 = L7_3.TYPE_DWORD
				if L6_3 == L7_3 then
					L5_3.value = "9999999"
					L5_3.freeze = true
				end
			end
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L0_3 = nil
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = [[

ACTIVADO]]
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 11 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_CODE_APP
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "3000"
			L2_3 = gg
			L2_3 = L2_3.TYPE_FLOAT
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L7_3 = 0
			L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			revert = L0_3
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			L1_3 = ipairs
			L2_3 = L0_3
			L1_3, L2_3, L3_3 = L1_3(L2_3)
			for L4_3, L5_3 in L1_3, L2_3, L3_3 do
				L6_3 = L5_3.flags
				L7_3 = gg
				L7_3 = L7_3.TYPE_FLOAT
				if L6_3 == L7_3 then
					L5_3.value = "10,000,000.0"
					L5_3.freeze = true
				end
			end
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L0_3 = nil
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = "\n ⚠️ APAGADO⚠️"
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 12 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_C_ALLOC
			L2_3 = gg
			L2_3 = L2_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "0.25F;1067869798D;1067869798D;1065353216D;1080326881D;1065353216D::37"
			L2_3 = gg
			L2_3 = L2_3.TYPE_FLOAT
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 5000
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			revert = L0_3
			L0_3 = gg
			L0_3 = L0_3.editAll
			L1_3 = "-20"
			L2_3 = gg
			L2_3 = L2_3.TYPE_FLOAT
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.clearResults
			L0_3()
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 900
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "\n🌀ACTIVADO🌀"
			L0_3(L1_3)
		end
		L0_3 = menu
		if L0_3 == 13 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_C_DATA
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "50"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L7_3 = 0
			L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			revert = L0_3
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			L1_3 = ipairs
			L2_3 = L0_3
			L1_3, L2_3, L3_3 = L1_3(L2_3)
			for L4_3, L5_3 in L1_3, L2_3, L3_3 do
				L6_3 = L5_3.flags
				L7_3 = gg
				L7_3 = L7_3.TYPE_DWORD
				if L6_3 == L7_3 then
					L5_3.value = "60"
					L5_3.freeze = true
				end
			end
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L0_3 = nil
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.sleep
			L2_3 = 100
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = "\n🌙ACTIVADO🌙"
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 14 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_C_DATA
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "60"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L7_3 = 0
			L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			revert = L0_3
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			L1_3 = ipairs
			L2_3 = L0_3
			L1_3, L2_3, L3_3 = L1_3(L2_3)
			for L4_3, L5_3 in L1_3, L2_3, L3_3 do
				L6_3 = L5_3.flags
				L7_3 = gg
				L7_3 = L7_3.TYPE_DWORD
				if L6_3 == L7_3 then
					L5_3.value = "50"
					L5_3.freeze = true
				end
			end
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L0_3 = nil
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.sleep
			L2_3 = 100
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = "\n🌙DESACTIVADO🌙"
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 15 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "1,014,817,001"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 2052
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 999999999
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = "999999999xp"
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 16 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "38654705671"
			L2_3 = gg
			L2_3 = L2_3.TYPE_QWORD
			L3_3 = false
			L4_3 = gg
			L4_3 = L4_3.SIGN_EQUAL
			L5_3 = 0
			L6_3 = -1
			L7_3 = 0
			L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			revert = L0_3
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 100
			L2_3 = nil
			L3_3 = nil
			L4_3 = nil
			L5_3 = nil
			L6_3 = nil
			L7_3 = nil
			L8_3 = nil
			L9_3 = nil
			L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
			L1_3 = ipairs
			L2_3 = L0_3
			L1_3, L2_3, L3_3 = L1_3(L2_3)
			for L4_3, L5_3 in L1_3, L2_3, L3_3 do
				L6_3 = L5_3.flags
				L7_3 = gg
				L7_3 = L7_3.TYPE_QWORD
				if L6_3 == L7_3 then
					L5_3.value = "38,654,705,673"
					L5_3.freeze = true
				end
			end
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L0_3 = nil
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = "\n ⏰ ACTIVADO ⏰ "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 17 then
			L0_3 = exit
			L0_3()
		end
		L0_3 = menu
		if L0_3 == 18 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "KNIFE"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1056
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 1
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = " FLOTAR BETA "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 19 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "KNIFE"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1056
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 0
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = " ACTIVADO "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 20 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "KNIFE"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1056
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 1
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = " FLOATING (ON) "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 21 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "KNIFE"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1056
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 0
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = " FLOATING (OFF) "
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 22 then
			L0_3 = gg
			L0_3 = L0_3.setRanges
			L1_3 = gg
			L1_3 = L1_3.REGION_ANONYMOUS
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "KNIFE"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "0"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.toast
			L1_3 = "PISTOL"
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.sleep
			L1_3 = 1000
			L0_3(L1_3)
			L0_3 = gg
			L0_3 = L0_3.refineNumber
			L1_3 = "13"
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.getResults
			L1_3 = 1
			L0_3 = L0_3(L1_3)
			w = L0_3
			L0_3 = {}
			L1_3 = {}
			L0_3[1] = L1_3
			L1_3 = L0_3[1]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 4
			L1_3.address = L2_3
			L1_3 = L0_3[1]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[1]
			L1_3.value = 1000
			L1_3 = L0_3[1]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[2] = L1_3
			L1_3 = L0_3[2]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 6
			L1_3.address = L2_3
			L1_3 = L0_3[2]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[2]
			L1_3.value = 1000
			L1_3 = L0_3[2]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[3] = L1_3
			L1_3 = L0_3[3]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 8
			L1_3.address = L2_3
			L1_3 = L0_3[3]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[3]
			L1_3.value = 1000
			L1_3 = L0_3[3]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[4] = L1_3
			L1_3 = L0_3[4]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 10
			L1_3.address = L2_3
			L1_3 = L0_3[4]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[4]
			L1_3.value = 1000
			L1_3 = L0_3[4]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[5] = L1_3
			L1_3 = L0_3[5]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 12
			L1_3.address = L2_3
			L1_3 = L0_3[5]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[5]
			L1_3.value = 1000
			L1_3 = L0_3[5]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[6] = L1_3
			L1_3 = L0_3[6]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 14
			L1_3.address = L2_3
			L1_3 = L0_3[6]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[6]
			L1_3.value = 1000
			L1_3 = L0_3[6]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[7] = L1_3
			L1_3 = L0_3[7]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 16
			L1_3.address = L2_3
			L1_3 = L0_3[7]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[7]
			L1_3.value = 1000
			L1_3 = L0_3[7]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[8] = L1_3
			L1_3 = L0_3[8]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 18
			L1_3.address = L2_3
			L1_3 = L0_3[8]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[8]
			L1_3.value = 32000
			L1_3 = L0_3[8]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[9] = L1_3
			L1_3 = L0_3[9]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 320
			L1_3.address = L2_3
			L1_3 = L0_3[9]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[9]
			L1_3.value = 999999999
			L1_3 = L0_3[9]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[10] = L1_3
			L1_3 = L0_3[10]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 104
			L1_3.address = L2_3
			L1_3 = L0_3[10]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DOUBLE
			L1_3.flags = L2_3
			L1_3 = L0_3[10]
			L1_3.value = 2
			L1_3 = L0_3[10]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[11] = L1_3
			L1_3 = L0_3[11]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 + 108
			L1_3.address = L2_3
			L1_3 = L0_3[11]
			L2_3 = gg
			L2_3 = L2_3.TYPE_WORD
			L1_3.flags = L2_3
			L1_3 = L0_3[11]
			L1_3.value = -66
			L1_3 = L0_3[11]
			L1_3.freeze = true
			L1_3 = {}
			L0_3[12] = L1_3
			L1_3 = L0_3[12]
			L2_3 = w
			L2_3 = L2_3[1]
			L2_3 = L2_3.address
			L2_3 = L2_3 - 1576
			L1_3.address = L2_3
			L1_3 = L0_3[12]
			L2_3 = gg
			L2_3 = L2_3.TYPE_DWORD
			L1_3.flags = L2_3
			L1_3 = L0_3[12]
			L1_3.value = 0
			L1_3 = L0_3[12]
			L1_3.freeze = true
			L1_3 = gg
			L1_3 = L1_3.setValues
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.addListItems
			L2_3 = L0_3
			L1_3(L2_3)
			L1_3 = gg
			L1_3 = L1_3.clearResults
			L1_3()
			L1_3 = gg
			L1_3 = L1_3.toast
			L2_3 = "GRENATE RUN ACTIVATED"
			L1_3(L2_3)
		end
		L0_3 = menu
		if L0_3 == 23 then
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = 13
			L2_3 = 2
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = 0
			L2_3 = 2
			L0_3(L1_3, L2_3)
			L0_3 = gg
			L0_3 = L0_3.searchNumber
			L1_3 = 13
			L2_3 = 2
			L0_3(L1_3, L2_3)
		end
		JokerGGScripter = -1
	end
end
function Exit()
	local L0_3, L1_3
	L0_3 = gg
	L0_3 = L0_3.clearResults
	L0_3()
	L0_3 = gg
	L0_3 = L0_3.toast
	L1_3 = " Script V2 THE LT7 PRO 27 "
	L0_3(L1_3)
	L0_3 = os
	L0_3 = L0_3.exit
	L0_3()
end
while true do
	while not gg.isVisible()do gg.sleep(100)end
	gg.setVisible(false)
	Home()
	gg.clearResults()
	collectgarbage()
end
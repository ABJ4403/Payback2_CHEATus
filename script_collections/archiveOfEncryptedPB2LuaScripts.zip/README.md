# Archives o' Encrypted PB2 lua script
This is archive of (almost) all encrypted stuff that i interested in
All rights reserved to each script owner, i do not own those encrypted lua scripts (.enc.lua).

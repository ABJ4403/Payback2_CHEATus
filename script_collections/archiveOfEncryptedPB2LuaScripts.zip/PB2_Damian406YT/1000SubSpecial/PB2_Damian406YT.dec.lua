--[[if gg.getFile():match("[^/]+$") == "script by Damian406YT.lua" then
else
  print("⚠ Do not change the name boss ⚠\n\n  Original Name: Script by Damian406yt.lua")
  return
end
if gg.getTargetPackage() == "net.apex_designs.payback2" then
else
  print("⚠ Use only in Payback 2 ⚠")
  os.exit()
end
gg.alert("[Damian406YT]\n\nThis script has:\n🔰 Weapons\n🔰 Cross walls\n🔰 Fly with the pistol\n🔰 Large body (it may not work)\n🔰 Destroy cars\n🔰 BETS OFF\n🔰 Remove Gui\n🔰 Increase camera\n🔰 Super Strong Lanflower\n🔰 No Bloom\n🔰 Destroy everything\n🔰 Mega Explanation\n🔰 Enjoy script: 3\n\n⚠️ It only works with CB ⚠️","Okay 👍")
gg.toast("\n⌛loading└⁠|⁠∵⁠|⁠┐⌛")
gg.sleep(1000)
gg.toast("\n⌛loading┌⁠|⁠∵⁠|⁠┘⌛")
gg.sleep(1000)
gg.toast("\n⌛loading└⁠|⁠∵⁠|⁠┐⌛")
gg.sleep(1000)
gg.toast("\n⌛loading┌⁠|⁠∵⁠|⁠┘⌛")
gg.sleep(1000)
gg.toast("abierto")]]
local on = "[🔵 ON ] "
local off = "[🔴 OFF ] "
Damian1 = off
Damian3 = off
Damian2 = off
Damian4 = off
Damian5 = off
Damian6 = off
Damian7 = off
Damian8 = off
Damian9 = off
Damian10 = off
function Home()
  gg.clearResults()
  local Damian = gg.choice({
    "➜ WEAPONS",
    "➜ BURN",
    Damian1 .. "➜ BIG BODY",
    Damian3 .. "➜ DESTROY ALL CARS",
    Damian2 .. "➜ PISTOL HACK",
    Damian4 .. "➜ WALL HACK",
    Damian5 .. "➜ FLOAT EVERYTHING",
    "➜ BOTS OFF",
    "➜ REMOVE GUI",
    Damian6 .. "➜ INCREASE CAMERA FOV",
    Damian7 .. "➜ MEGA EXPLOSION",
    Damian8 .. "➜ LANZALLAMAS (fire?) SUPER STRONG",
    Damian9 .. "➜ NO BLOOM",
    Damian10 .. "➜ DESTROY EVERYTHING",
    " ❌EXIT❌"
  },nil,"Damian PB2 Hax")
  if Damian == nil then
  elseif Damian == 1 then
    if Damian == 1 then
      gg.setRanges(gg.REGION_C_BSS)
      gg.toast("🔫Put the pistol🔫")
      gg.sleep(1000)
      gg.searchNumber("1.68155816e-43F;2.80259693e-44F;1.12103877e-42F;1.821688e-44F;0D~71131136D::61",gg.TYPE_DWORD)
      revert = gg.getResults(5000)
      local t = gg.getResults(5000)
      for i,v in ipairs(t) do
        if v.flags == gg.TYPE_DWORD then
          v.value = "71131136"
          v.freeze = true
        end
      end
      gg.addListItems(t)
      t = nil
      gg.clearResults()
      gg.toast("\n✔ARMAS (ON)✔")
    end
  elseif Damian == 2 then
    if Damian == 2 then
      gg.setRanges(gg.REGION_C_BSS)
      gg.searchNumber("1.68155816e-43F;0D;2.80259693e-44F;1.12103877e-42F;1.821688e-44F::45",gg.TYPE_DWORD)
      revert = gg.getResults(5000)
      local t = gg.getResults(5000)
      for i,v in ipairs(t) do
        if v.flags == gg.TYPE_DWORD then
          v.value = "9999"
          v.freeze = true
        end
      end
      gg.addListItems(t)
      t = nil
      gg.clearResults()
      gg.toast("\n✔QUEMARSE (ON)✔")
    end
  elseif Damian == 3 then
    if Damian1 == on then
      Damian1 = off
    else
      Damian1 = on
    end
    if Damian1 == on then
      gg.setRanges(gg.REGION_C_BSS)
      gg.clearResults()
      gg.toast("🔫Put the pistol🔫")
      gg.sleep(1000)
      gg.searchNumber("00000078h;00000014h;00000320h;0000000Dh;00010000h;00010000h",gg.TYPE_DWORD)
      gg.refineNumber("120",gg.TYPE_DWORD)
      w = gg.getResults(1)
      local q = {}
      q[1] = {}
      q[1].address = w[1].address + 544
      q[1].flags = gg.TYPE_FLOAT
      q[1].value = 5
      q[1].freeze = true
      gg.setValues(q)
      gg.addListItems(q)
      gg.clearResults()
      gg.toast("\n✔CUERPO GRANDE (ON)✔")
    else
      gg.setRanges(gg.REGION_C_BSS)
      gg.clearResults()
      gg.toast("🔫Put the pistol🔫")
      gg.sleep(1000)
      gg.searchNumber("00000078h;00000014h;00000320h;0000000Dh;00010000h;00010000h",gg.TYPE_DWORD)
      gg.refineNumber("120",gg.TYPE_DWORD)
      w = gg.getResults(1)
      local q = {}
      q[1] = {}
      q[1].address = w[1].address + 544
      q[1].flags = gg.TYPE_FLOAT
      q[1].value = 1
      q[1].freeze = false
      gg.setValues(q)
      gg.addListItems(q)
      gg.clearResults()
      gg.toast("\n✔CUERPO GRANDE (OFF)✔")
    end
  elseif Damian == 4 then
    if Damian3 == on then
      Damian3 = off
    else
      Damian3 = on
    end
    if Damian3 == on then
      gg.setRanges(gg.REGION_C_BSS)
      gg.clearResults()
      gg.searchNumber("3F5F773Ch;3F62C531h;3F661014h;3F6957F5h;3F6C9CE6h",gg.TYPE_DWORD)
      revert = gg.getResults(99999)
      gg.editAll("-1006481408",gg.TYPE_DWORD) -- just edit the 4th number
      gg.clearResults()
      gg.toast("\n✔DESTRUIR TODOS LOS CARROS (ON)✔")
    else
      gg.setRanges(gg.REGION_C_BSS)
      gg.clearResults()
      gg.searchNumber("-1006481408",gg.TYPE_DWORD)
      revert = gg.getResults(99999)
      gg.editAll("3F5F773Ch;3F62C531h;3F661014h;3F6957F5h;3F6C9CE6h",gg.TYPE_DWORD)
      gg.clearResults()
      gg.toast("\n✔DESTRUIR TODOS LOS CARROS (OFF)✔")
    end
  elseif Damian == 5 then
    if Damian2 == on then
      Damian2 = off
    else
      Damian2 = on
    end
    if Damian2 == on then
      gg.setRanges(gg.REGION_CODE_APP)
      gg.searchNumber("-60;0.00100000005 ",gg.TYPE_FLOAT)
      gg.refineNumber("-60",gg.TYPE_FLOAT)
      revert = gg.getResults(5000)
      gg.editAll("-10000",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔VOLAR CON LA PISTOLA (ON)✔")
    else
      gg.setRanges(gg.REGION_CODE_APP)
      gg.searchNumber("-10000;0.00100000005",gg.TYPE_FLOAT)
      gg.refineNumber("-10000",gg.TYPE_FLOAT)
      revert = gg.getResults(5000)
      gg.editAll("-60",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔VOLAR CON LA PISTOLA (OFF)✔")
    end
  elseif Damian == 6 then
    if Damian4 == on then
      Damian4 = off
    else
      Damian4 = on
    end
    if Damian4 == on then
      gg.clearResults()
      gg.setRanges(gg.REGION_C_ALLOC)
      gg.searchNumber("500;1140457472D",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("2140457472",gg.TYPE_DWORD)
      gg.clearResults()
      gg.toast("\n✔ATRAVESAR PAREDES (ON)✔")
    else
      gg.clearResults()
      gg.setRanges(gg.REGION_C_ALLOC)
      gg.searchNumber("2140457472",gg.TYPE_DWORD)
      revert = gg.getResults(100000)
      gg.editAll("1140457472",gg.TYPE_DWORD)
      gg.clearResults()
      gg.toast("\n✔ATRAVESAR PAREDES (OFF)✔")
    end
  elseif Damian == 7 then
    if Damian5 == on then
      Damian5 = off
    else
      Damian5 = on
    end
    if Damian5 == on then
      gg.clearResults()
      gg.setRanges(gg.REGION_C_BSS)
      gg.searchNumber("0.00476388913",gg.TYPE_FLOAT)
      revert = gg.getResults(99999)
      gg.editAll("-0.03333333507 ",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.setRanges(gg.REGION_C_DATA)
      gg.searchNumber("17.14999961853",gg.TYPE_FLOAT)
      revert = gg.getResults(99999)
      gg.editAll("-120",gg.TYPE_FLOAT)
      gg.toast("\n✔todo vuela (ON)✔")
      gg.clearResults()
    else
      gg.setRanges(gg.REGION_C_BSS)
      gg.searchNumber("-0.03333333507",gg.TYPE_FLOAT)
      revert = gg.getResults(99999)
      gg.editAll("0.00476388913",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.setRanges(gg.REGION_C_DATA)
      gg.searchNumber("-120",gg.TYPE_FLOAT)
      revert = gg.getResults(99999)
      gg.editAll("17.14999961853",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔todo vuela (OFF)✔")
    end
  elseif Damian == 8 then
    if Damian == 8 then
      gg.setRanges(gg.REGION_C_BSS)
      gg.clearResults()
      gg.searchNumber("52428800D;3.60133705e-43",gg.TYPE_FLOAT)
      revert = gg.getResults(99999)
      gg.editAll("0",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔ bots (OFF)✔")
    end
  elseif Damian == 9 then
    if Damian == 9 then
      gg.setRanges(gg.REGION_C_BSS)
      gg.clearResults()
      gg.searchNumber("38;1;2W;8;9;10;21;22;31;32;2;3;4::",gg.TYPE_DWORD)
      revert = gg.getResults(100000)
      gg.editAll("1",gg.TYPE_WORD)
      gg.clearResults()
      gg.toast("\n✔pantalla limpia (ON)✔")
    end
  elseif Damian == 10 then
    if Damian6 == on then
      Damian6 = off
    else
      Damian6 = on
    end
    if Damian6 == on then
      gg.setRanges(gg.REGION_CODE_APP)
      gg.clearResults()
      gg.searchNumber("0.02812499925 ",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("0.06812500298",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.searchNumber("36.33300018311",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("16.33300018311",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔aumentar camara (ON)✔")
    else
      gg.clearResults()
      gg.setRanges(gg.REGION_CODE_APP)
      gg.searchNumber("0.06812500298",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("0.02812499925",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.searchNumber("16.33300018311",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("36.33300018311",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔aumentar camara (OFF)✔")
    end
  elseif Damian == 11 then
    if Damian7 == on then
      Damian7 = off
    else
      Damian7 = on
    end
    if Damian7 == on then
      gg.setRanges(gg.REGION_CODE_APP)
      gg.clearResults()
      gg.searchNumber("10000000",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("1.025",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔mega exploción (ON)✔")
    else
      gg.clearResults()
      gg.setRanges(gg.REGION_CODE_APP)
      gg.searchNumber("1.025",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("10000000",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔mega exploción (OFF)✔")
    end
  elseif Damian == 12 then
    if Damian8 == on then
      Damian8 = off
    else
      Damian8 = on
    end
    if Damian8 == on then
      gg.setRanges(gg.REGION_C_ALLOC)
      gg.clearResults()
      gg.searchNumber("2.42449353e-38;1",gg.TYPE_FLOAT)
      gg.refineNumber("1",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("9000",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔lanzallamas super fuerte(ON)✔")
    else
      gg.setRanges(gg.REGION_C_ALLOC)
      gg.clearResults()
      gg.searchNumber("2.42449353e-38;9000",gg.TYPE_FLOAT)
      gg.refineNumber("9000",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("1",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔lanzallamas super fuerte(OFF)✔")
    end
  elseif Damian == 13 then
    if Damian9 == on then
      Damian9 = off
    else
      Damian9 = on
    end
    if Damian9 == on then
      gg.setRanges(gg.REGION_CODE_APP)
      gg.clearResults()
      gg.searchNumber("0.6;0.00061523437",gg.TYPE_FLOAT)
      gg.refineNumber("0.6",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("99999999999999",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔no bloom(ON)✔")
    else
      gg.setRanges(gg.REGION_CODE_APP)
      gg.clearResults()
      gg.searchNumber("99999999999999;0.00061523437",gg.TYPE_FLOAT)
      gg.refineNumber("99999999999999",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("0.6",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔no bloom(OFF)✔")
    end
  elseif Damian == 14 then
    if Damian10 == on then
      Damian10 = off
    else
      Damian10 = on
    end
    if Damian10 == on then
      gg.setRanges(gg.REGION_CODE_APP)
      gg.clearResults()
      gg.searchNumber("576",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("-576",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔destruir todo (ON)✔")
    else
      gg.setRanges(gg.REGION_CODE_APP)
      gg.clearResults()
      gg.searchNumber("-576",gg.TYPE_FLOAT)
      revert = gg.getResults(100000)
      gg.editAll("576",gg.TYPE_FLOAT)
      gg.clearResults()
      gg.toast("\n✔destruir todo (OFF)✔")
    end
  elseif Damian == 15 then
    if Damian == 15 then
      gg.clearResults()
      gg.clearList()
      --[[gg.toast("\n      🙏Gracias a ti🙏\n↪🔸Damian406YT🔸↩")
      print("\n💻Youtube: Damian406YT")
      print("╔╗﹏﹏﹏﹏\n║╚╗╔╦╗╔═╗\n║╬║║║║║╩╣\n╚═╝╠╗║╚═╝\n﹏﹏╚═╝﹏﹏﹏")
      print("█████████\n█▄█████▄█\n█▼▼▼▼▼\n█ PAYBACK2\n█▲▲▲▲▲\n█████████\n██ ██")
      print("\n\n🇨🇴")]]
      os.exit(--[[13933325]])
    end
    Damian406YT = -1
  end
end
while true do
  if gg.isVisible() then
    gg.setVisible(false)
    Home()
    gg.sleep(100)
  end
end
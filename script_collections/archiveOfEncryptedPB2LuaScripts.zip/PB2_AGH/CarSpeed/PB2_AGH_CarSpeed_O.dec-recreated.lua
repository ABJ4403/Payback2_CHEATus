--[[

	This is a FOSS replica of decrypted Cars Speed Hack that AlphaGG Made.
	Recreated by ABJ4403, Original By AlphaGG.
	Difference between the encrypted and replica version:
	- AlphaGG Credits not changed.
	- This replica Had my credit (very tiny, shouldnt be annonying enough, altough you can just remove it manually lol. located on function Exit())
	- This replica didn't require password to use.
	- This replica had some optimization applied (garbage collection, local values, potentially different while true thingy, simpler script (remember that simple = fast))
	- Because this replica isnt encrypted, you can use multiple memory regions in one file, by changing the gg.setRanges() below.
	- The encrypted version needs you to pick either one, and you cant use all memory region at the same time because theres just no way to just change the gg.REGION_ thing
	- The encrypted version is slow, because they need to decrypt stuff 😂️😂️😂️.
	- The encrypted version is only free as in price, while the FOSS replica is: Free as in price, and Free as in freedom (aka. source code is public)

]]
local t,CH
function Home()
	t,CH = {},gg.choice({
		"1.) Mundaneo",
		"2.) Pug",
		"3.) Portia",
		"4.) Bus",
		"5.) Vapour",
		"6.) Pug GTI",
		"7.) Fjord",
		"8.) Van",
		"9.) Limo",
		"10.) Cop Car",
		"11.) Scooby",
		"12.) Tank",
		"13.) Evo",
		"14.) Taxi",
		"15.) Ice Cream Van",
		"16.) Pickup",
		"17.) Hotrod",
		"18.) Helicopter",
		"19.) Pug Racer",
		"20.) Truck",
		"21.) SWAT Van",
		"22.) RC Truck",
		"23.) Rocket Car",
		"24.) Vapour GT",
		"25.) X550R",
		"26.) Rambler",
		"Speed Up All Cars",
		"Speed Hack ( OFF )",
		"Exit"
	},nil,"Alpha GG Hacker YT\n\nCar Hack")
	if CH then
		if CH == 29 then Exit()
		elseif CH == 27 then t = "70;45;70;500;90;42.5;85;130;175;80;61.75;2000;70;90;175;90;95;75;35;350;300;125;30;85;70;130"
		elseif CH == 28 then
		--this should do the opposite of enabling
			if revert then
				gg.setValues(revert)
				gg.toast('Made By Alpha GG\n∆ Car Speed Hack OFF ∆')
			else
				gg.toast('Made By Alpha GG\n∆ No previous results found ∆')
			end
			revert = nil
		elseif CH == 1 then t = 70
		elseif CH == 2 then t = 45
		elseif CH == 3 then t = 70
		elseif CH == 4 then t = 500
		elseif CH == 5 then t = 90
		elseif CH == 6 then t = 42.5
		elseif CH == 7 then t = 85
		elseif CH == 8 then t = 130
		elseif CH == 9 then t = 175
		elseif CH == 10 then t = 80
		elseif CH == 11 then t = 61.75
		elseif CH == 12 then t = 2000
		elseif CH == 13 then t = 70
		elseif CH == 14 then t = 90
		elseif CH == 15 then t = 175
		elseif CH == 16 then t = 90
		elseif CH == 17 then t = 95
		elseif CH == 18 then t = 75
		elseif CH == 19 then t = 35
		elseif CH == 20 then t = 350
		elseif CH == 21 then t = 300
		elseif CH == 22 then t = 125
		elseif CH == 23 then t = 30
		elseif CH == 24 then t = 85
		elseif CH == 25 then t = 70
		elseif CH == 26 then t = 130 end
	--set this depending on your usage
	-- | gg.REGION_ANONYMOUS | gg.REGION_C_BSS
		gg.setRanges(gg.REGION_OTHER)
		gg.searchNumber(t,gg.TYPE_FLOAT)
		revert = gg.getResults(5000)
		gg.editAll(-300,gg.TYPE_FLOAT)
		gg.clearResults()
		gg.toast('Made By Alpha GG\n∆ SUCCESS ∆')
	else
		gg.toast('Cancelled')
	end
	collectgarbage()
end
function Exit()
	print("This script is recreated in decrypted form by ABJ4403\nOriginally made (encrypted) by AlphaGG")
	os.exit()
end
while true do
	if gg.isVisible() then
		gg.setVisible(false)
		Home()
	end
end

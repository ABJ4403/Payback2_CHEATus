This contains most of the AlphaGGHackerYT scripts.

by the way, rest in peace... Alpha GG Hacker YouTube Channel
on ~21/03/2022, YouTube bans him for no "violating ToS?"
i think its because:
- AGH Shares script (and yes yt kinda hates that so be aware when you trying to share something external).
- AGH changes encryption credits on his GG-v1 script (SerrangGaming, and PGv3 encryption credits removed and all replaced by his name), so the original owner behind the encryption reports to youtube.

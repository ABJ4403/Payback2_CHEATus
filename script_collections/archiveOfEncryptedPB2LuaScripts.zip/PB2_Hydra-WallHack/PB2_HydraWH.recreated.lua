--[[

	This is a FOSS replica of decrypted Wall Hack that Hydra Made, Recreated by ABJ4403.
	Difference between the encrypted and replica version:
	- I cant recover everything, this may includes credit, password, whatnot, so fu hydra hehe.
	- This replica had my credit (very tiny, shouldnt be annonying enough, altough you can just remove it manually lol. located at line ?)
	- This replica had some optimization applied (garbage collection, mini memory buffer, local values, potentially different while true thingy, simpler script (remember that simple = fast))
	- This replica is able to be toggled on/off, and and its own menu hahaa suck u hydra noob.
	- The encrypted version is slow, because they need to decrypt stuff 😂️😂️😂️.
	- The encrypted version is only free as in price, while the FOSS replica is: Free as in price, and Free as in freedom (aka. source code is public).
	- The encrypted version is protected by no one but his own encryption, while the FOSS replica is protected by a community-made and legalized GNU GPL v3 License (so any violation related to close source crap will be taken immediately and seriously :D take that encryptor noob XD).

]]
local gg,Home = gg
function Home()
	local CH = gg.choice({
		"ON",
		"OFF",
		"Exit"
	},nil,"Wall Hack")
	if CH then
		if CH == 1 then
			gg.searchNumber("1078618499;1094412911;1;1034868570;1050796852::493",gg.TYPE_DWORD)
			gg.refineNumber(1)
			gg.getResults(1e3)
			gg.editAll(-1,gg.TYPE_DWORD)
		elseif CH == 2 then
			gg.searchNumber("1078618499;1094412911;-1;1034868570;1050796852::493",gg.TYPE_DWORD)
			gg.refineNumber(-1)
			gg.getResults(1e3)
			gg.editAll(1,gg.TYPE_DWORD)
		elseif CH == 3 then
			print("Script recreated in FOSS form by ABJ4403.\nProtected under GNU General Public License version 3")
			os.exit()
		end
		gg.clearResults()
	end
	CH = nil
	collectgarbage()
end
--cbss: i forget if this is the one that is in orig decrypted script
--anon: this isnt here and isnt tested.
--other: maybe same case as anon, but this one comes from pb2_chts
gg.setRanges(gg.REGION_C_BSS + gg.REGION_ANONYMOUS + gg.REGION_OTHER)
while true do
	if gg.isVisible() then
		gg.setVisible(false)
		Home()
	end
end
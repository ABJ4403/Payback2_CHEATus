.version	5.2

.format	0
.endianness	LITTLE
.int_size	4
.size_t_size	4
.instruction_size	4
.number_format	float	8

.function	main

.linedefined	-620756992
.lastlinedefined	-318767104
.numparams	29
.is_vararg	1
.maxstacksize	29
.source	null

.upvalue	"_ENV"	0	true

.constant	k0	"collectgarbage"
.constant	k1	"collect"
.constant	k2	"[' Locked ']\t"
.constant	k3	"\n\xf0\x9f\x94\xa5HydraAssassins\xf0\x9f\x94\xa5"
.constant	k4	"Bad"

gettabup      r0    u0    k0
loadk         r1    k1
call          r0     2     1
loadk         r0    k2
loadk         r1    k3
newtable      r2     0     0
closure       r3    f0
settable      r2    k4    r3
gettable      r3    r2    k4
call          r3     1     1
return        r0     1

.function	main/f0

.linedefined	-620756992
.lastlinedefined	-318767104
.numparams	29
.is_vararg	1
.maxstacksize	29
.source	null

.upvalue	null	0	false

.constant	k0	"gg"
.constant	k1	"setVisible"
.constant	k2	"io"
.constant	k3	"input"
.constant	k4	"getFile"
.constant	k5	"os"
.constant	k6	"remove"
.constant	k7	"gg.alert"
.constant	k8	"TBWAX"
.constant	k9	"_X"
.constant	k10	"loadfile"
.constant	k11	"output"
.constant	k12	"write"
.constant	k13	"read"
.constant	k14	"*a"
.constant	k15	"w"
.constant	k16	"Wrong"
.constant	k17	1
.constant	k18	"math"
.constant	k19	"random"
.constant	k20	150
.constant	k21	300
.constant	k22	"open"
.constant	k23	"string"
.constant	k24	"char"
.constant	k25	97
.constant	k26	122
.constant	k27	"rep"
.constant	k28	3
.constant	k29	"Kntuu"
.constant	k30	"toast"
.constant	k31	"\xe2\x8f\xb3 Please Wait.."
.constant	k32	"rename"
.constant	k33	"/storage/emulated/0/vx"
.constant	k34	"/storage/emulated/0/Android/NubLuhKontol"
.constant	k35	"r"
.constant	k36	""
.constant	k37	22
.constant	k38	2
.constant	k39	34
.constant	k40	21
.constant	k41	4
.constant	k42	40
.constant	k43	5
.constant	k44	24
.constant	k45	6
.constant	k46	49
.constant	k47	7
.constant	k48	42
.constant	k49	8
.constant	k50	38
.constant	k51	9
.constant	k52	45
.constant	k53	10
.constant	k54	43
.constant	k55	"ipairs"
.constant	k56	"TYPE_FLOAT"
.constant	k57	nil
.constant	k58	"exit"
.constant	k59	"multiChoice"
.constant	k60	"searchNumber"
.constant	k61	43475
.constant	k62	"Script for Payback 2 2.104.8"
.constant	k63	"1.0.0"
.constant	k64	"User"
.constant	k65	""
.constant	k66	0
.constant	k67	"Payback 2"
.constant	k68	"net.apex_designs.payback2"
.constant	k69	"2.104.8"
.constant	k70	110
.constant	k71	27
.constant	k72	20
.constant	k73	-41
.constant	k74	-139
.constant	k75	32
.constant	k76	-8347145
.constant	k77	100
.constant	k78	-8347168
.constant	k79	56
.constant	k80	11
.constant	k81	-8347151
.constant	k82	12
.constant	k83	13
.constant	k84	14
.constant	k85	53
.constant	k86	15
.constant	k87	16
.constant	k88	55
.constant	k89	17
.constant	k90	-8347099
.constant	k91	18
.constant	k92	19
.constant	k93	"DxD"
.constant	k94	"99.0"
.constant	k95	16126
.constant	k96	"\n"
.constant	k97	230
.constant	k98	-90
.constant	k99	-8347146
.constant	k100	-8347098
.constant	k101	-8347144
.constant	k102	48
.constant	k103	" v"
.constant	k104	" by "
.constant	k105	233
.constant	k106	54
.constant	k107	-8347152
.constant	k108	51
.constant	k109	23
.constant	k110	25
.constant	k111	26
.constant	k112	28
.constant	k113	29
.constant	k114	-8347147
.constant	k115	30
.constant	k116	31
.constant	k117	33
.constant	k118	35
.constant	k119	-8347150
.constant	k120	36
.constant	k121	37
.constant	k122	98
.constant	k123	"packageName"
.constant	k124	" "
.constant	k125	" ("
.constant	k126	")"
.constant	k127	"versionName"
.constant	k128	"versionCode"
.constant	k129	41
.constant	k130	-132
.constant	k131	"This script for "
.constant	k132	" ["
.constant	k133	"].\nYou select "
.constant	k134	"label"
.constant	k135	"].\nNow script exit."
.constant	k136	231
.constant	k137	-40
.constant	k138	-136
.constant	k139	39
.constant	k140	-8347149
.constant	k141	102
.constant	k142	-8347100
.constant	k143	52
.constant	k144	99
.constant	k145	-8347101
.constant	k146	-87
.constant	k147	-8347143
.constant	k148	44
.constant	k149	46
.constant	k150	50
.constant	k151	47
.constant	k152	-8347148
.constant	k153	"pairs"
.constant	k154	"A"
.constant	k155	true
.constant	k156	88
.constant	k157	-134
.constant	k158	-8347103
.constant	k159	101
.constant	k160	-8347102
.constant	k161	57
.constant	k162	58
.constant	k163	59
.constant	k164	60
.constant	k165	61
.constant	k166	62
.constant	k167	63
.constant	k168	64
.constant	k169	65
.constant	k170	-45
.constant	k171	-89
.constant	k172	66
.constant	k173	67
.constant	k174	68
.constant	k175	69
.constant	k176	70
.constant	k177	71
.constant	k178	72
.constant	k179	73
.constant	k180	74
.constant	k181	75
.constant	k182	76
.constant	k183	77
.constant	k184	78
.constant	k185	79
.constant	k186	80
.constant	k187	81
.constant	k188	82
.constant	k189	83
.constant	k190	84
.constant	k191	85
.constant	k192	86
.constant	k193	87
.constant	k194	89
.constant	k195	90
.constant	k196	91
.constant	k197	92
.constant	k198	93
.constant	k199	94
.constant	k200	95
.constant	k201	96
.constant	k202	103
.constant	k203	104
.constant	k204	105
.constant	k205	106
.constant	k206	107
.constant	k207	108
.constant	k208	109
.constant	k209	111
.constant	k210	112
.constant	k211	113
.constant	k212	114
.constant	k213	115
.constant	k214	116
.constant	k215	117
.constant	k216	118
.constant	k217	119
.constant	k218	120
.constant	k219	121
.constant	k220	123
.constant	k221	124
.constant	k222	125
.constant	k223	126
.constant	k224	127
.constant	k225	128
.constant	k226	129
.constant	k227	130
.constant	k228	131
.constant	k229	132
.constant	k230	133
.constant	k231	134
.constant	k232	135
.constant	k233	136
.constant	k234	137
.constant	k235	138
.constant	k236	139
.constant	k237	140
.constant	k238	141
.constant	k239	142
.constant	k240	143
.constant	k241	144
.constant	k242	145
.constant	k243	146
.constant	k244	147
.constant	k245	148
.constant	k246	149
.constant	k247	151
.constant	k248	152
.constant	k249	153
.constant	k250	154
.constant	k251	155
.constant	k252	-42
.constant	k253	-135
.constant	k254	-43
.constant	k255	-1
.constant	k256	-140

gettabup      r0    u0    k0
gettable      r0    r0    k1
loadbool      r1     0     0
call          r0     2     1
gettabup      r0    u0    k2
gettable      r0    r0    k3
gettabup      r1    u0    k0
gettable      r1    r1    k4
call          r1     1     0
call          r0     0     1
gettabup      r0    u0    k5
gettable      r0    r0    k6
gettabup      r1    u0    k0
gettable      r1    r1    k4
call          r1     1     0
call          r0     0     1
loadnil       r0     0
test          r0     0
jmp            0   l23
gettabup      r0    u0    k0
loadnil       r1     0
call          r0     2     1
.label	l23
gettabup      r0    u0    k0
gettable      r0    r0    k1
loadbool      r1     0     0
call          r0     2     1
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0   l69

.label	l69
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l111

.label	l111
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l153

.label	l153
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l195

.label	l195
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l237

.label	l237
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l279

.label	l279
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l321

.label	l321
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l363

.label	l363
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l405

.label	l405
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l447

.label	l447
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l489

.label	l489
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l531

.label	l531
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l573

.label	l573
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l615

.label	l615
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l657

.label	l657
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l699

.label	l699
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l741

.label	l741
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l783

.label	l783
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l825

.label	l825
loadnil       r0     0
test          r0     0
jmp            0  l870
jmp            0  l867

.label	l867
loadnil       r0     0
test          r0     0
jmp            0  l870
.label	l870
gettabup      r0    u0    k9
settabup      u0    k9    r0
gettabup      r0    u0   k10
gettabup      r1    u0    k0
gettable      r1    r1    k4
call          r1     1     0
call          r0     0     2
test          r0     1
jmp            0  l896
gettabup      r0    u0    k2
gettable      r0    r0   k11
gettabup      r1    u0    k0
gettable      r1    r1    k4
call          r1     1     0
call          r0     0     1
gettabup      r0    u0    k2
gettable      r0    r0   k12
gettabup      r1    u0    k2
gettable      r1    r1   k13
loadk         r2   k14
call          r1     2     2
loadk         r2   k15
call          r0     3     1
gettabup      r0    u0   k16
tailcall      r0     1
return        r0     0
.label	l896
gettabup      r0    u0    k2
gettable      r0    r0   k11
gettabup      r1    u0    k0
gettable      r1    r1    k4
call          r1     1     0
call          r0     0     1
loadk         r0   k17
gettabup      r1    u0   k18
gettable      r1    r1   k19
loadk         r2   k20
loadk         r3   k21
call          r1     3     2
loadk         r2   k17
forprep       r0  l943
.label	l910
gettabup      r4    u0    k2
gettable      r4    r4   k22
gettabup      r5    u0    k0
gettable      r5    r5    k4
call          r5     1     2
gettabup      r6    u0   k23
gettable      r6    r6   k24
gettabup      r7    u0   k18
gettable      r7    r7   k19
loadk         r8   k25
loadk         r9   k26
call          r7     3     0
call          r6     0     2
gettabup      r7    u0    k2
gettable      r7    r7    k3
gettabup      r8    u0    k0
gettable      r8    r8    k4
call          r8     1     0
call          r7     0     2
self          r7    r7   k13
loadk         r9   k14
call          r7     3     2
self          r7    r7   k27
loadk         r9   k28
call          r7     3     2
concat        r5    r5    r7
loadk         r6   k15
call          r4     3     2
settabup      u0   k29    r4
gettabup      r4    u0    k0
gettable      r4    r4   k30
loadk         r5   k31
call          r4     2     1
.label	l943
forloop       r0  l910
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0  l986

.label	l986
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1028

.label	l1028
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1070

.label	l1070
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1112

.label	l1112
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1154

.label	l1154
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1196

.label	l1196
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1238

.label	l1238
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1280

.label	l1280
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1322

.label	l1322
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1364

.label	l1364
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1406

.label	l1406
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1448

.label	l1448
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1490

.label	l1490
loadnil       r0     0
test          r0     0
jmp            0 l1535
jmp            0 l1532

.label	l1532
loadnil       r0     0
test          r0     0
jmp            0 l1535
.label	l1535
gettabup      r0    u0    k9
settabup      u0    k9    r0
gettabup      r0    u0    k2
gettable      r0    r0   k12
gettabup      r1    u0    k2
gettable      r1    r1   k13
loadk         r2   k14
call          r1     2     2
loadk         r2   k15
call          r0     3     1
loadnil       r0     0
test          r0     0
jmp            0 l1551
gettabup      r0    u0    k0
loadnil       r1     0
call          r0     2     1
.label	l1551
gettabup      r0    u0    k5
gettable      r0    r0   k32
gettabup      r1    u0    k0
gettable      r1    r1    k4
call          r1     1     2
loadk         r2   k33
call          r0     3     1
gettabup      r0    u0    k0
gettable      r0    r0    k1
loadbool      r1     0     0
call          r0     2     1
gettabup      r0    u0    k5
gettable      r0    r0   k32
loadk         r1   k33
loadk         r2   k34
call          r0     3     1
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1609

.label	l1609
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1651

.label	l1651
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1693

.label	l1693
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1735

.label	l1735
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1777

.label	l1777
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1819

.label	l1819
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1861

.label	l1861
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1903

.label	l1903
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1945

.label	l1945
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l1987

.label	l1987
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l2029

.label	l2029
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l2071

.label	l2071
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l2113

.label	l2113
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l2155

.label	l2155
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l2197

.label	l2197
loadnil       r0     0
test          r0     0
jmp            0 l2242
jmp            0 l2239

.label	l2239
loadnil       r0     0
test          r0     0
jmp            0 l2242
.label	l2242
gettabup      r0    u0    k9
settabup      u0    k9    r0
gettabup      r0    u0   k10
gettabup      r1    u0    k0
gettable      r1    r1    k4
call          r1     1     0
call          r0     0     2
test          r0     1
jmp            0 l2261
gettabup      r0    u0    k5
gettable      r0    r0   k32
loadk         r1   k34
gettabup      r2    u0    k0
gettable      r2    r2    k4
call          r2     1     0
call          r0     0     1
gettabup      r0    u0   k16
tailcall      r0     1
return        r0     0
.label	l2261
loadnil       r0     0
test          r0     0
jmp            0 l2267
gettabup      r0    u0    k0
loadnil       r1     0
call          r0     2     1
.label	l2267
gettabup      r0    u0    k5
gettable      r0    r0   k32
loadk         r1   k33
loadk         r2   k34
call          r0     3     1
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2314

.label	l2314
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2356

.label	l2356
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2398

.label	l2398
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2440

.label	l2440
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2482

.label	l2482
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2524

.label	l2524
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2566

.label	l2566
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2608

.label	l2608
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2650

.label	l2650
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2692

.label	l2692
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2734

.label	l2734
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2776

.label	l2776
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2818

.label	l2818
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2860

.label	l2860
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2902

.label	l2902
loadnil       r0     0
test          r0     0
jmp            0 l2947
jmp            0 l2944

.label	l2944
loadnil       r0     0
test          r0     0
jmp            0 l2947
.label	l2947
gettabup      r0    u0    k9
settabup      u0    k9    r0
gettabup      r0    u0   k10
gettabup      r1    u0    k0
gettable      r1    r1    k4
call          r1     1     0
call          r0     0     2
test          r0     1
jmp            0 l2966
gettabup      r0    u0    k5
gettable      r0    r0   k32
loadk         r1   k34
gettabup      r2    u0    k0
gettable      r2    r2    k4
call          r2     1     0
call          r0     0     1
gettabup      r0    u0   k16
tailcall      r0     1
return        r0     0
.label	l2966
loadnil       r0     0
test          r0     0
jmp            0 l2972
gettabup      r0    u0    k0
loadnil       r1     0
call          r0     2     1
.label	l2972
gettabup      r0    u0    k5
gettable      r0    r0   k32
loadk         r1   k34
gettabup      r2    u0    k0
gettable      r2    r2    k4
call          r2     1     0
call          r0     0     1
gettabup      r0    u0    k2
gettable      r0    r0    k3
gettabup      r1    u0    k0
gettable      r1    r1    k4
call          r1     1     2
loadk         r2   k35
call          r0     3     1
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3028

.label	l3028
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3070

.label	l3070
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3112

.label	l3112
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3154

.label	l3154
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3196

.label	l3196
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3238

.label	l3238
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3280

.label	l3280
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3322

.label	l3322
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3364

.label	l3364
loadnil       r0     0
test          r0     0
jmp            0 l3409
jmp            0 l3406

.label	l3406
loadnil       r0     0
test          r0     0
jmp            0 l3409
.label	l3409
gettabup      r0    u0    k9
settabup      u0    k9    r0
loadnil       r0     0
test          r0     0
jmp            0 l3417
gettabup      r0    u0    k0
loadnil       r1     0
call          r0     2     1
.label	l3417
gettabup      r0    u0    k0
gettable      r0    r0    k1
loadbool      r1     1     0
call          r0     2     1
.label	l3421
loadbool      r0     0     0
test          r0     0
jmp            0 l3439
newtable      r0     0     0
loadnil       r1     4
settable      r0    r1    r2
gettable      r2    r0    r1
test          r2     0
jmp            0 l3421
gettable      r2    r0    r1
move          r3    r0
call          r2     2     2
settable      r0    r1    r2
gettable      r2    r0    r1
move          r3    r0
call          r2     2     2
settable      r0    r1    r2
jmp            0 l3421
.label	l3439
loadnil       r0     0
loadk         r0   k36
newtable      r1     0    10
settable      r1   k17   k37
settable      r1   k38   k39
settable      r1   k28   k40
settable      r1   k41   k42
settable      r1   k43   k44
settable      r1   k45   k46
settable      r1   k47   k48
settable      r1   k49   k50
settable      r1   k51   k52
settable      r1   k53   k54
newtable      r2     1     0
loadk         r3   k37
setlist       r2     1     1
gettabup      r3    u0   k55
newtable      r4     0     0
call          r3     2     4
jmp            0 l23471
.label	l23458
newtable      r7     2     0
loadnil       r8     1
setlist       r7     2     1
newtable      r8     2     0
loadnil       r9     1
setlist       r8     2     1
settable      r7   k56    r8
eq             1    r7   k57
jmp            0 l23471
gettable      r8    r7    k5
gettable      r8    r8   k58
call          r8     1     2
settable      r7   k59    r8
.label	l23471
tforcall      r3     1
tforloop      r5 l23458
gettabup      r3    u0   k55
newtable      r4     0     0
call          r3     2     4
jmp            0 l23485
.label	l23477
newtable      r7     2     0
loadnil       r8     1
setlist       r7     2     1
eq             1    r7   k57
jmp            0 l23485
gettable      r8    r7   k56
call          r8     1     2
settable      r7   k60    r8
.label	l23485
tforcall      r3     1
tforloop      r5 l23477
.label	l23487
loadbool      r3     0     0
test          r3     0
jmp            0 l23505
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23487
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23487
.label	l23505
loadbool      r3     0     0
test          r3     0
jmp            0 l23523
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23505
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23505
.label	l23523
loadbool      r3     0     0
test          r3     0
jmp            0 l23541
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23523
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23523
.label	l23541
loadbool      r3     0     0
test          r3     0
jmp            0 l23559
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23541
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23541
.label	l23559
loadbool      r3     0     0
test          r3     0
jmp            0 l23577
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23559
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23559
.label	l23577
loadbool      r3     0     0
test          r3     0
jmp            0 l23595
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23577
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23577
.label	l23595
loadbool      r3     0     0
test          r3     0
jmp            0 l23613
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23595
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23595
.label	l23613
loadbool      r3     0     0
test          r3     0
jmp            0 l23631
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23613
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23613
.label	l23631
loadbool      r3     0     0
test          r3     0
jmp            0 l23649
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23631
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23631
.label	l23649
loadbool      r3     0     0
test          r3     0
jmp            0 l23667
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23649
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23649
.label	l23667
loadbool      r3     0     0
test          r3     0
jmp            0 l23685
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23667
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23667
.label	l23685
loadbool      r3     0     0
test          r3     0
jmp            0 l23703
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23685
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23685
.label	l23703
loadbool      r3     0     0
test          r3     0
jmp            0 l23721
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23703
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23703
.label	l23721
loadbool      r3     0     0
test          r3     0
jmp            0 l23739
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23721
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23721
.label	l23739
loadbool      r3     0     0
test          r3     0
jmp            0 l23757
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23739
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23739
.label	l23757
loadbool      r3     0     0
test          r3     0
jmp            0 l23775
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23757
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23757
.label	l23775
loadbool      r3     0     0
test          r3     0
jmp            0 l23793
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23775
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23775
.label	l23793
loadbool      r3     0     0
test          r3     0
jmp            0 l23811
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23793
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23793
.label	l23811
loadbool      r3     0     0
test          r3     0
jmp            0 l23829
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23811
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23811
.label	l23829
loadbool      r3     0     0
test          r3     0
jmp            0 l23847
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23829
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23829
.label	l23847
loadbool      r3     0     0
test          r3     0
jmp            0 l23865
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23847
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23847
.label	l23865
loadbool      r3     0     0
test          r3     0
jmp            0 l23883
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23865
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23865
.label	l23883
loadbool      r3     0     0
test          r3     0
jmp            0 l23901
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23883
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23883
.label	l23901
loadbool      r3     0     0
test          r3     0
jmp            0 l23919
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23901
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23901
.label	l23919
loadbool      r3     0     0
test          r3     0
jmp            0 l23937
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23919
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23919
.label	l23937
loadbool      r3     0     0
test          r3     0
jmp            0 l23955
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23937
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23937
.label	l23955
loadbool      r3     0     0
test          r3     0
jmp            0 l23973
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23955
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23955
.label	l23973
loadbool      r3     0     0
test          r3     0
jmp            0 l23991
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23973
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23973
.label	l23991
loadbool      r3     0     0
test          r3     0
jmp            0 l24009
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l23991
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l23991
.label	l24009
loadbool      r3     0     0
test          r3     0
jmp            0 l24027
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24009
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24009
.label	l24027
loadbool      r3     0     0
test          r3     0
jmp            0 l24045
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24027
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24027
.label	l24045
loadbool      r3     0     0
test          r3     0
jmp            0 l24063
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24045
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24045
.label	l24063
loadbool      r3     0     0
test          r3     0
jmp            0 l24081
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24063
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24063
.label	l24081
loadbool      r3     0     0
test          r3     0
jmp            0 l24099
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24081
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24081
.label	l24099
loadbool      r3     0     0
test          r3     0
jmp            0 l24117
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24099
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24099
.label	l24117
loadbool      r3     0     0
test          r3     0
jmp            0 l24135
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24117
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24117
.label	l24135
loadbool      r3     0     0
test          r3     0
jmp            0 l24153
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24135
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24135
.label	l24153
loadbool      r3     0     0
test          r3     0
jmp            0 l24171
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24153
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24153
.label	l24171
loadbool      r3     0     0
test          r3     0
jmp            0 l24189
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24171
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24171
.label	l24189
loadbool      r3     0     0
test          r3     0
jmp            0 l24207
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24189
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24189
.label	l24207
loadbool      r3     0     0
test          r3     0
jmp            0 l24225
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24207
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24207
.label	l24225
loadbool      r3     0     0
test          r3     0
jmp            0 l24243
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24225
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24225
.label	l24243
loadbool      r3     0     0
test          r3     0
jmp            0 l24261
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24243
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24243
.label	l24261
loadbool      r3     0     0
test          r3     0
jmp            0 l24279
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24261
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24261
.label	l24279
loadbool      r3     0     0
test          r3     0
jmp            0 l24297
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24279
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24279
.label	l24297
loadbool      r3     0     0
test          r3     0
jmp            0 l24315
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24297
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24297
.label	l24315
loadbool      r3     0     0
test          r3     0
jmp            0 l24333
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24315
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24315
.label	l24333
loadbool      r3     0     0
test          r3     0
jmp            0 l24351
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24333
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24333
.label	l24351
loadbool      r3     0     0
test          r3     0
jmp            0 l24369
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24351
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24351
.label	l24369
loadbool      r3     0     0
test          r3     0
jmp            0 l24387
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24369
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24369
.label	l24387
loadbool      r3     0     0
test          r3     0
jmp            0 l24405
newtable      r3     0     0
loadnil       r4     4
settable      r3    r4    r5
gettable      r5    r3    r4
test          r5     0
jmp            0 l24387
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
gettable      r5    r3    r4
move          r6    r3
call          r5     2     2
settable      r3    r4    r5
jmp            0 l24387
.label	l24405
gettabup      r3    u0   k55
newtable      r4     0     0
call          r3     2     4
jmp            0 l24422
.label	l24409
newtable      r7     2     0
loadnil       r8     1
setlist       r7     2     1
newtable      r8     2     0
loadnil       r9     1
setlist       r8     2     1
settable      r7   k56    r8
eq             1    r7   k57
jmp            0 l24422
gettable      r8    r7    k5
gettable      r8    r8   k58
call          r8     1     2
settable      r7   k59    r8
.label	l24422
tforcall      r3     1
tforloop      r5 l24409
gettabup      r3    u0   k55
newtable      r4     0     0
call          r3     2     4
jmp            0 l24436
.label	l24428
newtable      r7     2     0
loadnil       r8     1
setlist       r7     2     1
eq             1    r7   k57
jmp            0 l24436
gettable      r8    r7   k56
call          r8     1     2
settable      r7   k60    r8
.label	l24436
tforcall      r3     1
tforloop      r5 l24428
newtable      r3     1     0
loadk         r4   k39
setlist       r3     1     1
newtable      r4     1     0
loadk         r5   k61
setlist       r4     1     1
gettabup      r5    u0   k55
newtable      r6     0     0
call          r5     2     4
jmp            0 l24461
.label	l24448
newtable      r9     2     0
loadnil      r10     1
setlist       r9     2     1
newtable     r10     2     0
loadnil      r11     1
setlist      r10     2     1
settable      r9   k56   r10
eq             1    r9   k57
jmp            0 l24461
gettable     r10    r9    k5
gettable     r10   r10   k58
call         r10     1     2
settable      r9   k59   r10
.label	l24461
tforcall      r5     1
tforloop      r7 l24448
gettabup      r5    u0   k55
newtable      r6     0     0
call          r5     2     4
jmp            0 l24475
.label	l24467
newtable      r9     2     0
loadnil      r10     1
setlist       r9     2     1
eq             1    r9   k57
jmp            0 l24475
gettable     r10    r9   k56
call         r10     1     2
settable      r9   k60   r10
.label	l24475
tforcall      r5     1
tforloop      r7 l24467
.label	l24477
loadbool      r5     0     0
test          r5     0
jmp            0 l24495
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24477
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24477
.label	l24495
loadbool      r5     0     0
test          r5     0
jmp            0 l24513
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24495
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24495
.label	l24513
loadbool      r5     0     0
test          r5     0
jmp            0 l24531
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24513
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24513
.label	l24531
loadbool      r5     0     0
test          r5     0
jmp            0 l24549
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24531
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24531
.label	l24549
loadbool      r5     0     0
test          r5     0
jmp            0 l24567
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24549
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24549
.label	l24567
loadbool      r5     0     0
test          r5     0
jmp            0 l24585
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24567
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24567
.label	l24585
loadbool      r5     0     0
test          r5     0
jmp            0 l24603
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24585
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24585
.label	l24603
loadbool      r5     0     0
test          r5     0
jmp            0 l24621
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24603
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24603
.label	l24621
loadbool      r5     0     0
test          r5     0
jmp            0 l24639
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24621
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24621
.label	l24639
loadbool      r5     0     0
test          r5     0
jmp            0 l24657
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24639
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24639
.label	l24657
loadbool      r5     0     0
test          r5     0
jmp            0 l24675
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24657
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24657
.label	l24675
loadbool      r5     0     0
test          r5     0
jmp            0 l24693
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24675
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24675
.label	l24693
loadbool      r5     0     0
test          r5     0
jmp            0 l24711
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24693
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24693
.label	l24711
loadbool      r5     0     0
test          r5     0
jmp            0 l24729
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24711
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24711
.label	l24729
loadbool      r5     0     0
test          r5     0
jmp            0 l24747
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24729
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24729
.label	l24747
loadbool      r5     0     0
test          r5     0
jmp            0 l24765
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24747
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24747
.label	l24765
loadbool      r5     0     0
test          r5     0
jmp            0 l24783
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24765
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24765
.label	l24783
loadbool      r5     0     0
test          r5     0
jmp            0 l24801
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24783
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24783
.label	l24801
loadbool      r5     0     0
test          r5     0
jmp            0 l24819
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24801
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24801
.label	l24819
loadbool      r5     0     0
test          r5     0
jmp            0 l24837
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24819
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24819
.label	l24837
loadbool      r5     0     0
test          r5     0
jmp            0 l24855
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24837
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24837
.label	l24855
loadbool      r5     0     0
test          r5     0
jmp            0 l24873
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24855
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24855
.label	l24873
loadbool      r5     0     0
test          r5     0
jmp            0 l24891
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24873
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24873
.label	l24891
loadbool      r5     0     0
test          r5     0
jmp            0 l24909
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24891
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24891
.label	l24909
loadbool      r5     0     0
test          r5     0
jmp            0 l24927
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24909
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24909
.label	l24927
loadbool      r5     0     0
test          r5     0
jmp            0 l24945
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24927
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24927
.label	l24945
loadbool      r5     0     0
test          r5     0
jmp            0 l24963
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24945
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24945
.label	l24963
loadbool      r5     0     0
test          r5     0
jmp            0 l24981
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24963
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24963
.label	l24981
loadbool      r5     0     0
test          r5     0
jmp            0 l24999
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24981
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24981
.label	l24999
loadbool      r5     0     0
test          r5     0
jmp            0 l25017
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l24999
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l24999
.label	l25017
loadbool      r5     0     0
test          r5     0
jmp            0 l25035
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25017
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25017
.label	l25035
loadbool      r5     0     0
test          r5     0
jmp            0 l25053
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25035
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25035
.label	l25053
loadbool      r5     0     0
test          r5     0
jmp            0 l25071
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25053
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25053
.label	l25071
loadbool      r5     0     0
test          r5     0
jmp            0 l25089
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25071
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25071
.label	l25089
loadbool      r5     0     0
test          r5     0
jmp            0 l25107
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25089
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25089
.label	l25107
loadbool      r5     0     0
test          r5     0
jmp            0 l25125
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25107
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25107
.label	l25125
loadbool      r5     0     0
test          r5     0
jmp            0 l25143
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25125
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25125
.label	l25143
loadbool      r5     0     0
test          r5     0
jmp            0 l25161
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25143
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25143
.label	l25161
loadbool      r5     0     0
test          r5     0
jmp            0 l25179
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25161
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25161
.label	l25179
loadbool      r5     0     0
test          r5     0
jmp            0 l25197
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25179
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25179
.label	l25197
loadbool      r5     0     0
test          r5     0
jmp            0 l25215
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25197
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25197
.label	l25215
loadbool      r5     0     0
test          r5     0
jmp            0 l25233
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25215
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25215
.label	l25233
loadbool      r5     0     0
test          r5     0
jmp            0 l25251
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25233
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25233
.label	l25251
loadbool      r5     0     0
test          r5     0
jmp            0 l25269
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25251
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25251
.label	l25269
loadbool      r5     0     0
test          r5     0
jmp            0 l25287
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25269
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25269
.label	l25287
loadbool      r5     0     0
test          r5     0
jmp            0 l25305
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25287
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25287
.label	l25305
loadbool      r5     0     0
test          r5     0
jmp            0 l25323
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25305
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25305
.label	l25323
loadbool      r5     0     0
test          r5     0
jmp            0 l25341
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25323
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25323
.label	l25341
loadbool      r5     0     0
test          r5     0
jmp            0 l25359
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25341
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25341
.label	l25359
loadbool      r5     0     0
test          r5     0
jmp            0 l25377
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25359
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25359
.label	l25377
loadbool      r5     0     0
test          r5     0
jmp            0 l25395
newtable      r5     0     0
loadnil       r6     4
settable      r5    r6    r7
gettable      r7    r5    r6
test          r7     0
jmp            0 l25377
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
gettable      r7    r5    r6
move          r8    r5
call          r7     2     2
settable      r5    r6    r7
jmp            0 l25377
.label	l25395
closure       r5    f0
.label	l25396
loadbool      r6     0     0
test          r6     0
jmp            0 l25414
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25396
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25396
.label	l25414
loadbool      r6     0     0
test          r6     0
jmp            0 l25432
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25414
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25414
.label	l25432
loadbool      r6     0     0
test          r6     0
jmp            0 l25450
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25432
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25432
.label	l25450
loadbool      r6     0     0
test          r6     0
jmp            0 l25468
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25450
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25450
.label	l25468
loadbool      r6     0     0
test          r6     0
jmp            0 l25486
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25468
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25468
.label	l25486
loadbool      r6     0     0
test          r6     0
jmp            0 l25504
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25486
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25486
.label	l25504
loadbool      r6     0     0
test          r6     0
jmp            0 l25522
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25504
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25504
.label	l25522
loadbool      r6     0     0
test          r6     0
jmp            0 l25540
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25522
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25522
.label	l25540
loadbool      r6     0     0
test          r6     0
jmp            0 l25558
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25540
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25540
.label	l25558
loadbool      r6     0     0
test          r6     0
jmp            0 l25576
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25558
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25558
.label	l25576
loadbool      r6     0     0
test          r6     0
jmp            0 l25594
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25576
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25576
.label	l25594
loadbool      r6     0     0
test          r6     0
jmp            0 l25612
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25594
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25594
.label	l25612
loadbool      r6     0     0
test          r6     0
jmp            0 l25630
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25612
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25612
.label	l25630
loadbool      r6     0     0
test          r6     0
jmp            0 l25648
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25630
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25630
.label	l25648
loadbool      r6     0     0
test          r6     0
jmp            0 l25666
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25648
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25648
.label	l25666
loadbool      r6     0     0
test          r6     0
jmp            0 l25684
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25666
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25666
.label	l25684
loadbool      r6     0     0
test          r6     0
jmp            0 l25702
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25684
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25684
.label	l25702
loadbool      r6     0     0
test          r6     0
jmp            0 l25720
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25702
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25702
.label	l25720
loadbool      r6     0     0
test          r6     0
jmp            0 l25738
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25720
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25720
.label	l25738
loadbool      r6     0     0
test          r6     0
jmp            0 l25756
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25738
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25738
.label	l25756
loadbool      r6     0     0
test          r6     0
jmp            0 l25774
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25756
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25756
.label	l25774
loadbool      r6     0     0
test          r6     0
jmp            0 l25792
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25774
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25774
.label	l25792
loadbool      r6     0     0
test          r6     0
jmp            0 l25810
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25792
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25792
.label	l25810
loadbool      r6     0     0
test          r6     0
jmp            0 l25828
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25810
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25810
.label	l25828
loadbool      r6     0     0
test          r6     0
jmp            0 l25846
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25828
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25828
.label	l25846
loadbool      r6     0     0
test          r6     0
jmp            0 l25864
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25846
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25846
.label	l25864
loadbool      r6     0     0
test          r6     0
jmp            0 l25882
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25864
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25864
.label	l25882
loadbool      r6     0     0
test          r6     0
jmp            0 l25900
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25882
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25882
.label	l25900
loadbool      r6     0     0
test          r6     0
jmp            0 l25918
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25900
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25900
.label	l25918
loadbool      r6     0     0
test          r6     0
jmp            0 l25936
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25918
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25918
.label	l25936
loadbool      r6     0     0
test          r6     0
jmp            0 l25954
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25936
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25936
.label	l25954
loadbool      r6     0     0
test          r6     0
jmp            0 l25972
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25954
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25954
.label	l25972
loadbool      r6     0     0
test          r6     0
jmp            0 l25990
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25972
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25972
.label	l25990
loadbool      r6     0     0
test          r6     0
jmp            0 l26008
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l25990
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l25990
.label	l26008
loadbool      r6     0     0
test          r6     0
jmp            0 l26026
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26008
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26008
.label	l26026
loadbool      r6     0     0
test          r6     0
jmp            0 l26044
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26026
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26026
.label	l26044
loadbool      r6     0     0
test          r6     0
jmp            0 l26062
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26044
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26044
.label	l26062
loadbool      r6     0     0
test          r6     0
jmp            0 l26080
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26062
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26062
.label	l26080
loadbool      r6     0     0
test          r6     0
jmp            0 l26098
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26080
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26080
.label	l26098
loadbool      r6     0     0
test          r6     0
jmp            0 l26116
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26098
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26098
.label	l26116
loadbool      r6     0     0
test          r6     0
jmp            0 l26134
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26116
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26116
.label	l26134
loadbool      r6     0     0
test          r6     0
jmp            0 l26152
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26134
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26134
.label	l26152
loadbool      r6     0     0
test          r6     0
jmp            0 l26170
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26152
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26152
.label	l26170
loadbool      r6     0     0
test          r6     0
jmp            0 l26188
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26170
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26170
.label	l26188
loadbool      r6     0     0
test          r6     0
jmp            0 l26206
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26188
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26188
.label	l26206
loadbool      r6     0     0
test          r6     0
jmp            0 l26224
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26206
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26206
.label	l26224
loadbool      r6     0     0
test          r6     0
jmp            0 l26242
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26224
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26224
.label	l26242
loadbool      r6     0     0
test          r6     0
jmp            0 l26260
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26242
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26242
.label	l26260
loadbool      r6     0     0
test          r6     0
jmp            0 l26278
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26260
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26260
.label	l26278
loadbool      r6     0     0
test          r6     0
jmp            0 l26296
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26278
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26278
.label	l26296
loadbool      r6     0     0
test          r6     0
jmp            0 l26314
newtable      r6     0     0
loadnil       r7     4
settable      r6    r7    r8
gettable      r8    r6    r7
test          r8     0
jmp            0 l26296
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
gettable      r8    r6    r7
move          r9    r6
call          r8     2     2
settable      r6    r7    r8
jmp            0 l26296
.label	l26314
closure       r6    f1
.label	l26315
loadbool      r7     0     0
test          r7     0
jmp            0 l26333
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l26315
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l26315
.label	l26333
loadk         r7   k62
loadk         r8   k63
loadk         r9   k64
loadk        r10   k65
loadk        r11   k66
loadk        r12   k67
loadk        r13   k68
loadk        r14   k69
loadk        r15   k70
gettabup     r16    u0    k0
move         r17    r5
move         r18    r6
newtable     r19     0     1
newtable     r20     0    18
settable     r20   k17   k48
settable     r20   k38   k71
settable     r20   k28   k72
settable     r20   k41   k73
settable     r20   k43   k74
settable     r20   k45   k75
settable     r20   k47   k76
settable     r20   k49   k77
settable     r20   k51   k78
settable     r20   k53   k79
settable     r20   k80   k81
settable     r20   k82   k75
settable     r20   k83   k76
settable     r20   k84   k85
settable     r20   k86   k78
settable     r20   k87   k88
settable     r20   k89   k90
settable     r20   k91   k75
settable     r20   k92   k76
settable     r20   k72   k46
settable     r19   k93   r20
call         r18     2     0
call         r17     0     2
gettable     r16   r16   r17
loadk        r17   k94
loadk        r18   k95
call         r16     3     1
eq             1   r10   k65
jmp            0 l26379
loadk        r16   k96
move         r17   r10
concat       r10   r16   r17
.label	l26379
gettabup     r16    u0    k0
move         r17    r5
move         r18    r6
newtable     r19     0     1
newtable     r20     0    14
settable     r20   k17   k54
settable     r20   k38   k97
settable     r20   k28   k72
settable     r20   k41   k73
settable     r20   k43   k98
settable     r20   k45   k75
settable     r20   k47   k99
settable     r20   k49   k77
settable     r20   k51   k78
settable     r20   k53   k88
settable     r20   k80  k100
settable     r20   k82   k75
settable     r20   k83  k101
settable     r20   k84  k102
settable     r19   k93   r20
call         r18     2     0
call         r17     0     2
gettable     r16   r16   r17
move         r17    r7
loadk        r18  k103
move         r19    r8
loadk        r20  k104
move         r21    r9
move         r22   r10
concat       r17   r17   r22
call         r16     2     1
eq             1   r11   k66
jmp            0 l26917
gettabup     r16    u0    k0
move         r17    r5
move         r18    r6
newtable     r19     0     1
newtable     r20     0    26
settable     r20   k17   k48
settable     r20   k38  k105
settable     r20   k28   k72
settable     r20   k41   k73
settable     r20   k43   k74
settable     r20   k45   k75
settable     r20   k47  k101
settable     r20   k49  k102
settable     r20   k51   k78
settable     r20   k53  k106
settable     r20   k80  k107
settable     r20   k82   k75
settable     r20   k83   k99
settable     r20   k84   k77
settable     r20   k86   k78
settable     r20   k87   k88
settable     r20   k89   k90
settable     r20   k91   k75
settable     r20   k92   k76
settable     r20   k72  k108
settable     r20   k40   k78
settable     r20   k37   k88
settable     r20  k109   k81
settable     r20   k44   k75
settable     r20  k110  k101
settable     r20  k111  k102
settable     r20   k71   k78
settable     r20  k112   k85
settable     r20  k113  k114
settable     r20  k115   k75
settable     r20  k116   k76
settable     r20   k75   k25
settable     r20  k117   k78
settable     r20   k39   k88
settable     r20  k118  k119
settable     r20  k120   k75
settable     r20  k121   k76
settable     r20   k50  k122
settable     r19   k93   r20
call         r18     2     0
call         r17     0     2
gettable     r16   r16   r17
call         r16     1     2
loadnil      r17     0
test         r17     0
jmp            0 l26838
jmp            0 l26502

.label	l26502
loadnil      r17     0
test         r17     0
jmp            0 l26838
jmp            0 l26544

.label	l26544
loadnil      r17     0
test         r17     0
jmp            0 l26838
jmp            0 l26586

.label	l26586
loadnil      r17     0
test         r17     0
jmp            0 l26838
jmp            0 l26628

.label	l26628
loadnil      r17     0
test         r17     0
jmp            0 l26838
jmp            0 l26670

.label	l26670
loadnil      r17     0
test         r17     0
jmp            0 l26838
jmp            0 l26712

.label	l26712
loadnil      r17     0
test         r17     0
jmp            0 l26838
jmp            0 l26754

.label	l26754
loadnil      r17     0
test         r17     0
jmp            0 l26838
jmp            0 l26796

.label	l26796
loadnil      r17     0
test         r17     0
jmp            0 l26838
jmp            0 l26838

.label	l26838
loadbool     r17     0     0
loadbool     r18     0     0
le             0   k17   r11
jmp            0 l26844
move         r17   r13
gettable     r18   r16  k123
.label	l26844
le             0   k38   r11
jmp            0 l26860
move         r19   r17
loadk        r20  k124
move         r21   r14
loadk        r22  k125
move         r23   r15
loadk        r24  k126
concat       r17   r19   r24
move         r19   r18
loadk        r20  k124
gettable     r21   r16  k127
loadk        r22  k125
gettable     r23   r16  k128
loadk        r24  k126
concat       r18   r19   r24
.label	l26860
eq             1   r17   r18
jmp            0 l26917
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    14
settable     r23   k17  k129
settable     r23   k38  k111
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43  k130
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49   k46
settable     r23   k51   k78
settable     r23   k53   k88
settable     r23   k80   k90
settable     r23   k82   k75
settable     r23   k83  k101
settable     r23   k84  k102
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
loadk        r20  k131
move         r21   r12
loadk        r22  k132
move         r23   r17
loadk        r24  k133
gettable     r25   r16  k134
loadk        r26  k132
move         r27   r18
loadk        r28  k135
concat       r20   r20   r28
call         r19     2     1
gettabup     r19    u0    k5
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    11
settable     r23   k17   k48
settable     r23   k38  k136
settable     r23   k28   k72
settable     r23   k41  k137
settable     r23   k43  k138
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49   k85
settable     r23   k51   k78
settable     r23   k53   k79
settable     r23   k80  k107
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
call         r19     1     1
.label	l26917
loadnil      r16     0
newtable     r17     0     0
move         r18    r5
move         r19    r6
newtable     r20     0     1
newtable     r21     0    23
settable     r21   k17  k139
settable     r21   k38  k105
settable     r21   k28   k72
settable     r21   k41   k73
settable     r21   k43   k98
settable     r21   k45   k75
settable     r21   k47  k140
settable     r21   k49  k141
settable     r21   k51   k78
settable     r21   k53  k108
settable     r21   k80  k142
settable     r21   k82   k75
settable     r21   k83   k76
settable     r21   k84   k88
settable     r21   k86   k78
settable     r21   k87   k88
settable     r21   k89  k142
settable     r21   k91   k75
settable     r21   k92   k76
settable     r21   k72   k79
settable     r21   k40   k78
settable     r21   k37  k143
settable     r21  k109  k114
settable     r21   k44   k75
settable     r21  k110   k76
settable     r21  k111  k144
settable     r21   k71   k78
settable     r21  k112  k108
settable     r21  k113  k145
settable     r20   k93   r21
call         r19     2     0
call         r18     0     0
setlist      r17     0     1
gettabup     r18    u0    k0
move         r19    r5
move         r20    r6
newtable     r21     0     1
newtable     r22     0    17
settable     r22   k17   k48
settable     r22   k38  k110
settable     r22   k28   k72
settable     r22   k41   k73
settable     r22   k43  k146
settable     r22   k45   k75
settable     r22   k47   k76
settable     r22   k49  k122
settable     r22   k51   k78
settable     r22   k53   k88
settable     r22   k80  k147
settable     r22   k82   k75
settable     r22   k83   k76
settable     r22   k84  k144
settable     r22   k86   k78
settable     r22   k87   k79
settable     r22   k89  k107
settable     r21   k93   r22
call         r20     2     0
call         r19     0     2
gettable     r18   r18   r19
newtable     r19     0     0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    29
settable     r23   k17   k42
settable     r23   k38  k112
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43   k74
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49   k79
settable     r23   k51   k78
settable     r23   k53   k88
settable     r23   k80   k81
settable     r23   k82   k75
settable     r23   k83   k99
settable     r23   k84  k141
settable     r23   k86   k78
settable     r23   k87   k79
settable     r23   k89  k107
settable     r23   k91   k75
settable     r23   k92  k119
settable     r23   k72  k144
settable     r23   k40   k78
settable     r23   k37   k85
settable     r23  k109  k145
settable     r23   k44   k75
settable     r23  k110   k99
settable     r23  k111   k77
settable     r23   k71   k78
settable     r23  k112   k88
settable     r23  k113  k100
settable     r23  k115   k75
settable     r23  k116   k76
settable     r23   k75  k141
settable     r23  k117   k78
settable     r23   k39   k79
settable     r23  k118  k140
settable     r23  k120   k75
settable     r23  k121   k76
settable     r23   k50  k122
settable     r23  k139   k78
settable     r23   k42   k88
settable     r23  k129   k90
settable     r23   k48   k75
settable     r23   k54   k76
settable     r23  k148  k102
settable     r23   k52   k78
settable     r23  k149  k150
settable     r23  k151  k145
settable     r23  k102   k75
settable     r23   k46  k152
settable     r23  k150  k106
settable     r22   k93   r23
call         r21     2     0
call         r20     0     0
setlist      r19     0     1
loadnil      r20     0
newtable     r21     0     0
move         r22    r5
move         r23    r6
newtable     r24     0     1
newtable     r25     0    11
settable     r25   k17   k54
settable     r25   k38   k97
settable     r25   k28   k72
settable     r25   k41   k73
settable     r25   k43   k74
settable     r25   k45   k75
settable     r25   k47  k101
settable     r25   k49  k143
settable     r25   k51   k78
settable     r25   k53   k79
settable     r25   k80  k107
settable     r24   k93   r25
call         r23     2     0
call         r22     0     0
setlist      r21     0     1
call         r18     4     2
test         r18     1
jmp            0 l27066
return        r0     1
.label	l27066
gettabup     r19    u0  k153
move         r20   r17
call         r19     2     4
jmp            0 l27074
.label	l27070
gettable     r24   r18   k17
eq             0   r24   r23
jmp            0 l27074
settabup      u0  k154  k155
.label	l27074
tforcall     r19     2
tforloop     r21 l27070
gettabup     r19    u0  k154
eq             1   r19  k155
jmp            0 l27214
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    14
settable     r23   k17  k129
settable     r23   k38  k111
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43  k130
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49   k46
settable     r23   k51   k78
settable     r23   k53   k88
settable     r23   k80   k90
settable     r23   k82   k75
settable     r23   k83  k101
settable     r23   k84  k102
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    33
settable     r23   k17  k156
settable     r23   k38   k71
settable     r23   k28   k72
settable     r23   k41   k17
settable     r23   k43  k157
settable     r23   k45   k75
settable     r23   k47  k158
settable     r23   k49  k144
settable     r23   k51   k78
settable     r23   k53  k150
settable     r23   k80  k145
settable     r23   k82   k75
settable     r23   k83  k114
settable     r23   k84   k46
settable     r23   k86   k78
settable     r23   k87   k88
settable     r23   k89   k90
settable     r23   k91   k75
settable     r23   k92   k76
settable     r23   k72  k159
settable     r23   k40   k78
settable     r23   k37   k88
settable     r23  k109  k160
settable     r23   k44   k75
settable     r23  k110   k76
settable     r23  k111  k159
settable     r23   k71   k78
settable     r23  k112  k150
settable     r23  k113  k145
settable     r23  k115   k75
settable     r23  k116  k114
settable     r23   k75  k144
settable     r23  k117   k78
settable     r23   k39  k106
settable     r23  k118  k142
settable     r23  k120   k75
settable     r23  k121   k76
settable     r23   k50  k141
settable     r23  k139   k78
settable     r23   k42   k88
settable     r23  k129  k100
settable     r23   k48   k75
settable     r23   k54  k101
settable     r23  k148  k108
settable     r23   k52   k78
settable     r23  k149   k88
settable     r23  k151  k160
settable     r23  k102   k75
settable     r23   k46   k76
settable     r23  k150  k159
settable     r23  k108   k78
settable     r23  k143   k88
settable     r23   k85  k107
settable     r23  k106   k75
settable     r23   k88   k90
settable     r23   k79  k159
settable     r23  k161   k78
settable     r23  k162   k25
settable     r23  k163   k99
settable     r23  k164   k75
settable     r23  k165  k158
settable     r23  k166  k144
settable     r23  k167   k78
settable     r23  k168  k150
settable     r23  k169  k145
settable     r22   k93   r23
call         r21     2     0
call         r20     0     0
call         r19     0     1
return        r0     1

.label	l27214
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    14
settable     r23   k17   k54
settable     r23   k38   k97
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43   k98
settable     r23   k45   k75
settable     r23   k47   k99
settable     r23   k49   k77
settable     r23   k51   k78
settable     r23   k53   k88
settable     r23   k80  k100
settable     r23   k82   k75
settable     r23   k83  k101
settable     r23   k84  k102
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    33
settable     r23   k17  k156
settable     r23   k38   k71
settable     r23   k28   k72
settable     r23   k41   k17
settable     r23   k43  k130
settable     r23   k45   k75
settable     r23   k47  k147
settable     r23   k49   k46
settable     r23   k51   k78
settable     r23   k53  k150
settable     r23   k80  k145
settable     r23   k82   k75
settable     r23   k83  k152
settable     r23   k84  k141
settable     r23   k86   k78
settable     r23   k87   k88
settable     r23   k89  k160
settable     r23   k91   k75
settable     r23   k92   k76
settable     r23   k72  k159
settable     r23   k40   k78
settable     r23   k37   k88
settable     r23  k109   k90
settable     r23   k44   k75
settable     r23  k110   k76
settable     r23  k111   k46
settable     r23   k71   k78
settable     r23  k112  k106
settable     r23  k113  k100
settable     r23  k115   k75
settable     r23  k116  k101
settable     r23   k75  k102
settable     r23  k117   k78
settable     r23   k39  k150
settable     r23  k118  k145
settable     r23  k120   k75
settable     r23  k121  k114
settable     r23   k50  k144
settable     r23  k139   k78
settable     r23   k42  k106
settable     r23  k129  k142
settable     r23   k48   k75
settable     r23   k54   k76
settable     r23  k148  k141
settable     r23   k52   k78
settable     r23  k149   k88
settable     r23  k151  k100
settable     r23  k102   k75
settable     r23   k46  k101
settable     r23  k150  k108
settable     r23  k108   k78
settable     r23  k143   k88
settable     r23   k85  k160
settable     r23  k106   k75
settable     r23   k88   k76
settable     r23   k79  k159
settable     r23  k161   k78
settable     r23  k162   k88
settable     r23  k163  k107
settable     r23  k164   k75
settable     r23  k165  k119
settable     r23  k166  k144
settable     r23  k167   k78
settable     r23  k168  k150
settable     r23  k169  k142
settable     r22   k93   r23
call         r21     2     0
call         r20     0     0
call         r19     0     1
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    25
settable     r23   k17  k129
settable     r23   k38  k112
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43  k130
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49   k46
settable     r23   k51   k78
settable     r23   k53  k106
settable     r23   k80  k142
settable     r23   k82   k75
settable     r23   k83   k76
settable     r23   k84  k159
settable     r23   k86   k78
settable     r23   k87   k85
settable     r23   k89   k90
settable     r23   k91   k75
settable     r23   k92   k76
settable     r23   k72   k46
settable     r23   k40   k78
settable     r23   k37   k88
settable     r23  k109  k100
settable     r23   k44   k75
settable     r23  k110  k101
settable     r23  k111   k46
settable     r23   k71   k78
settable     r23  k112   k88
settable     r23  k113  k101
settable     r23  k115   k75
settable     r23  k116  k101
settable     r23   k75  k102
settable     r23  k117   k78
settable     r23   k39   k88
settable     r23  k118  k100
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
call         r19     1     1
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    25
settable     r23   k17   k48
settable     r23   k38  k112
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43   k74
settable     r23   k45   k75
settable     r23   k47   k99
settable     r23   k49   k77
settable     r23   k51   k78
settable     r23   k53   k88
settable     r23   k80   k90
settable     r23   k82   k75
settable     r23   k83   k99
settable     r23   k84  k141
settable     r23   k86   k78
settable     r23   k87   k88
settable     r23   k89  k152
settable     r23   k91   k75
settable     r23   k92  k114
settable     r23   k72   k25
settable     r23   k40   k78
settable     r23   k37   k79
settable     r23  k109   k81
settable     r23   k44   k75
settable     r23  k110   k76
settable     r23  k111  k161
settable     r23   k71   k78
settable     r23  k112  k106
settable     r23  k113   k90
settable     r23  k115   k75
settable     r23  k116   k76
settable     r23   k75   k46
settable     r23  k117   k78
settable     r23   k39   k88
settable     r23  k118   k90
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    42
settable     r23   k17   k50
settable     r23   k38  k111
settable     r23   k28   k72
settable     r23   k41  k170
settable     r23   k43  k171
settable     r23   k45   k75
settable     r23   k47  k152
settable     r23   k49  k108
settable     r23   k51   k78
settable     r23   k53  k143
settable     r23   k80  k152
settable     r23   k82   k75
settable     r23   k83  k152
settable     r23   k84  k150
settable     r23   k86   k78
settable     r23   k87  k108
settable     r23   k89  k142
settable     r23   k91   k75
settable     r23   k92  k152
settable     r23   k72  k143
settable     r23   k40   k78
settable     r23   k37  k143
settable     r23  k109  k107
settable     r23   k44   k75
settable     r23  k110  k152
settable     r23  k111   k85
settable     r23   k71   k78
settable     r23  k112  k143
settable     r23  k113  k114
settable     r23  k115   k75
settable     r23  k116  k152
settable     r23   k75   k88
settable     r23  k117   k78
settable     r23   k39  k108
settable     r23  k118  k142
settable     r23  k120   k75
settable     r23  k121  k140
settable     r23   k50  k144
settable     r23  k139   k78
settable     r23   k42  k143
settable     r23  k129  k114
settable     r23   k48   k75
settable     r23   k54  k152
settable     r23  k148  k102
settable     r23   k52   k78
settable     r23  k149  k143
settable     r23  k151  k107
settable     r23  k102   k75
settable     r23   k46  k140
settable     r23  k150   k77
settable     r23  k108   k78
settable     r23  k143  k108
settable     r23   k85   k90
settable     r23  k106   k75
settable     r23   k88  k152
settable     r23   k79   k85
settable     r23  k161   k78
settable     r23  k162  k108
settable     r23  k163  k142
settable     r23  k164   k75
settable     r23  k165  k140
settable     r23  k166   k77
settable     r23  k167   k78
settable     r23  k168  k143
settable     r23  k169   k76
settable     r23  k172   k75
settable     r23  k173  k140
settable     r23  k174   k77
settable     r23  k175   k78
settable     r23  k176   k79
settable     r23  k177  k158
settable     r23  k178   k75
settable     r23  k179  k140
settable     r23  k180   k77
settable     r23  k181   k78
settable     r23  k182  k143
settable     r23  k183   k76
settable     r23  k184   k75
settable     r23  k185  k140
settable     r23  k186   k77
settable     r23  k187   k78
settable     r23  k188  k108
settable     r23  k189  k145
settable     r23  k190   k75
settable     r23  k191  k140
settable     r23  k192  k141
settable     r23  k193   k78
settable     r23  k156  k143
settable     r23  k194  k107
settable     r23  k195   k75
settable     r23  k196  k152
settable     r23  k197  k143
settable     r23  k198   k78
settable     r23  k199  k143
settable     r23  k200  k119
settable     r23  k201   k75
settable     r23   k25  k152
settable     r23  k122  k143
settable     r23  k144   k78
settable     r23   k77  k143
settable     r23  k159   k81
settable     r23  k141   k75
settable     r23  k202  k152
settable     r23  k203  k108
settable     r23  k204   k78
settable     r23  k205  k108
settable     r23  k206  k145
settable     r23  k207   k75
settable     r23  k208  k152
settable     r23   k70   k88
settable     r23  k209   k78
settable     r23  k210  k108
settable     r23  k211  k142
settable     r23  k212   k75
settable     r23  k213  k140
settable     r23  k214  k144
settable     r23  k215   k78
settable     r23  k216  k143
settable     r23  k217   k81
settable     r23  k218   k75
settable     r23  k219  k140
settable     r23   k26  k144
settable     r23  k220   k78
settable     r23  k221  k143
settable     r23  k222  k140
settable     r23  k223   k75
settable     r23  k224  k152
settable     r23  k225   k85
settable     r23  k226   k78
settable     r23  k227  k143
settable     r23  k228  k119
settable     r23  k229   k75
settable     r23  k230  k152
settable     r23  k231  k143
settable     r23  k232   k78
settable     r23  k233  k143
settable     r23  k234   k81
settable     r23  k235   k75
settable     r23  k236  k140
settable     r23  k237  k159
settable     r23  k238   k78
settable     r23  k239  k143
settable     r23  k240   k99
settable     r23  k241   k75
settable     r23  k242  k152
settable     r23  k243  k106
settable     r23  k244   k78
settable     r23  k245  k143
settable     r23  k246  k107
settable     r23   k20   k75
settable     r23  k247  k152
settable     r23  k248   k85
settable     r23  k249   k78
settable     r23  k250  k108
settable     r23  k251  k100
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettabup     r21    u0    k0
move         r22    r5
move         r23    r6
newtable     r24     0     1
newtable     r25     0    23
settable     r25   k17  k129
settable     r25   k38   k97
settable     r25   k28   k72
settable     r25   k41  k252
settable     r25   k43  k253
settable     r25   k45   k75
settable     r25   k47  k114
settable     r25   k49  k144
settable     r25   k51   k78
settable     r25   k53   k85
settable     r25   k80   k81
settable     r25   k82   k75
settable     r25   k83   k99
settable     r25   k84  k122
settable     r25   k86   k78
settable     r25   k87   k85
settable     r25   k89  k107
settable     r25   k91   k75
settable     r25   k92   k99
settable     r25   k72  k108
settable     r25   k40   k78
settable     r25   k37   k85
settable     r25  k109  k160
settable     r25   k44   k75
settable     r25  k110  k114
settable     r25  k111  k159
settable     r25   k71   k78
settable     r25  k112   k85
settable     r25  k113  k107
settable     r24   k93   r25
call         r23     2     0
call         r22     0     2
gettable     r21   r21   r22
loadbool     r22     0     0
gettabup     r23    u0    k0
move         r24    r5
move         r25    r6
newtable     r26     0     1
newtable     r27     0    23
settable     r27   k17   k42
settable     r27   k38  k112
settable     r27   k28   k72
settable     r27   k41  k254
settable     r27   k43  k253
settable     r27   k45   k75
settable     r27   k47  k114
settable     r27   k49  k108
settable     r27   k51   k78
settable     r27   k53   k85
settable     r27   k80  k158
settable     r27   k82   k75
settable     r27   k83   k99
settable     r27   k84  k122
settable     r27   k86   k78
settable     r27   k87   k85
settable     r27   k89   k81
settable     r27   k91   k75
settable     r27   k92  k114
settable     r27   k72   k77
settable     r27   k40   k78
settable     r27   k37  k106
settable     r27  k109   k81
settable     r27   k44   k75
settable     r27  k110  k152
settable     r27  k111   k77
settable     r27   k71   k78
settable     r27  k112   k85
settable     r27  k113  k101
settable     r26   k93   r27
call         r25     2     0
call         r24     0     2
gettable     r23   r23   r24
loadk        r24   k66
loadk        r25  k255
loadk        r26   k66
call         r19     8     1
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    26
settable     r23   k17   k48
settable     r23   k38  k110
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43  k146
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49  k122
settable     r23   k51   k78
settable     r23   k53  k106
settable     r23   k80  k100
settable     r23   k82   k75
settable     r23   k83   k76
settable     r23   k84   k46
settable     r23   k86   k78
settable     r23   k87   k88
settable     r23   k89  k100
settable     r23   k91   k75
settable     r23   k92   k76
settable     r23   k72  k141
settable     r23   k40   k78
settable     r23   k37   k85
settable     r23  k109   k90
settable     r23   k44   k75
settable     r23  k110   k76
settable     r23  k111   k46
settable     r23   k71   k78
settable     r23  k112   k88
settable     r23  k113  k100
settable     r23  k115   k75
settable     r23  k116  k101
settable     r23   k75   k46
settable     r23  k117   k78
settable     r23   k39   k88
settable     r23  k118  k147
settable     r23  k120   k75
settable     r23  k121   k76
settable     r23   k50   k46
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
call         r19     1     1
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    25
settable     r23   k17   k48
settable     r23   k38   k71
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43   k74
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49  k150
settable     r23   k51   k78
settable     r23   k53   k88
settable     r23   k80  k114
settable     r23   k82   k75
settable     r23   k83   k76
settable     r23   k84   k25
settable     r23   k86   k78
settable     r23   k87   k88
settable     r23   k89   k81
settable     r23   k91   k75
settable     r23   k92  k114
settable     r23   k72   k25
settable     r23   k40   k78
settable     r23   k37   k79
settable     r23  k109   k81
settable     r23   k44   k75
settable     r23  k110   k76
settable     r23  k111  k161
settable     r23   k71   k78
settable     r23  k112  k106
settable     r23  k113   k90
settable     r23  k115   k75
settable     r23  k116   k76
settable     r23   k75   k46
settable     r23  k117   k78
settable     r23   k39   k88
settable     r23  k118   k90
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0     2
settable     r23   k17   k50
settable     r23   k38  k111
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettabup     r21    u0    k0
move         r22    r5
move         r23    r6
newtable     r24     0     1
newtable     r25     0    23
settable     r25   k17  k129
settable     r25   k38   k97
settable     r25   k28   k72
settable     r25   k41  k252
settable     r25   k43  k253
settable     r25   k45   k75
settable     r25   k47  k114
settable     r25   k49  k144
settable     r25   k51   k78
settable     r25   k53   k85
settable     r25   k80   k81
settable     r25   k82   k75
settable     r25   k83   k99
settable     r25   k84  k122
settable     r25   k86   k78
settable     r25   k87   k85
settable     r25   k89  k107
settable     r25   k91   k75
settable     r25   k92   k99
settable     r25   k72  k108
settable     r25   k40   k78
settable     r25   k37   k85
settable     r25  k109  k160
settable     r25   k44   k75
settable     r25  k110  k114
settable     r25  k111  k159
settable     r25   k71   k78
settable     r25  k112   k85
settable     r25  k113  k107
settable     r24   k93   r25
call         r23     2     0
call         r22     0     2
gettable     r21   r21   r22
loadbool     r22     0     0
gettabup     r23    u0    k0
move         r24    r5
move         r25    r6
newtable     r26     0     1
newtable     r27     0    23
settable     r27   k17   k42
settable     r27   k38  k112
settable     r27   k28   k72
settable     r27   k41  k254
settable     r27   k43  k253
settable     r27   k45   k75
settable     r27   k47  k114
settable     r27   k49  k108
settable     r27   k51   k78
settable     r27   k53   k85
settable     r27   k80  k158
settable     r27   k82   k75
settable     r27   k83   k99
settable     r27   k84  k122
settable     r27   k86   k78
settable     r27   k87   k85
settable     r27   k89   k81
settable     r27   k91   k75
settable     r27   k92  k114
settable     r27   k72   k77
settable     r27   k40   k78
settable     r27   k37  k106
settable     r27  k109   k81
settable     r27   k44   k75
settable     r27  k110  k152
settable     r27  k111   k77
settable     r27   k71   k78
settable     r27  k112   k85
settable     r27  k113  k101
settable     r26   k93   r27
call         r25     2     0
call         r24     0     2
gettable     r23   r23   r24
loadk        r24   k66
loadk        r25  k255
loadk        r26   k66
call         r19     8     1
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    26
settable     r23   k17   k48
settable     r23   k38  k110
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43  k146
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49  k122
settable     r23   k51   k78
settable     r23   k53  k106
settable     r23   k80  k100
settable     r23   k82   k75
settable     r23   k83   k76
settable     r23   k84   k46
settable     r23   k86   k78
settable     r23   k87   k88
settable     r23   k89  k100
settable     r23   k91   k75
settable     r23   k92   k76
settable     r23   k72  k141
settable     r23   k40   k78
settable     r23   k37   k85
settable     r23  k109   k90
settable     r23   k44   k75
settable     r23  k110   k76
settable     r23  k111   k46
settable     r23   k71   k78
settable     r23  k112   k88
settable     r23  k113  k100
settable     r23  k115   k75
settable     r23  k116  k101
settable     r23   k75   k46
settable     r23  k117   k78
settable     r23   k39   k88
settable     r23  k118  k147
settable     r23  k120   k75
settable     r23  k121   k76
settable     r23   k50   k46
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
call         r19     1     1
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    23
settable     r23   k17   k48
settable     r23   k38  k105
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43   k74
settable     r23   k45   k75
settable     r23   k47  k101
settable     r23   k49  k102
settable     r23   k51   k78
settable     r23   k53   k85
settable     r23   k80   k90
settable     r23   k82   k75
settable     r23   k83   k76
settable     r23   k84   k46
settable     r23   k86   k78
settable     r23   k87   k88
settable     r23   k89  k100
settable     r23   k91   k75
settable     r23   k92  k101
settable     r23   k72   k46
settable     r23   k40   k78
settable     r23   k37   k88
settable     r23  k109  k101
settable     r23   k44   k75
settable     r23  k110  k101
settable     r23  k111  k102
settable     r23   k71   k78
settable     r23  k112   k88
settable     r23  k113  k100
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
loadk        r20   k42
loadnil      r21     7
call         r19    10     2
move         r16   r19
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    18
settable     r23   k17   k48
settable     r23   k38  k136
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43    k0
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49   k85
settable     r23   k51   k78
settable     r23   k53   k79
settable     r23   k80  k107
settable     r23   k82   k75
settable     r23   k83  k152
settable     r23   k84   k77
settable     r23   k86   k78
settable     r23   k87   k88
settable     r23   k89  k101
settable     r23   k91   k75
settable     r23   k92   k76
settable     r23   k72   k79
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0     2
settable     r23   k17   k50
settable     r23   k38  k110
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettabup     r21    u0    k0
move         r22    r5
move         r23    r6
newtable     r24     0     1
newtable     r25     0    23
settable     r25   k17  k129
settable     r25   k38   k97
settable     r25   k28   k72
settable     r25   k41  k252
settable     r25   k43  k253
settable     r25   k45   k75
settable     r25   k47  k114
settable     r25   k49  k144
settable     r25   k51   k78
settable     r25   k53   k85
settable     r25   k80   k81
settable     r25   k82   k75
settable     r25   k83   k99
settable     r25   k84  k122
settable     r25   k86   k78
settable     r25   k87   k85
settable     r25   k89  k107
settable     r25   k91   k75
settable     r25   k92   k99
settable     r25   k72  k108
settable     r25   k40   k78
settable     r25   k37   k85
settable     r25  k109  k160
settable     r25   k44   k75
settable     r25  k110  k114
settable     r25  k111  k159
settable     r25   k71   k78
settable     r25  k112   k85
settable     r25  k113  k107
settable     r24   k93   r25
call         r23     2     0
call         r22     0     2
gettable     r21   r21   r22
call         r19     3     1
gettabup     r19    u0    k0
move         r20    r5
move         r21    r6
newtable     r22     0     1
newtable     r23     0    26
settable     r23   k17   k48
settable     r23   k38  k110
settable     r23   k28   k72
settable     r23   k41   k73
settable     r23   k43  k146
settable     r23   k45   k75
settable     r23   k47   k76
settable     r23   k49  k122
settable     r23   k51   k78
settable     r23   k53  k106
settable     r23   k80  k100
settable     r23   k82   k75
settable     r23   k83   k76
settable     r23   k84   k46
settable     r23   k86   k78
settable     r23   k87   k88
settable     r23   k89  k100
settable     r23   k91   k75
settable     r23   k92   k76
settable     r23   k72  k141
settable     r23   k40   k78
settable     r23   k37   k85
settable     r23  k109   k90
settable     r23   k44   k75
settable     r23  k110   k76
settable     r23  k111   k46
settable     r23   k71   k78
settable     r23  k112   k88
settable     r23  k113  k100
settable     r23  k115   k75
settable     r23  k116  k101
settable     r23   k75   k46
settable     r23  k117   k78
settable     r23   k39   k88
settable     r23  k118  k147
settable     r23  k120   k75
settable     r23  k121   k76
settable     r23   k50   k46
settable     r22   k93   r23
call         r21     2     0
call         r20     0     2
gettable     r19   r19   r20
call         r19     1     1
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28081

.label	l28081
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28123

.label	l28123
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28165

.label	l28165
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28207

.label	l28207
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28249

.label	l28249
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28291

.label	l28291
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28333

.label	l28333
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28375

.label	l28375
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28417

.label	l28417
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28459

.label	l28459
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28501

.label	l28501
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28543

.label	l28543
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28585

.label	l28585
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28627

.label	l28627
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28669

.label	l28669
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28711

.label	l28711
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28753

.label	l28753
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28795

.label	l28795
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28837

.label	l28837
loadnil      r19     0
test         r19     0
jmp            0 l28882
jmp            0 l28879

.label	l28879
loadnil      r19     0
test         r19     0
jmp            0 l28882
.label	l28882
gettabup     r19    u0    k9
settabup      u0    k9   r19
return        r0     1

.function	main/f0/f0

.linedefined	-620756992
.lastlinedefined	-318767104
.numparams	29
.is_vararg	1
.maxstacksize	29
.source	null

.upvalue	null	0	false

.constant	k0	"gsub"
.constant	k1	" "
.constant	k2	""
.constant	k3	".."

self          r1    r0    k0
loadk         r3    k1
loadk         r4    k2
call          r1     4     2
move          r0    r1
self          r1    r0    k0
loadk         r3    k3
closure       r4    f0
call          r1     4     2
return        r1     2
return        r0     1

.function	main/f0/f0/f0

.linedefined	-620756992
.lastlinedefined	-318767104
.numparams	29
.is_vararg	1
.maxstacksize	29
.source	null

.upvalue	null	0	false

.constant	k0	"string"
.constant	k1	"char"
.constant	k2	"tonumber"
.constant	k3	16
.constant	k4	500
.constant	k5	256

gettabup      r1    u0    k0
gettable      r1    r1    k1
gettabup      r2    u0    k2
move          r3    r0
loadk         r4    k3
call          r2     3     2
add           r2    r2    k4
mod           r2    r2    k5
tailcall      r1     2
return        r1     0
return        r0     1

.function	main/f0/f1

.linedefined	-620756992
.lastlinedefined	-318767104
.numparams	29
.is_vararg	1
.maxstacksize	29
.source	null

.upvalue	null	0	false
.upvalue	null	2	true
.upvalue	null	3	true
.upvalue	null	4	true

.constant	k0	"DxD"
.constant	k1	""
.constant	k2	"ipairs"
.constant	k3	1
.constant	k4	"string"
.constant	k5	"char"
.constant	k6	256
.constant	k7	2
.constant	k8	6
.constant	k9	4
.constant	k10	5
.constant	k11	124882960

gettable      r1    r0    k0
loadk         r2    k1
gettabup      r3    u0    k2
move          r4    r1
call          r3     2     4
jmp            0 l3682
.label	l7
eq             0    r6    k3
jmp            0  l924
.label	l9
loadbool      r7     0     0
test          r7     0
jmp            0   l27
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0    l9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0    l9
.label	l27
loadbool      r7     0     0
test          r7     0
jmp            0   l45
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0   l27
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0   l27
.label	l45
loadbool      r7     0     0
test          r7     0
jmp            0   l63
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0   l45
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0   l45
.label	l63
loadbool      r7     0     0
test          r7     0
jmp            0   l81
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0   l63
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0   l63
.label	l81
loadbool      r7     0     0
test          r7     0
jmp            0   l99
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0   l81
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0   l81
.label	l99
loadbool      r7     0     0
test          r7     0
jmp            0  l117
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0   l99
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0   l99
.label	l117
loadbool      r7     0     0
test          r7     0
jmp            0  l135
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l117
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l117
.label	l135
loadbool      r7     0     0
test          r7     0
jmp            0  l153
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l135
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l135
.label	l153
loadbool      r7     0     0
test          r7     0
jmp            0  l171
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l153
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l153
.label	l171
loadbool      r7     0     0
test          r7     0
jmp            0  l189
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l171
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l171
.label	l189
loadbool      r7     0     0
test          r7     0
jmp            0  l207
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l189
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l189
.label	l207
loadbool      r7     0     0
test          r7     0
jmp            0  l225
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l207
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l207
.label	l225
loadbool      r7     0     0
test          r7     0
jmp            0  l243
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l225
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l225
.label	l243
loadbool      r7     0     0
test          r7     0
jmp            0  l261
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l243
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l243
.label	l261
loadbool      r7     0     0
test          r7     0
jmp            0  l279
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l261
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l261
.label	l279
loadbool      r7     0     0
test          r7     0
jmp            0  l297
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l279
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l279
.label	l297
loadbool      r7     0     0
test          r7     0
jmp            0  l315
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l297
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l297
.label	l315
loadbool      r7     0     0
test          r7     0
jmp            0  l333
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l315
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l315
.label	l333
loadbool      r7     0     0
test          r7     0
jmp            0  l351
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l333
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l333
.label	l351
loadbool      r7     0     0
test          r7     0
jmp            0  l369
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l351
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l351
.label	l369
loadbool      r7     0     0
test          r7     0
jmp            0  l387
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l369
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l369
.label	l387
loadbool      r7     0     0
test          r7     0
jmp            0  l405
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l387
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l387
.label	l405
loadbool      r7     0     0
test          r7     0
jmp            0  l423
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l405
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l405
.label	l423
loadbool      r7     0     0
test          r7     0
jmp            0  l441
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l423
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l423
.label	l441
loadbool      r7     0     0
test          r7     0
jmp            0  l459
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l441
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l441
.label	l459
loadbool      r7     0     0
test          r7     0
jmp            0  l477
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l459
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l459
.label	l477
loadbool      r7     0     0
test          r7     0
jmp            0  l495
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l477
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l477
.label	l495
loadbool      r7     0     0
test          r7     0
jmp            0  l513
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l495
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l495
.label	l513
loadbool      r7     0     0
test          r7     0
jmp            0  l531
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l513
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l513
.label	l531
loadbool      r7     0     0
test          r7     0
jmp            0  l549
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l531
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l531
.label	l549
loadbool      r7     0     0
test          r7     0
jmp            0  l567
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l549
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l549
.label	l567
loadbool      r7     0     0
test          r7     0
jmp            0  l585
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l567
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l567
.label	l585
loadbool      r7     0     0
test          r7     0
jmp            0  l603
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l585
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l585
.label	l603
loadbool      r7     0     0
test          r7     0
jmp            0  l621
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l603
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l603
.label	l621
loadbool      r7     0     0
test          r7     0
jmp            0  l639
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l621
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l621
.label	l639
loadbool      r7     0     0
test          r7     0
jmp            0  l657
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l639
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l639
.label	l657
loadbool      r7     0     0
test          r7     0
jmp            0  l675
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l657
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l657
.label	l675
loadbool      r7     0     0
test          r7     0
jmp            0  l693
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l675
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l675
.label	l693
loadbool      r7     0     0
test          r7     0
jmp            0  l711
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l693
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l693
.label	l711
loadbool      r7     0     0
test          r7     0
jmp            0  l729
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l711
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l711
.label	l729
loadbool      r7     0     0
test          r7     0
jmp            0  l747
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l729
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l729
.label	l747
loadbool      r7     0     0
test          r7     0
jmp            0  l765
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l747
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l747
.label	l765
loadbool      r7     0     0
test          r7     0
jmp            0  l783
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l765
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l765
.label	l783
loadbool      r7     0     0
test          r7     0
jmp            0  l801
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l783
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l783
.label	l801
loadbool      r7     0     0
test          r7     0
jmp            0  l819
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l801
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l801
.label	l819
loadbool      r7     0     0
test          r7     0
jmp            0  l837
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l819
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l819
.label	l837
loadbool      r7     0     0
test          r7     0
jmp            0  l855
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l837
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l837
.label	l855
loadbool      r7     0     0
test          r7     0
jmp            0  l873
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l855
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l855
.label	l873
loadbool      r7     0     0
test          r7     0
jmp            0  l891
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l873
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l873
.label	l891
loadbool      r7     0     0
test          r7     0
jmp            0  l909
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l891
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l891
.label	l909
move          r7    r2
gettabup      r8    u0    k4
gettable      r8    r8    k5
gettable      r9    r1    k3
gettabup     r10    u1    k3
add           r9    r9   r10
gettabup     r10    u2    k3
sub          r10   r10    k3
gettabup     r11    u1    k3
add          r11   r11    k3
mul          r10   r10   r11
add           r9    r9   r10
mod           r9    r9    k6
call          r8     2     2
concat        r2    r7    r8
.label	l924
eq             0    r6    k7
jmp            0 l1841
.label	l926
loadbool      r7     0     0
test          r7     0
jmp            0  l944
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l926
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l926
.label	l944
loadbool      r7     0     0
test          r7     0
jmp            0  l962
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l944
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l944
.label	l962
loadbool      r7     0     0
test          r7     0
jmp            0  l980
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l962
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l962
.label	l980
loadbool      r7     0     0
test          r7     0
jmp            0  l998
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l980
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l980
.label	l998
loadbool      r7     0     0
test          r7     0
jmp            0 l1016
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0  l998
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0  l998
.label	l1016
loadbool      r7     0     0
test          r7     0
jmp            0 l1034
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1016
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1016
.label	l1034
loadbool      r7     0     0
test          r7     0
jmp            0 l1052
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1034
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1034
.label	l1052
loadbool      r7     0     0
test          r7     0
jmp            0 l1070
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1052
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1052
.label	l1070
loadbool      r7     0     0
test          r7     0
jmp            0 l1088
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1070
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1070
.label	l1088
loadbool      r7     0     0
test          r7     0
jmp            0 l1106
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1088
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1088
.label	l1106
loadbool      r7     0     0
test          r7     0
jmp            0 l1124
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1106
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1106
.label	l1124
loadbool      r7     0     0
test          r7     0
jmp            0 l1142
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1124
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1124
.label	l1142
loadbool      r7     0     0
test          r7     0
jmp            0 l1160
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1142
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1142
.label	l1160
loadbool      r7     0     0
test          r7     0
jmp            0 l1178
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1160
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1160
.label	l1178
loadbool      r7     0     0
test          r7     0
jmp            0 l1196
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1178
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1178
.label	l1196
loadbool      r7     0     0
test          r7     0
jmp            0 l1214
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1196
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1196
.label	l1214
loadbool      r7     0     0
test          r7     0
jmp            0 l1232
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1214
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1214
.label	l1232
loadbool      r7     0     0
test          r7     0
jmp            0 l1250
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1232
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1232
.label	l1250
loadbool      r7     0     0
test          r7     0
jmp            0 l1268
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1250
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1250
.label	l1268
loadbool      r7     0     0
test          r7     0
jmp            0 l1286
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1268
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1268
.label	l1286
loadbool      r7     0     0
test          r7     0
jmp            0 l1304
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1286
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1286
.label	l1304
loadbool      r7     0     0
test          r7     0
jmp            0 l1322
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1304
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1304
.label	l1322
loadbool      r7     0     0
test          r7     0
jmp            0 l1340
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1322
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1322
.label	l1340
loadbool      r7     0     0
test          r7     0
jmp            0 l1358
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1340
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1340
.label	l1358
loadbool      r7     0     0
test          r7     0
jmp            0 l1376
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1358
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1358
.label	l1376
loadbool      r7     0     0
test          r7     0
jmp            0 l1394
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1376
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1376
.label	l1394
loadbool      r7     0     0
test          r7     0
jmp            0 l1412
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1394
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1394
.label	l1412
loadbool      r7     0     0
test          r7     0
jmp            0 l1430
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1412
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1412
.label	l1430
loadbool      r7     0     0
test          r7     0
jmp            0 l1448
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1430
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1430
.label	l1448
loadbool      r7     0     0
test          r7     0
jmp            0 l1466
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1448
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1448
.label	l1466
loadbool      r7     0     0
test          r7     0
jmp            0 l1484
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1466
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1466
.label	l1484
loadbool      r7     0     0
test          r7     0
jmp            0 l1502
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1484
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1484
.label	l1502
loadbool      r7     0     0
test          r7     0
jmp            0 l1520
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1502
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1502
.label	l1520
loadbool      r7     0     0
test          r7     0
jmp            0 l1538
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1520
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1520
.label	l1538
loadbool      r7     0     0
test          r7     0
jmp            0 l1556
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1538
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1538
.label	l1556
loadbool      r7     0     0
test          r7     0
jmp            0 l1574
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1556
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1556
.label	l1574
loadbool      r7     0     0
test          r7     0
jmp            0 l1592
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1574
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1574
.label	l1592
loadbool      r7     0     0
test          r7     0
jmp            0 l1610
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1592
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1592
.label	l1610
loadbool      r7     0     0
test          r7     0
jmp            0 l1628
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1610
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1610
.label	l1628
loadbool      r7     0     0
test          r7     0
jmp            0 l1646
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1628
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1628
.label	l1646
loadbool      r7     0     0
test          r7     0
jmp            0 l1664
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1646
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1646
.label	l1664
loadbool      r7     0     0
test          r7     0
jmp            0 l1682
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1664
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1664
.label	l1682
loadbool      r7     0     0
test          r7     0
jmp            0 l1700
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1682
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1682
.label	l1700
loadbool      r7     0     0
test          r7     0
jmp            0 l1718
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1700
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1700
.label	l1718
loadbool      r7     0     0
test          r7     0
jmp            0 l1736
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1718
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1718
.label	l1736
loadbool      r7     0     0
test          r7     0
jmp            0 l1754
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1736
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1736
.label	l1754
loadbool      r7     0     0
test          r7     0
jmp            0 l1772
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1754
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1754
.label	l1772
loadbool      r7     0     0
test          r7     0
jmp            0 l1790
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1772
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1772
.label	l1790
loadbool      r7     0     0
test          r7     0
jmp            0 l1808
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1790
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1790
.label	l1808
loadbool      r7     0     0
test          r7     0
jmp            0 l1826
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1808
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1808
.label	l1826
move          r7    r2
gettabup      r8    u0    k4
gettable      r8    r8    k5
gettable      r9    r1    k7
gettabup     r10    u1    k3
sub           r9    r9   r10
gettabup     r10    u2    k3
add          r10   r10    k7
gettabup     r11    u1    k3
add          r11   r11    k7
mul          r10   r10   r11
add           r9    r9   r10
mod           r9    r9    k6
call          r8     2     2
concat        r2    r7    r8
.label	l1841
lt             0    k7    r6
jmp            0 l2761
lt             0    r6    k8
jmp            0 l2761
.label	l1845
loadbool      r7     0     0
test          r7     0
jmp            0 l1863
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1845
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1845
.label	l1863
loadbool      r7     0     0
test          r7     0
jmp            0 l1881
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1863
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1863
.label	l1881
loadbool      r7     0     0
test          r7     0
jmp            0 l1899
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1881
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1881
.label	l1899
loadbool      r7     0     0
test          r7     0
jmp            0 l1917
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1899
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1899
.label	l1917
loadbool      r7     0     0
test          r7     0
jmp            0 l1935
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1917
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1917
.label	l1935
loadbool      r7     0     0
test          r7     0
jmp            0 l1953
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1935
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1935
.label	l1953
loadbool      r7     0     0
test          r7     0
jmp            0 l1971
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1953
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1953
.label	l1971
loadbool      r7     0     0
test          r7     0
jmp            0 l1989
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1971
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1971
.label	l1989
loadbool      r7     0     0
test          r7     0
jmp            0 l2007
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l1989
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l1989
.label	l2007
loadbool      r7     0     0
test          r7     0
jmp            0 l2025
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2007
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2007
.label	l2025
loadbool      r7     0     0
test          r7     0
jmp            0 l2043
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2025
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2025
.label	l2043
loadbool      r7     0     0
test          r7     0
jmp            0 l2061
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2043
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2043
.label	l2061
loadbool      r7     0     0
test          r7     0
jmp            0 l2079
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2061
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2061
.label	l2079
loadbool      r7     0     0
test          r7     0
jmp            0 l2097
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2079
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2079
.label	l2097
loadbool      r7     0     0
test          r7     0
jmp            0 l2115
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2097
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2097
.label	l2115
loadbool      r7     0     0
test          r7     0
jmp            0 l2133
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2115
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2115
.label	l2133
loadbool      r7     0     0
test          r7     0
jmp            0 l2151
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2133
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2133
.label	l2151
loadbool      r7     0     0
test          r7     0
jmp            0 l2169
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2151
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2151
.label	l2169
loadbool      r7     0     0
test          r7     0
jmp            0 l2187
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2169
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2169
.label	l2187
loadbool      r7     0     0
test          r7     0
jmp            0 l2205
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2187
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2187
.label	l2205
loadbool      r7     0     0
test          r7     0
jmp            0 l2223
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2205
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2205
.label	l2223
loadbool      r7     0     0
test          r7     0
jmp            0 l2241
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2223
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2223
.label	l2241
loadbool      r7     0     0
test          r7     0
jmp            0 l2259
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2241
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2241
.label	l2259
loadbool      r7     0     0
test          r7     0
jmp            0 l2277
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2259
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2259
.label	l2277
loadbool      r7     0     0
test          r7     0
jmp            0 l2295
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2277
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2277
.label	l2295
loadbool      r7     0     0
test          r7     0
jmp            0 l2313
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2295
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2295
.label	l2313
loadbool      r7     0     0
test          r7     0
jmp            0 l2331
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2313
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2313
.label	l2331
loadbool      r7     0     0
test          r7     0
jmp            0 l2349
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2331
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2331
.label	l2349
loadbool      r7     0     0
test          r7     0
jmp            0 l2367
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2349
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2349
.label	l2367
loadbool      r7     0     0
test          r7     0
jmp            0 l2385
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2367
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2367
.label	l2385
loadbool      r7     0     0
test          r7     0
jmp            0 l2403
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2385
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2385
.label	l2403
loadbool      r7     0     0
test          r7     0
jmp            0 l2421
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2403
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2403
.label	l2421
loadbool      r7     0     0
test          r7     0
jmp            0 l2439
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2421
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2421
.label	l2439
loadbool      r7     0     0
test          r7     0
jmp            0 l2457
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2439
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2439
.label	l2457
loadbool      r7     0     0
test          r7     0
jmp            0 l2475
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2457
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2457
.label	l2475
loadbool      r7     0     0
test          r7     0
jmp            0 l2493
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2475
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2475
.label	l2493
loadbool      r7     0     0
test          r7     0
jmp            0 l2511
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2493
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2493
.label	l2511
loadbool      r7     0     0
test          r7     0
jmp            0 l2529
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2511
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2511
.label	l2529
loadbool      r7     0     0
test          r7     0
jmp            0 l2547
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2529
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2529
.label	l2547
loadbool      r7     0     0
test          r7     0
jmp            0 l2565
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2547
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2547
.label	l2565
loadbool      r7     0     0
test          r7     0
jmp            0 l2583
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2565
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2565
.label	l2583
loadbool      r7     0     0
test          r7     0
jmp            0 l2601
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2583
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2583
.label	l2601
loadbool      r7     0     0
test          r7     0
jmp            0 l2619
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2601
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2601
.label	l2619
loadbool      r7     0     0
test          r7     0
jmp            0 l2637
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2619
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2619
.label	l2637
loadbool      r7     0     0
test          r7     0
jmp            0 l2655
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2637
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2637
.label	l2655
loadbool      r7     0     0
test          r7     0
jmp            0 l2673
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2655
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2655
.label	l2673
loadbool      r7     0     0
test          r7     0
jmp            0 l2691
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2673
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2673
.label	l2691
loadbool      r7     0     0
test          r7     0
jmp            0 l2709
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2691
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2691
.label	l2709
loadbool      r7     0     0
test          r7     0
jmp            0 l2727
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2709
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2709
.label	l2727
loadbool      r7     0     0
test          r7     0
jmp            0 l2745
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2727
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2727
.label	l2745
move          r7    r2
gettabup      r8    u0    k4
gettable      r8    r8    k5
gettable      r9    r1    r6
gettabup     r10    u1    k3
gettabup     r11    u2    k3
add          r10   r10   r11
add          r10   r10    r6
mul          r10   r10    k9
gettabup     r11    u1    k3
add          r11   r11    r6
mul          r10   r10   r11
mod          r10   r10    k6
add           r9    r9   r10
call          r8     2     2
concat        r2    r7    r8
.label	l2761
lt             0   k10    r6
jmp            0 l3682
.label	l2763
loadbool      r7     0     0
test          r7     0
jmp            0 l2781
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2763
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2763
.label	l2781
loadbool      r7     0     0
test          r7     0
jmp            0 l2799
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2781
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2781
.label	l2799
loadbool      r7     0     0
test          r7     0
jmp            0 l2817
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2799
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2799
.label	l2817
loadbool      r7     0     0
test          r7     0
jmp            0 l2835
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2817
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2817
.label	l2835
loadbool      r7     0     0
test          r7     0
jmp            0 l2853
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2835
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2835
.label	l2853
loadbool      r7     0     0
test          r7     0
jmp            0 l2871
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2853
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2853
.label	l2871
loadbool      r7     0     0
test          r7     0
jmp            0 l2889
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2871
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2871
.label	l2889
loadbool      r7     0     0
test          r7     0
jmp            0 l2907
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2889
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2889
.label	l2907
loadbool      r7     0     0
test          r7     0
jmp            0 l2925
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2907
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2907
.label	l2925
loadbool      r7     0     0
test          r7     0
jmp            0 l2943
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2925
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2925
.label	l2943
loadbool      r7     0     0
test          r7     0
jmp            0 l2961
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2943
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2943
.label	l2961
loadbool      r7     0     0
test          r7     0
jmp            0 l2979
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2961
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2961
.label	l2979
loadbool      r7     0     0
test          r7     0
jmp            0 l2997
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2979
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2979
.label	l2997
loadbool      r7     0     0
test          r7     0
jmp            0 l3015
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l2997
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l2997
.label	l3015
loadbool      r7     0     0
test          r7     0
jmp            0 l3033
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3015
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3015
.label	l3033
loadbool      r7     0     0
test          r7     0
jmp            0 l3051
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3033
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3033
.label	l3051
loadbool      r7     0     0
test          r7     0
jmp            0 l3069
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3051
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3051
.label	l3069
loadbool      r7     0     0
test          r7     0
jmp            0 l3087
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3069
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3069
.label	l3087
loadbool      r7     0     0
test          r7     0
jmp            0 l3105
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3087
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3087
.label	l3105
loadbool      r7     0     0
test          r7     0
jmp            0 l3123
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3105
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3105
.label	l3123
loadbool      r7     0     0
test          r7     0
jmp            0 l3141
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3123
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3123
.label	l3141
loadbool      r7     0     0
test          r7     0
jmp            0 l3159
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3141
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3141
.label	l3159
loadbool      r7     0     0
test          r7     0
jmp            0 l3177
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3159
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3159
.label	l3177
loadbool      r7     0     0
test          r7     0
jmp            0 l3195
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3177
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3177
.label	l3195
loadbool      r7     0     0
test          r7     0
jmp            0 l3213
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3195
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3195
.label	l3213
loadbool      r7     0     0
test          r7     0
jmp            0 l3231
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3213
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3213
.label	l3231
loadbool      r7     0     0
test          r7     0
jmp            0 l3249
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3231
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3231
.label	l3249
loadbool      r7     0     0
test          r7     0
jmp            0 l3267
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3249
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3249
.label	l3267
loadbool      r7     0     0
test          r7     0
jmp            0 l3285
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3267
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3267
.label	l3285
loadbool      r7     0     0
test          r7     0
jmp            0 l3303
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3285
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3285
.label	l3303
loadbool      r7     0     0
test          r7     0
jmp            0 l3321
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3303
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3303
.label	l3321
loadbool      r7     0     0
test          r7     0
jmp            0 l3339
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3321
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3321
.label	l3339
loadbool      r7     0     0
test          r7     0
jmp            0 l3357
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3339
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3339
.label	l3357
loadbool      r7     0     0
test          r7     0
jmp            0 l3375
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3357
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3357
.label	l3375
loadbool      r7     0     0
test          r7     0
jmp            0 l3393
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3375
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3375
.label	l3393
loadbool      r7     0     0
test          r7     0
jmp            0 l3411
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3393
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3393
.label	l3411
loadbool      r7     0     0
test          r7     0
jmp            0 l3429
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3411
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3411
.label	l3429
loadbool      r7     0     0
test          r7     0
jmp            0 l3447
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3429
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3429
.label	l3447
loadbool      r7     0     0
test          r7     0
jmp            0 l3465
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3447
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3447
.label	l3465
loadbool      r7     0     0
test          r7     0
jmp            0 l3483
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3465
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3465
.label	l3483
loadbool      r7     0     0
test          r7     0
jmp            0 l3501
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3483
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3483
.label	l3501
loadbool      r7     0     0
test          r7     0
jmp            0 l3519
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3501
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3501
.label	l3519
loadbool      r7     0     0
test          r7     0
jmp            0 l3537
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3519
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3519
.label	l3537
loadbool      r7     0     0
test          r7     0
jmp            0 l3555
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3537
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3537
.label	l3555
loadbool      r7     0     0
test          r7     0
jmp            0 l3573
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3555
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3555
.label	l3573
loadbool      r7     0     0
test          r7     0
jmp            0 l3591
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3573
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3573
.label	l3591
loadbool      r7     0     0
test          r7     0
jmp            0 l3609
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3591
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3591
.label	l3609
loadbool      r7     0     0
test          r7     0
jmp            0 l3627
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3609
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3609
.label	l3627
loadbool      r7     0     0
test          r7     0
jmp            0 l3645
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3627
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3627
.label	l3645
loadbool      r7     0     0
test          r7     0
jmp            0 l3663
newtable      r7     0     0
loadnil       r8     4
settable      r7    r8    r9
gettable      r9    r7    r8
test          r9     0
jmp            0 l3645
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
gettable      r9    r7    r8
move         r10    r7
call          r9     2     2
settable      r7    r8    r9
jmp            0 l3645
.label	l3663
move          r7    r2
gettabup      r8    u0    k4
gettable      r8    r8    k5
gettable      r9    r1    r6
gettabup     r10    u1    k3
gettabup     r11    u2    k3
add          r10   r10   r11
add          r10   r10    r6
mul          r10   r10    k9
gettabup     r11    u1    k3
add          r11   r11    r6
mul          r10   r10   r11
mul          r10   r10   k11
mod          r10   r10    k6
gettabup     r11    u3    k3
mul          r10   r10   r11
add           r9    r9   r10
call          r8     2     2
concat        r2    r7    r8
.label	l3682
tforcall      r3     1
tforloop      r5    l7
return        r2     2
return        r0     1


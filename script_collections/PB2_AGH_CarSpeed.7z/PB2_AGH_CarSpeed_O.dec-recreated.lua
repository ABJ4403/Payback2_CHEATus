--[[

	This is a replica of decrypted Speed cars that AlphaGG Made
	Recreated by ABJ4403
	Original By AlphaGG

]]--
local t,CH = {}
function ConcatTables(t1,t2)
	--[[
		Creates new table then
		add table 1 and table 2
	]]
	for i=1,#t2 do
		t1[#t1+i] = t2[i]
	end
	return t1
end

function Home()
	CH = gg.multiChoice({
		"1.) Mundaneo",
		"2.) Pug",
		"3.) Portia",
		"4.) Bus",
		"5.) Vapour",
		"6.) Pug GTI",
		"7.) Fjord",
		"8.) Van",
		"9.) Limo",
		"10.) Cop Car",
		"11.) Scooby",
		"12.) Tank",
		"13.) Evo",
		"14.) Taxi",
		"15.) Ice Cream Van",
		"16.) Pickup",
		"17.) Hotrod",
		"18.) Helicopter",
		"19.) Pug Racer",
		"20.) Truck",
		"21.) SWAT Van",
		"22.) RC Truck",
		"23.) Rocket Car",
		"24.) Vapour GT",
		"25.) X550R",
		"26.) Rambler",
		"Speed Up All Cars",
		"Speed Hack ( OFF )",
		"Exit"
	},nil,"Alpha GG Hacker YT\n\nCar Hack")
	if CH then
		if CH[29] then  end
		gg.setRanges(gg.REGION_OTHER)
		t = {}
		if CH[27] then t = ConcatTables(t,{70,45,70,500,90,42.5,85,130,175,80,61.75,2000,70,90,175,90,95,75,35,350,300,125,30,85,70,130}) end
		elseif CH[28] then -- this should do the opposite of enabling
		else
			if CH[1] then t = ConcatTables(t,{70}) end
			if CH[2] then t = ConcatTables(t,{45}) end
			if CH[3] then t = ConcatTables(t,{70}) end
			if CH[4] then t = ConcatTables(t,{500}) end
			if CH[5] then t = ConcatTables(t,{90}) end
			if CH[6] then t = ConcatTables(t,{42.5}) end
			if CH[7] then t = ConcatTables(t,{85}) end
			if CH[8] then t = ConcatTables(t,{130}) end
			if CH[9] then t = ConcatTables(t,{175}) end
			if CH[10] then t = ConcatTables(t,{80}) end
			if CH[11] then t = ConcatTables(t,{61.75}) end
			if CH[12] then t = ConcatTables(t,{2000}) end
			if CH[13] then t = ConcatTables(t,{70}) end
			if CH[14] then t = ConcatTables(t,{90}) end
			if CH[15] then t = ConcatTables(t,{175}) end
			if CH[16] then t = ConcatTables(t,{90}) end
			if CH[17] then t = ConcatTables(t,{95}) end
			if CH[18] then t = ConcatTables(t,{75}) end
			if CH[19] then t = ConcatTables(t,{35}) end
			if CH[20] then t = ConcatTables(t,{350}) end
			if CH[21] then t = ConcatTables(t,{300}) end
			if CH[22] then t = ConcatTables(t,{125}) end
			if CH[23] then t = ConcatTables(t,{30}) end
			if CH[24] then t = ConcatTables(t,{85}) end
			if CH[25] then t = ConcatTables(t,{70}) end
			if CH[26] then t = ConcatTables(t,{130}) end
		end
		for i=1,#t do
			gg.searchNumber(t[i],gg.TYPE_FLOAT)
			revert = gg.getResult(5000)
			gg.editAll(-300,gg.TYPE_FLOAT)
			gg.clearResults()
		end
		gg.toast('Made By Alpha GG\n[Triangle] SUCCESS [Triangle]')
	else
		gg.toast('Cancelled')
	end
end

function Exit()
	print("This script is recreated in decrypted form by ABJ4403\nOriginally made (encrypted) by AlphaGG")
	gg.clearResults()
	os.exit()
end

while true do
	if gg.isVisible() then
		gg.setVisible(false)
		Home()
	end
end
